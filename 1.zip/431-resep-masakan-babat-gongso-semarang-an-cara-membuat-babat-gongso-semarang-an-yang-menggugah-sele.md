---
description: "Resep masakan Babat gongso Semarang-an | Cara Membuat Babat gongso Semarang-an Yang Menggugah Selera"
title: "Resep masakan Babat gongso Semarang-an | Cara Membuat Babat gongso Semarang-an Yang Menggugah Selera"
slug: 431-resep-masakan-babat-gongso-semarang-an-cara-membuat-babat-gongso-semarang-an-yang-menggugah-selera
date: 2020-07-17T12:00:24.002Z
image: https://img-global.cpcdn.com/recipes/20664d61657e5bd6/751x532cq70/babat-gongso-semarang-an-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/20664d61657e5bd6/751x532cq70/babat-gongso-semarang-an-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/20664d61657e5bd6/751x532cq70/babat-gongso-semarang-an-foto-resep-utama.jpg
author: Vernon Soto
ratingvalue: 3.3
reviewcount: 13
recipeingredient:
- " Babat Sapi lupa gak ditimbang"
- "1 buah tomat potong2"
- " Gula merah garam penyedap"
- " Kecap manis sesuai selera"
- "Secukupnya Air"
- " Minyak untuk menumis"
- " Bumbu halus"
- "7 buah Bawang Merah"
- "4 buah bawang putih"
- "3 buah cabai keriting"
- "7 buah cabai merah setan"
- "3 buah kemiri"
- " Bumbu cemplung"
- "2 buah Daun seregeprek"
- " Daun jeruk"
- " Daun salam"
- " Lengkuas geprek"
- " Jahe geprek"
recipeinstructions:
- "Cuci bersih babat, kemudian rebus dengan metode 5 30 7, setelah empuk potong2 sesuai selera"
- "Panaskan minyak untuk menumis. Tumis bumbu halus dan bumbu cemplung hingga harum. Masukkan babat yang sudah direbus tadi. Setelah itu beri sedikit air (jangan banyak2, klw bahasa jawanya nyemek2 😅)"
- "Masukkan garam, gula jawa, penyedap dan kecap manis,,,rebus sebentar sampai bumbu meresap ke dalam babat."
- "Setelah mendidih, angkat, siap disajikan."
categories:
- Resep
tags:
- babat
- gongso
- semarangan

katakunci: babat gongso semarangan 
nutrition: 137 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Lunch

---


![Babat gongso Semarang-an](https://img-global.cpcdn.com/recipes/20664d61657e5bd6/751x532cq70/babat-gongso-semarang-an-foto-resep-utama.jpg)

Kamu Sedang mencari ide resep babat gongso semarang-an yang Sempurna? Cara menyiapkannya memang tidak susah dan tidak juga mudah. bila keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal babat gongso semarang-an yang enak selayaknya punya aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari babat gongso semarang-an, pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara membuat dan menyajikannya. Tak perlu pusing jika hendak menyiapkan babat gongso semarang-an yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian istimewa.


Nah, kali ini kita coba, yuk, ciptakan babat gongso semarang-an sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa membuat Babat gongso Semarang-an memakai 18 bahan dan 4 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Babat gongso Semarang-an:

1. Sediakan  Babat Sapi (lupa gak ditimbang)
1. Siapkan 1 buah tomat (potong2)
1. Siapkan  Gula merah, garam, penyedap
1. Ambil  Kecap manis (sesuai selera)
1. Gunakan Secukupnya Air
1. Gunakan  Minyak (untuk menumis)
1. Gunakan  Bumbu halus
1. Sediakan 7 buah Bawang Merah
1. Ambil 4 buah bawang putih
1. Sediakan 3 buah cabai keriting
1. Ambil 7 buah cabai merah setan
1. Siapkan 3 buah kemiri
1. Gunakan  Bumbu cemplung
1. Sediakan 2 buah Daun sere(geprek)
1. Sediakan  Daun jeruk
1. Siapkan  Daun salam
1. Sediakan  Lengkuas geprek
1. Siapkan  Jahe geprek




<!--inarticleads2-->

##### Cara menyiapkan Babat gongso Semarang-an:

1. Cuci bersih babat, kemudian rebus dengan metode 5 30 7, setelah empuk potong2 sesuai selera
1. Panaskan minyak untuk menumis. Tumis bumbu halus dan bumbu cemplung hingga harum. Masukkan babat yang sudah direbus tadi. Setelah itu beri sedikit air (jangan banyak2, klw bahasa jawanya nyemek2 😅)
1. Masukkan garam, gula jawa, penyedap dan kecap manis,,,rebus sebentar sampai bumbu meresap ke dalam babat.
1. Setelah mendidih, angkat, siap disajikan.




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan Babat gongso Semarang-an yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman ataupun menjadi ide dalam berjualan makanan. Selamat mencoba!
