---
description: "Resep Gongso Ayam Pedas Full Bumbu | Cara Membuat Gongso Ayam Pedas Full Bumbu Yang Enak Dan Lezat"
title: "Resep Gongso Ayam Pedas Full Bumbu | Cara Membuat Gongso Ayam Pedas Full Bumbu Yang Enak Dan Lezat"
slug: 196-resep-gongso-ayam-pedas-full-bumbu-cara-membuat-gongso-ayam-pedas-full-bumbu-yang-enak-dan-lezat
date: 2020-08-19T12:19:47.915Z
image: https://img-global.cpcdn.com/recipes/9e1990884442d0ca/751x532cq70/gongso-ayam-pedas-full-bumbu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9e1990884442d0ca/751x532cq70/gongso-ayam-pedas-full-bumbu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9e1990884442d0ca/751x532cq70/gongso-ayam-pedas-full-bumbu-foto-resep-utama.jpg
author: Celia Murray
ratingvalue: 4.1
reviewcount: 8
recipeingredient:
- "2 potong bagian ayam misal 1 dada ayam 1 paha ayam"
- "2 lembar Daun jeruk"
- "1 daun salam"
- " Kecap manis"
- " Air"
- " Minyak goreng"
- " Lada bubuk optional"
- " Bumbu balado sachet optional"
- " Bumbu halus"
- "3 bawang merah"
- "1 bawang putih"
- "1 kemiri"
- "3 cabe merah"
- "4 cabe rawit optional"
- " Garam"
- "Sedikit gula pasir"
recipeinstructions:
- "Rebus ayam, tiriskan. Lalu suwir2 ayam."
- "Haluskan bumbu halus, lalu tumis dengan minyak goreng. Tambahkan daun jeruk dan daun salam, aduk sampai wangi. Tambahkan sedikit air."
- "Masukkan kecap dan lada bubuk secukupnya, tingkat rasa sesuai selera. Bisa ditambahkan bumbu balado agar lebih terasa pedas baladonya, tapi kalau tidak it&#39;s ok bumbunya udah berasa kok."
- "Masukkan ayam dan aduk sampai merata. Tunggu beberapa saat sampai bumbu meresap dan air tinggal sedikit seperti bumbu kental, lalu matikan api. Siap dimakan dengan nasi panas."
categories:
- Resep
tags:
- gongso
- ayam
- pedas

katakunci: gongso ayam pedas 
nutrition: 248 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Lunch

---


![Gongso Ayam Pedas Full Bumbu](https://img-global.cpcdn.com/recipes/9e1990884442d0ca/751x532cq70/gongso-ayam-pedas-full-bumbu-foto-resep-utama.jpg)

Kamu Sedang mencari inspirasi resep gongso ayam pedas full bumbu yang Menggugah Selera? Cara membuatnya memang susah-susah gampang. apabila salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gongso ayam pedas full bumbu yang enak seharusnya memiliki aroma dan cita rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ayam pedas full bumbu, pertama dari jenis bahan, kemudian pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan gongso ayam pedas full bumbu enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.




Di bawah ini ada beberapa tips dan trik praktis untuk membuat gongso ayam pedas full bumbu yang siap dikreasikan. Anda bisa membuat Gongso Ayam Pedas Full Bumbu menggunakan 16 jenis bahan dan 4 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Gongso Ayam Pedas Full Bumbu:

1. Gunakan 2 potong bagian ayam (misal 1 dada ayam, 1 paha ayam)
1. Gunakan 2 lembar Daun jeruk
1. Sediakan 1 daun salam
1. Gunakan  Kecap manis
1. Sediakan  Air
1. Siapkan  Minyak goreng
1. Ambil  Lada bubuk (optional)
1. Sediakan  Bumbu balado sachet (optional)
1. Siapkan  Bumbu halus
1. Gunakan 3 bawang merah
1. Sediakan 1 bawang putih
1. Gunakan 1 kemiri
1. Gunakan 3 cabe merah
1. Sediakan 4 cabe rawit (optional)
1. Ambil  Garam
1. Ambil Sedikit gula pasir




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso Ayam Pedas Full Bumbu:

1. Rebus ayam, tiriskan. Lalu suwir2 ayam.
1. Haluskan bumbu halus, lalu tumis dengan minyak goreng. Tambahkan daun jeruk dan daun salam, aduk sampai wangi. Tambahkan sedikit air.
1. Masukkan kecap dan lada bubuk secukupnya, tingkat rasa sesuai selera. Bisa ditambahkan bumbu balado agar lebih terasa pedas baladonya, tapi kalau tidak it&#39;s ok bumbunya udah berasa kok.
1. Masukkan ayam dan aduk sampai merata. Tunggu beberapa saat sampai bumbu meresap dan air tinggal sedikit seperti bumbu kental, lalu matikan api. Siap dimakan dengan nasi panas.




Bagaimana? Mudah bukan? Itulah cara membuat gongso ayam pedas full bumbu yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
