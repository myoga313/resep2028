---
description: "Bahan Gongso Ati Ampela | Cara Membuat Gongso Ati Ampela Yang Menggugah Selera"
title: "Bahan Gongso Ati Ampela | Cara Membuat Gongso Ati Ampela Yang Menggugah Selera"
slug: 57-bahan-gongso-ati-ampela-cara-membuat-gongso-ati-ampela-yang-menggugah-selera
date: 2020-09-25T11:20:18.635Z
image: https://img-global.cpcdn.com/recipes/ec87ae71490c5082/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ec87ae71490c5082/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ec87ae71490c5082/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
author: Herbert Lewis
ratingvalue: 4.9
reviewcount: 3
recipeingredient:
- "3 buah ati ayam"
- "5 buah ampela"
- "1 batang sereh geprek"
- "3 lembar daun jeruk"
- "2 sdm kecap manis"
- "2 sdm saus tiram"
- "1 sdt kaldu bubuk ayam"
- "Secukupnya garam lada bubuk dan gula pasir"
- "3/4 gelas air matang"
- " Bumbu iris"
- "5 butir bwg merah"
- "3 siung bwg putih"
- "10 cabe rawit sesuai selera"
- " Cabe hijau sy skip"
recipeinstructions:
- "Rebus ati ampela hingga matang, tiriskan lalu potong2."
- "Tumis bumbu iris, sereh getek dan daun jeruk hingga wangi, masukkan ati ampela. Aduk rata."
- "Beri air, kecap manis, saos tiram, garam, gula, lada, dan kaldu bubuk. Masak hingga kuah sisa sedikit."
- "Angkat dan sajikan 💚"
categories:
- Resep
tags:
- gongso
- ati
- ampela

katakunci: gongso ati ampela 
nutrition: 121 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Dessert

---


![Gongso Ati Ampela](https://img-global.cpcdn.com/recipes/ec87ae71490c5082/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep gongso ati ampela yang Menggugah Selera? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. semisal salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso ati ampela yang enak seharusnya memiliki aroma dan rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ati ampela, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tak perlu pusing kalau hendak menyiapkan gongso ati ampela yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan istimewa.




Nah, kali ini kita coba, yuk, siapkan gongso ati ampela sendiri di rumah. Tetap dengan bahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Gongso Ati Ampela memakai 14 bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Gongso Ati Ampela:

1. Ambil 3 buah ati ayam
1. Ambil 5 buah ampela
1. Gunakan 1 batang sereh, geprek
1. Gunakan 3 lembar daun jeruk
1. Siapkan 2 sdm kecap manis
1. Ambil 2 sdm saus tiram
1. Siapkan 1 sdt kaldu bubuk ayam
1. Siapkan Secukupnya garam, lada bubuk dan gula pasir
1. Gunakan 3/4 gelas air matang
1. Gunakan  Bumbu iris:
1. Ambil 5 butir bwg merah
1. Siapkan 3 siung bwg putih
1. Gunakan 10 cabe rawit /sesuai selera
1. Siapkan  Cabe hijau (sy skip)




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso Ati Ampela:

1. Rebus ati ampela hingga matang, tiriskan lalu potong2.
1. Tumis bumbu iris, sereh getek dan daun jeruk hingga wangi, masukkan ati ampela. Aduk rata.
1. Beri air, kecap manis, saos tiram, garam, gula, lada, dan kaldu bubuk. Masak hingga kuah sisa sedikit.
1. Angkat dan sajikan 💚




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Harapan kami, olahan Gongso Ati Ampela yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman maupun menjadi inspirasi untuk berjualan makanan. Selamat mencoba!
