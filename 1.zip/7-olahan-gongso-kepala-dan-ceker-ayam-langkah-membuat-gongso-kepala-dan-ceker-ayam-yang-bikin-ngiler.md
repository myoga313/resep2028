---
description: "Olahan Gongso Kepala dan ceker ayam | Langkah Membuat Gongso Kepala dan ceker ayam Yang Bikin Ngiler"
title: "Olahan Gongso Kepala dan ceker ayam | Langkah Membuat Gongso Kepala dan ceker ayam Yang Bikin Ngiler"
slug: 7-olahan-gongso-kepala-dan-ceker-ayam-langkah-membuat-gongso-kepala-dan-ceker-ayam-yang-bikin-ngiler
date: 2020-07-30T03:59:42.448Z
image: https://img-global.cpcdn.com/recipes/6893ed98b2fe536d/751x532cq70/gongso-kepala-dan-ceker-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6893ed98b2fe536d/751x532cq70/gongso-kepala-dan-ceker-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6893ed98b2fe536d/751x532cq70/gongso-kepala-dan-ceker-ayam-foto-resep-utama.jpg
author: Leroy Curtis
ratingvalue: 3.1
reviewcount: 15
recipeingredient:
- "3 buah kepala ayam ungkep"
- "6 buah ceker ayam ungkep"
- "1 batang sereh memarkan"
- "3 cm lengkuas memarkan"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 butir tomat ukuran kecil"
- "3 sendok makan kecap manis"
- "1 sendok makan saos tiram"
- "secukupnya Gula garam kaldu ayam"
- "250 ml air"
- " Minyak untuk menumis"
- " Bumbu halus"
- "11 buah bawang merah"
- "3 siung bawang putih"
- "7 buah cabai rawit buat yang suka pedes boleh ditambah ya"
- "5 butir merica"
- "1 ruas jahe"
recipeinstructions:
- "Haluskan bumbu halus."
- "Siapkan kepala dan ceker yg sudah diungkep. Kalo yg belum diungkep bisa diungkep dulu pake bumbu racik ayam goreng. Hehehe"
- "Tumis bumbu halus, sereh, lengkuas. Setelah harus masukkan daun salam. Masak hingga bumbu matang."
- "Setelah matang, masukkan kepala dan ceker ayam. Lalu tambahkan air. Masukkan tomat yg sudah dipotong-potong, kecap manis, saus tiram, gula, garam, dan kaldu ayam. Masak hingga air menyusut."
- "Setelah menyusut koreksi rasa. Gongso siap untuk disajikan. Simple banget kaann..."
categories:
- Resep
tags:
- gongso
- kepala
- dan

katakunci: gongso kepala dan 
nutrition: 295 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dinner

---


![Gongso Kepala dan ceker ayam](https://img-global.cpcdn.com/recipes/6893ed98b2fe536d/751x532cq70/gongso-kepala-dan-ceker-ayam-foto-resep-utama.jpg)

Anda sedang mencari ide resep gongso kepala dan ceker ayam yang Bikin Ngiler? Cara membuatnya memang tidak susah dan tidak juga mudah. sekiranya keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal gongso kepala dan ceker ayam yang enak selayaknya memiliki aroma dan rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso kepala dan ceker ayam, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tidak usah pusing jika mau menyiapkan gongso kepala dan ceker ayam yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian istimewa.

Ungkep kepala, ceker, ati ampela sampai empuk. Nggak hanya babat yang enak dimasak bumbu gongso tapi juga bisa daging ayam yang tidak kalah enaknya, sehingga juga cocok untuk yang nggak suka jeroan. - Gongso dan tambahkan daun salam, daun jeruk, sereh geprek, dan lengkuas geprek tumis hingga harum - Setelah harum tambahkan air secukupnya dan masukkan bumbu- bumbu penyedap seperti garam, gula, kaldu bubuk, lada bubuk secukupnya. Rasakan bila sudah enak masukkan ceker yang.


Nah, kali ini kita coba, yuk, kreasikan gongso kepala dan ceker ayam sendiri di rumah. Tetap berbahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Gongso Kepala dan ceker ayam memakai 18 jenis bahan dan 5 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Gongso Kepala dan ceker ayam:

1. Ambil 3 buah kepala ayam ungkep
1. Ambil 6 buah ceker ayam ungkep
1. Ambil 1 batang sereh (memarkan)
1. Sediakan 3 cm lengkuas (memarkan)
1. Ambil 2 lembar daun salam
1. Ambil 3 lembar daun jeruk
1. Sediakan 1 butir tomat ukuran kecil
1. Gunakan 3 sendok makan kecap manis
1. Gunakan 1 sendok makan saos tiram
1. Siapkan secukupnya Gula, garam, kaldu ayam
1. Gunakan 250 ml air
1. Sediakan  Minyak untuk menumis
1. Gunakan  Bumbu halus
1. Siapkan 11 buah bawang merah
1. Siapkan 3 siung bawang putih
1. Siapkan 7 buah cabai rawit (buat yang suka pedes boleh ditambah ya)
1. Ambil 5 butir merica
1. Gunakan 1 ruas jahe




<!--inarticleads2-->

##### Cara membuat Gongso Kepala dan ceker ayam:

1. Haluskan bumbu halus.
1. Siapkan kepala dan ceker yg sudah diungkep. Kalo yg belum diungkep bisa diungkep dulu pake bumbu racik ayam goreng. Hehehe
1. Tumis bumbu halus, sereh, lengkuas. Setelah harus masukkan daun salam. Masak hingga bumbu matang.
1. Setelah matang, masukkan kepala dan ceker ayam. Lalu tambahkan air. Masukkan tomat yg sudah dipotong-potong, kecap manis, saus tiram, gula, garam, dan kaldu ayam. Masak hingga air menyusut.
1. Setelah menyusut koreksi rasa. Gongso siap untuk disajikan. Simple banget kaann...




Terima kasih telah membaca resep yang kami tampilkan di sini. Harapan kami, olahan Gongso Kepala dan ceker ayam yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman maupun menjadi inspirasi bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
