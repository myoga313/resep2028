---
description: "Bahan Babat Gongso | Cara Bikin Babat Gongso Yang Sempurna"
title: "Bahan Babat Gongso | Cara Bikin Babat Gongso Yang Sempurna"
slug: 486-bahan-babat-gongso-cara-bikin-babat-gongso-yang-sempurna
date: 2020-12-02T14:56:20.046Z
image: https://img-global.cpcdn.com/recipes/c7b62cc6c3d66c57/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c7b62cc6c3d66c57/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c7b62cc6c3d66c57/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: David Johnson
ratingvalue: 3.1
reviewcount: 15
recipeingredient:
- " Babat Sapi cuci bersih"
- " Daun Jeruk"
- " Daun Salam"
- " Lengkuas memarkan"
- " Serai memarkan"
- " Kecap Manis"
- " Gula Merah"
- " Kaldu Sapi Bubuk"
- " Garam"
- " Tomat potong"
- " Cabai Rawit Merah"
- " Air"
- " Minyak Untuk Menumis"
- " Bumbu Yang Dihaluskan"
- " Bawang Merah"
- " Bawang Putih"
- " Cabai Merah"
- " Kemiri"
- " Makan Merica Halus"
- " Ketumbar Halus"
recipeinstructions:
- "Rebus babat sapi selama ± 3 menit lalu buang air rebusan pertama. Lalu rebus kembali air masukkan babat rebus sampai babat empuk lalu potong-potong sesuai selera. Tumis bumbu yang dihaluskan masukkan juga daun salam, daun jeruk, serai dan lengkuas. Tumis hingga harum lalu masukkan babat aduk sampai rata. Tambahkan juga 250 ml air."
- "Tambahkan garam, kaldu bubuk, gula merah, kecap manis dan cabai rawit merah. Masak sampai air agak menyusut lalu masukkan potongan tomat. Cek rasa, masak sampai air mengental dan menyusut matikan kompor."
- "Hidangkan Babat Gongso selagi hangat. Untuk kuah bisa sampai kuah kering atau agak basah (Sesuai selera). Selamat mencoba."
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 240 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Lunch

---


![Babat Gongso](https://img-global.cpcdn.com/recipes/c7b62cc6c3d66c57/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep babat gongso yang Enak Dan Lezat? Cara Memasaknya memang tidak terlalu sulit namun tidak gampang juga. sekiranya salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal babat gongso yang enak selayaknya memiliki aroma dan rasa yang dapat memancing selera kita.

Com - Babat Gongso kali ini special karena ada isonya. Babat Gongso yang menjadi tujuan kuliner setiap orang yang ke Semarang, merupakan setidaknya primadona dari sekian banyak makanan yang ada di Semarang. Yuk, belajar membuat Babat Gongso di rumah Anda!

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso, pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan babat gongso enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian istimewa.


Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah babat gongso yang siap dikreasikan. Anda dapat membuat Babat Gongso menggunakan 20 bahan dan 3 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Babat Gongso:

1. Sediakan  Babat Sapi, cuci bersih
1. Ambil  Daun Jeruk
1. Sediakan  Daun Salam
1. Ambil  Lengkuas, memarkan
1. Ambil  Serai, memarkan
1. Ambil  Kecap Manis
1. Sediakan  Gula Merah
1. Ambil  Kaldu Sapi Bubuk
1. Siapkan  Garam
1. Gunakan  Tomat, potong
1. Gunakan  Cabai Rawit Merah
1. Gunakan  Air
1. Siapkan  Minyak Untuk Menumis
1. Sediakan  Bumbu Yang Dihaluskan*
1. Ambil  Bawang Merah
1. Siapkan  Bawang Putih
1. Siapkan  Cabai Merah
1. Ambil  Kemiri
1. Ambil  Makan Merica Halus
1. Gunakan  Ketumbar Halus




<!--inarticleads2-->

##### Cara membuat Babat Gongso:

1. Rebus babat sapi selama ± 3 menit lalu buang air rebusan pertama. Lalu rebus kembali air masukkan babat rebus sampai babat empuk lalu potong-potong sesuai selera. Tumis bumbu yang dihaluskan masukkan juga daun salam, daun jeruk, serai dan lengkuas. Tumis hingga harum lalu masukkan babat aduk sampai rata. Tambahkan juga 250 ml air.
1. Tambahkan garam, kaldu bubuk, gula merah, kecap manis dan cabai rawit merah. Masak sampai air agak menyusut lalu masukkan potongan tomat. Cek rasa, masak sampai air mengental dan menyusut matikan kompor.
1. Hidangkan Babat Gongso selagi hangat. Untuk kuah bisa sampai kuah kering atau agak basah (Sesuai selera). Selamat mencoba.




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Harapan kami, olahan Babat Gongso yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman maupun menjadi inspirasi bagi Anda yang berkeinginan untuk berjualan makanan. Selamat mencoba!
