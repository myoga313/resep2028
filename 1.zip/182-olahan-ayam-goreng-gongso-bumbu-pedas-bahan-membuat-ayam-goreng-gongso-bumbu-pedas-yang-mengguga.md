---
description: "Olahan Ayam Goreng Gongso Bumbu Pedas | Bahan Membuat Ayam Goreng Gongso Bumbu Pedas Yang Menggugah Selera"
title: "Olahan Ayam Goreng Gongso Bumbu Pedas | Bahan Membuat Ayam Goreng Gongso Bumbu Pedas Yang Menggugah Selera"
slug: 182-olahan-ayam-goreng-gongso-bumbu-pedas-bahan-membuat-ayam-goreng-gongso-bumbu-pedas-yang-menggugah-selera
date: 2020-12-26T13:46:21.665Z
image: https://img-global.cpcdn.com/recipes/b4d56decb7d4c613/751x532cq70/ayam-goreng-gongso-bumbu-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b4d56decb7d4c613/751x532cq70/ayam-goreng-gongso-bumbu-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b4d56decb7d4c613/751x532cq70/ayam-goreng-gongso-bumbu-pedas-foto-resep-utama.jpg
author: Erik Simpson
ratingvalue: 3.5
reviewcount: 3
recipeingredient:
- "1 ekor ayam potong2"
- "2 lbr daun salam"
- "2 cm lengkuas memarkan"
- "1 sdt garam"
- "2 cm jahe memarkan"
- "200 ml air"
- "3 sdm kecap manis"
- "Secukupnya minyak goreng"
- " Bumbu Halus"
- "5 siung bawang putih"
- "10 bh bawang merah"
- "5 bh cabai merah"
- "3 bh cabai rawit"
- "3 bh kemiri"
- "1 sdt gula merah"
recipeinstructions:
- "Rebus ayam dalam 300ml air, didihkan. Tambahkan semua bahan kecuali bumbu halus, masak sampai ayam matang dan empuk, angkat"
- "Goreng ayam sampai setengah matang"
- "Panaskan minyak 2 sdm, tumis bumbu halus sampai harum, masukkan ayam. Aduk hingga ayam terbalut bumbu."
- "Tambahkan air, masak sampai kuah mengental, angkat, lalu hidangkan dengan taburan bawang goreng"
categories:
- Resep
tags:
- ayam
- goreng
- gongso

katakunci: ayam goreng gongso 
nutrition: 287 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Goreng Gongso Bumbu Pedas](https://img-global.cpcdn.com/recipes/b4d56decb7d4c613/751x532cq70/ayam-goreng-gongso-bumbu-pedas-foto-resep-utama.jpg)

Kamu Sedang mencari ide resep ayam goreng gongso bumbu pedas yang Enak Dan Lezat? Cara Memasaknya memang tidak susah dan tidak juga mudah. jikalau keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal ayam goreng gongso bumbu pedas yang enak harusnya sih mempunyai aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam goreng gongso bumbu pedas, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tak perlu pusing kalau mau menyiapkan ayam goreng gongso bumbu pedas enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.




Nah, kali ini kita coba, yuk, kreasikan ayam goreng gongso bumbu pedas sendiri di rumah. Tetap dengan bahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Ayam Goreng Gongso Bumbu Pedas memakai 15 bahan dan 4 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam Goreng Gongso Bumbu Pedas:

1. Siapkan 1 ekor ayam, potong2
1. Siapkan 2 lbr daun salam
1. Gunakan 2 cm lengkuas, memarkan
1. Ambil 1 sdt garam
1. Ambil 2 cm jahe, memarkan
1. Sediakan 200 ml air
1. Gunakan 3 sdm kecap manis
1. Sediakan Secukupnya minyak goreng
1. Ambil  Bumbu Halus:
1. Sediakan 5 siung bawang putih
1. Siapkan 10 bh bawang merah
1. Gunakan 5 bh cabai merah
1. Siapkan 3 bh cabai rawit
1. Ambil 3 bh kemiri
1. Gunakan 1 sdt gula merah




<!--inarticleads2-->

##### Cara menyiapkan Ayam Goreng Gongso Bumbu Pedas:

1. Rebus ayam dalam 300ml air, didihkan. Tambahkan semua bahan kecuali bumbu halus, masak sampai ayam matang dan empuk, angkat
1. Goreng ayam sampai setengah matang
1. Panaskan minyak 2 sdm, tumis bumbu halus sampai harum, masukkan ayam. Aduk hingga ayam terbalut bumbu.
1. Tambahkan air, masak sampai kuah mengental, angkat, lalu hidangkan dengan taburan bawang goreng




Bagaimana? Gampang kan? Itulah cara menyiapkan ayam goreng gongso bumbu pedas yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
