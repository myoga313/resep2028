---
description: "Bahan Babat Gongso ala Semarang | Cara Masak Babat Gongso ala Semarang Yang Paling Enak"
title: "Bahan Babat Gongso ala Semarang | Cara Masak Babat Gongso ala Semarang Yang Paling Enak"
slug: 276-bahan-babat-gongso-ala-semarang-cara-masak-babat-gongso-ala-semarang-yang-paling-enak
date: 2020-11-20T02:59:55.136Z
image: https://img-global.cpcdn.com/recipes/90e4e03b66adbe56/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/90e4e03b66adbe56/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/90e4e03b66adbe56/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg
author: Christian Graves
ratingvalue: 3.1
reviewcount: 13
recipeingredient:
- " babat sapi"
- " bawang merah"
- " bawang putih"
- " cabai merah keritingsesuai selera"
- " cabai rawit merahsesuai selera"
- " kemiri"
- " kecap manissesuai selera"
- " kecap asin1 sdt garam"
- " kaldu jamurkaldu lainsesuai selera"
- " air putih"
- " minyak goreng untuk menumis"
recipeinstructions:
- "Siapkan semua bahan.. Cuci bersih babat, rebus hingga empuk, bisa dipresto atau pakai metode 5.30.7, potong/iris sesuai selera. Iris 5 btr bawang merah, sisanya haluskan bersama bawang putih+kemiri+cabai"
- "Panaskan minyak, goreng bawang merah hingga layu, masukkan bumbu halus, tumis hingga matang/agak kering, masukkan babat, aduk merata"
- "Tambahkan air+kecap manis+kecap asin/garam+kaldu jamur, aduk merata. Tunggu hingga air berkurang, cek rasa. Done.. Yuuk cobain"
categories:
- Resep
tags:
- babat
- gongso
- ala

katakunci: babat gongso ala 
nutrition: 172 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dinner

---


![Babat Gongso ala Semarang](https://img-global.cpcdn.com/recipes/90e4e03b66adbe56/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg)

Lagi mencari inspirasi resep babat gongso ala semarang yang Sempurna? Cara Buatnya memang tidak susah dan tidak juga mudah. kalau keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal babat gongso ala semarang yang enak selayaknya mempunyai aroma dan rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso ala semarang, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tak perlu pusing kalau hendak menyiapkan babat gongso ala semarang yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.


Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah babat gongso ala semarang yang siap dikreasikan. Anda dapat menyiapkan Babat Gongso ala Semarang menggunakan 11 jenis bahan dan 3 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Babat Gongso ala Semarang:

1. Gunakan  babat sapi
1. Gunakan  bawang merah
1. Gunakan  bawang putih
1. Sediakan  cabai merah keriting/sesuai selera
1. Siapkan  cabai rawit merah/sesuai selera
1. Gunakan  kemiri
1. Gunakan  kecap manis/sesuai selera
1. Siapkan  kecap asin/1 sdt garam
1. Ambil  kaldu jamur/kaldu lain/sesuai selera
1. Sediakan  air putih
1. Siapkan  minyak goreng untuk menumis




<!--inarticleads2-->

##### Cara membuat Babat Gongso ala Semarang:

1. Siapkan semua bahan.. Cuci bersih babat, rebus hingga empuk, bisa dipresto atau pakai metode 5.30.7, potong/iris sesuai selera. Iris 5 btr bawang merah, sisanya haluskan bersama bawang putih+kemiri+cabai
1. Panaskan minyak, goreng bawang merah hingga layu, masukkan bumbu halus, tumis hingga matang/agak kering, masukkan babat, aduk merata
1. Tambahkan air+kecap manis+kecap asin/garam+kaldu jamur, aduk merata. Tunggu hingga air berkurang, cek rasa. Done.. Yuuk cobain




Gimana nih? Gampang kan? Itulah cara membuat babat gongso ala semarang yang bisa Anda praktikkan di rumah. Selamat mencoba!
