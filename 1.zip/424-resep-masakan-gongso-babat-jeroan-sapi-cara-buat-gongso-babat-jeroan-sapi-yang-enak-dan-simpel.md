---
description: "Resep masakan Gongso Babat (jeroan sapi) | Cara Buat Gongso Babat (jeroan sapi) Yang Enak dan Simpel"
title: "Resep masakan Gongso Babat (jeroan sapi) | Cara Buat Gongso Babat (jeroan sapi) Yang Enak dan Simpel"
slug: 424-resep-masakan-gongso-babat-jeroan-sapi-cara-buat-gongso-babat-jeroan-sapi-yang-enak-dan-simpel
date: 2020-11-10T13:04:18.601Z
image: https://img-global.cpcdn.com/recipes/08b3b4bf2bc84c6a/751x532cq70/gongso-babat-jeroan-sapi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/08b3b4bf2bc84c6a/751x532cq70/gongso-babat-jeroan-sapi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/08b3b4bf2bc84c6a/751x532cq70/gongso-babat-jeroan-sapi-foto-resep-utama.jpg
author: Lela Zimmerman
ratingvalue: 3.8
reviewcount: 6
recipeingredient:
- "500 gram babat dan jeroan sapi"
- "5 helai kobis buang tulang daunnya"
- "1 buah tomat sedang"
- "1 tangkai daun bawang"
- " Bumbu halus"
- "2 buah kemiri"
- "1/2 sdt merica butiran"
- "4 siung bawang putih"
- "8 siung bawang merah"
- "1 ruas jahe"
- "10 buah cabe merah"
- " Bumbu geprek"
- "1 batang sereh"
- "2 ruas lengkuas"
- " Bumbu utuhan"
- "1 lembar daun salam"
- "2 lembar daun jeruk"
- "secukupnya Gula garam"
recipeinstructions:
- "Masukan jeroan saat air mendidih lalu Rebus hingga empuk, sertakan garam dan jahe sedikit. Cuci bersih bumbu ulek dan pelengkap lainnya."
- "Ulek dan geprek bumbu, iris kol, tomat dan daun bawang."
- "Setelah jeroan empuk iris sesuai selera lalu tumis sebentar kemudian sisihkan."
- "Tumis semua bumbu hingga wangi dan layu, masukan kol aduk rata..menyusul jeroan tadi. Tambahkan gula dan garam."
- "Tutup sebentar hingga bumbu meresap.. sesaat sebelum diangkat, masukan tomat dan daun bawang."
categories:
- Resep
tags:
- gongso
- babat
- jeroan

katakunci: gongso babat jeroan 
nutrition: 225 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dinner

---


![Gongso Babat (jeroan sapi)](https://img-global.cpcdn.com/recipes/08b3b4bf2bc84c6a/751x532cq70/gongso-babat-jeroan-sapi-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep gongso babat (jeroan sapi) yang Enak Dan Mudah? Cara Buatnya memang tidak susah dan tidak juga mudah. seandainya salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso babat (jeroan sapi) yang enak harusnya sih memiliki aroma dan rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso babat (jeroan sapi), pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara membuat dan menyajikannya. Tak perlu pusing kalau hendak menyiapkan gongso babat (jeroan sapi) enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian istimewa.


Nah, kali ini kita coba, yuk, buat gongso babat (jeroan sapi) sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa membuat Gongso Babat (jeroan sapi) memakai 18 bahan dan 5 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Gongso Babat (jeroan sapi):

1. Sediakan 500 gram babat dan jeroan sapi
1. Ambil 5 helai kobis buang tulang daunnya
1. Siapkan 1 buah tomat sedang
1. Gunakan 1 tangkai daun bawang
1. Ambil  Bumbu halus
1. Sediakan 2 buah kemiri
1. Gunakan 1/2 sdt merica butiran
1. Siapkan 4 siung bawang putih
1. Gunakan 8 siung bawang merah
1. Siapkan 1 ruas jahe
1. Gunakan 10 buah cabe merah
1. Gunakan  Bumbu geprek
1. Gunakan 1 batang sereh
1. Gunakan 2 ruas lengkuas
1. Sediakan  Bumbu utuhan
1. Gunakan 1 lembar daun salam
1. Ambil 2 lembar daun jeruk
1. Gunakan secukupnya Gula garam




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso Babat (jeroan sapi):

1. Masukan jeroan saat air mendidih lalu Rebus hingga empuk, sertakan garam dan jahe sedikit. Cuci bersih bumbu ulek dan pelengkap lainnya.
1. Ulek dan geprek bumbu, iris kol, tomat dan daun bawang.
1. Setelah jeroan empuk iris sesuai selera lalu tumis sebentar kemudian sisihkan.
1. Tumis semua bumbu hingga wangi dan layu, masukan kol aduk rata..menyusul jeroan tadi. Tambahkan gula dan garam.
1. Tutup sebentar hingga bumbu meresap.. sesaat sebelum diangkat, masukan tomat dan daun bawang.




Terima kasih telah membaca resep yang kami tampilkan di sini. Harapan kami, olahan Gongso Babat (jeroan sapi) yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi ide dalam berbisnis kuliner. Selamat mencoba!
