---
description: "Resep masakan Gongso Bakso Pedas | Langkah Membuat Gongso Bakso Pedas Yang Enak Dan Mudah"
title: "Resep masakan Gongso Bakso Pedas | Langkah Membuat Gongso Bakso Pedas Yang Enak Dan Mudah"
slug: 129-resep-masakan-gongso-bakso-pedas-langkah-membuat-gongso-bakso-pedas-yang-enak-dan-mudah
date: 2020-10-06T09:18:12.514Z
image: https://img-global.cpcdn.com/recipes/2534043_623064d59ca3892e/751x532cq70/gongso-bakso-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2534043_623064d59ca3892e/751x532cq70/gongso-bakso-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2534043_623064d59ca3892e/751x532cq70/gongso-bakso-pedas-foto-resep-utama.jpg
author: Phoebe Allen
ratingvalue: 5
reviewcount: 4
recipeingredient:
- "10 butir Bakso sapi  iris bagi 3"
- "2 butir Sosis sapi  iris serong"
- "1 butir Telur ayam  kocok lepas"
- "5 lbr Daun sawi hijau"
- "1/2 buah Bawang bombay  cincang halus"
- "2 siung Bawang putih  cincang halus"
- "1 Siung Bawang merah  iris tipis"
- "5 buah Cabai domba  iris tipis"
- "1 batang Daun Bawang  iris serong"
- "2 sdt Kaldu ayam"
- "1/2 sdt Merica bubuk"
- "1 sdt Gula pasir"
- "3 sdm kecap manis"
- "1 sdm Saus tiram"
- "2 sdm Saus sambal"
- "250 ml Air"
- "3 sdm Minyak goreng"
recipeinstructions:
- "Panaskan minyak goreng, tumis bawang putih, bawang merah, bawang bombay dan cabai sampai harum. sisihkan samping"
- "Masukkan telur kemudian orak arik, tambahkan bakso dan sosis aduk sampai merata dengan bumbu"
- "Tambahkan air, bumbui dg kaldu bubuk, gula pasir, merica bubuk, kecap manis, saus sambal dan saus tiram. Tunggu sampai air mendidih"
- "Masukkan daun sawi hijau, aduk-aduk dan masak sampai matang. Matikan kompor, dan siap disajikan."
categories:
- Resep
tags:
- gongso
- bakso
- pedas

katakunci: gongso bakso pedas 
nutrition: 287 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dinner

---


![Gongso Bakso Pedas](https://img-global.cpcdn.com/recipes/2534043_623064d59ca3892e/751x532cq70/gongso-bakso-pedas-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep gongso bakso pedas yang Lezat? Cara membuatnya memang tidak susah dan tidak juga mudah. andaikan keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal gongso bakso pedas yang enak seharusnya memiliki aroma dan cita rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso bakso pedas, mulai dari jenis bahan, kemudian pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tidak usah pusing jika hendak menyiapkan gongso bakso pedas yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian spesial.


Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah gongso bakso pedas yang siap dikreasikan. Anda bisa membuat Gongso Bakso Pedas menggunakan 17 bahan dan 4 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Gongso Bakso Pedas:

1. Ambil 10 butir Bakso sapi - iris bagi 3
1. Ambil 2 butir Sosis sapi - iris serong
1. Ambil 1 butir Telur ayam - kocok lepas
1. Ambil 5 lbr Daun sawi hijau
1. Sediakan 1/2 buah Bawang bombay - cincang halus
1. Gunakan 2 siung Bawang putih - cincang halus
1. Gunakan 1 Siung Bawang merah - iris tipis
1. Gunakan 5 buah Cabai domba - iris tipis
1. Gunakan 1 batang Daun Bawang - iris serong
1. Sediakan 2 sdt Kaldu ayam
1. Ambil 1/2 sdt Merica bubuk
1. Ambil 1 sdt Gula pasir
1. Ambil 3 sdm kecap manis
1. Sediakan 1 sdm Saus tiram
1. Ambil 2 sdm Saus sambal
1. Sediakan 250 ml Air
1. Siapkan 3 sdm Minyak goreng




<!--inarticleads2-->

##### Cara menyiapkan Gongso Bakso Pedas:

1. Panaskan minyak goreng, tumis bawang putih, bawang merah, bawang bombay dan cabai sampai harum. sisihkan samping
1. Masukkan telur kemudian orak arik, tambahkan bakso dan sosis aduk sampai merata dengan bumbu
1. Tambahkan air, bumbui dg kaldu bubuk, gula pasir, merica bubuk, kecap manis, saus sambal dan saus tiram. Tunggu sampai air mendidih
1. Masukkan daun sawi hijau, aduk-aduk dan masak sampai matang. Matikan kompor, dan siap disajikan.




Bagaimana? Gampang kan? Itulah cara menyiapkan gongso bakso pedas yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
