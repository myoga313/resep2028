---
description: "Bahan Ayam gongso | Cara Buat Ayam gongso Yang Lezat Sekali"
title: "Bahan Ayam gongso | Cara Buat Ayam gongso Yang Lezat Sekali"
slug: 256-bahan-ayam-gongso-cara-buat-ayam-gongso-yang-lezat-sekali
date: 2020-10-31T13:37:57.995Z
image: https://img-global.cpcdn.com/recipes/1139a23dc3570006/751x532cq70/ayam-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1139a23dc3570006/751x532cq70/ayam-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1139a23dc3570006/751x532cq70/ayam-gongso-foto-resep-utama.jpg
author: Walter Buchanan
ratingvalue: 3.8
reviewcount: 14
recipeingredient:
- "1/4 kg ayam boleh bagian apa aja siangi lalu potong kecil2"
- " Bumbu halus"
- "4 buah cabe setan opsional bagi yg suka pedes"
- "4 buah cabe merah  rawit"
- "3 siung bawang merah"
- "2 siung bawang putih"
- "2 gelondong kemiri"
- "Secukupnya merica"
- " Kunyit"
- " Jahe"
- "Secukupnya garam gula  penyedap"
- "3 sdm Kecap sekitar"
- " Saus tiram"
- "2 buah tomat iris agak tebal"
- "1 lonjor daun bawang iris agak tebal"
- "2 buah bawang bombay iris2 agak tebal"
recipeinstructions:
- "Rebus ayam, lalu goreng sebentar"
- "Potong daun bawang, tomat dan bawang bombayy"
- "Panaskan wajan dan sedikit minyak, tumis bumbu halus hingga wangi"
- "Masukkan bahan yg dirajang, tumis hingga agak layu"
- "Masukkan ayam, tambahkan kecap, saus tiram, tambahkan air"
- "Tes rasa, tunggu hingga air agak susut"
- "Hidangkan"
categories:
- Resep
tags:
- ayam
- gongso

katakunci: ayam gongso 
nutrition: 175 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam gongso](https://img-global.cpcdn.com/recipes/1139a23dc3570006/751x532cq70/ayam-gongso-foto-resep-utama.jpg)

Bunda Sedang mencari ide resep ayam gongso yang Lezat Sekali? Cara menyiapkannya memang tidak susah dan tidak juga mudah. semisal salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal ayam gongso yang enak seharusnya punya aroma dan cita rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso, pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tak perlu pusing jika ingin menyiapkan ayam gongso yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.


Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah ayam gongso yang siap dikreasikan. Anda bisa membuat Ayam gongso memakai 16 bahan dan 7 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam gongso:

1. Siapkan 1/4 kg ayam (boleh bagian apa aja) siangi lalu potong kecil2
1. Ambil  Bumbu halus:
1. Sediakan 4 buah cabe setan (opsional bagi yg suka pedes)
1. Siapkan 4 buah cabe merah / rawit
1. Siapkan 3 siung bawang merah
1. Sediakan 2 siung bawang putih
1. Ambil 2 gelondong kemiri
1. Ambil Secukupnya merica
1. Gunakan  Kunyit
1. Siapkan  Jahe
1. Siapkan Secukupnya garam, gula &amp; penyedap
1. Sediakan 3 sdm Kecap sekitar
1. Gunakan  Saus tiram
1. Siapkan 2 buah tomat iris agak tebal
1. Sediakan 1 lonjor daun bawang iris agak tebal
1. Gunakan 2 buah bawang bombay iris2 agak tebal




<!--inarticleads2-->

##### Cara membuat Ayam gongso:

1. Rebus ayam, lalu goreng sebentar
1. Potong daun bawang, tomat dan bawang bombayy
1. Panaskan wajan dan sedikit minyak, tumis bumbu halus hingga wangi
1. Masukkan bahan yg dirajang, tumis hingga agak layu
1. Masukkan ayam, tambahkan kecap, saus tiram, tambahkan air
1. Tes rasa, tunggu hingga air agak susut
1. Hidangkan




Bagaimana? Mudah bukan? Itulah cara menyiapkan ayam gongso yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
