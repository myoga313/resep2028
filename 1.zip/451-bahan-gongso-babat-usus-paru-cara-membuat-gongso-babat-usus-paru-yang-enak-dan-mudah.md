---
description: "Bahan Gongso babat usus paru | Cara Membuat Gongso babat usus paru Yang Enak Dan Mudah"
title: "Bahan Gongso babat usus paru | Cara Membuat Gongso babat usus paru Yang Enak Dan Mudah"
slug: 451-bahan-gongso-babat-usus-paru-cara-membuat-gongso-babat-usus-paru-yang-enak-dan-mudah
date: 2020-09-09T06:15:07.519Z
image: https://img-global.cpcdn.com/recipes/402194068487084e/751x532cq70/gongso-babat-usus-paru-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/402194068487084e/751x532cq70/gongso-babat-usus-paru-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/402194068487084e/751x532cq70/gongso-babat-usus-paru-foto-resep-utama.jpg
author: Isaiah Adkins
ratingvalue: 4.7
reviewcount: 11
recipeingredient:
- "500 gr babat usus paru"
- "1 buah Jenuk nipis"
- "2 helai daun salam"
- "1 buah bawang bombai bs skip"
- " Bumbu halus"
- "11 cabe keriting"
- "9 cabe kecil"
- "13 bawang merah"
- "5 bawang putih"
- "5 kemiri sangrai"
- " Bahan tambahan"
- "secukupnya Kecap gula garam royko daging"
- " Lada bubuk sedikit bwt tambah pedesnyaboleh skip"
- " Air 500 cc kurang lebih y bun"
recipeinstructions:
- "Rebus babat usus paru dalam waktu 1 jam 10 menit jgn lupa masukkan jeruk nipis potong jd 4 dan 2 helai daun salam, bisa kasih sedikit royko ya bun bisa jd skip. Oiya bisa jd di presto dlm waktu 20 menitan ya bun"
- "Siapkan bumbu halus dan siapkan bawang bombay di iris agak lebar ya bun"
- "Tumis bawang bombai, agak layu"
- "Masukkan bumbu halus, tumis hingga harum, tambah air 500 cc bagi yg suka nyemek(bg yg suka nanti matangnya agak kering bisa dikurangi), masukkan masukkan rebusan babat usus paru yg sudah empuk, masukkan bahan tambahan. Cek rasa (proses masak kurang lebih 15 sampai 20 menit)"
categories:
- Resep
tags:
- gongso
- babat
- usus

katakunci: gongso babat usus 
nutrition: 277 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dessert

---


![Gongso babat usus paru](https://img-global.cpcdn.com/recipes/402194068487084e/751x532cq70/gongso-babat-usus-paru-foto-resep-utama.jpg)

Sedang mencari inspirasi resep gongso babat usus paru yang Sedap? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. Jika salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gongso babat usus paru yang enak selayaknya mempunyai aroma dan rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso babat usus paru, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tak perlu pusing kalau ingin menyiapkan gongso babat usus paru yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.




Berikut ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah gongso babat usus paru yang siap dikreasikan. Anda dapat membuat Gongso babat usus paru menggunakan 14 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Gongso babat usus paru:

1. Siapkan 500 gr babat usus paru
1. Gunakan 1 buah Jenuk nipis
1. Sediakan 2 helai daun salam
1. Sediakan 1 buah bawang bombai (bs skip)
1. Sediakan  Bumbu halus
1. Siapkan 11 cabe keriting
1. Siapkan 9 cabe kecil
1. Sediakan 13 bawang merah
1. Ambil 5 bawang putih
1. Sediakan 5 kemiri (sangrai)
1. Sediakan  Bahan tambahan
1. Sediakan secukupnya Kecap, gula, garam, royko daging
1. Gunakan  Lada bubuk sedikit bwt tambah pedesnya(boleh skip)
1. Ambil  Air 500 cc kurang lebih y bun




<!--inarticleads2-->

##### Cara menyiapkan Gongso babat usus paru:

1. Rebus babat usus paru dalam waktu 1 jam 10 menit jgn lupa masukkan jeruk nipis potong jd 4 dan 2 helai daun salam, bisa kasih sedikit royko ya bun bisa jd skip. Oiya bisa jd di presto dlm waktu 20 menitan ya bun
1. Siapkan bumbu halus dan siapkan bawang bombay di iris agak lebar ya bun
1. Tumis bawang bombai, agak layu
1. Masukkan bumbu halus, tumis hingga harum, tambah air 500 cc bagi yg suka nyemek(bg yg suka nanti matangnya agak kering bisa dikurangi), masukkan masukkan rebusan babat usus paru yg sudah empuk, masukkan bahan tambahan. Cek rasa (proses masak kurang lebih 15 sampai 20 menit)




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Besar harapan kami, olahan Gongso babat usus paru yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman ataupun menjadi inspirasi untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
