---
description: "Resep Nasi Goreng Jengkol | Cara Bikin Nasi Goreng Jengkol Yang Lezat"
title: "Resep Nasi Goreng Jengkol | Cara Bikin Nasi Goreng Jengkol Yang Lezat"
slug: 376-resep-nasi-goreng-jengkol-cara-bikin-nasi-goreng-jengkol-yang-lezat
date: 2020-09-03T08:04:02.540Z
image: https://img-global.cpcdn.com/recipes/c7e319fea1868b6e/751x532cq70/nasi-goreng-jengkol-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c7e319fea1868b6e/751x532cq70/nasi-goreng-jengkol-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c7e319fea1868b6e/751x532cq70/nasi-goreng-jengkol-foto-resep-utama.jpg
author: Clayton Mills
ratingvalue: 4.1
reviewcount: 11
recipeingredient:
- "5 buah jengkol"
- "5 buah cabe"
- "1/2 wortel"
- "3 sdm kecap"
- "1 sdm penyedap"
- "1/2 sdm garam"
- "1/2 sdm gula"
- "secukupnya Kembang koll"
- "3 centong nasi putih"
- "2 siung bawang putih"
- "3 siung bawang merah"
- "3 sdm minyak goreng"
- "2 butir telur"
- "1/2 sdm lada bubuk"
recipeinstructions:
- "Tumis bawang dan cabe sampai harum sisihkan dipinggir penggorengan. Ceplok telor dan oseng-oseng sampai kering."
- "Masukan potongan jengkol dan sayur lalu aduk sampai sayur (perhatikan tingkat kematangan yang tepat)"
- "Masukan nasi dan aduk sampai rata, masukan bumbu dan kecap. Aduk lagi sampai rata. Sebelum api dimatikan, cicipi terlebih dahulu sampai rasa sesuai selera."
- "Selamat mencoba 😉"
categories:
- Resep
tags:
- nasi
- goreng
- jengkol

katakunci: nasi goreng jengkol 
nutrition: 247 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Dessert

---


![Nasi Goreng Jengkol](https://img-global.cpcdn.com/recipes/c7e319fea1868b6e/751x532cq70/nasi-goreng-jengkol-foto-resep-utama.jpg)

Bunda lagi mencari ide resep nasi goreng jengkol yang Sempurna? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. Jika keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal nasi goreng jengkol yang enak selayaknya memiliki aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari nasi goreng jengkol, pertama dari jenis bahan, kemudian pemilihan bahan segar sampai cara membuat dan menyajikannya. Tak perlu pusing jika mau menyiapkan nasi goreng jengkol enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.


Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah nasi goreng jengkol yang siap dikreasikan. Anda bisa menyiapkan Nasi Goreng Jengkol memakai 14 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Nasi Goreng Jengkol:

1. Siapkan 5 buah jengkol
1. Sediakan 5 buah cabe
1. Gunakan 1/2 wortel
1. Ambil 3 sdm kecap
1. Siapkan 1 sdm penyedap
1. Sediakan 1/2 sdm garam
1. Siapkan 1/2 sdm gula
1. Sediakan secukupnya Kembang koll
1. Ambil 3 centong nasi putih
1. Gunakan 2 siung bawang putih
1. Ambil 3 siung bawang merah
1. Ambil 3 sdm minyak goreng
1. Gunakan 2 butir telur
1. Sediakan 1/2 sdm lada bubuk




<!--inarticleads2-->

##### Langkah-langkah membuat Nasi Goreng Jengkol:

1. Tumis bawang dan cabe sampai harum sisihkan dipinggir penggorengan. Ceplok telor dan oseng-oseng sampai kering.
1. Masukan potongan jengkol dan sayur lalu aduk sampai sayur (perhatikan tingkat kematangan yang tepat)
1. Masukan nasi dan aduk sampai rata, masukan bumbu dan kecap. Aduk lagi sampai rata. Sebelum api dimatikan, cicipi terlebih dahulu sampai rasa sesuai selera.
1. Selamat mencoba 😉




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Besar harapan kami, olahan Nasi Goreng Jengkol yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman maupun menjadi ide untuk berbisnis kuliner. Selamat mencoba!
