---
description: "Olahan Gongso Ampela | Bahan Membuat Gongso Ampela Yang Paling Enak"
title: "Olahan Gongso Ampela | Bahan Membuat Gongso Ampela Yang Paling Enak"
slug: 280-olahan-gongso-ampela-bahan-membuat-gongso-ampela-yang-paling-enak
date: 2020-07-25T21:39:51.315Z
image: https://img-global.cpcdn.com/recipes/c17d1b0231749e06/751x532cq70/gongso-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c17d1b0231749e06/751x532cq70/gongso-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c17d1b0231749e06/751x532cq70/gongso-ampela-foto-resep-utama.jpg
author: Joel McLaughlin
ratingvalue: 3.7
reviewcount: 10
recipeingredient:
- " ampela"
- " Bumbu Rebusan"
- " Daun salam"
- " Sereh"
- " daun jeruk"
- " jahe"
- " lengkuas"
- " ketumbar bubuk"
- " air"
- " Bumbu dihaluskan"
- " cabe"
- " bawang merah"
- " bawang putih"
- " kunyit"
- " Bumbu lainya"
- " bawang merah diiris"
- " cabe jablay"
- " daun jeruk"
- " sereh"
- " daun salam"
- " kecap manis"
- " Garam"
- " air"
- " Minyak untuk menggoreng"
recipeinstructions:
- "Didihkan air, kemudian masukan daun salam, daun jeruk, sereh, jahe, lengkuas dan ketumbar bubuk aduk. Kemudian masukkan ampela. Rebus sampai matang, kemudian angkat dan potong potong"
- "Goreng bawang merah iris sampai wangi, masukkan potongan ampela. Goreng hingga setengah kering, angkat"
- "Tumis bumbu halus sampai wangi, tambahkan air masak sampai air mendidih masukkan ampela, tambahkan kecap, garam, penyedap rasa koreksi rasa, matikan kompor dan angkat"
- "Siap disantap dengan nasi hangat 😘"
categories:
- Resep
tags:
- gongso
- ampela

katakunci: gongso ampela 
nutrition: 119 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dinner

---


![Gongso Ampela](https://img-global.cpcdn.com/recipes/c17d1b0231749e06/751x532cq70/gongso-ampela-foto-resep-utama.jpg)

Bunda lagi mencari ide resep gongso ampela yang Sedap? Cara Memasaknya memang susah-susah gampang. Jika salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso ampela yang enak harusnya sih mempunyai aroma dan cita rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ampela, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tidak usah pusing jika mau menyiapkan gongso ampela yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian istimewa.




Nah, kali ini kita coba, yuk, siapkan gongso ampela sendiri di rumah. Tetap berbahan yang sederhana, sajian ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Gongso Ampela menggunakan 24 bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Gongso Ampela:

1. Siapkan  ampela
1. Gunakan  Bumbu Rebusan
1. Gunakan  Daun salam
1. Sediakan  Sereh
1. Gunakan  daun jeruk
1. Siapkan  jahe
1. Gunakan  lengkuas
1. Sediakan  ketumbar bubuk
1. Gunakan  air
1. Siapkan  Bumbu dihaluskan
1. Siapkan  cabe
1. Sediakan  bawang merah
1. Ambil  bawang putih
1. Ambil  kunyit
1. Gunakan  Bumbu lainya
1. Ambil  bawang merah, diiris
1. Siapkan  cabe jablay
1. Siapkan  daun jeruk
1. Gunakan  sereh
1. Sediakan  daun salam
1. Siapkan  kecap manis
1. Gunakan  Garam
1. Gunakan  air
1. Siapkan  Minyak untuk menggoreng




<!--inarticleads2-->

##### Cara membuat Gongso Ampela:

1. Didihkan air, kemudian masukan daun salam, daun jeruk, sereh, jahe, lengkuas dan ketumbar bubuk aduk. Kemudian masukkan ampela. Rebus sampai matang, kemudian angkat dan potong potong
1. Goreng bawang merah iris sampai wangi, masukkan potongan ampela. Goreng hingga setengah kering, angkat
1. Tumis bumbu halus sampai wangi, tambahkan air masak sampai air mendidih masukkan ampela, tambahkan kecap, garam, penyedap rasa koreksi rasa, matikan kompor dan angkat
1. Siap disantap dengan nasi hangat 😘




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Harapan kami, olahan Gongso Ampela yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman ataupun menjadi inspirasi bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
