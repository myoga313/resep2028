---
description: "Bumbu Ayam petai gongso pedas | Cara Masak Ayam petai gongso pedas Yang Bikin Ngiler"
title: "Bumbu Ayam petai gongso pedas | Cara Masak Ayam petai gongso pedas Yang Bikin Ngiler"
slug: 194-bumbu-ayam-petai-gongso-pedas-cara-masak-ayam-petai-gongso-pedas-yang-bikin-ngiler
date: 2020-10-27T00:01:41.152Z
image: https://img-global.cpcdn.com/recipes/c502b24d310f404b/751x532cq70/ayam-petai-gongso-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c502b24d310f404b/751x532cq70/ayam-petai-gongso-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c502b24d310f404b/751x532cq70/ayam-petai-gongso-pedas-foto-resep-utama.jpg
author: Chester Swanson
ratingvalue: 3.7
reviewcount: 9
recipeingredient:
- " Ayamcuci bersih"
- "siung Bawang merahiris5"
- "5 siung Bawang merah"
- "5 siung Bawang putih"
- "1 potong Terasi"
- "5 buah Cabe merah"
- "5 buah Cabe rawit pedas sesuai selera pedas nya"
- "1,5 sdt Garam"
- "1 potong Gula merah"
- "1 sdt Gula putih"
- "4 sdm Minyak untuk menumis"
- "3 sdm Kecap manis"
recipeinstructions:
- "Rebus ayam dengan air, ditambah dengan daun salam,angkat dan tiriskan"
- "Halus kan semua bumbu, bawang putih, bawang merah, cabai dan terasi"
- "Panaskan pengorengan sedeng sedikit minyak, masukan bumbu halus gongso sampai harus, masukan sedikit air, tambah kan garam, gula pasir, gula merah,masukan ayam, dan tambah kan kecap manis, cek rasa dan sajikan"
categories:
- Resep
tags:
- ayam
- petai
- gongso

katakunci: ayam petai gongso 
nutrition: 279 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam petai gongso pedas](https://img-global.cpcdn.com/recipes/c502b24d310f404b/751x532cq70/ayam-petai-gongso-pedas-foto-resep-utama.jpg)

Kamu Sedang mencari ide resep ayam petai gongso pedas yang Sedap? Cara Buatnya memang tidak susah dan tidak juga mudah. Jika salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal ayam petai gongso pedas yang enak selayaknya punya aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam petai gongso pedas, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tidak usah pusing kalau ingin menyiapkan ayam petai gongso pedas yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian spesial.


Di bawah ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah ayam petai gongso pedas yang siap dikreasikan. Anda dapat menyiapkan Ayam petai gongso pedas memakai 12 bahan dan 3 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam petai gongso pedas:

1. Siapkan  Ayam(cuci bersih)
1. Gunakan siung Bawang merah(iris)5
1. Ambil 5 siung Bawang merah
1. Siapkan 5 siung Bawang putih
1. Gunakan 1 potong Terasi
1. Gunakan 5 buah Cabe merah
1. Siapkan 5 buah Cabe rawit pedas (sesuai selera pedas nya)
1. Sediakan 1,5 sdt Garam
1. Ambil 1 potong Gula merah
1. Sediakan 1 sdt Gula putih
1. Ambil 4 sdm Minyak untuk menumis
1. Siapkan 3 sdm Kecap manis




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam petai gongso pedas:

1. Rebus ayam dengan air, ditambah dengan daun salam,angkat dan tiriskan
1. Halus kan semua bumbu, bawang putih, bawang merah, cabai dan terasi
1. Panaskan pengorengan sedeng sedikit minyak, masukan bumbu halus gongso sampai harus, masukan sedikit air, tambah kan garam, gula pasir, gula merah,masukan ayam, dan tambah kan kecap manis, cek rasa dan sajikan




Terima kasih telah membaca resep yang kami tampilkan di sini. Harapan kami, olahan Ayam petai gongso pedas yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman maupun menjadi inspirasi bagi Anda yang berkeinginan untuk berjualan makanan. Selamat mencoba!
