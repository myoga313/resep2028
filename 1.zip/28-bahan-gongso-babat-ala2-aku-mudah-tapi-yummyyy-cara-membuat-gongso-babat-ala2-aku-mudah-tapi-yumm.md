---
description: "Bahan Gongso Babat ala2 aku, mudah tapi yummyyy..😁 | Cara Membuat Gongso Babat ala2 aku, mudah tapi yummyyy..😁 Yang Enak Dan Lezat"
title: "Bahan Gongso Babat ala2 aku, mudah tapi yummyyy..😁 | Cara Membuat Gongso Babat ala2 aku, mudah tapi yummyyy..😁 Yang Enak Dan Lezat"
slug: 28-bahan-gongso-babat-ala2-aku-mudah-tapi-yummyyy-cara-membuat-gongso-babat-ala2-aku-mudah-tapi-yummyyy-yang-enak-dan-lezat
date: 2020-09-25T12:40:43.868Z
image: https://img-global.cpcdn.com/recipes/50f47637170ffff0/751x532cq70/gongso-babat-ala2-aku-mudah-tapi-yummyyy😁-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/50f47637170ffff0/751x532cq70/gongso-babat-ala2-aku-mudah-tapi-yummyyy😁-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/50f47637170ffff0/751x532cq70/gongso-babat-ala2-aku-mudah-tapi-yummyyy😁-foto-resep-utama.jpg
author: Don Pratt
ratingvalue: 4.2
reviewcount: 4
recipeingredient:
- "300 gr babatyg sudah direbus empuk"
- "1 lbr daun salam"
- "1 cm lengkuasdikeprek"
- "5 bh cabe rawitiris2"
- "50 ml air"
- " bumbu halus"
- "2 btr kemirisanggrai"
- "10 bh cabe keriting"
- "8 btr bawang merah"
- "4 btr bawang putih"
- "1 sdt merica"
- " bumbu lainnya"
- "1 sdm kecap manis sesuai selera banyaknya"
- "secukupnya garamgulapenyedap rasa"
- "1 sdm air lemonjeruk nipis"
recipeinstructions:
- "Potong2 babat sesuai selera"
- "Tumis bumbu halus,daun salam,lengkuas sampe harum."
- "Masukan babat,tambahkan bumbu lainnya,cabe rawit dan air."
- "Masak sampai bumbu meresap. koreksi rasa. Angkat. yummyy..^.^"
categories:
- Resep
tags:
- gongso
- babat
- ala2

katakunci: gongso babat ala2 
nutrition: 266 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Lunch

---


![Gongso Babat ala2 aku, mudah tapi yummyyy..😁](https://img-global.cpcdn.com/recipes/50f47637170ffff0/751x532cq70/gongso-babat-ala2-aku-mudah-tapi-yummyyy😁-foto-resep-utama.jpg)

Sedang mencari inspirasi resep gongso babat ala2 aku, mudah tapi yummyyy..😁 yang Paling Enak? Cara Bikinnya memang susah-susah gampang. seumpama keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso babat ala2 aku, mudah tapi yummyyy..😁 yang enak harusnya sih memiliki aroma dan cita rasa yang bisa memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso babat ala2 aku, mudah tapi yummyyy..😁, pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tak perlu pusing jika mau menyiapkan gongso babat ala2 aku, mudah tapi yummyyy..😁 yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.


Di bawah ini ada beberapa tips dan trik praktis untuk membuat gongso babat ala2 aku, mudah tapi yummyyy..😁 yang siap dikreasikan. Anda bisa menyiapkan Gongso Babat ala2 aku, mudah tapi yummyyy..😁 menggunakan 15 bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Gongso Babat ala2 aku, mudah tapi yummyyy..😁:

1. Ambil 300 gr babat,yg sudah direbus empuk
1. Sediakan 1 lbr daun salam
1. Siapkan 1 cm lengkuas,dikeprek
1. Siapkan 5 bh cabe rawit,iris2
1. Siapkan 50 ml air
1. Siapkan  bumbu halus:
1. Siapkan 2 btr kemiri,sanggrai
1. Siapkan 10 bh cabe keriting
1. Siapkan 8 btr bawang merah
1. Siapkan 4 btr bawang putih
1. Ambil 1 sdt merica
1. Sediakan  bumbu lainnya:
1. Gunakan 1 sdm kecap manis (sesuai selera banyaknya)
1. Sediakan secukupnya garam,gula,penyedap rasa
1. Siapkan 1 sdm air lemon/jeruk nipis




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso Babat ala2 aku, mudah tapi yummyyy..😁:

1. Potong2 babat sesuai selera
1. Tumis bumbu halus,daun salam,lengkuas sampe harum.
1. Masukan babat,tambahkan bumbu lainnya,cabe rawit dan air.
1. Masak sampai bumbu meresap. koreksi rasa. Angkat. yummyy..^.^




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan Gongso Babat ala2 aku, mudah tapi yummyyy..😁 yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman ataupun menjadi inspirasi dalam berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
