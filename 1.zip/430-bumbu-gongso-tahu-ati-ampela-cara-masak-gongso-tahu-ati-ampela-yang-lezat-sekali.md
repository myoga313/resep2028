---
description: "Bumbu Gongso Tahu Ati Ampela | Cara Masak Gongso Tahu Ati Ampela Yang Lezat Sekali"
title: "Bumbu Gongso Tahu Ati Ampela | Cara Masak Gongso Tahu Ati Ampela Yang Lezat Sekali"
slug: 430-bumbu-gongso-tahu-ati-ampela-cara-masak-gongso-tahu-ati-ampela-yang-lezat-sekali
date: 2020-12-14T08:00:43.414Z
image: https://img-global.cpcdn.com/recipes/50bcd2527176ae55/751x532cq70/gongso-tahu-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/50bcd2527176ae55/751x532cq70/gongso-tahu-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/50bcd2527176ae55/751x532cq70/gongso-tahu-ati-ampela-foto-resep-utama.jpg
author: Amanda Allen
ratingvalue: 4.9
reviewcount: 11
recipeingredient:
- "6 pasang ati ampela"
- "1 blok tahu putih besar potongpotong"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1 tangkai daun bawang"
- "1 keping gula merah"
- "2 sdm kecap manis"
- "Secukupnya garam dan kaldu bubuk"
- "1 gelas air"
- " Bumbu ungkep "
- "3 siung bawang merah"
- "2 siung bawang putih"
- "1 ruas jahe geprek"
- "1 ruas kunyit bakar geprek"
- "1/2 sdt ketumbar bubuk"
- "2 Lembar daun salam"
- "1 batang serai"
- " Bumbu halus"
- "7 buah cabai merah keriting"
- "3 siung bawang putih"
- "6 siung bawang merah"
- "1 ruas kunyit bakar"
recipeinstructions:
- "Rebus ati ampela dengan bumbu ungkep biarkan meresap sisihkan. Setelah dingin potong kecil. Goreng tahu sisihkan"
- "Tumis bawang putih, bawang merah, daun bawang kemudian masukkan ati ampela tumis sampai agak kering. angkat sisihkan"
- "Haluskan bumbu halus saya di blender saja kemudian tumis sampai bumbu matang"
- "Masukkan ati ampela, tahu kemudian tuang air beri kecap manis bumbui dengan gula garam dan kaldu bubuk aduk rata."
- "Masak api sedang saja tunggu bumbu meresap koreksi rasa angkat sajikan. Saya bikin yang kering atau kalau suka yang berkuah boleh saja."
categories:
- Resep
tags:
- gongso
- tahu
- ati

katakunci: gongso tahu ati 
nutrition: 287 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Lunch

---


![Gongso Tahu Ati Ampela](https://img-global.cpcdn.com/recipes/50bcd2527176ae55/751x532cq70/gongso-tahu-ati-ampela-foto-resep-utama.jpg)

Bunda lagi mencari ide resep gongso tahu ati ampela yang Mudah Dan Praktis? Cara Buatnya memang tidak susah dan tidak juga mudah. sekiranya keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gongso tahu ati ampela yang enak seharusnya memiliki aroma dan rasa yang bisa memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso tahu ati ampela, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tak perlu pusing jika hendak menyiapkan gongso tahu ati ampela enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian spesial.


Berikut ini ada beberapa cara mudah dan praktis dalam mengolah gongso tahu ati ampela yang siap dikreasikan. Anda bisa membuat Gongso Tahu Ati Ampela memakai 22 bahan dan 5 tahap pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Gongso Tahu Ati Ampela:

1. Ambil 6 pasang ati ampela
1. Siapkan 1 blok tahu putih besar potong-potong
1. Sediakan 5 siung bawang merah
1. Ambil 3 siung bawang putih
1. Siapkan 1 tangkai daun bawang
1. Sediakan 1 keping gula merah
1. Gunakan 2 sdm kecap manis
1. Ambil Secukupnya garam dan kaldu bubuk
1. Siapkan 1 gelas air
1. Gunakan  Bumbu ungkep :
1. Sediakan 3 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Sediakan 1 ruas jahe geprek
1. Siapkan 1 ruas kunyit bakar geprek
1. Sediakan 1/2 sdt ketumbar bubuk
1. Gunakan 2 Lembar daun salam
1. Siapkan 1 batang serai
1. Sediakan  Bumbu halus:
1. Gunakan 7 buah cabai merah keriting
1. Siapkan 3 siung bawang putih
1. Siapkan 6 siung bawang merah
1. Ambil 1 ruas kunyit bakar




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso Tahu Ati Ampela:

1. Rebus ati ampela dengan bumbu ungkep biarkan meresap sisihkan. Setelah dingin potong kecil. Goreng tahu sisihkan
1. Tumis bawang putih, bawang merah, daun bawang kemudian masukkan ati ampela tumis sampai agak kering. angkat sisihkan
1. Haluskan bumbu halus saya di blender saja kemudian tumis sampai bumbu matang
1. Masukkan ati ampela, tahu kemudian tuang air beri kecap manis bumbui dengan gula garam dan kaldu bubuk aduk rata.
1. Masak api sedang saja tunggu bumbu meresap koreksi rasa angkat sajikan. Saya bikin yang kering atau kalau suka yang berkuah boleh saja.




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan Gongso Tahu Ati Ampela yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman ataupun menjadi inspirasi bagi Anda yang berkeinginan untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
