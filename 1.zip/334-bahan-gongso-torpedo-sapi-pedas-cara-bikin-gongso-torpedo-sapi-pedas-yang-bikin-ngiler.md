---
description: "Bahan Gongso Torpedo Sapi Pedas | Cara Bikin Gongso Torpedo Sapi Pedas Yang Bikin Ngiler"
title: "Bahan Gongso Torpedo Sapi Pedas | Cara Bikin Gongso Torpedo Sapi Pedas Yang Bikin Ngiler"
slug: 334-bahan-gongso-torpedo-sapi-pedas-cara-bikin-gongso-torpedo-sapi-pedas-yang-bikin-ngiler
date: 2020-09-11T20:20:33.699Z
image: https://img-global.cpcdn.com/recipes/23a3a45b91b3d5f4/751x532cq70/gongso-torpedo-sapi-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/23a3a45b91b3d5f4/751x532cq70/gongso-torpedo-sapi-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/23a3a45b91b3d5f4/751x532cq70/gongso-torpedo-sapi-pedas-foto-resep-utama.jpg
author: Jane Terry
ratingvalue: 5
reviewcount: 13
recipeingredient:
- " torpedo sapi"
- " daun salam"
- " lengkuas"
- " cabai rawit utuh"
- " tomat"
- " garam"
- " gula jawa sisir"
- " gula pasir"
- " kaldu bubuk"
- " saos tiram"
- " kecap manis"
- " air"
- " Bumbu Halus "
- " bawang putih"
- " bawang merah"
- " cabai"
- " kemiri"
- " jahe"
recipeinstructions:
- "Rebus torpedo sampe empuk dan potong2 sesuai selera."
- "Haluskan bahan bumbu halus."
- "Tumis bumbu halus bersama daun salam dan lengkuas, tumis sampai benar2 matang dan tanak."
- "Jika terlalu kering, tambah sedikit air dan tumis lagi sampai minyak bening &amp; tenang."
- "Masukkan torpedo sapi, aduk sampai tercampur bumbu."
- "Masukkan air, garam, gula, kaldu bubuk. Masak sampai mendidih."
- "Tambahkan cabai rawit utuh. Masak sampai air sedikit menyusut."
- "Tambahkan kecap dan saos tiram, aduk rata."
- "Masukkan irisan tomat &amp; Masak sampai air menyusut, dika suka berkuah masak jangan sampai air menyusut banyak ya."
categories:
- Resep
tags:
- gongso
- torpedo
- sapi

katakunci: gongso torpedo sapi 
nutrition: 142 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dinner

---


![Gongso Torpedo Sapi Pedas](https://img-global.cpcdn.com/recipes/23a3a45b91b3d5f4/751x532cq70/gongso-torpedo-sapi-pedas-foto-resep-utama.jpg)

Sedang mencari ide resep gongso torpedo sapi pedas yang Mudah Dan Praktis? Cara membuatnya memang tidak susah dan tidak juga mudah. seumpama salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso torpedo sapi pedas yang enak selayaknya punya aroma dan cita rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso torpedo sapi pedas, pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tak perlu pusing jika ingin menyiapkan gongso torpedo sapi pedas yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian istimewa.


Berikut ini ada beberapa cara mudah dan praktis dalam mengolah gongso torpedo sapi pedas yang siap dikreasikan. Anda dapat membuat Gongso Torpedo Sapi Pedas memakai 18 bahan dan 9 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Gongso Torpedo Sapi Pedas:

1. Siapkan  torpedo sapi
1. Ambil  daun salam
1. Ambil  lengkuas
1. Sediakan  cabai rawit utuh
1. Siapkan  tomat
1. Sediakan  garam
1. Gunakan  gula jawa sisir
1. Siapkan  gula pasir
1. Sediakan  kaldu bubuk
1. Ambil  saos tiram
1. Ambil  kecap manis
1. Sediakan  air
1. Gunakan  Bumbu Halus :
1. Gunakan  bawang putih
1. Ambil  bawang merah
1. Sediakan  cabai
1. Gunakan  kemiri
1. Ambil  jahe




<!--inarticleads2-->

##### Cara membuat Gongso Torpedo Sapi Pedas:

1. Rebus torpedo sampe empuk dan potong2 sesuai selera.
1. Haluskan bahan bumbu halus.
1. Tumis bumbu halus bersama daun salam dan lengkuas, tumis sampai benar2 matang dan tanak.
1. Jika terlalu kering, tambah sedikit air dan tumis lagi sampai minyak bening &amp; tenang.
1. Masukkan torpedo sapi, aduk sampai tercampur bumbu.
1. Masukkan air, garam, gula, kaldu bubuk. Masak sampai mendidih.
1. Tambahkan cabai rawit utuh. Masak sampai air sedikit menyusut.
1. Tambahkan kecap dan saos tiram, aduk rata.
1. Masukkan irisan tomat &amp; Masak sampai air menyusut, dika suka berkuah masak jangan sampai air menyusut banyak ya.




Gimana nih? Gampang kan? Itulah cara menyiapkan gongso torpedo sapi pedas yang bisa Anda lakukan di rumah. Selamat mencoba!
