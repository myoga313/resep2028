---
description: "Resep Gongso Ayam | Cara Bikin Gongso Ayam Yang Paling Enak"
title: "Resep Gongso Ayam | Cara Bikin Gongso Ayam Yang Paling Enak"
slug: 229-resep-gongso-ayam-cara-bikin-gongso-ayam-yang-paling-enak
date: 2021-01-14T07:56:13.597Z
image: https://img-global.cpcdn.com/recipes/ab4972c48a0da623/751x532cq70/gongso-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ab4972c48a0da623/751x532cq70/gongso-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ab4972c48a0da623/751x532cq70/gongso-ayam-foto-resep-utama.jpg
author: Ricky Pittman
ratingvalue: 5
reviewcount: 4
recipeingredient:
- " dada ayam"
- " bawang merah"
- " bawang putih"
- " cabe merah"
- " cabe rawit merah"
- " tomat merah"
- " saos cabe"
- " saos tomat"
- " kecap manis"
- " air"
- " garam"
- " Masako"
recipeinstructions:
- "Bersihkan dada ayam dengan air bersih, potong-potong sesuai selera, lalu digoreng/direbus sampai matang"
- "Sambil menunggu ayam matang, kupas bawang merah dan bawang putih, buang tangkai cabe merah dan cabe rawit merah, potong ujung tomat, lalu cuci semuanya dengan air bersih"
- "Setelah itu, iris bawang merah, bawang putih, cabe merah, dan cabe rawit merah. Tomat potong dadu"
- "Panaskan minyak untuk menumis, masukkan bawang merah dan bawang putih, masukkan cabe merah dan cabe rawit merah, lalu masukkan tomat. Tumis sampai harum dan kekuningan"
- "Masukkan ayam yang sudah matang, campur dengan bumbu yang sudah ditumis"
- "Tuangkan air sampai menutupi permukaan ayam, tunggu sampai mendidih"
- "Masukkan saos cabe, saos tomat, kecap manis, secukupnya garam, dan secukupnya Masako. Campur supaya rata, koreksi rasa"
- "Biarkan air menyustut, setelah itu Gongso Ayam siap dihidangkan"
categories:
- Resep
tags:
- gongso
- ayam

katakunci: gongso ayam 
nutrition: 100 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT56M"
recipeyield: "4"
recipecategory: Dinner

---


![Gongso Ayam](https://img-global.cpcdn.com/recipes/ab4972c48a0da623/751x532cq70/gongso-ayam-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep gongso ayam yang Enak dan Simpel? Cara menyiapkannya memang tidak susah dan tidak juga mudah. misalnya salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso ayam yang enak selayaknya memiliki aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ayam, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tidak usah pusing jika ingin menyiapkan gongso ayam enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian spesial.

Lihat juga resep Gongso Ayam ala Semarangan enak lainnya. Aduuuuuh lama gak upload nih, tapi tenang aja kita bakalan rajin lagi kok hehe. kali ini kita masak gongso ayam nih, siapa tau jadi ide masak buat temen. Gongso berarti tumis dalam bahasa jawa.


Berikut ini ada beberapa cara mudah dan praktis untuk membuat gongso ayam yang siap dikreasikan. Anda bisa membuat Gongso Ayam menggunakan 12 jenis bahan dan 8 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Gongso Ayam:

1. Gunakan  dada ayam
1. Sediakan  bawang merah
1. Siapkan  bawang putih
1. Ambil  cabe merah
1. Siapkan  cabe rawit merah
1. Siapkan  tomat merah
1. Ambil  saos cabe
1. Ambil  saos tomat
1. Gunakan  kecap manis
1. Gunakan  air
1. Ambil  garam
1. Gunakan  Masako


Jadi Gongso Ayam kali ini bisa dikatakan dengan sebutan Gongso Ayam Suwir istimewa atau Goreng ataupun Gongso Ayam Goreng Suwir loh. Yah mungkin berbeda daerah berbeda juga. 

<!--inarticleads2-->

##### Langkah-langkah membuat Gongso Ayam:

1. Bersihkan dada ayam dengan air bersih, potong-potong sesuai selera, lalu digoreng/direbus sampai matang
1. Sambil menunggu ayam matang, kupas bawang merah dan bawang putih, buang tangkai cabe merah dan cabe rawit merah, potong ujung tomat, lalu cuci semuanya dengan air bersih
1. Setelah itu, iris bawang merah, bawang putih, cabe merah, dan cabe rawit merah. Tomat potong dadu
1. Panaskan minyak untuk menumis, masukkan bawang merah dan bawang putih, masukkan cabe merah dan cabe rawit merah, lalu masukkan tomat. Tumis sampai harum dan kekuningan
1. Masukkan ayam yang sudah matang, campur dengan bumbu yang sudah ditumis
1. Tuangkan air sampai menutupi permukaan ayam, tunggu sampai mendidih
1. Masukkan saos cabe, saos tomat, kecap manis, secukupnya garam, dan secukupnya Masako. Campur supaya rata, koreksi rasa
1. Biarkan air menyustut, setelah itu Gongso Ayam siap dihidangkan




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Harapan kami, olahan Gongso Ayam yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman maupun menjadi inspirasi untuk berbisnis kuliner. Selamat mencoba!
