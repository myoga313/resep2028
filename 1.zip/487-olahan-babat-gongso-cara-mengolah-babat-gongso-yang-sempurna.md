---
description: "Olahan Babat gongso | Cara Mengolah Babat gongso Yang Sempurna"
title: "Olahan Babat gongso | Cara Mengolah Babat gongso Yang Sempurna"
slug: 487-olahan-babat-gongso-cara-mengolah-babat-gongso-yang-sempurna
date: 2020-09-29T22:43:01.391Z
image: https://img-global.cpcdn.com/recipes/03edb6af8e61a19c/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/03edb6af8e61a19c/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/03edb6af8e61a19c/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Ina Carson
ratingvalue: 4.9
reviewcount: 11
recipeingredient:
- " Babat"
- " Serai"
- " Daun salam"
- " Daun jeruk"
- " Garam"
- " Jahe"
- " Bumbu halus"
- " bawang merah"
- " bawang putih"
- " Cabe rawit"
- " cabe merah"
- " Kemiri"
- " Jahe kunyit"
- " Serai"
- " Daun salam daun jeruk"
- " Kecap manis"
- " Garamgulapenyedap rasa"
recipeinstructions:
- "Masak air yg diberi garam, jahe geprek, sereh, daun salam dan daun jeruk"
- "Setelah mendidih masukkan babat yg sudah dicuci bersih, masak hingga babat empuk (bisa juga di presto), sisihkan dan iris sesuai selera"
- "Haluskan bawang merah,bawang putih, cabe merah, cabe rawit, kemiri, kunyit. Tumis hingga harum"
- "Masukkan daun salam, daun jeruk, serai, jahe geprek."
- "Tambahkan sedikit air, masukkan babat yg sudah direbus, masukan garam, gula dan penyedap tambahkan kecap. icip2 rasa, sajikan 😊"
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 123 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Lunch

---


![Babat gongso](https://img-global.cpcdn.com/recipes/03edb6af8e61a19c/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep babat gongso yang Mudah Dan Praktis? Cara Bikinnya memang susah-susah gampang. misalnya salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal babat gongso yang enak seharusnya mempunyai aroma dan rasa yang mampu memancing selera kita.

Com - Babat Gongso kali ini special karena ada isonya. Babat Gongso yang menjadi tujuan kuliner setiap orang yang ke Semarang, merupakan setidaknya primadona dari sekian banyak makanan yang ada di Semarang. Yuk, belajar membuat Babat Gongso di rumah Anda!

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari babat gongso, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tak perlu pusing kalau mau menyiapkan babat gongso yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian istimewa.


Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah babat gongso yang siap dikreasikan. Anda bisa menyiapkan Babat gongso memakai 17 bahan dan 5 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Babat gongso:

1. Gunakan  Babat
1. Ambil  Serai
1. Siapkan  Daun salam
1. Gunakan  Daun jeruk
1. Sediakan  Garam
1. Ambil  Jahe
1. Ambil  Bumbu halus
1. Siapkan  bawang merah
1. Gunakan  bawang putih
1. Ambil  Cabe rawit
1. Ambil  cabe merah
1. Ambil  Kemiri
1. Ambil  Jahe, kunyit
1. Gunakan  Serai
1. Ambil  Daun salam, daun jeruk
1. Sediakan  Kecap manis
1. Sediakan  Garam,gula,penyedap rasa




<!--inarticleads2-->

##### Cara membuat Babat gongso:

1. Masak air yg diberi garam, jahe geprek, sereh, daun salam dan daun jeruk
1. Setelah mendidih masukkan babat yg sudah dicuci bersih, masak hingga babat empuk (bisa juga di presto), sisihkan dan iris sesuai selera
1. Haluskan bawang merah,bawang putih, cabe merah, cabe rawit, kemiri, kunyit. Tumis hingga harum
1. Masukkan daun salam, daun jeruk, serai, jahe geprek.
1. Tambahkan sedikit air, masukkan babat yg sudah direbus, masukan garam, gula dan penyedap tambahkan kecap. icip2 rasa, sajikan 😊




Gimana nih? Mudah bukan? Itulah cara menyiapkan babat gongso yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
