---
description: "Resep masakan Gongso Ati Ampela | Resep Bumbu Gongso Ati Ampela Yang Lezat"
title: "Resep masakan Gongso Ati Ampela | Resep Bumbu Gongso Ati Ampela Yang Lezat"
slug: 271-resep-masakan-gongso-ati-ampela-resep-bumbu-gongso-ati-ampela-yang-lezat
date: 2020-11-26T21:53:13.161Z
image: https://img-global.cpcdn.com/recipes/8785e6fff3e6573e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8785e6fff3e6573e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8785e6fff3e6573e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
author: Alfred Vargas
ratingvalue: 4
reviewcount: 10
recipeingredient:
- "5 pasang ati ampela"
- "3 siung bawang merah iris"
- "1 sdt garam"
- "1 sdm gula pasir"
- "1/2 sdt kunyit bubuk"
- "2 sdm kecap manis"
- "100 ml air"
- " Bumbu cemplung "
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 batang sereh geprek"
- "1 jempol jahe geprek"
- "1 jempol laos geprek"
- "1 sdt ketumbar bubuk"
- " Bumbu halus "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "5 buah cabe merah keriting"
- "3 buah cabe rawit"
recipeinstructions:
- "Rebus ati ampela dengan bumbu cemplung. Angkat &amp; tiriskan kemudian potong-potong"
- "Tumis irisan bawang merah hingga harum kemudian masukkan irisan ati ampela. Angkat &amp; sisihkan"
- "Tumis bumbu halus dengan minyak bekas menumis tadi hingga harum"
- "Masukkan air kemudian bumbui dengan garam, gula, kecap manis &amp; kunyit bubuk kemudian tes rasa. Masukkan ati ampela, masak sebentar hingga air menyusut agar bumbu meresap"
- "Gongso ati ampela siap disajikan ❤"
categories:
- Resep
tags:
- gongso
- ati
- ampela

katakunci: gongso ati ampela 
nutrition: 260 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Dinner

---


![Gongso Ati Ampela](https://img-global.cpcdn.com/recipes/8785e6fff3e6573e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg)

Bunda Sedang mencari ide resep gongso ati ampela yang Menggugah Selera? Cara Buatnya memang tidak susah dan tidak juga mudah. Jika keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso ati ampela yang enak harusnya sih memiliki aroma dan cita rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ati ampela, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan gongso ati ampela yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian spesial.




Nah, kali ini kita coba, yuk, siapkan gongso ati ampela sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Gongso Ati Ampela memakai 19 bahan dan 5 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Gongso Ati Ampela:

1. Gunakan 5 pasang ati ampela
1. Siapkan 3 siung bawang merah, iris
1. Ambil 1 sdt garam
1. Gunakan 1 sdm gula pasir
1. Sediakan 1/2 sdt kunyit bubuk
1. Ambil 2 sdm kecap manis
1. Gunakan 100 ml air
1. Ambil  Bumbu cemplung :
1. Sediakan 2 lembar daun salam
1. Ambil 3 lembar daun jeruk
1. Siapkan 1 batang sereh, geprek
1. Siapkan 1 jempol jahe, geprek
1. Siapkan 1 jempol laos, geprek
1. Sediakan 1 sdt ketumbar bubuk
1. Gunakan  Bumbu halus :
1. Sediakan 5 siung bawang merah
1. Sediakan 3 siung bawang putih
1. Gunakan 5 buah cabe merah keriting
1. Siapkan 3 buah cabe rawit




<!--inarticleads2-->

##### Cara membuat Gongso Ati Ampela:

1. Rebus ati ampela dengan bumbu cemplung. Angkat &amp; tiriskan kemudian potong-potong
1. Tumis irisan bawang merah hingga harum kemudian masukkan irisan ati ampela. Angkat &amp; sisihkan
1. Tumis bumbu halus dengan minyak bekas menumis tadi hingga harum
1. Masukkan air kemudian bumbui dengan garam, gula, kecap manis &amp; kunyit bubuk kemudian tes rasa. Masukkan ati ampela, masak sebentar hingga air menyusut agar bumbu meresap
1. Gongso ati ampela siap disajikan ❤




Terima kasih telah membaca resep yang kami tampilkan di sini. Harapan kami, olahan Gongso Ati Ampela yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman ataupun menjadi ide bagi Anda yang berkeinginan untuk berbisnis kuliner. Selamat mencoba!
