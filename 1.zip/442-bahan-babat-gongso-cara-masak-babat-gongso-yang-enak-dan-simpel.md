---
description: "Bahan Babat Gongso | Cara Masak Babat Gongso Yang Enak dan Simpel"
title: "Bahan Babat Gongso | Cara Masak Babat Gongso Yang Enak dan Simpel"
slug: 442-bahan-babat-gongso-cara-masak-babat-gongso-yang-enak-dan-simpel
date: 2021-01-15T02:59:29.033Z
image: https://img-global.cpcdn.com/recipes/ee5bcdd1cc0acb12/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ee5bcdd1cc0acb12/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ee5bcdd1cc0acb12/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Millie Ferguson
ratingvalue: 4.9
reviewcount: 10
recipeingredient:
- "300 gram babat"
- "2 sdm gula merah sisir"
- "3 sdm kecap manis"
- "3 lembar daun jeruk"
- "4 lembar daun salam"
- "1 batang sereh"
- "1 ruas lengkuas"
- "1 sdt garam"
- "500 ml air"
- "1 buah tomat"
- "8 buah cabe rawit sesuai selera"
- " Bumbu halus"
- "5 siung bawang merah"
- "5 siung bawang putih"
- "1 cm jahe"
- "3 buah kemiri"
- "1 sdt ketumbar"
- "1/2 sdt merica bubuk"
- "100 ml air"
recipeinstructions:
- "Uleg bumbu halus. Sisihkan."
- "Rebus babat. Buang airnya dan potong- potong babanya sesuai selera."
- "Tumis bumbu halus sampai beraroma. Tambahkan daun salam, daun jeruk, serai dan lengkuas. Tambahkan 100 ml air. Masak sampai bumbu keluar minyak kembali."
- "Masukkan air 500 ml dan potongan babat. Masak sampai air agak menyusut, tambahkan gula jawa, kecap manis dan garam."
- "Kalau kuahnya tinggal sepertiga, masukkan irisan tomat dan cabe rawit utuh. Masak sampai kuah menyusut dan meresap ke babat. Matikan kompor."
- "Angkat dan sajikan..."
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 277 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dessert

---


![Babat Gongso](https://img-global.cpcdn.com/recipes/ee5bcdd1cc0acb12/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Sedang mencari ide resep babat gongso yang Bikin Ngiler? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. andaikata salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal babat gongso yang enak seharusnya punya aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari babat gongso, pertama dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tak perlu pusing jika hendak menyiapkan babat gongso enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan istimewa.




Nah, kali ini kita coba, yuk, kreasikan babat gongso sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Babat Gongso memakai 19 jenis bahan dan 6 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Babat Gongso:

1. Siapkan 300 gram babat
1. Gunakan 2 sdm gula merah sisir
1. Ambil 3 sdm kecap manis
1. Sediakan 3 lembar daun jeruk
1. Ambil 4 lembar daun salam
1. Sediakan 1 batang sereh
1. Sediakan 1 ruas lengkuas
1. Ambil 1 sdt garam
1. Sediakan 500 ml air
1. Gunakan 1 buah tomat
1. Ambil 8 buah cabe rawit (sesuai selera)
1. Siapkan  Bumbu halus
1. Sediakan 5 siung bawang merah
1. Gunakan 5 siung bawang putih
1. Ambil 1 cm jahe
1. Sediakan 3 buah kemiri
1. Sediakan 1 sdt ketumbar
1. Gunakan 1/2 sdt merica bubuk
1. Ambil 100 ml air




<!--inarticleads2-->

##### Cara menyiapkan Babat Gongso:

1. Uleg bumbu halus. Sisihkan.
1. Rebus babat. Buang airnya dan potong- potong babanya sesuai selera.
1. Tumis bumbu halus sampai beraroma. Tambahkan daun salam, daun jeruk, serai dan lengkuas. Tambahkan 100 ml air. Masak sampai bumbu keluar minyak kembali.
1. Masukkan air 500 ml dan potongan babat. Masak sampai air agak menyusut, tambahkan gula jawa, kecap manis dan garam.
1. Kalau kuahnya tinggal sepertiga, masukkan irisan tomat dan cabe rawit utuh. Masak sampai kuah menyusut dan meresap ke babat. Matikan kompor.
1. Angkat dan sajikan...




Gimana nih? Gampang kan? Itulah cara membuat babat gongso yang bisa Anda lakukan di rumah. Selamat mencoba!
