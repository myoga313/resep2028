---
description: "Resep Ayam Gongso | Cara Mengolah Ayam Gongso Yang Mudah Dan Praktis"
title: "Resep Ayam Gongso | Cara Mengolah Ayam Gongso Yang Mudah Dan Praktis"
slug: 46-resep-ayam-gongso-cara-mengolah-ayam-gongso-yang-mudah-dan-praktis
date: 2021-01-05T16:53:03.460Z
image: https://img-global.cpcdn.com/recipes/f62167703103c41e/751x532cq70/ayam-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f62167703103c41e/751x532cq70/ayam-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f62167703103c41e/751x532cq70/ayam-gongso-foto-resep-utama.jpg
author: Ada Morton
ratingvalue: 4.2
reviewcount: 14
recipeingredient:
- "1/2 kg dada ayam"
- "Sedikit kol"
- "Sedikit sawi hijau"
- " Daun bawang"
- "1 butir telur"
- "2 siung bawang putih"
- "3 cabe rawit"
- " Saos pedas bs tomat klo g suka pedas"
- " Kecap manis dan asin"
- "1/2 sdt Merica bubuk"
- "Secukupnya garam dan penyedap"
recipeinstructions:
- "Siapkan bahan...Cuci bersih ayam,masak dengan bumbu (me : bumbu racik ayam goreng) smp matang dan empuk"
- "Goreng sebentar jangan terlalu kering agar tdk keras. Kemudian suwir2 kecil sesuai selera"
- "Geprek bawang putih,kemudian tumis hingga harum,masukkan telur,saat setengah matang,masukkan daun bawang dan cabe. Tumis hingga harum"
- "Tambahkan sedikit air agar tdk gosong,lalu masukkan sayur yg sudah dipotong kecil2."
- "Tambahkan kecap,saos,garam dan merica. Terakhir masukkan ayam,sambil diaduk2 hingga matang."
- "Ayam gongso sudah matang,siap disajikan. Selamat mencoba. Semoga bermanfaat."
categories:
- Resep
tags:
- ayam
- gongso

katakunci: ayam gongso 
nutrition: 102 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Gongso](https://img-global.cpcdn.com/recipes/f62167703103c41e/751x532cq70/ayam-gongso-foto-resep-utama.jpg)

Bunda Sedang mencari ide resep ayam gongso yang Menggugah Selera? Cara Bikinnya memang tidak terlalu sulit namun tidak gampang juga. apabila keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal ayam gongso yang enak selayaknya mempunyai aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menyajikannya. Tidak usah pusing jika hendak menyiapkan ayam gongso yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian spesial.


Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah ayam gongso yang siap dikreasikan. Anda bisa menyiapkan Ayam Gongso memakai 11 bahan dan 6 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Gongso:

1. Ambil 1/2 kg dada ayam
1. Ambil Sedikit kol
1. Ambil Sedikit sawi hijau
1. Siapkan  Daun bawang
1. Siapkan 1 butir telur
1. Ambil 2 siung bawang putih
1. Gunakan 3 cabe rawit
1. Sediakan  Saos pedas (bs tomat klo g suka pedas)
1. Siapkan  Kecap manis dan asin
1. Siapkan 1/2 sdt Merica bubuk
1. Gunakan Secukupnya garam dan penyedap




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Gongso:

1. Siapkan bahan...Cuci bersih ayam,masak dengan bumbu (me : bumbu racik ayam goreng) smp matang dan empuk
1. Goreng sebentar jangan terlalu kering agar tdk keras. Kemudian suwir2 kecil sesuai selera
1. Geprek bawang putih,kemudian tumis hingga harum,masukkan telur,saat setengah matang,masukkan daun bawang dan cabe. Tumis hingga harum
1. Tambahkan sedikit air agar tdk gosong,lalu masukkan sayur yg sudah dipotong kecil2.
1. Tambahkan kecap,saos,garam dan merica. Terakhir masukkan ayam,sambil diaduk2 hingga matang.
1. Ayam gongso sudah matang,siap disajikan. Selamat mencoba. Semoga bermanfaat.




Gimana nih? Mudah bukan? Itulah cara membuat ayam gongso yang bisa Anda praktikkan di rumah. Selamat mencoba!
