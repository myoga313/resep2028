---
description: "Resep masakan Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳 | Cara Masak Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳 Yang Menggugah Selera"
title: "Resep masakan Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳 | Cara Masak Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳 Yang Menggugah Selera"
slug: 178-resep-masakan-gongso-ayam-pedas-khas-semarang-dapurwiwin-cara-masak-gongso-ayam-pedas-khas-semarang-dapurwiwin-yang-menggugah-selera
date: 2020-08-30T05:58:22.195Z
image: https://img-global.cpcdn.com/recipes/805edecca99c9ca2/751x532cq70/gongso-ayam-pedas-khas-semarang-dapurwiwin-👩🏻🍳-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/805edecca99c9ca2/751x532cq70/gongso-ayam-pedas-khas-semarang-dapurwiwin-👩🏻🍳-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/805edecca99c9ca2/751x532cq70/gongso-ayam-pedas-khas-semarang-dapurwiwin-👩🏻🍳-foto-resep-utama.jpg
author: Eva Cook
ratingvalue: 3
reviewcount: 6
recipeingredient:
- " Bahan"
- "1 ekor ayam kampung suwirsuwir"
- "5 Buah Cabe Rawit Setan"
- "sesuai selera Kobis"
- "1/2 Buah Tomat"
- "1/2 Bawang Bombay"
- " Daun BawangLoncang"
- "1 ruas lengkuas"
- "secukupnya Kecap Manis"
- "secukupnya Gula Garam"
- "secukupnya Air"
- " Bahan Bumbu Halus"
- "5 Siung Bawang Merah"
- "2 Siung Bawang Putih"
- "3 Buah Cabe Merah"
- "3 Butir Kemiri"
recipeinstructions:
- "Siapkan bahan."
- "Uleg bumbu halus."
- "Suwir-suwir ayam sesuai selera, geprek lengkuas, cincang bombay, iris-iris (kobis, daun bawang, cabe merah, tomat)."
- "Tumis bombay cincang + bumbu halus hingga harum, masukkan ayam suwir, tambahkan air, kemudian kobis, daun bawang, tomat dan cabe rawit utuh."
- "Aduk-aduk sebentar tunggu hingga airnya meresap biar mantap, kemudian hidangkan."
categories:
- Resep
tags:
- gongso
- ayam
- pedas

katakunci: gongso ayam pedas 
nutrition: 185 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Dessert

---


![Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳](https://img-global.cpcdn.com/recipes/805edecca99c9ca2/751x532cq70/gongso-ayam-pedas-khas-semarang-dapurwiwin-👩🏻🍳-foto-resep-utama.jpg)

Lagi mencari inspirasi resep gongso ayam pedas khas semarang #dapurwiwin 👩🏻‍🍳 yang Enak Dan Lezat? Cara Bikinnya memang tidak terlalu sulit namun tidak gampang juga. seumpama keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso ayam pedas khas semarang #dapurwiwin 👩🏻‍🍳 yang enak seharusnya mempunyai aroma dan cita rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ayam pedas khas semarang #dapurwiwin 👩🏻‍🍳, pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tak perlu pusing jika hendak menyiapkan gongso ayam pedas khas semarang #dapurwiwin 👩🏻‍🍳 yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian istimewa.


Di bawah ini ada beberapa tips dan trik praktis dalam mengolah gongso ayam pedas khas semarang #dapurwiwin 👩🏻‍🍳 yang siap dikreasikan. Anda dapat membuat Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳 menggunakan 16 jenis bahan dan 5 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳:

1. Gunakan  Bahan
1. Ambil 1 ekor ayam kampung (suwir-suwir)
1. Siapkan 5 Buah Cabe Rawit Setan
1. Siapkan sesuai selera Kobis
1. Siapkan 1/2 Buah Tomat
1. Sediakan 1/2 Bawang Bombay
1. Gunakan  Daun Bawang/Loncang
1. Ambil 1 ruas lengkuas
1. Gunakan secukupnya Kecap Manis
1. Siapkan secukupnya Gula Garam
1. Ambil secukupnya Air
1. Gunakan  Bahan Bumbu Halus
1. Ambil 5 Siung Bawang Merah
1. Siapkan 2 Siung Bawang Putih
1. Ambil 3 Buah Cabe Merah
1. Gunakan 3 Butir Kemiri




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳:

1. Siapkan bahan.
1. Uleg bumbu halus.
1. Suwir-suwir ayam sesuai selera, geprek lengkuas, cincang bombay, iris-iris (kobis, daun bawang, cabe merah, tomat).
1. Tumis bombay cincang + bumbu halus hingga harum, masukkan ayam suwir, tambahkan air, kemudian kobis, daun bawang, tomat dan cabe rawit utuh.
1. Aduk-aduk sebentar tunggu hingga airnya meresap biar mantap, kemudian hidangkan.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳">



Terima kasih telah membaca resep yang tim kami tampilkan di sini. Harapan kami, olahan Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳 yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman maupun menjadi inspirasi untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
