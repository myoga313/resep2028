---
description: "Bahan Ayam gongso cabe ijo | Cara Mengolah Ayam gongso cabe ijo Yang Enak Banget"
title: "Bahan Ayam gongso cabe ijo | Cara Mengolah Ayam gongso cabe ijo Yang Enak Banget"
slug: 233-bahan-ayam-gongso-cabe-ijo-cara-mengolah-ayam-gongso-cabe-ijo-yang-enak-banget
date: 2020-08-24T06:41:58.844Z
image: https://img-global.cpcdn.com/recipes/0dfa28a441df89f3/751x532cq70/ayam-gongso-cabe-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0dfa28a441df89f3/751x532cq70/ayam-gongso-cabe-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0dfa28a441df89f3/751x532cq70/ayam-gongso-cabe-ijo-foto-resep-utama.jpg
author: Mildred Henry
ratingvalue: 3.8
reviewcount: 11
recipeingredient:
- " dada ayam fillet potong dadu"
- " kecil kol iris kasar"
- " kecil tomat merah belah 4"
- " cabe ijo besar potong2 besar"
- " cabe rawit utuh"
- " daun salam"
- " lengkuas"
- " garam kaldu bubuk dan lada bubuk"
- " kecap manis"
- " air"
- " Minyak untuk menumis"
- " Bawang goreng"
- " Haluskan "
- " bawang merah"
- " bawang putih"
- " cabe merah keriting"
- " kemiri"
recipeinstructions:
- "Siapkan semua bahan..."
- "Tumis bumbu halus hingga harum. Masukkan potongan daging ayam, daun salam dan lengkuas. Masak sampai ayam berubah warna."
- "Tuangi air dan aduk2. Masak sampai air menyusut kemudian masukkan kol."
- "Setelah kol ayam dan kol matang, masukkan irisan cabe ijo, tomat juga cabe rawit utuh."
- "Bumbui dengan garam dan lada bubuk, cek rasa. Beri kaldu bubuk dan terakhir tuang kecap manis. Aduk rata...angkat, sajikan dengan bawang goreng."
categories:
- Resep
tags:
- ayam
- gongso
- cabe

katakunci: ayam gongso cabe 
nutrition: 123 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam gongso cabe ijo](https://img-global.cpcdn.com/recipes/0dfa28a441df89f3/751x532cq70/ayam-gongso-cabe-ijo-foto-resep-utama.jpg)

Anda sedang mencari ide resep ayam gongso cabe ijo yang Bisa Manjain Lidah? Cara membuatnya memang susah-susah gampang. Jika keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal ayam gongso cabe ijo yang enak seharusnya memiliki aroma dan rasa yang mampu memancing selera kita.

Lihat juga resep Gongso Ayam ala Semarangan enak lainnya. There are no reviews for Ayam Kampoeng Cabe Ijo, Indonesia yet. Be the first to write a review!

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso cabe ijo, pertama dari jenis bahan, kemudian pemilihan bahan segar sampai cara membuat dan menyajikannya. Tidak usah pusing kalau ingin menyiapkan ayam gongso cabe ijo yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.


Nah, kali ini kita coba, yuk, ciptakan ayam gongso cabe ijo sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Ayam gongso cabe ijo memakai 17 jenis bahan dan 5 tahap pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam gongso cabe ijo:

1. Ambil  dada ayam fillet, potong dadu
1. Siapkan  (kecil) kol, iris kasar
1. Sediakan  (kecil) tomat merah, belah 4
1. Gunakan  cabe ijo besar, potong2 besar
1. Gunakan  cabe rawit utuh
1. Gunakan  daun salam
1. Gunakan  lengkuas
1. Sediakan  garam, kaldu bubuk dan lada bubuk
1. Siapkan  kecap manis
1. Siapkan  air
1. Gunakan  Minyak untuk menumis
1. Siapkan  Bawang goreng
1. Ambil  Haluskan :
1. Sediakan  bawang merah
1. Gunakan  bawang putih
1. Gunakan  cabe merah keriting
1. Ambil  kemiri


Di Opa Resto kami menyediakan menu ini berupa nasi yang dikemas lengkap dengan lauk pauknya yaitu daging sapi bumbu, ayam gongso/rica-rica, bakmie, kentang, kering tempe, acar kuning dan sambal goreng ati. Sangat praktis, bersih dan tentu saja enak rasanya. Resep Ayam Cabai Ijo dan Cara Memasaknya dengan Mudah Cepat dan Nikmat. Sering kali kita mendapati masakan yang berbahan ayam baik Ayam dengan balutan sambell ijo yang tingkat pedasnya dijamin standar. 

<!--inarticleads2-->

##### Cara membuat Ayam gongso cabe ijo:

1. Siapkan semua bahan...
1. Tumis bumbu halus hingga harum. Masukkan potongan daging ayam, daun salam dan lengkuas. Masak sampai ayam berubah warna.
1. Tuangi air dan aduk2. Masak sampai air menyusut kemudian masukkan kol.
1. Setelah kol ayam dan kol matang, masukkan irisan cabe ijo, tomat juga cabe rawit utuh.
1. Bumbui dengan garam dan lada bubuk, cek rasa. Beri kaldu bubuk dan terakhir tuang kecap manis. Aduk rata...angkat, sajikan dengan bawang goreng.


Ini juga aman dilambung kok Bunda baik untuk suami, anak-anak maupun. Untuk penyajiannya, ayam cabe ijo bisa disajikan bersama nasi putih hangat dan lalapan mentimun. Bisa juga disajikan seperti di rumah makan padang; sajikan bersama rebusan daun singkong muda. Pasti akan membuat acara santap siang ataupun santap malam di rumah anda terasa sangat istimewa. Haii hari ini aku akan share resep dan cara membuat ayam suwir Bahan&#34;nya : daging ayam Bumbu&#34;nya : Bawang bombay Cabe. 

Gimana nih? Gampang kan? Itulah cara membuat ayam gongso cabe ijo yang bisa Anda praktikkan di rumah. Selamat mencoba!
