---
description: "Bumbu Gongso Ati Ampela | Resep Bumbu Gongso Ati Ampela Yang Enak Dan Mudah"
title: "Bumbu Gongso Ati Ampela | Resep Bumbu Gongso Ati Ampela Yang Enak Dan Mudah"
slug: 485-bumbu-gongso-ati-ampela-resep-bumbu-gongso-ati-ampela-yang-enak-dan-mudah
date: 2020-08-18T02:42:20.444Z
image: https://img-global.cpcdn.com/recipes/ff2a775d19da276a/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ff2a775d19da276a/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ff2a775d19da276a/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
author: Walter Cross
ratingvalue: 3.1
reviewcount: 10
recipeingredient:
- " ati ampela potong2"
- " daun salam"
- " daun jeruk"
- " stengah ruas lengkuas geprek"
- " tomat ptong2"
- " kecap manis"
- " gula dan garam"
- " cabai rawit utuh saya 10 krna suka pedes"
- " air"
- " Bumbu halus"
- " bawang merah"
- " bawang putih"
- " kunyit"
- " cabai merah besar"
- " cabai rawit"
recipeinstructions:
- "Siapkan bahan, Rebus ati ampela kurleb 10 menit. Siapkan bumbu Ulek/bumbu halus."
- "Tumis bumbu halus hingga harum, masukan daun salam, daun jeruk, dan lengkuas, masukan kecap."
- "Masukan ati ampela lalu tambahkan air, beri garam, dan gula, ciicipi.. masukan tomat dan cabai utuh, aduk hingga rata. Angkat.."
categories:
- Resep
tags:
- gongso
- ati
- ampela

katakunci: gongso ati ampela 
nutrition: 294 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Lunch

---


![Gongso Ati Ampela](https://img-global.cpcdn.com/recipes/ff2a775d19da276a/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg)

Kamu Sedang mencari inspirasi resep gongso ati ampela yang Enak dan Simpel? Cara Memasaknya memang tidak susah dan tidak juga mudah. jikalau keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gongso ati ampela yang enak seharusnya memiliki aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ati ampela, mulai dari jenis bahan, kemudian pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tak perlu pusing jika ingin menyiapkan gongso ati ampela enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian istimewa.


Di bawah ini ada beberapa tips dan trik praktis untuk membuat gongso ati ampela yang siap dikreasikan. Anda bisa membuat Gongso Ati Ampela memakai 15 bahan dan 3 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Gongso Ati Ampela:

1. Sediakan  ati ampela, potong2
1. Ambil  daun salam
1. Siapkan  daun jeruk
1. Ambil  stengah ruas lengkuas, geprek
1. Gunakan  tomat, ptong2
1. Ambil  kecap manis
1. Gunakan  gula dan garam
1. Ambil  cabai rawit utuh (saya 10 krna suka pedes)
1. Sediakan  air
1. Ambil  Bumbu halus
1. Ambil  bawang merah
1. Siapkan  bawang putih
1. Siapkan  kunyit
1. Ambil  cabai merah besar
1. Sediakan  cabai rawit




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso Ati Ampela:

1. Siapkan bahan, Rebus ati ampela kurleb 10 menit. Siapkan bumbu Ulek/bumbu halus.
1. Tumis bumbu halus hingga harum, masukan daun salam, daun jeruk, dan lengkuas, masukan kecap.
1. Masukan ati ampela lalu tambahkan air, beri garam, dan gula, ciicipi.. masukan tomat dan cabai utuh, aduk hingga rata. Angkat..




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan Gongso Ati Ampela yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman maupun menjadi ide bagi Anda yang berkeinginan untuk berbisnis kuliner. Selamat mencoba!
