---
description: "Olahan Gongso ayam | Langkah Membuat Gongso ayam Yang Enak Dan Lezat"
title: "Olahan Gongso ayam | Langkah Membuat Gongso ayam Yang Enak Dan Lezat"
slug: 244-olahan-gongso-ayam-langkah-membuat-gongso-ayam-yang-enak-dan-lezat
date: 2020-08-19T11:19:35.918Z
image: https://img-global.cpcdn.com/recipes/0928f4bdbfe5f6a0/751x532cq70/gongso-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0928f4bdbfe5f6a0/751x532cq70/gongso-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0928f4bdbfe5f6a0/751x532cq70/gongso-ayam-foto-resep-utama.jpg
author: Austin Barber
ratingvalue: 5
reviewcount: 9
recipeingredient:
- "1/2 kg ayam"
- " jeruk nipis"
- " bumbu iris "
- "3 btr bawang putih geprek"
- "1/2 btr bombay iris kasar"
- "3 bh cabe merah teropong iris kasar memanjang"
- "3 bh cabe ijo teropong iris kasar memanjang"
- "1 ruas jahe geprek"
- " bumbu tambahan "
- "3 sdm kecap manis"
- "2 sdm saos tiram"
- "1 sdm saos sambal"
- "1/2 bh tomat bagi 5"
- "secukupnya garam penyedap"
recipeinstructions:
- "Cuci bersih ayam, lalu lumuri air nipis, diamkan sekitar 5 mnt, cuci lagi"
- "Rebus ayam dengan 1 ruas jahe agar tidak amis, setelah matang matikan api"
- "Tumis bumbu iris smp agak layu lalu masukkan ayam..kemudian tambahkan kecap manis, saos tiram dan saos sambal"
- "Aduk&#34; agar tidak gosong..."
- "Sesaat sebelum diangkat masukkan potongan tomat.. aduk smp agak layu, kemudian angkat,"
- "Note : masak dengan api besar ya...dan akan lebih sedap jika ada daun bawang yg diiris kasar...dimasukkan bersamaan dengan tomat.."
categories:
- Resep
tags:
- gongso
- ayam

katakunci: gongso ayam 
nutrition: 254 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Lunch

---


![Gongso ayam](https://img-global.cpcdn.com/recipes/0928f4bdbfe5f6a0/751x532cq70/gongso-ayam-foto-resep-utama.jpg)

Sedang mencari ide resep gongso ayam yang Enak Dan Mudah? Cara Buatnya memang tidak susah dan tidak juga mudah. jikalau salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso ayam yang enak seharusnya punya aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ayam, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan gongso ayam yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.


Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah gongso ayam yang siap dikreasikan. Anda dapat membuat Gongso ayam memakai 14 bahan dan 6 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Gongso ayam:

1. Siapkan 1/2 kg ayam
1. Ambil  jeruk nipis
1. Gunakan  bumbu iris&#34; :
1. Ambil 3 btr bawang putih geprek
1. Sediakan 1/2 btr bombay iris kasar
1. Gunakan 3 bh cabe merah teropong iris kasar memanjang
1. Gunakan 3 bh cabe ijo teropong iris kasar memanjang
1. Siapkan 1 ruas jahe geprek
1. Siapkan  bumbu tambahan :
1. Gunakan 3 sdm kecap manis
1. Siapkan 2 sdm saos tiram
1. Sediakan 1 sdm saos sambal
1. Sediakan 1/2 bh tomat bagi 5
1. Gunakan secukupnya garam, penyedap




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso ayam:

1. Cuci bersih ayam, lalu lumuri air nipis, diamkan sekitar 5 mnt, cuci lagi
1. Rebus ayam dengan 1 ruas jahe agar tidak amis, setelah matang matikan api
1. Tumis bumbu iris smp agak layu lalu masukkan ayam..kemudian tambahkan kecap manis, saos tiram dan saos sambal
1. Aduk&#34; agar tidak gosong...
1. Sesaat sebelum diangkat masukkan potongan tomat.. aduk smp agak layu, kemudian angkat,
1. Note : masak dengan api besar ya...dan akan lebih sedap jika ada daun bawang yg diiris kasar...dimasukkan bersamaan dengan tomat..




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Harapan kami, olahan Gongso ayam yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman ataupun menjadi ide untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
