---
description: "Bahan Rica Rica bumbu Gongso Kulit Ayam | Cara Bikin Rica Rica bumbu Gongso Kulit Ayam Yang Lezat Sekali"
title: "Bahan Rica Rica bumbu Gongso Kulit Ayam | Cara Bikin Rica Rica bumbu Gongso Kulit Ayam Yang Lezat Sekali"
slug: 201-bahan-rica-rica-bumbu-gongso-kulit-ayam-cara-bikin-rica-rica-bumbu-gongso-kulit-ayam-yang-lezat-sekali
date: 2020-11-07T00:06:41.417Z
image: https://img-global.cpcdn.com/recipes/769116f84f200474/751x532cq70/rica-rica-bumbu-gongso-kulit-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/769116f84f200474/751x532cq70/rica-rica-bumbu-gongso-kulit-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/769116f84f200474/751x532cq70/rica-rica-bumbu-gongso-kulit-ayam-foto-resep-utama.jpg
author: Frank Alexander
ratingvalue: 5
reviewcount: 13
recipeingredient:
- "500 gr kulit ayam"
- "3 siung bawang merah diiris tipis"
- "3 siung bawang putih diiris tipis"
- "4 buah cabai rawit dipotong kecil ato sesuai selera"
- "2 buah cabai merah keriting"
- "secukupnya Lada bubuk"
- "secukupnya Garam"
- "secukupnya Margarin"
- "secukupnya Kaldu bubuk"
- "3 sdm saos tiram"
- "3 sdm kecap manis"
- " Lengkuas digeprek"
- " Gula merah disisir halus"
- "secukupnya Vetsin"
- "secukupnya Air"
recipeinstructions:
- "Bersihkan kulit ayam dengan air hangat supaya tidak amis"
- "Panaskan margarin dalam wajan kemudian masukkan bawang putih dan tunggu sampe keluar aromanya"
- "Masukkan bawang merah, cabai rawit, cabai keriting, gula jawa sisir, dan lengkuas kemudian tunggu hingga meleleh dan agak kering / gongso"
- "Masukkan air secukupnya, kemudian tunggu hingga mendidih."
- "Setelah mendidih maka masukkan saos tiram, kecap manis, vetsin dan lada bubuk."
- "Koreksi rasanya. Apabila kurang pedas bisa ditambahkan dengan cabai rawit."
- "Setelah terlihat matang, masukkan kulit ayam kedalamnya dan tunggu hingga meresap. Sisakan sedikit air di dalam masakannya."
- "Koreksi rasanya kembali dan rica gongo kulit ayam siap dihidangkan"
categories:
- Resep
tags:
- rica
- rica
- bumbu

katakunci: rica rica bumbu 
nutrition: 273 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Dessert

---


![Rica Rica bumbu Gongso Kulit Ayam](https://img-global.cpcdn.com/recipes/769116f84f200474/751x532cq70/rica-rica-bumbu-gongso-kulit-ayam-foto-resep-utama.jpg)

Lagi mencari ide resep rica rica bumbu gongso kulit ayam yang Bisa Manjain Lidah? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. semisal keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal rica rica bumbu gongso kulit ayam yang enak seharusnya punya aroma dan rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari rica rica bumbu gongso kulit ayam, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menyajikannya. Tidak usah pusing jika hendak menyiapkan rica rica bumbu gongso kulit ayam yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.


Nah, kali ini kita coba, yuk, buat rica rica bumbu gongso kulit ayam sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Rica Rica bumbu Gongso Kulit Ayam memakai 15 jenis bahan dan 8 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Rica Rica bumbu Gongso Kulit Ayam:

1. Sediakan 500 gr kulit ayam
1. Gunakan 3 siung bawang merah diiris tipis
1. Sediakan 3 siung bawang putih diiris tipis
1. Sediakan 4 buah cabai rawit dipotong kecil ato sesuai selera
1. Ambil 2 buah cabai merah keriting
1. Siapkan secukupnya Lada bubuk
1. Ambil secukupnya Garam
1. Sediakan secukupnya Margarin
1. Gunakan secukupnya Kaldu bubuk
1. Sediakan 3 sdm saos tiram
1. Sediakan 3 sdm kecap manis
1. Gunakan  Lengkuas digeprek
1. Gunakan  Gula merah disisir halus
1. Gunakan secukupnya Vetsin
1. Gunakan secukupnya Air




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Rica Rica bumbu Gongso Kulit Ayam:

1. Bersihkan kulit ayam dengan air hangat supaya tidak amis
1. Panaskan margarin dalam wajan kemudian masukkan bawang putih dan tunggu sampe keluar aromanya
1. Masukkan bawang merah, cabai rawit, cabai keriting, gula jawa sisir, dan lengkuas kemudian tunggu hingga meleleh dan agak kering / gongso
1. Masukkan air secukupnya, kemudian tunggu hingga mendidih.
1. Setelah mendidih maka masukkan saos tiram, kecap manis, vetsin dan lada bubuk.
1. Koreksi rasanya. Apabila kurang pedas bisa ditambahkan dengan cabai rawit.
1. Setelah terlihat matang, masukkan kulit ayam kedalamnya dan tunggu hingga meresap. Sisakan sedikit air di dalam masakannya.
1. Koreksi rasanya kembali dan rica gongo kulit ayam siap dihidangkan




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Harapan kami, olahan Rica Rica bumbu Gongso Kulit Ayam yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman maupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Selamat mencoba!
