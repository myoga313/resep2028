---
description: "Resep masakan Gongso ati ampla pedas | Langkah Membuat Gongso ati ampla pedas Yang Enak dan Simpel"
title: "Resep masakan Gongso ati ampla pedas | Langkah Membuat Gongso ati ampla pedas Yang Enak dan Simpel"
slug: 77-resep-masakan-gongso-ati-ampla-pedas-langkah-membuat-gongso-ati-ampla-pedas-yang-enak-dan-simpel
date: 2020-10-06T15:58:26.206Z
image: https://img-global.cpcdn.com/recipes/e90dbb9a393478e9/751x532cq70/gongso-ati-ampla-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e90dbb9a393478e9/751x532cq70/gongso-ati-ampla-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e90dbb9a393478e9/751x532cq70/gongso-ati-ampla-pedas-foto-resep-utama.jpg
author: Lida Kim
ratingvalue: 4.3
reviewcount: 13
recipeingredient:
- "10 pasang ati ampla"
- " Bumbu halus"
- "25 buah cabe rawit merahtergantung selera ya Bun"
- "10 cabe merah keriting"
- "2 buah cabe merah besar buang biji"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "1 ruas kunyit"
- " Bumbu cemplung"
- "5 lembar daun jeruk buang batang tengahnya"
- "Secukupnya lengkoas geprek"
- "4 lembar daun salam"
- "1 sdt lada bubuk"
- "4 sdm kecap manis"
- "Secukup nya garam"
- "Secukupnya kaldu bubuk"
- "1 sdt gula pasir"
- " Setngh gelas belimbing air"
- "Sedikit minyak untuk menumis"
recipeinstructions:
- "Bersihkan ati ampla lalu cuci dan rebus,beri sedikit garam,jeruk nipis dan sedikit kecap Inggris,rebus sampai matang dan sisihkan"
- "Panaskan minyak tumis bumbu halus sampai harum tambahkan bumbu cemplung aduk rata"
- "Masukkan ati ampla yg sudah direbus td,beri sedikit air,garam,gula pasir, penyedap rasa,lada dan kecap aduk rata"
- "Masak sampai matang dan sedikit kental lalu koreksi rasa,jika sudah pas dan matang segera angkat dan sajikan"
categories:
- Resep
tags:
- gongso
- ati
- ampla

katakunci: gongso ati ampla 
nutrition: 193 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Dinner

---


![Gongso ati ampla pedas](https://img-global.cpcdn.com/recipes/e90dbb9a393478e9/751x532cq70/gongso-ati-ampla-pedas-foto-resep-utama.jpg)

Bunda Sedang mencari ide resep gongso ati ampla pedas yang Enak Dan Mudah? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. seumpama keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso ati ampla pedas yang enak seharusnya memiliki aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ati ampla pedas, pertama dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tidak usah pusing jika mau menyiapkan gongso ati ampla pedas enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.

Lihat juga resep Gongso Ayam ala Semarangan enak lainnya. Sehingga Warung Gongso Mbak Ninie cocok untuk semua kalangan.. Yuk segera kesini aja, rasanya bikin kamu pengen dateng lagi.. .


Di bawah ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah gongso ati ampla pedas yang siap dikreasikan. Anda dapat membuat Gongso ati ampla pedas memakai 19 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Gongso ati ampla pedas:

1. Sediakan 10 pasang ati ampla
1. Ambil  Bumbu halus
1. Sediakan 25 buah cabe rawit merah(tergantung selera ya Bun)
1. Siapkan 10 cabe merah keriting
1. Siapkan 2 buah cabe merah besar buang biji
1. Ambil 10 siung bawang merah
1. Ambil 5 siung bawang putih
1. Sediakan 1 ruas kunyit
1. Siapkan  Bumbu cemplung
1. Siapkan 5 lembar daun jeruk buang batang tengahnya
1. Gunakan Secukupnya lengkoas geprek
1. Sediakan 4 lembar daun salam
1. Siapkan 1 sdt lada bubuk
1. Gunakan 4 sdm kecap manis
1. Siapkan Secukup nya garam
1. Siapkan Secukupnya kaldu bubuk
1. Siapkan 1 sdt gula pasir
1. Ambil  Setngh gelas belimbing air
1. Gunakan Sedikit minyak untuk menumis


Selain daging ayam, bahan lain seperti babat iso, ati ampela dan telur juga cocok dimasak gongso. Saat digongso atau ditumis masih dipadu beberapa bumbu termasuk lombok, sehingga ada juga rasa pedas,&#34; ungkap pengelola. Babat Gongso Terenak di Semarang - Super Pedas Manis Mantap Jiwa. Saat mencicipi babat gongso telur, bumbunya sangat terasa. &#34;Untuk bumbu intinya yang digunakan adalah bawang merah, bawang putih, dan cabai,&#34; jelas Dian. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso ati ampla pedas:

1. Bersihkan ati ampla lalu cuci dan rebus,beri sedikit garam,jeruk nipis dan sedikit kecap Inggris,rebus sampai matang dan sisihkan
1. Panaskan minyak tumis bumbu halus sampai harum tambahkan bumbu cemplung aduk rata
1. Masukkan ati ampla yg sudah direbus td,beri sedikit air,garam,gula pasir, penyedap rasa,lada dan kecap aduk rata
1. Masak sampai matang dan sedikit kental lalu koreksi rasa,jika sudah pas dan matang segera angkat dan sajikan


Babat yang dimasak dengan beragam bumbu dengan tambahan telur menghasilkan perpaduan rasa gurih dan sedikit pedas sangat cocok. Nasi goreng ati ampela spesial dapat anda sajikan di tengah kelaurga anda. Yuk, coba di rumah anda dengan panduan resep di bawah ini. Nasi goreng yang spesial dari bahan utama nasi dan ati ampela yang memiliki cita rasa yang pedas akan menambah selera makan keluarga anda. Babat Gongso Terenak Di Semarang Super Pedas Manis Mantap Jiwa. 

Bagaimana? Gampang kan? Itulah cara membuat gongso ati ampla pedas yang bisa Anda praktikkan di rumah. Selamat mencoba!
