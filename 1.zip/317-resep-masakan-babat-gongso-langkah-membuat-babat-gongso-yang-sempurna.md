---
description: "Resep masakan Babat gongso | Langkah Membuat Babat gongso Yang Sempurna"
title: "Resep masakan Babat gongso | Langkah Membuat Babat gongso Yang Sempurna"
slug: 317-resep-masakan-babat-gongso-langkah-membuat-babat-gongso-yang-sempurna
date: 2020-10-03T20:05:55.733Z
image: https://img-global.cpcdn.com/recipes/e2413d99b10af22d/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e2413d99b10af22d/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e2413d99b10af22d/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Elmer Rodriquez
ratingvalue: 4.4
reviewcount: 5
recipeingredient:
- " babat yg sdh di rebus"
- " Kol"
- " tomat"
- " cabe rawit merahselera jika suka pedas bs tambahkan"
- " cabe merah keriting"
- " bawang merah"
- " bawang putih"
- " lada bubuk"
- " garam"
- " gula merah"
- " penyedap me royko"
- " daun salam"
- " saus tiram"
- " kecap manis"
- " air"
- " Bahan rebus babat"
- " bawang merah"
- " bawang putih"
- " ketumbar"
- " daun jeruk"
- " daun salam"
- " lengkuas"
- " garam"
recipeinstructions:
- "Cuci bersih babat. Uleg bahan-bahan yg untuk merebus babat (bawang merah,bawang putih,ketumbar,daun jeruk) lalu rebus babat dg bumbu yg sdh dihaluskan dan tambahkan daun salam,lengkuas (geprek),garam sampai matang."
- "Uleg bumbu (cabe rawit merah,cabe merah keriting,bawang merah,bawang putih) sampai halus lalu tumis/gongso bumbu yg sdh dihaluskan dan tambahkan garam,gula merah,lada bubuk,penyedap rasa,daun salam sampai harum lalu masukkan babat yg sdh direbut td,jgn lupa babat dipotong-potong terlebih dahulu lalu tambahkan saus tiram,kecap manis,1 gelas belimbing air aduk-aduk sampai rata."
- "Dan terakhir masukkan kol yg di iris kasar kecil-kecil. (Note ya bun,kalau gak suka sayur blh di skip namun kalau mau pake sayur masukkinnya terakir krn nunggu babat meresap dg bumbu cpt layu). Test rasa dan siap dihidangkan."
- "Supaya cantik diatasnya di beri toping kol yg sudah diiris dan potongan tomat.Selamat mencoba🙏"
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 105 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Dinner

---


![Babat gongso](https://img-global.cpcdn.com/recipes/e2413d99b10af22d/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep babat gongso yang Enak Dan Mudah? Cara Bikinnya memang susah-susah gampang. misalnya keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal babat gongso yang enak seharusnya memiliki aroma dan cita rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan babat gongso enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian istimewa.




Nah, kali ini kita coba, yuk, variasikan babat gongso sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa membuat Babat gongso memakai 23 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Babat gongso:

1. Ambil  babat yg sdh di rebus
1. Gunakan  Kol
1. Siapkan  tomat
1. Ambil  cabe rawit merah(selera jika suka pedas bs tambahkan)
1. Siapkan  cabe merah keriting
1. Ambil  bawang merah
1. Sediakan  bawang putih
1. Siapkan  lada bubuk
1. Gunakan  garam
1. Siapkan  gula merah
1. Siapkan  penyedap (me: royko)
1. Siapkan  daun salam
1. Siapkan  saus tiram
1. Gunakan  kecap manis
1. Ambil  air
1. Ambil  Bahan rebus babat
1. Sediakan  bawang merah
1. Siapkan  bawang putih
1. Gunakan  ketumbar
1. Sediakan  daun jeruk
1. Ambil  daun salam
1. Siapkan  lengkuas
1. Ambil  garam




<!--inarticleads2-->

##### Cara membuat Babat gongso:

1. Cuci bersih babat. Uleg bahan-bahan yg untuk merebus babat (bawang merah,bawang putih,ketumbar,daun jeruk) lalu rebus babat dg bumbu yg sdh dihaluskan dan tambahkan daun salam,lengkuas (geprek),garam sampai matang.
1. Uleg bumbu (cabe rawit merah,cabe merah keriting,bawang merah,bawang putih) sampai halus lalu tumis/gongso bumbu yg sdh dihaluskan dan tambahkan garam,gula merah,lada bubuk,penyedap rasa,daun salam sampai harum lalu masukkan babat yg sdh direbut td,jgn lupa babat dipotong-potong terlebih dahulu lalu tambahkan saus tiram,kecap manis,1 gelas belimbing air aduk-aduk sampai rata.
1. Dan terakhir masukkan kol yg di iris kasar kecil-kecil. (Note ya bun,kalau gak suka sayur blh di skip namun kalau mau pake sayur masukkinnya terakir krn nunggu babat meresap dg bumbu cpt layu). Test rasa dan siap dihidangkan.
1. Supaya cantik diatasnya di beri toping kol yg sudah diiris dan potongan tomat.Selamat mencoba🙏




Bagaimana? Mudah bukan? Itulah cara membuat babat gongso yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
