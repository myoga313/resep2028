---
description: "Bahan Gongso Telur Sayuran Pedas | Cara Membuat Gongso Telur Sayuran Pedas Yang Sedap"
title: "Bahan Gongso Telur Sayuran Pedas | Cara Membuat Gongso Telur Sayuran Pedas Yang Sedap"
slug: 62-bahan-gongso-telur-sayuran-pedas-cara-membuat-gongso-telur-sayuran-pedas-yang-sedap
date: 2020-12-15T18:01:20.185Z
image: https://img-global.cpcdn.com/recipes/e5ada82ba3f2aefb/751x532cq70/gongso-telur-sayuran-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e5ada82ba3f2aefb/751x532cq70/gongso-telur-sayuran-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e5ada82ba3f2aefb/751x532cq70/gongso-telur-sayuran-pedas-foto-resep-utama.jpg
author: Lelia Bass
ratingvalue: 4.9
reviewcount: 9
recipeingredient:
- "2 btr telur kocok lepas"
- "1 bh tahu potong dadu kecil"
- "1 bh wortel potong stik"
- "5 bh boncis potong selera"
- "1 bh tomat merah potong dadu kecil"
- "1 btg seledri iris halus"
- "2 sdm margarin untuk menumis"
- "1 sdm kecap manis"
- "1 sdm saos pedas"
- "1 sdm bon cabe"
- "1 sdt merica bubuk"
- "1 sdt garam halus"
- "1 sdm gula pasir"
- " Bumbu halus "
- "5 bh cabe merah kriting"
- "2 siung bawang putih"
- "3 siung bawang merah"
recipeinstructions:
- "Siapkan bahan dan bumbu"
- "Kocok telur masukkan tahu aduk sampai tercampur, lalu di goreng orak arik, sisihkan"
- "Gongso bumbu dengan margarin sampai harum, tambahkan air tunggu sampai mendidih, lalu masukkan sayuran, bon cabe, garam, kecap dan saos pedas.... Aduk aduk tunggu sampai sayur setengah matang"
- "Kemudian masukkan tomat, gula, garam dan orak arik telur tahu aduk sampai tercampur rata, baru masukkan irisan seledri"
- "Terus diaduk supaya tidak gosong, koreksi rasa, sudah oke matikan kompor, pindahkan di piring saji.... Dan siap dinikmati.... SELESAI....."
categories:
- Resep
tags:
- gongso
- telur
- sayuran

katakunci: gongso telur sayuran 
nutrition: 272 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Dessert

---


![Gongso Telur Sayuran Pedas](https://img-global.cpcdn.com/recipes/e5ada82ba3f2aefb/751x532cq70/gongso-telur-sayuran-pedas-foto-resep-utama.jpg)

Kamu Sedang mencari ide resep gongso telur sayuran pedas yang Sempurna? Cara Bikinnya memang susah-susah gampang. andaikata keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso telur sayuran pedas yang enak harusnya sih punya aroma dan rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso telur sayuran pedas, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan gongso telur sayuran pedas yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian spesial.


Nah, kali ini kita coba, yuk, kreasikan gongso telur sayuran pedas sendiri di rumah. Tetap berbahan yang sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Gongso Telur Sayuran Pedas memakai 17 bahan dan 5 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Gongso Telur Sayuran Pedas:

1. Sediakan 2 btr telur, kocok lepas
1. Sediakan 1 bh tahu, potong dadu kecil
1. Gunakan 1 bh wortel, potong stik
1. Gunakan 5 bh boncis, potong selera
1. Ambil 1 bh tomat merah, potong dadu kecil
1. Ambil 1 btg seledri, iris halus
1. Gunakan 2 sdm margarin, untuk menumis
1. Siapkan 1 sdm kecap manis
1. Gunakan 1 sdm saos pedas
1. Gunakan 1 sdm bon cabe
1. Sediakan 1 sdt merica bubuk
1. Siapkan 1 sdt garam halus
1. Siapkan 1 sdm gula pasir
1. Ambil  Bumbu halus :
1. Siapkan 5 bh cabe merah kriting
1. Ambil 2 siung bawang putih
1. Gunakan 3 siung bawang merah




<!--inarticleads2-->

##### Cara membuat Gongso Telur Sayuran Pedas:

1. Siapkan bahan dan bumbu
1. Kocok telur masukkan tahu aduk sampai tercampur, lalu di goreng orak arik, sisihkan
1. Gongso bumbu dengan margarin sampai harum, tambahkan air tunggu sampai mendidih, lalu masukkan sayuran, bon cabe, garam, kecap dan saos pedas.... Aduk aduk tunggu sampai sayur setengah matang
1. Kemudian masukkan tomat, gula, garam dan orak arik telur tahu aduk sampai tercampur rata, baru masukkan irisan seledri
1. Terus diaduk supaya tidak gosong, koreksi rasa, sudah oke matikan kompor, pindahkan di piring saji.... Dan siap dinikmati.... SELESAI.....




Gimana nih? Gampang kan? Itulah cara menyiapkan gongso telur sayuran pedas yang bisa Anda praktikkan di rumah. Selamat mencoba!
