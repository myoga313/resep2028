---
description: "Olahan Babat gongso | Cara Buat Babat gongso Yang Paling Enak"
title: "Olahan Babat gongso | Cara Buat Babat gongso Yang Paling Enak"
slug: 476-olahan-babat-gongso-cara-buat-babat-gongso-yang-paling-enak
date: 2020-09-30T02:08:46.753Z
image: https://img-global.cpcdn.com/recipes/7a1ec8cd11442ec6/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7a1ec8cd11442ec6/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7a1ec8cd11442ec6/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Myrtle Harvey
ratingvalue: 4.9
reviewcount: 10
recipeingredient:
- "300 g babat sapi"
- "Secukupnya kapur sirih serai salam"
- "1 buah cabai merah besar iris tipis"
- "10 butir bawang merah iris kasar"
- "Secukupnya garam dan kaldu bubuk"
- "3-4 sdm kecap manis"
- " Haluskan "
- "10 buah cabai merah keriting"
- "4 siung bawang putih"
- "2 butir kemiri sangrai"
recipeinstructions:
- "Rendam babat di air kapur sirih 30-60 menit. Kerok dengan sendok sampai item2nya ilang. Cuci bersih. (Skip)"
- "Blansir mendidih 30 menit, buang airnya. Rebus dengan api kecil, tambahin salam, serai dan garam. Rebus sampai benar-benar empuk. Tiriskan dan potong-potong."
- "Sementara nunggu merrbus, siapkan bahan-bahan lain."
- "Panaskan minyak, tumis bumbu halus sampai harum dan matang. Masukkan babat, bawang merah, cabe. Tambahkan sedikit air. Bumbui dengan kecap, garam, kaldu. Koreksi rasa. Masak hingga air surut."
- "Angkat dan sajikan."
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 258 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Lunch

---


![Babat gongso](https://img-global.cpcdn.com/recipes/7a1ec8cd11442ec6/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Bunda lagi mencari inspirasi resep babat gongso yang Bikin Ngiler? Cara membuatnya memang susah-susah gampang. semisal keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal babat gongso yang enak seharusnya memiliki aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari babat gongso, pertama dari jenis bahan, lalu pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tidak usah pusing jika ingin menyiapkan babat gongso enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian spesial.




Berikut ini ada beberapa cara mudah dan praktis dalam mengolah babat gongso yang siap dikreasikan. Anda bisa menyiapkan Babat gongso memakai 10 bahan dan 5 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Babat gongso:

1. Ambil 300 g babat sapi
1. Ambil Secukupnya kapur sirih, serai, salam
1. Sediakan 1 buah cabai merah besar, iris tipis
1. Ambil 10 butir bawang merah, iris kasar
1. Gunakan Secukupnya garam dan kaldu bubuk
1. Siapkan 3-4 sdm kecap manis
1. Ambil  Haluskan ::
1. Gunakan 10 buah cabai merah keriting
1. Sediakan 4 siung bawang putih
1. Sediakan 2 butir kemiri sangrai




<!--inarticleads2-->

##### Langkah-langkah membuat Babat gongso:

1. Rendam babat di air kapur sirih 30-60 menit. Kerok dengan sendok sampai item2nya ilang. Cuci bersih. (Skip)
1. Blansir mendidih 30 menit, buang airnya. Rebus dengan api kecil, tambahin salam, serai dan garam. Rebus sampai benar-benar empuk. Tiriskan dan potong-potong.
1. Sementara nunggu merrbus, siapkan bahan-bahan lain.
1. Panaskan minyak, tumis bumbu halus sampai harum dan matang. Masukkan babat, bawang merah, cabe. Tambahkan sedikit air. Bumbui dengan kecap, garam, kaldu. Koreksi rasa. Masak hingga air surut.
1. Angkat dan sajikan.




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Harapan kami, olahan Babat gongso yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman maupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
