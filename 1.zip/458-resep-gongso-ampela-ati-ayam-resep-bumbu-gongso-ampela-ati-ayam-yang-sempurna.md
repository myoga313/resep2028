---
description: "Resep Gongso ampela ati Ayam | Resep Bumbu Gongso ampela ati Ayam Yang Sempurna"
title: "Resep Gongso ampela ati Ayam | Resep Bumbu Gongso ampela ati Ayam Yang Sempurna"
slug: 458-resep-gongso-ampela-ati-ayam-resep-bumbu-gongso-ampela-ati-ayam-yang-sempurna
date: 2020-12-21T06:31:08.739Z
image: https://img-global.cpcdn.com/recipes/32a497c23c0bca3b/751x532cq70/gongso-ampela-ati-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/32a497c23c0bca3b/751x532cq70/gongso-ampela-ati-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/32a497c23c0bca3b/751x532cq70/gongso-ampela-ati-ayam-foto-resep-utama.jpg
author: Jerome Frazier
ratingvalue: 3.5
reviewcount: 14
recipeingredient:
- " ampla ati ayam"
- " cabe ijo tw"
- " Bumbu"
- " cabe rawit galak"
- " cabe merah kriting"
- " bawang merah"
- " bawang putih"
- " tomat"
- " lengkuas"
- " daun salam"
- " bumbu kaldu"
- " gula pasir"
- " garam"
- " minyak goreng"
recipeinstructions:
- "Cuci bersih ampla ati lalu rebus dan potong2 menurut selera"
- "Haluskan bumbu dan potong2 cabe ijonya..lalu tumis bumbu halus sampe wangi dan masukkan ampla atinya"
- "Setelah ampla masuk lalu masukkan cabe ijonya aduk rata tambahkan semua bumbu tambahannya..tambahkan sedikit air..cek rasa..setelah matang angkat hidang kan dengan nasi panaa"
categories:
- Resep
tags:
- gongso
- ampela
- ati

katakunci: gongso ampela ati 
nutrition: 237 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Dessert

---


![Gongso ampela ati Ayam](https://img-global.cpcdn.com/recipes/32a497c23c0bca3b/751x532cq70/gongso-ampela-ati-ayam-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep gongso ampela ati ayam yang Enak Dan Lezat? Cara Memasaknya memang susah-susah gampang. apabila keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gongso ampela ati ayam yang enak seharusnya memiliki aroma dan rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ampela ati ayam, mulai dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tak perlu pusing kalau mau menyiapkan gongso ampela ati ayam enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan spesial.

Lihat juga resep Gongso Ayam ala Semarangan enak lainnya. Cara membuat gongso ati ampela yang sedap. Ati ayam punya citarasa yang gurih manis, sementara ampela punya tektstur kenyal yang bikin nagih.


Di bawah ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah gongso ampela ati ayam yang siap dikreasikan. Anda dapat membuat Gongso ampela ati Ayam menggunakan 14 jenis bahan dan 3 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Gongso ampela ati Ayam:

1. Ambil  ampla ati ayam
1. Ambil  cabe ijo tw
1. Ambil  Bumbu
1. Ambil  cabe rawit galak
1. Siapkan  cabe merah kriting
1. Ambil  bawang merah
1. Ambil  bawang putih
1. Siapkan  tomat
1. Sediakan  lengkuas
1. Siapkan  daun salam
1. Sediakan  bumbu kaldu
1. Ambil  gula pasir
1. Sediakan  garam
1. Gunakan  minyak goreng


Nah, jika kamu bosan dengan olahan hati ayam biasanya, ada baiknya untuk mencoba resep-resep baru ini. Meski pemula sekalipun, langkah-langkah memasak ini juga mudah untuk dipraktikkan. Kalau diolah dengan tepat, ati ampela ayam bisa menjadi hidangan yang super nikmat, tidak bau dan empuk. Kuncinya yaitu merebus ati ampela dengan rempah-rempah aromatik. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso ampela ati Ayam:

1. Cuci bersih ampla ati lalu rebus dan potong2 menurut selera
1. Haluskan bumbu dan potong2 cabe ijonya..lalu tumis bumbu halus sampe wangi dan masukkan ampla atinya
1. Setelah ampla masuk lalu masukkan cabe ijonya aduk rata tambahkan semua bumbu tambahannya..tambahkan sedikit air..cek rasa..setelah matang angkat hidang kan dengan nasi panaa


Karena ati ampela bisa mengeras bila dimasak terlalu lama, sebelum mengolahnya kamu harus pastikan untuk menumis. Selain daging ayam, gongso juga bisa menggunakan bahan lain seperti usus sapi, babat, ati ampela, hingga ceker ayam. Jika Teman Traveler ingin mencoba kuliner Solo, jangan lupa untuk mampir ke sini ya. Sama seperti bagian ayam lainnya, ampela ayam memiliki banyak kandungan nutrisi dan juga rasa yang sangat lezat, tidak hanya mengandung kolesterol. Resep Masak Ati Ampela Ayam Kecap Pedas Manis rasanya dijamin enak banget pedasnya bikin makan pengen nambah terus. 

Gimana nih? Gampang kan? Itulah cara membuat gongso ampela ati ayam yang bisa Anda praktikkan di rumah. Selamat mencoba!
