---
description: "Bumbu Ayam Gongso 🐥🌶🥘 | Langkah Membuat Ayam Gongso 🐥🌶🥘 Yang Lezat"
title: "Bumbu Ayam Gongso 🐥🌶🥘 | Langkah Membuat Ayam Gongso 🐥🌶🥘 Yang Lezat"
slug: 294-bumbu-ayam-gongso-langkah-membuat-ayam-gongso-yang-lezat
date: 2020-09-30T14:47:55.295Z
image: https://img-global.cpcdn.com/recipes/286617cd649333d8/751x532cq70/ayam-gongso-🐥🌶🥘-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/286617cd649333d8/751x532cq70/ayam-gongso-🐥🌶🥘-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/286617cd649333d8/751x532cq70/ayam-gongso-🐥🌶🥘-foto-resep-utama.jpg
author: Darrell Warner
ratingvalue: 4.3
reviewcount: 5
recipeingredient:
- " paha ayam fillet"
- " mentegamargarin"
- " kecap manis"
- " Bumbu Halus "
- " bawang merah"
- " bawang putih"
- " kemiri"
- " cabe merah keriting"
- " cabe rawit merah optional"
- " gula merah"
- " royco"
- " gula pasir"
- " garam"
- " Bumbu Iris "
- " bawang merah"
- " cabe rawit merah optional"
recipeinstructions:
- "Bersihkan ayam, lalu potong ayam bentuk kotak/dadu, sisihkan."
- "Haluskan bumbu halus, kecuali gula merah, royco, garam dan gula pasir."
- "Panaskan sedikit minyak dan mentega/margarin pada wajan/penggorengan. Lalu masukkan irisan bawang merah, tumis sebentar, kemudian masukkan bumbu halus. Tumis kembali bumbu sampai setengah matang."
- "Setelah bumbu hampir matang, masukkan irisan gula merah dan irisan cabe rawit merah. Tumis kembali bumbu sampai matang."
- "Setelah bumbu matang, masukkan ayam, aduk rata sampai semua tercampur. Setelah itu, masukkan kecap manis, royco dan gula pasir. Cek rasa. Apabila kurang asin, bisa tambahkan garam. Disesuaikan dengan selera masing-masing."
- "Masak ayam sampai benar-benar ter (gongso), sampai agak kecoklatan/karamelisasi."
- "Setelah matang, angkat dan sajikan dengan nasi hangat. 🍚☺"
categories:
- Resep
tags:
- ayam
- gongso

katakunci: ayam gongso 
nutrition: 183 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Gongso 🐥🌶🥘](https://img-global.cpcdn.com/recipes/286617cd649333d8/751x532cq70/ayam-gongso-🐥🌶🥘-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep ayam gongso 🐥🌶🥘 yang Bisa Manjain Lidah? Cara Bikinnya memang tidak terlalu sulit namun tidak gampang juga. bila salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal ayam gongso 🐥🌶🥘 yang enak seharusnya mempunyai aroma dan rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam gongso 🐥🌶🥘, pertama dari jenis bahan, lalu pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tidak usah pusing jika hendak menyiapkan ayam gongso 🐥🌶🥘 enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian spesial.




Nah, kali ini kita coba, yuk, siapkan ayam gongso 🐥🌶🥘 sendiri di rumah. Tetap berbahan sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Ayam Gongso 🐥🌶🥘 menggunakan 16 jenis bahan dan 7 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Gongso 🐥🌶🥘:

1. Sediakan  paha ayam fillet
1. Siapkan  mentega/margarin
1. Gunakan  kecap manis
1. Gunakan  Bumbu Halus :
1. Gunakan  bawang merah
1. Gunakan  bawang putih
1. Siapkan  kemiri
1. Sediakan  cabe merah keriting
1. Sediakan  cabe rawit merah (optional)
1. Ambil  gula merah
1. Siapkan  royco
1. Sediakan  gula pasir
1. Gunakan  garam
1. Ambil  Bumbu Iris :
1. Sediakan  bawang merah
1. Ambil  cabe rawit merah (optional)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Gongso 🐥🌶🥘:

1. Bersihkan ayam, lalu potong ayam bentuk kotak/dadu, sisihkan.
1. Haluskan bumbu halus, kecuali gula merah, royco, garam dan gula pasir.
1. Panaskan sedikit minyak dan mentega/margarin pada wajan/penggorengan. Lalu masukkan irisan bawang merah, tumis sebentar, kemudian masukkan bumbu halus. Tumis kembali bumbu sampai setengah matang.
1. Setelah bumbu hampir matang, masukkan irisan gula merah dan irisan cabe rawit merah. Tumis kembali bumbu sampai matang.
1. Setelah bumbu matang, masukkan ayam, aduk rata sampai semua tercampur. Setelah itu, masukkan kecap manis, royco dan gula pasir. Cek rasa. Apabila kurang asin, bisa tambahkan garam. Disesuaikan dengan selera masing-masing.
1. Masak ayam sampai benar-benar ter (gongso), sampai agak kecoklatan/karamelisasi.
1. Setelah matang, angkat dan sajikan dengan nasi hangat. 🍚☺




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan Ayam Gongso 🐥🌶🥘 yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman ataupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
