---
description: "Resep masakan Ati Ayam Gongso Semarang | Cara Membuat Ati Ayam Gongso Semarang Yang Bisa Manjain Lidah"
title: "Resep masakan Ati Ayam Gongso Semarang | Cara Membuat Ati Ayam Gongso Semarang Yang Bisa Manjain Lidah"
slug: 332-resep-masakan-ati-ayam-gongso-semarang-cara-membuat-ati-ayam-gongso-semarang-yang-bisa-manjain-lidah
date: 2021-01-15T06:18:19.154Z
image: https://img-global.cpcdn.com/recipes/e02ffeeb70583874/751x532cq70/ati-ayam-gongso-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e02ffeeb70583874/751x532cq70/ati-ayam-gongso-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e02ffeeb70583874/751x532cq70/ati-ayam-gongso-semarang-foto-resep-utama.jpg
author: Hattie Allison
ratingvalue: 3.5
reviewcount: 14
recipeingredient:
- " Ati ayam"
- " Daun jeruk"
- " Salam"
- " Lengkuas geprek"
- " Sereh geprek"
- " Kecap manis"
- " Garam"
- " Kaldu jamur"
- " Air"
- " Minyak utk menumis"
- " Bumbu yg dihaluskan "
- " Bawang merah"
- " Bawang putih"
- " Jahe"
- " Cabe merah"
- " Kemiri"
recipeinstructions:
- "Rebus ati ayam beri salam dan daun jeruk setelah 5 menit matikan kompor lalu tiriskan"
- "Persiapkan bahan2 yg lain. Bahan yg dihaluskan dgn blender"
- "Tumis bumbu yg dihaluskan masukan salam,sereh,lengkuas dan daun jeruk aduk2 lalu masukan air lalu masukan ati ayam aduk2 beri garam,kecap manis,kaldu jamur masak hingga bumbu meresap dan matang kuah menyusut"
- "Sajikan"
categories:
- Resep
tags:
- ati
- ayam
- gongso

katakunci: ati ayam gongso 
nutrition: 100 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT46M"
recipeyield: "4"
recipecategory: Dinner

---


![Ati Ayam Gongso Semarang](https://img-global.cpcdn.com/recipes/e02ffeeb70583874/751x532cq70/ati-ayam-gongso-semarang-foto-resep-utama.jpg)

Bunda lagi mencari inspirasi resep ati ayam gongso semarang yang Lezat? Cara membuatnya memang susah-susah gampang. sekiranya keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal ati ayam gongso semarang yang enak harusnya sih memiliki aroma dan rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari ati ayam gongso semarang, mulai dari jenis bahan, kedua pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tidak usah pusing jika ingin menyiapkan ati ayam gongso semarang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.


Nah, kali ini kita coba, yuk, siapkan ati ayam gongso semarang sendiri di rumah. Tetap berbahan yang sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Ati Ayam Gongso Semarang memakai 16 jenis bahan dan 4 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ati Ayam Gongso Semarang:

1. Sediakan  Ati ayam
1. Gunakan  Daun jeruk
1. Gunakan  Salam
1. Siapkan  Lengkuas geprek
1. Sediakan  Sereh geprek
1. Siapkan  Kecap manis
1. Gunakan  Garam
1. Ambil  Kaldu jamur
1. Gunakan  Air
1. Ambil  Minyak utk menumis
1. Ambil  Bumbu yg dihaluskan :
1. Ambil  Bawang merah
1. Sediakan  Bawang putih
1. Siapkan  Jahe
1. Sediakan  Cabe merah
1. Gunakan  Kemiri




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ati Ayam Gongso Semarang:

1. Rebus ati ayam beri salam dan daun jeruk setelah 5 menit matikan kompor lalu tiriskan
1. Persiapkan bahan2 yg lain. Bahan yg dihaluskan dgn blender
1. Tumis bumbu yg dihaluskan masukan salam,sereh,lengkuas dan daun jeruk aduk2 lalu masukan air lalu masukan ati ayam aduk2 beri garam,kecap manis,kaldu jamur masak hingga bumbu meresap dan matang kuah menyusut
1. Sajikan




Bagaimana? Mudah bukan? Itulah cara menyiapkan ati ayam gongso semarang yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
