---
description: "Resep masakan Gongso Babat Plus Telor | Cara Bikin Gongso Babat Plus Telor Yang Sedap"
title: "Resep masakan Gongso Babat Plus Telor | Cara Bikin Gongso Babat Plus Telor Yang Sedap"
slug: 33-resep-masakan-gongso-babat-plus-telor-cara-bikin-gongso-babat-plus-telor-yang-sedap
date: 2020-09-09T11:00:26.953Z
image: https://img-global.cpcdn.com/recipes/df8ac84b2ce06945/751x532cq70/gongso-babat-plus-telor-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/df8ac84b2ce06945/751x532cq70/gongso-babat-plus-telor-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/df8ac84b2ce06945/751x532cq70/gongso-babat-plus-telor-foto-resep-utama.jpg
author: Nannie Walton
ratingvalue: 3.4
reviewcount: 14
recipeingredient:
- "500 gr Babat bisa anduksumpingusus bersihkan"
- "2 butir Jeruk Nipis belah 2"
- "4 lbr Daun Salam"
- "4 butir telur rebus kupas tambahan dr aku"
- "2 sdm Garam"
- " Bumbu Halus "
- "15 Cabai merah keriting"
- "10 siung Bawang merah"
- "4 siung Bawang Putih"
- "6 btr Kemirisangrai"
- " Bumbu yang ditumis"
- "7 siung Bawang merah iris serong agak tebal untuk textur"
- "Secukupnya Garam Kaldu bubuk Gula Pasir"
- " kecap manis"
recipeinstructions:
- "Bersihkan babat, rebus hingga empuk (bisa di presto kurleb 20 menit dgn diberi air scukupnya, potongan jeruk nipis+daun salam+garam)"
- "Setelah empuk, tiriskan, Potong2 sesuai selera."
- "Sementara itu, rebus sebentar rawit merah+cabai merah di air bekas rebusan babat, tiriskan lalu blender semua bumbu halus jadi satu."
- "Panaskan minyak, tumis Bawang merah yg uda dpotong kasar, tumis sampai harum. minyak dibanyakkin ya soalnya nanti masuk bumbu Halus"
- "Masukkan gula, kecap, garam, kaldu bubuk sesuai selera, lalu masukkan babat dan telur rebus aduk2 (pelan2 ya jangan sampai telurnya hancur), kemudian tambahkan air +/-100cc"
- "Setelah keliatan tercampur, matikan api. jangan tumis terlalu lama karena babat sdh empuk, jadi bumbu gampang meresap. cicipi rasanya"
- "Angkat, sajikan dengan nasi hangat, bawang merah goreng+krupuk"
- "Wow...kebayang pedesnya..."
categories:
- Resep
tags:
- gongso
- babat
- plus

katakunci: gongso babat plus 
nutrition: 157 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dessert

---


![Gongso Babat Plus Telor](https://img-global.cpcdn.com/recipes/df8ac84b2ce06945/751x532cq70/gongso-babat-plus-telor-foto-resep-utama.jpg)

Bunda lagi mencari inspirasi resep gongso babat plus telor yang Enak Banget? Cara menyiapkannya memang tidak susah dan tidak juga mudah. sekiranya keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gongso babat plus telor yang enak selayaknya punya aroma dan cita rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso babat plus telor, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tidak usah pusing kalau hendak menyiapkan gongso babat plus telor yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.




Nah, kali ini kita coba, yuk, ciptakan gongso babat plus telor sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Gongso Babat Plus Telor memakai 14 jenis bahan dan 8 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Gongso Babat Plus Telor:

1. Gunakan 500 gr Babat (bisa anduk,sumping,usus)- bersihkan
1. Sediakan 2 butir Jeruk Nipis, belah 2
1. Siapkan 4 lbr Daun Salam
1. Ambil 4 butir telur, rebus, kupas (tambahan dr aku)
1. Gunakan 2 sdm Garam
1. Ambil  Bumbu Halus :
1. Gunakan 15 Cabai merah keriting
1. Siapkan 10 siung Bawang merah
1. Sediakan 4 siung Bawang Putih
1. Ambil 6 btr Kemiri,sangrai
1. Siapkan  Bumbu yang ditumis:
1. Siapkan 7 siung Bawang merah iris serong agak tebal (untuk textur)
1. Sediakan Secukupnya Garam, Kaldu bubuk, Gula Pasir
1. Sediakan  kecap manis




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso Babat Plus Telor:

1. Bersihkan babat, rebus hingga empuk (bisa di presto kurleb 20 menit dgn diberi air scukupnya, potongan jeruk nipis+daun salam+garam)
1. Setelah empuk, tiriskan, Potong2 sesuai selera.
1. Sementara itu, rebus sebentar rawit merah+cabai merah di air bekas rebusan babat, tiriskan lalu blender semua bumbu halus jadi satu.
1. Panaskan minyak, tumis Bawang merah yg uda dpotong kasar, tumis sampai harum. minyak dibanyakkin ya soalnya nanti masuk bumbu Halus
1. Masukkan gula, kecap, garam, kaldu bubuk sesuai selera, lalu masukkan babat dan telur rebus aduk2 (pelan2 ya jangan sampai telurnya hancur), kemudian tambahkan air +/-100cc
1. Setelah keliatan tercampur, matikan api. jangan tumis terlalu lama karena babat sdh empuk, jadi bumbu gampang meresap. cicipi rasanya
1. Angkat, sajikan dengan nasi hangat, bawang merah goreng+krupuk
1. Wow...kebayang pedesnya...




Bagaimana? Mudah bukan? Itulah cara membuat gongso babat plus telor yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
