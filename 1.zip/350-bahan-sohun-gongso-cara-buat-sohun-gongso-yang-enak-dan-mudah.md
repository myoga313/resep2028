---
description: "Bahan Sohun gongso | Cara Buat Sohun gongso Yang Enak Dan Mudah"
title: "Bahan Sohun gongso | Cara Buat Sohun gongso Yang Enak Dan Mudah"
slug: 350-bahan-sohun-gongso-cara-buat-sohun-gongso-yang-enak-dan-mudah
date: 2020-08-27T15:15:50.422Z
image: https://img-global.cpcdn.com/recipes/ab51f01998e71677/751x532cq70/sohun-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ab51f01998e71677/751x532cq70/sohun-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ab51f01998e71677/751x532cq70/sohun-gongso-foto-resep-utama.jpg
author: Mae Patrick
ratingvalue: 3.4
reviewcount: 7
recipeingredient:
- "1 ikat mie sohun besar"
- "1 ikat kacang panjang"
- "2 siung bawang putih"
- "5 Siung bawang merah"
- "10 cabe rawit sesuai selera kepedesan"
- " Kecap bango"
recipeinstructions:
- "Rendam mie sohun dalam air panas selama 5 menit... Lalu tiriskan."
- "Haluskan cabe, bawang putih dan bawang merah"
- "Panaskan 2 sendok minyak goreng, setelah panas,gongso bumbu hingga wangi, lalu masukkan kacang panjang"
- "Masukan garam, gula merah dan air.. setelah kacang lunak masukkan mie sohun. Tambahkan sedikit kecap (agar warna cantik)"
- "Gongso hingga air habis, dan mie sudah matang.."
categories:
- Resep
tags:
- sohun
- gongso

katakunci: sohun gongso 
nutrition: 191 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Lunch

---


![Sohun gongso](https://img-global.cpcdn.com/recipes/ab51f01998e71677/751x532cq70/sohun-gongso-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep sohun gongso yang Lezat? Cara membuatnya memang susah-susah gampang. jikalau keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal sohun gongso yang enak selayaknya mempunyai aroma dan cita rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari sohun gongso, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tak perlu pusing jika ingin menyiapkan sohun gongso yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian spesial.




Berikut ini ada beberapa tips dan trik praktis untuk membuat sohun gongso yang siap dikreasikan. Anda bisa menyiapkan Sohun gongso memakai 6 bahan dan 5 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Sohun gongso:

1. Gunakan 1 ikat mie sohun besar
1. Ambil 1 ikat kacang panjang
1. Sediakan 2 siung bawang putih
1. Ambil 5 Siung bawang merah
1. Sediakan 10 cabe rawit (sesuai selera kepedesan)
1. Ambil  Kecap bango




<!--inarticleads2-->

##### Cara menyiapkan Sohun gongso:

1. Rendam mie sohun dalam air panas selama 5 menit... Lalu tiriskan.
1. Haluskan cabe, bawang putih dan bawang merah
1. Panaskan 2 sendok minyak goreng, setelah panas,gongso bumbu hingga wangi, lalu masukkan kacang panjang
1. Masukan garam, gula merah dan air.. setelah kacang lunak masukkan mie sohun. Tambahkan sedikit kecap (agar warna cantik)
1. Gongso hingga air habis, dan mie sudah matang..




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Harapan kami, olahan Sohun gongso yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman ataupun menjadi inspirasi bagi Anda yang berkeinginan untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
