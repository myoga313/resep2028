---
description: "Bahan Gongso Telur | Cara Mengolah Gongso Telur Yang Enak Dan Lezat"
title: "Bahan Gongso Telur | Cara Mengolah Gongso Telur Yang Enak Dan Lezat"
slug: 59-bahan-gongso-telur-cara-mengolah-gongso-telur-yang-enak-dan-lezat
date: 2020-07-20T22:34:50.321Z
image: https://img-global.cpcdn.com/recipes/b3cc9057dcdc6e04/751x532cq70/gongso-telur-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b3cc9057dcdc6e04/751x532cq70/gongso-telur-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b3cc9057dcdc6e04/751x532cq70/gongso-telur-foto-resep-utama.jpg
author: Loretta Jacobs
ratingvalue: 4.5
reviewcount: 11
recipeingredient:
- "1 btr telur ayam"
- "1 bh tomat merah potong dadu"
- "1/2 mangkok irisan kol"
- "1 tangkai daun bawang iris kasar"
- "2 sdm minyak sayur"
- "1 sdm kecap manis"
- "1 sdm saus sambal"
- "100 ml air"
- "1 sdt gula merah"
- "secukupnya merica bubuk"
- "secukupnya garam"
- "secukupnya kaldu jamur"
- " Bumbu halus"
- "1 siung bawang putih"
- "2 siung bawang merah"
- "1/2 butir kemiri"
- "3 buah cabe merah atau sesuai selera"
recipeinstructions:
- "Panaskan wajan lalu buat telur orak arik. sisihkan."
- "Panaskan minyak dalam wajan, tumis bumbu halus sampai harum atau berwarna agak kecoklatan."
- "Tambahkan saus dan kecap, aduk rata dan panaskan sebentar."
- "Masukkan air, aduk rata dan masak sampai meletup-letup dan sedikit mengental."
- "Kemudian tambahkan telur, tomat, kol, dan daun bawang. Aduk rata."
- "Masak hingga bumbu meresap atau hingga kol dan tomat layu."
- "Sajikan selagi hangat."
categories:
- Resep
tags:
- gongso
- telur

katakunci: gongso telur 
nutrition: 132 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Lunch

---


![Gongso Telur](https://img-global.cpcdn.com/recipes/b3cc9057dcdc6e04/751x532cq70/gongso-telur-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep gongso telur yang Sedap? Cara Buatnya memang tidak susah dan tidak juga mudah. semisal keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso telur yang enak harusnya sih mempunyai aroma dan rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso telur, mulai dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tak perlu pusing jika ingin menyiapkan gongso telur yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian istimewa.




Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah gongso telur yang siap dikreasikan. Anda dapat menyiapkan Gongso Telur menggunakan 17 jenis bahan dan 7 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Gongso Telur:

1. Siapkan 1 btr telur ayam
1. Siapkan 1 bh tomat merah, potong dadu
1. Gunakan 1/2 mangkok irisan kol
1. Gunakan 1 tangkai daun bawang, iris kasar
1. Ambil 2 sdm minyak sayur
1. Ambil 1 sdm kecap manis
1. Ambil 1 sdm saus sambal
1. Sediakan 100 ml air
1. Sediakan 1 sdt gula merah
1. Sediakan secukupnya merica bubuk
1. Ambil secukupnya garam
1. Gunakan secukupnya kaldu jamur
1. Sediakan  Bumbu halus
1. Siapkan 1 siung bawang putih
1. Ambil 2 siung bawang merah
1. Ambil 1/2 butir kemiri
1. Sediakan 3 buah cabe merah atau sesuai selera




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso Telur:

1. Panaskan wajan lalu buat telur orak arik. sisihkan.
1. Panaskan minyak dalam wajan, tumis bumbu halus sampai harum atau berwarna agak kecoklatan.
1. Tambahkan saus dan kecap, aduk rata dan panaskan sebentar.
1. Masukkan air, aduk rata dan masak sampai meletup-letup dan sedikit mengental.
1. Kemudian tambahkan telur, tomat, kol, dan daun bawang. Aduk rata.
1. Masak hingga bumbu meresap atau hingga kol dan tomat layu.
1. Sajikan selagi hangat.




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Harapan kami, olahan Gongso Telur yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman ataupun menjadi inspirasi bagi Anda yang berkeinginan untuk berbisnis kuliner. Selamat mencoba!
