---
description: "Resep Gongso Sayap Ayam | Cara Bikin Gongso Sayap Ayam Yang Bikin Ngiler"
title: "Resep Gongso Sayap Ayam | Cara Bikin Gongso Sayap Ayam Yang Bikin Ngiler"
slug: 282-resep-gongso-sayap-ayam-cara-bikin-gongso-sayap-ayam-yang-bikin-ngiler
date: 2020-10-25T16:20:04.687Z
image: https://img-global.cpcdn.com/recipes/4b644ec51826fb4b/751x532cq70/gongso-sayap-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4b644ec51826fb4b/751x532cq70/gongso-sayap-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4b644ec51826fb4b/751x532cq70/gongso-sayap-ayam-foto-resep-utama.jpg
author: Edward Swanson
ratingvalue: 3.5
reviewcount: 13
recipeingredient:
- "6 Sayap ayam dipotong menjadi 2"
- "2 lembar daun jeruk"
- "1 batang sereh di geprek"
- "1/2 butir gula merah"
- "3 siung Bawang putih"
- "6 siung Bawang merah"
- "8 buah Cabe merah keriting"
- "3 butir Kemiri"
- "1 ruas jari Jahe"
- "Secukupnya garam"
- "Secukupnya penyedap"
- "Secukupnya air"
- " Bumbu gonggso "
- "6 siung bawang merah iris kasar"
- "10 buah cabe rawit merah"
recipeinstructions:
- "Potong sayap ayam menjadi 2 bagian. Cuci dan rendam dgn garam dan air jeruk nipis. Cuci bersih kembali. Kemudian panggang / goreng setengah matang agar tidak hancur saat dimasak dengan bumbu2. Sisihkan ayam. Aslinya sayap ayam tidak digoreng."
- "Haluskan bumbu, lalu tumis sampai keluar aroma wangi"
- "Masukkan sayap ayam aduk rata lalu tuang air. Ungkep sayap ayam sampai air menyusut atau sampai air nyemek2, jangan lupa koreksi rasanya."
- "Gongso atau tumis irisan bawang merah dan cabe rawit asal layu saja, masukkan sebagian kedalam sayap ayam lalu aduk rata. Gongso sayap ayam siap disajikan dengan ditabur sebagian bumbu gongso."
categories:
- Resep
tags:
- gongso
- sayap
- ayam

katakunci: gongso sayap ayam 
nutrition: 236 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Lunch

---


![Gongso Sayap Ayam](https://img-global.cpcdn.com/recipes/4b644ec51826fb4b/751x532cq70/gongso-sayap-ayam-foto-resep-utama.jpg)

Bunda Sedang mencari ide resep gongso sayap ayam yang Enak Banget? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. sekiranya keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso sayap ayam yang enak seharusnya punya aroma dan cita rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso sayap ayam, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tidak usah pusing jika hendak menyiapkan gongso sayap ayam yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan istimewa.




Nah, kali ini kita coba, yuk, buat gongso sayap ayam sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Gongso Sayap Ayam memakai 15 bahan dan 4 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Gongso Sayap Ayam:

1. Sediakan 6 Sayap ayam, dipotong menjadi 2
1. Siapkan 2 lembar daun jeruk
1. Sediakan 1 batang sereh di geprek
1. Gunakan 1/2 butir gula merah
1. Sediakan 3 siung Bawang putih
1. Ambil 6 siung Bawang merah
1. Gunakan 8 buah Cabe merah keriting
1. Ambil 3 butir Kemiri
1. Ambil 1 ruas jari Jahe
1. Gunakan Secukupnya garam
1. Siapkan Secukupnya penyedap
1. Sediakan Secukupnya air
1. Sediakan  Bumbu gonggso :
1. Ambil 6 siung bawang merah, iris kasar
1. Siapkan 10 buah cabe rawit merah




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso Sayap Ayam:

1. Potong sayap ayam menjadi 2 bagian. Cuci dan rendam dgn garam dan air jeruk nipis. Cuci bersih kembali. Kemudian panggang / goreng setengah matang agar tidak hancur saat dimasak dengan bumbu2. Sisihkan ayam. Aslinya sayap ayam tidak digoreng.
1. Haluskan bumbu, lalu tumis sampai keluar aroma wangi
1. Masukkan sayap ayam aduk rata lalu tuang air. Ungkep sayap ayam sampai air menyusut atau sampai air nyemek2, jangan lupa koreksi rasanya.
1. Gongso atau tumis irisan bawang merah dan cabe rawit asal layu saja, masukkan sebagian kedalam sayap ayam lalu aduk rata. Gongso sayap ayam siap disajikan dengan ditabur sebagian bumbu gongso.




Gimana nih? Mudah bukan? Itulah cara membuat gongso sayap ayam yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
