---
description: "Bumbu Ayam gongso cabe ijo | Cara Buat Ayam gongso cabe ijo Yang Paling Enak"
title: "Bumbu Ayam gongso cabe ijo | Cara Buat Ayam gongso cabe ijo Yang Paling Enak"
slug: 232-bumbu-ayam-gongso-cabe-ijo-cara-buat-ayam-gongso-cabe-ijo-yang-paling-enak
date: 2020-08-28T08:14:53.221Z
image: https://img-global.cpcdn.com/recipes/0dfa28a441df89f3/751x532cq70/ayam-gongso-cabe-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0dfa28a441df89f3/751x532cq70/ayam-gongso-cabe-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0dfa28a441df89f3/751x532cq70/ayam-gongso-cabe-ijo-foto-resep-utama.jpg
author: Catherine Waters
ratingvalue: 5
reviewcount: 9
recipeingredient:
- "250 gr dada ayam fillet potong dadu"
- "1 buah kecil kol iris kasar"
- "2 buah kecil tomat merah belah 4"
- "5 buah cabe ijo besar potong2 besar"
- "2 buah cabe rawit utuh"
- "1 lembar daun salam"
- "Sepotong lengkuas"
- "Secukupnya garam kaldu bubuk dan lada bubuk"
- "3 sdm kecap manis"
- "100 ml air"
- " Minyak untuk menumis"
- " Bawang goreng"
- " Haluskan "
- "4 butir bawang merah"
- "2 siung bawang putih"
- "3 buah cabe merah keriting"
- "1 butir kemiri"
recipeinstructions:
- "Siapkan semua bahan..."
- "Tumis bumbu halus hingga harum. Masukkan potongan daging ayam, daun salam dan lengkuas. Masak sampai ayam berubah warna."
- "Tuangi air dan aduk2. Masak sampai air menyusut kemudian masukkan kol."
- "Setelah kol ayam dan kol matang, masukkan irisan cabe ijo, tomat juga cabe rawit utuh."
- "Bumbui dengan garam dan lada bubuk, cek rasa. Beri kaldu bubuk dan terakhir tuang kecap manis. Aduk rata...angkat, sajikan dengan bawang goreng."
categories:
- Resep
tags:
- ayam
- gongso
- cabe

katakunci: ayam gongso cabe 
nutrition: 225 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam gongso cabe ijo](https://img-global.cpcdn.com/recipes/0dfa28a441df89f3/751x532cq70/ayam-gongso-cabe-ijo-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep ayam gongso cabe ijo yang Lezat? Cara membuatnya memang tidak susah dan tidak juga mudah. Jika keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal ayam gongso cabe ijo yang enak seharusnya mempunyai aroma dan cita rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso cabe ijo, pertama dari jenis bahan, kemudian pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tak perlu pusing kalau ingin menyiapkan ayam gongso cabe ijo yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan spesial.

Lihat juga resep Gongso Ayam ala Semarangan enak lainnya. There are no reviews for Ayam Kampoeng Cabe Ijo, Indonesia yet. Be the first to write a review!


Di bawah ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah ayam gongso cabe ijo yang siap dikreasikan. Anda dapat membuat Ayam gongso cabe ijo menggunakan 17 bahan dan 5 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam gongso cabe ijo:

1. Siapkan 250 gr dada ayam fillet, potong dadu
1. Siapkan 1 buah (kecil) kol, iris kasar
1. Siapkan 2 buah (kecil) tomat merah, belah 4
1. Gunakan 5 buah cabe ijo besar, potong2 besar
1. Siapkan 2 buah cabe rawit utuh
1. Ambil 1 lembar daun salam
1. Siapkan Sepotong lengkuas
1. Ambil Secukupnya garam, kaldu bubuk dan lada bubuk
1. Siapkan 3 sdm kecap manis
1. Gunakan 100 ml air
1. Ambil  Minyak untuk menumis
1. Sediakan  Bawang goreng
1. Gunakan  Haluskan :
1. Siapkan 4 butir bawang merah
1. Ambil 2 siung bawang putih
1. Ambil 3 buah cabe merah keriting
1. Sediakan 1 butir kemiri


Di Opa Resto kami menyediakan menu ini berupa nasi yang dikemas lengkap dengan lauk pauknya yaitu daging sapi bumbu, ayam gongso/rica-rica, bakmie, kentang, kering tempe, acar kuning dan sambal goreng ati. Sangat praktis, bersih dan tentu saja enak rasanya. Resep Ayam Cabai Ijo dan Cara Memasaknya dengan Mudah Cepat dan Nikmat. Sering kali kita mendapati masakan yang berbahan ayam baik Ayam dengan balutan sambell ijo yang tingkat pedasnya dijamin standar. 

<!--inarticleads2-->

##### Cara menyiapkan Ayam gongso cabe ijo:

1. Siapkan semua bahan...
1. Tumis bumbu halus hingga harum. Masukkan potongan daging ayam, daun salam dan lengkuas. Masak sampai ayam berubah warna.
1. Tuangi air dan aduk2. Masak sampai air menyusut kemudian masukkan kol.
1. Setelah kol ayam dan kol matang, masukkan irisan cabe ijo, tomat juga cabe rawit utuh.
1. Bumbui dengan garam dan lada bubuk, cek rasa. Beri kaldu bubuk dan terakhir tuang kecap manis. Aduk rata...angkat, sajikan dengan bawang goreng.


Ini juga aman dilambung kok Bunda baik untuk suami, anak-anak maupun. Untuk penyajiannya, ayam cabe ijo bisa disajikan bersama nasi putih hangat dan lalapan mentimun. Bisa juga disajikan seperti di rumah makan padang; sajikan bersama rebusan daun singkong muda. Pasti akan membuat acara santap siang ataupun santap malam di rumah anda terasa sangat istimewa. Haii hari ini aku akan share resep dan cara membuat ayam suwir Bahan&#34;nya : daging ayam Bumbu&#34;nya : Bawang bombay Cabe. 

Terima kasih telah menggunakan resep yang kami tampilkan di sini. Besar harapan kami, olahan Ayam gongso cabe ijo yang mudah di atas dapat membantu Anda menyiapkan makanan yang menarik untuk keluarga/teman maupun menjadi inspirasi dalam berbisnis kuliner. Selamat mencoba!
