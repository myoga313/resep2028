---
description: "Resep masakan Ayam Gongso | Resep Bumbu Ayam Gongso Yang Paling Enak"
title: "Resep masakan Ayam Gongso | Resep Bumbu Ayam Gongso Yang Paling Enak"
slug: 304-resep-masakan-ayam-gongso-resep-bumbu-ayam-gongso-yang-paling-enak
date: 2020-09-04T09:12:16.707Z
image: https://img-global.cpcdn.com/recipes/6abd680c11ee0b62/751x532cq70/ayam-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6abd680c11ee0b62/751x532cq70/ayam-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6abd680c11ee0b62/751x532cq70/ayam-gongso-foto-resep-utama.jpg
author: Alex Bailey
ratingvalue: 3.8
reviewcount: 6
recipeingredient:
- "1/2 ekor Ayam sedang cuci bersih"
- "3 siung Bawang merah"
- "2 siung Bawang putih"
- "1/2 siung Bawang bombay"
- "7 biji Cabe rawit"
- "2 sdm Kecap manis"
- "2 sdm Saos Tiram"
- "1/3 sdt Himalaya salt"
- "1/3 sdt Lada bubuk"
- "1/2 sdt Kaldu bubuk"
- " Air untuk merebus"
recipeinstructions:
- "Potong ayah agak kecil, lalu didihkan air dan rebus hingga ayam matang. Sisihkan jangan dibuang air rebusannya"
- "Iris trio bawang dan cabe, aslinya dihaluskan ya bamer, baput n cabe nya. Lalu tumis dengan minyak hingga wangi"
- "Masukkan air rebusan, kecap, saos tiram, garam, lada, kaldu bubuk. Masak hingga mendidih"
- "Masukkan ayam, masak hingga kuah meresap ke daging ayam"
- "Angkat dan sajikan, nikmat dengan sebakul nasi"
categories:
- Resep
tags:
- ayam
- gongso

katakunci: ayam gongso 
nutrition: 287 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Gongso](https://img-global.cpcdn.com/recipes/6abd680c11ee0b62/751x532cq70/ayam-gongso-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep ayam gongso yang Enak Banget? Cara Buatnya memang susah-susah gampang. Jika keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal ayam gongso yang enak seharusnya mempunyai aroma dan rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam gongso, mulai dari jenis bahan, lalu pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tak perlu pusing jika ingin menyiapkan ayam gongso yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan spesial.




Nah, kali ini kita coba, yuk, siapkan ayam gongso sendiri di rumah. Tetap berbahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Ayam Gongso menggunakan 11 bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Gongso:

1. Sediakan 1/2 ekor Ayam sedang, cuci bersih
1. Siapkan 3 siung Bawang merah
1. Sediakan 2 siung Bawang putih
1. Gunakan 1/2 siung Bawang bombay
1. Siapkan 7 biji Cabe rawit
1. Ambil 2 sdm Kecap manis
1. Sediakan 2 sdm Saos Tiram
1. Siapkan 1/3 sdt Himalaya salt
1. Siapkan 1/3 sdt Lada bubuk
1. Sediakan 1/2 sdt Kaldu bubuk
1. Gunakan  Air untuk merebus




<!--inarticleads2-->

##### Cara membuat Ayam Gongso:

1. Potong ayah agak kecil, lalu didihkan air dan rebus hingga ayam matang. Sisihkan jangan dibuang air rebusannya
1. Iris trio bawang dan cabe, aslinya dihaluskan ya bamer, baput n cabe nya. Lalu tumis dengan minyak hingga wangi
1. Masukkan air rebusan, kecap, saos tiram, garam, lada, kaldu bubuk. Masak hingga mendidih
1. Masukkan ayam, masak hingga kuah meresap ke daging ayam
1. Angkat dan sajikan, nikmat dengan sebakul nasi




Terima kasih telah membaca resep yang kami tampilkan di sini. Besar harapan kami, olahan Ayam Gongso yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman ataupun menjadi inspirasi bagi Anda yang berkeinginan untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
