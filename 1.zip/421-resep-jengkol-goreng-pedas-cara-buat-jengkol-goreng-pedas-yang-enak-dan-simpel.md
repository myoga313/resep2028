---
description: "Resep Jengkol goreng pedas | Cara Buat Jengkol goreng pedas Yang Enak dan Simpel"
title: "Resep Jengkol goreng pedas | Cara Buat Jengkol goreng pedas Yang Enak dan Simpel"
slug: 421-resep-jengkol-goreng-pedas-cara-buat-jengkol-goreng-pedas-yang-enak-dan-simpel
date: 2020-12-07T10:26:41.974Z
image: https://img-global.cpcdn.com/recipes/b3a7649ea1ec5a2a/751x532cq70/jengkol-goreng-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b3a7649ea1ec5a2a/751x532cq70/jengkol-goreng-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b3a7649ea1ec5a2a/751x532cq70/jengkol-goreng-pedas-foto-resep-utama.jpg
author: Mattie Kelley
ratingvalue: 4.2
reviewcount: 11
recipeingredient:
- "250 gr jengkol"
- "2 siung bawang putih"
- "5 siung bawang merah"
- "2 bh cabe merah besar buang biji"
- "10 bh cabe rawit atau sesuai selera"
- "1 bh terasi ABC"
- "2 lembar daun jeruk"
- "secukupnya Kaldu jamur"
recipeinstructions:
- "Rendam jengkol semalaman dalam air bekas cucian beras lalu kupas kulitnya, potong jd 4 bagian"
- "Goreng jengkol sampai matang"
- "Blender halus bawang merah, bawang putih, cabe rawit dan cabe besar"
- "Tumis bumbu halus, terasi dan daun jeruk sampai wangi dan bumbu matang"
- "Setelah bumbu matang, masukkan jengkol yg sdh digoreng, aduk rata, tambahkan garam dan kaldu jamur, aduk rata, koreksi rasa"
- "Angkat dan siap disajikan dengan nasi hangat"
categories:
- Resep
tags:
- jengkol
- goreng
- pedas

katakunci: jengkol goreng pedas 
nutrition: 241 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dinner

---


![Jengkol goreng pedas](https://img-global.cpcdn.com/recipes/b3a7649ea1ec5a2a/751x532cq70/jengkol-goreng-pedas-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep jengkol goreng pedas yang Sedap? Cara membuatnya memang tidak susah dan tidak juga mudah. apabila keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal jengkol goreng pedas yang enak harusnya sih punya aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari jengkol goreng pedas, pertama dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tidak usah pusing kalau hendak menyiapkan jengkol goreng pedas yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian istimewa.




Nah, kali ini kita coba, yuk, ciptakan jengkol goreng pedas sendiri di rumah. Tetap dengan bahan sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Jengkol goreng pedas memakai 8 jenis bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Jengkol goreng pedas:

1. Sediakan 250 gr jengkol
1. Ambil 2 siung bawang putih
1. Gunakan 5 siung bawang merah
1. Siapkan 2 bh cabe merah besar, buang biji
1. Gunakan 10 bh cabe rawit, atau sesuai selera
1. Sediakan 1 bh terasi ABC
1. Gunakan 2 lembar daun jeruk
1. Siapkan secukupnya Kaldu jamur




<!--inarticleads2-->

##### Langkah-langkah membuat Jengkol goreng pedas:

1. Rendam jengkol semalaman dalam air bekas cucian beras lalu kupas kulitnya, potong jd 4 bagian
1. Goreng jengkol sampai matang
1. Blender halus bawang merah, bawang putih, cabe rawit dan cabe besar
1. Tumis bumbu halus, terasi dan daun jeruk sampai wangi dan bumbu matang
1. Setelah bumbu matang, masukkan jengkol yg sdh digoreng, aduk rata, tambahkan garam dan kaldu jamur, aduk rata, koreksi rasa
1. Angkat dan siap disajikan dengan nasi hangat




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Harapan kami, olahan Jengkol goreng pedas yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman ataupun menjadi ide untuk berbisnis kuliner. Selamat mencoba!
