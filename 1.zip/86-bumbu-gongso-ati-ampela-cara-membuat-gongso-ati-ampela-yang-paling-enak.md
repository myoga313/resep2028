---
description: "Bumbu Gongso Ati Ampela | Cara Membuat Gongso Ati Ampela Yang Paling Enak"
title: "Bumbu Gongso Ati Ampela | Cara Membuat Gongso Ati Ampela Yang Paling Enak"
slug: 86-bumbu-gongso-ati-ampela-cara-membuat-gongso-ati-ampela-yang-paling-enak
date: 2020-10-26T12:43:34.711Z
image: https://img-global.cpcdn.com/recipes/24af7ef3f331ac02/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/24af7ef3f331ac02/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/24af7ef3f331ac02/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
author: Raymond Zimmerman
ratingvalue: 4.9
reviewcount: 11
recipeingredient:
- "2 buah Ati ampela bersihkan"
- "1 batang Serai"
- "2 lembar daun jeruk"
- "1/3 sdt Himalaya salt"
- "1 sdt Gula pasir"
- "1/2 sdt Kaldu bubuk"
- "1 sdm Kecap manis"
- "1 sdm Saos tiram"
- "1/2 gls Air matang"
- " Bahan iris "
- "3 siung Bawang merah"
- "2 siung Barang putih"
- "1 buah Cabe hijau besar"
- "3 buah Cabe rawit"
recipeinstructions:
- "Rebus ati ampela hingga matang, tiriskan lalu potong2"
- "Tumis bahan iris hingga wangi, masukkan ati ampela. Aduk rata"
- "Beri air, kecap manis, saos tiram, garam, gula dan lada bubuk. Masak hingga kuah menyusut"
- "Angkat dan sajikan"
categories:
- Resep
tags:
- gongso
- ati
- ampela

katakunci: gongso ati ampela 
nutrition: 133 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Lunch

---


![Gongso Ati Ampela](https://img-global.cpcdn.com/recipes/24af7ef3f331ac02/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep gongso ati ampela yang Bisa Manjain Lidah? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. bila salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso ati ampela yang enak seharusnya memiliki aroma dan cita rasa yang bisa memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ati ampela, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menyajikannya. Tak perlu pusing kalau ingin menyiapkan gongso ati ampela yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian istimewa.


Di bawah ini ada beberapa tips dan trik praktis dalam mengolah gongso ati ampela yang siap dikreasikan. Anda bisa menyiapkan Gongso Ati Ampela memakai 14 bahan dan 4 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Gongso Ati Ampela:

1. Siapkan 2 buah Ati ampela, bersihkan
1. Ambil 1 batang Serai
1. Siapkan 2 lembar daun jeruk
1. Gunakan 1/3 sdt Himalaya salt
1. Ambil 1 sdt Gula pasir
1. Gunakan 1/2 sdt Kaldu bubuk
1. Gunakan 1 sdm Kecap manis
1. Siapkan 1 sdm Saos tiram
1. Gunakan 1/2 gls Air matang
1. Siapkan  Bahan iris :
1. Ambil 3 siung Bawang merah
1. Ambil 2 siung Barang putih
1. Gunakan 1 buah Cabe hijau besar
1. Sediakan 3 buah Cabe rawit




<!--inarticleads2-->

##### Cara membuat Gongso Ati Ampela:

1. Rebus ati ampela hingga matang, tiriskan lalu potong2
1. Tumis bahan iris hingga wangi, masukkan ati ampela. Aduk rata
1. Beri air, kecap manis, saos tiram, garam, gula dan lada bubuk. Masak hingga kuah menyusut
1. Angkat dan sajikan




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Harapan kami, olahan Gongso Ati Ampela yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman maupun menjadi ide dalam berjualan makanan. Semoga bermanfaat dan selamat mencoba!
