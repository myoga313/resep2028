---
description: "Resep masakan Babat gongso sederhana | Resep Membuat Babat gongso sederhana Yang Menggugah Selera"
title: "Resep masakan Babat gongso sederhana | Resep Membuat Babat gongso sederhana Yang Menggugah Selera"
slug: 31-resep-masakan-babat-gongso-sederhana-resep-membuat-babat-gongso-sederhana-yang-menggugah-selera
date: 2021-01-01T06:57:18.182Z
image: https://img-global.cpcdn.com/recipes/d70cc3fba37bdec4/751x532cq70/babat-gongso-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d70cc3fba37bdec4/751x532cq70/babat-gongso-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d70cc3fba37bdec4/751x532cq70/babat-gongso-sederhana-foto-resep-utama.jpg
author: Dylan Miles
ratingvalue: 3.7
reviewcount: 15
recipeingredient:
- "4 ons babat sapi"
- "200 ml air"
- "1 Batang seraiambil putrinya dan memarkan"
- "2 lbr daun salam"
- "2 ruas lengkuas memarkan"
- "4 butir bawang merah iris tipis"
- "2 sdm kecap manis"
- "1 sdt garam"
- "1/4 sdt gula"
- "5 sdm untuk menumis"
- " bahan rebusan"
- "2 cm lengkuas"
- "2 cm jahe"
- "2 lbr daun salam"
- "1 ltr air untuk merebus"
- " bumbu halus"
- "2 cm kunyit bakar"
- "4 buah cabai rawit merah"
- "6 buah cabai merah keriting"
- "2 butir kemiri sangrai"
- "3 siung bawang putih"
- "5 butir bawang merah"
recipeinstructions:
- "Siapkan semua bahan,cuci bersih babat lalu rebus dengan bumbu rebusan hingga msak dan empuk"
- "Dinginkan sebentar babat sebelum d potong sesuai selera.siapkan minyak untuk menumis...tumis seraiblengkuas dan daun salam hingga harum masukan bawang merah iris dan bumbu halus..tumis hingga harum"
- "Masukan potongan babat sambil d aduk - aduk, masukan cekap,garam dan gula..aduk hingga bumbu merata..masak dengan api sedang"
- "Terakhir masukan air dan aduk hingga merata...masak sampai semua meresap sempurna..angkat dan tiriskan..bisa d tambah dengan bawang merah goreng..jika suka"
categories:
- Resep
tags:
- babat
- gongso
- sederhana

katakunci: babat gongso sederhana 
nutrition: 290 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Lunch

---


![Babat gongso sederhana](https://img-global.cpcdn.com/recipes/d70cc3fba37bdec4/751x532cq70/babat-gongso-sederhana-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep babat gongso sederhana yang Lezat? Cara Bikinnya memang tidak susah dan tidak juga mudah. sekiranya salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal babat gongso sederhana yang enak seharusnya memiliki aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari babat gongso sederhana, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan babat gongso sederhana enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan spesial.

Resep babat gongso sederhana ala rumahan. bahan mudah dan gampang ditemukan.#babatgongso #babatgongsosemarang #babatgongsosederhana #masakanrumahan. Lihat juga resep Babat Gongso ala Semarang enak lainnya. Babat Gongso Khas Semarang, Pedes, Manis, Gurih.


Nah, kali ini kita coba, yuk, kreasikan babat gongso sederhana sendiri di rumah. Tetap dengan bahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Babat gongso sederhana menggunakan 22 bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Babat gongso sederhana:

1. Sediakan 4 ons babat sapi
1. Ambil 200 ml air
1. Sediakan 1 Batang serai..ambil putrinya dan memarkan
1. Gunakan 2 lbr daun salam
1. Gunakan 2 ruas lengkuas memarkan
1. Sediakan 4 butir bawang merah iris tipis
1. Siapkan 2 sdm kecap manis
1. Siapkan 1 sdt garam
1. Siapkan 1/4 sdt gula
1. Siapkan 5 sdm untuk menumis
1. Siapkan  bahan rebusan:
1. Gunakan 2 cm lengkuas
1. Gunakan 2 cm jahe
1. Sediakan 2 lbr daun salam
1. Ambil 1 ltr air untuk merebus
1. Siapkan  bumbu halus
1. Ambil 2 cm kunyit bakar
1. Gunakan 4 buah cabai rawit merah
1. Ambil 6 buah cabai merah keriting
1. Sediakan 2 butir kemiri sangrai
1. Ambil 3 siung bawang putih
1. Sediakan 5 butir bawang merah


Babat pun siap untuk kemudian di-gongso atau ditumis bersama racikan bumbu. Penyajian nasi goreng babat dan babat gongso tergolong sederhana. Tapi, rasanya yang pedas manis menggugah selera. Pecinta jeroan bakal terpuaskan oleh rasa daging babat yang empuk. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Babat gongso sederhana:

1. Siapkan semua bahan,cuci bersih babat lalu rebus dengan bumbu rebusan hingga msak dan empuk
1. Dinginkan sebentar babat sebelum d potong sesuai selera.siapkan minyak untuk menumis...tumis seraiblengkuas dan daun salam hingga harum masukan bawang merah iris dan bumbu halus..tumis hingga harum
1. Masukan potongan babat sambil d aduk - aduk, masukan cekap,garam dan gula..aduk hingga bumbu merata..masak dengan api sedang
1. Terakhir masukan air dan aduk hingga merata...masak sampai semua meresap sempurna..angkat dan tiriskan..bisa d tambah dengan bawang merah goreng..jika suka


Resep jeroan yang paling populer adalah gongso. Masakan asal Semarang ini bahkan disukai oleh para bule. Resep Babat Gongso ala Dapur Bunda Didi, Gampang, Enak Banget Dimakan dengan Nasi Resep Babat Gongso ala Maya Barang merah Barang putih Cabe merah besar Cabe rawit Cabe ijo Daun. Yuk, belajar membuat Babat Gongso di rumah Anda! 

Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Babat gongso sederhana yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi ide dalam berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
