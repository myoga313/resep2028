---
description: "Bumbu Ati gongso | Langkah Membuat Ati gongso Yang Sedap"
title: "Bumbu Ati gongso | Langkah Membuat Ati gongso Yang Sedap"
slug: 433-bumbu-ati-gongso-langkah-membuat-ati-gongso-yang-sedap
date: 2020-08-18T16:34:43.587Z
image: https://img-global.cpcdn.com/recipes/02e4de0d4e8651cf/751x532cq70/ati-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/02e4de0d4e8651cf/751x532cq70/ati-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/02e4de0d4e8651cf/751x532cq70/ati-gongso-foto-resep-utama.jpg
author: Isaiah Atkins
ratingvalue: 3
reviewcount: 9
recipeingredient:
- "6 potong hati ayam"
- "1 buah bawang bombay"
- "sesuai selera Cabe rawit"
- " Merica bubuk"
- " Gula jawa"
- " Kecap"
- " Garam"
- "1 buah tomat"
recipeinstructions:
- "Cuci bersih hati ayam lalu rebus kurleb 10menit"
- "Setelah agak dingin, potong-potong hati ayam sesuai selera"
- "Iris bawang bombay kemudian tumis sampai layu"
- "Masukkan hati ayam,cabe, garam, gula jawa, kecap, tomat yang sudah dipotong, lalu beri merica bubuk agak banyak"
- "Masak sampai bumbu meresap. Angkat dan sajikan"
categories:
- Resep
tags:
- ati
- gongso

katakunci: ati gongso 
nutrition: 185 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dessert

---


![Ati gongso](https://img-global.cpcdn.com/recipes/02e4de0d4e8651cf/751x532cq70/ati-gongso-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep ati gongso yang Lezat? Cara Memasaknya memang susah-susah gampang. seumpama salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal ati gongso yang enak harusnya sih punya aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari ati gongso, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tidak usah pusing jika ingin menyiapkan ati gongso yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.




Nah, kali ini kita coba, yuk, ciptakan ati gongso sendiri di rumah. Tetap dengan bahan sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Ati gongso memakai 8 jenis bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ati gongso:

1. Gunakan 6 potong hati ayam
1. Sediakan 1 buah bawang bombay
1. Gunakan sesuai selera Cabe rawit
1. Siapkan  Merica bubuk
1. Sediakan  Gula jawa
1. Gunakan  Kecap
1. Sediakan  Garam
1. Gunakan 1 buah tomat




<!--inarticleads2-->

##### Langkah-langkah membuat Ati gongso:

1. Cuci bersih hati ayam lalu rebus kurleb 10menit
1. Setelah agak dingin, potong-potong hati ayam sesuai selera
1. Iris bawang bombay kemudian tumis sampai layu
1. Masukkan hati ayam,cabe, garam, gula jawa, kecap, tomat yang sudah dipotong, lalu beri merica bubuk agak banyak
1. Masak sampai bumbu meresap. Angkat dan sajikan




Bagaimana? Gampang kan? Itulah cara membuat ati gongso yang bisa Anda praktikkan di rumah. Selamat mencoba!
