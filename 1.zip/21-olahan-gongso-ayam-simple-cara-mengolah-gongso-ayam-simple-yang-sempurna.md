---
description: "Olahan Gongso ayam simple | Cara Mengolah Gongso ayam simple Yang Sempurna"
title: "Olahan Gongso ayam simple | Cara Mengolah Gongso ayam simple Yang Sempurna"
slug: 21-olahan-gongso-ayam-simple-cara-mengolah-gongso-ayam-simple-yang-sempurna
date: 2020-09-16T05:24:37.359Z
image: https://img-global.cpcdn.com/recipes/073cf1f8c6bf36d3/751x532cq70/gongso-ayam-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/073cf1f8c6bf36d3/751x532cq70/gongso-ayam-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/073cf1f8c6bf36d3/751x532cq70/gongso-ayam-simple-foto-resep-utama.jpg
author: Chris Green
ratingvalue: 3.7
reviewcount: 12
recipeingredient:
- "1/4 kg Ayam aku pakai ceker kepala dan sayap"
- "2 butir bawang putih"
- "4 butir bawang merah"
- "1/2 butir kemiri"
- "Secukupnya ketumbar bubuk"
- "1 sachet masako ayam bisa ganti dengan garam biasa"
- "Secukupnya gula pasir"
- "Secukupnya kecap manis"
- "Segenggam cabai sesuai selera"
recipeinstructions:
- "Cuci bersih ayam.. lalu rebus hingga empuk (kurang lebih setengah jam pakai api kecil)"
- "Selagi menunggu ayam empuk kita haluskan dulu bumbunya (bawang putih, bawang merah, kemiri, ketumbar bubuk, cabai)"
- "Setelah ayam sudah dirasa empuk buang airnya.. lalu siapkan wajan untuk menumis beri sedikit minyak, tunggu hingga panas kuku masukan bahan halus dan tumis hingga harum"
- "Setelah bumbu matang dan harum masukan sedikit air sisa rebusan ayam/air putih biasa dan masukan ayam.. aduk hingga rata lalu masukan 1 bungkus masako, sedikit gula, dan secukupnya kecap manis aduk hingga mendidih.. tunggu beberapa menit hingga air sedikit menyusut dan ayam gongso siap di sajikan 😄😊"
categories:
- Resep
tags:
- gongso
- ayam
- simple

katakunci: gongso ayam simple 
nutrition: 234 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dessert

---


![Gongso ayam simple](https://img-global.cpcdn.com/recipes/073cf1f8c6bf36d3/751x532cq70/gongso-ayam-simple-foto-resep-utama.jpg)

Kamu Sedang mencari inspirasi resep gongso ayam simple yang Enak dan Simpel? Cara menyiapkannya memang tidak susah dan tidak juga mudah. andaikata salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso ayam simple yang enak selayaknya mempunyai aroma dan rasa yang dapat memancing selera kita.

Makanan Gongso ayam ini enak anda bisa mencoba memasak sendiri dirumah. Terinspirasi dari menu babat gongso, kali ini kami memasak ayam gongso. Lihat juga resep Gongso Ayam ala Semarangan enak lainnya.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ayam simple, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menyajikannya. Tidak usah pusing jika mau menyiapkan gongso ayam simple yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.


Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah gongso ayam simple yang siap dikreasikan. Anda dapat membuat Gongso ayam simple menggunakan 9 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Gongso ayam simple:

1. Siapkan 1/4 kg Ayam (aku pakai ceker, kepala, dan sayap)
1. Gunakan 2 butir bawang putih
1. Siapkan 4 butir bawang merah
1. Sediakan 1/2 butir kemiri
1. Gunakan Secukupnya ketumbar bubuk
1. Sediakan 1 sachet masako ayam (bisa ganti dengan garam biasa)
1. Ambil Secukupnya gula pasir
1. Ambil Secukupnya kecap manis
1. Ambil Segenggam cabai (sesuai selera)


PagesBusinessesFood &amp; drinkRestaurantAngkringan Joglo Eco Spesial Gongso Ayam/Sapi &amp; Sop Durem. Ayam Gongso Merah ala saya/foto pribadiSahur, adalah momen yang paling malas buat saya. Karena, mata dipaksa melek dini hari untuk menyiapkan mak. Indonesia memiliki beragam olahan ayam yang lezat. 

<!--inarticleads2-->

##### Cara membuat Gongso ayam simple:

1. Cuci bersih ayam.. lalu rebus hingga empuk (kurang lebih setengah jam pakai api kecil)
1. Selagi menunggu ayam empuk kita haluskan dulu bumbunya (bawang putih, bawang merah, kemiri, ketumbar bubuk, cabai)
1. Setelah ayam sudah dirasa empuk buang airnya.. lalu siapkan wajan untuk menumis beri sedikit minyak, tunggu hingga panas kuku masukan bahan halus dan tumis hingga harum
1. Setelah bumbu matang dan harum masukan sedikit air sisa rebusan ayam/air putih biasa dan masukan ayam.. aduk hingga rata lalu masukan 1 bungkus masako, sedikit gula, dan secukupnya kecap manis aduk hingga mendidih.. tunggu beberapa menit hingga air sedikit menyusut dan ayam gongso siap di sajikan 😄😊


Setiap daerah memiliki menu ayam andalannya, salah satunya Semarang. Ibu kota Jawa Tengah ini punya sajian bernama ayam gongso. Mukbang- resep babat gongso / oseng babat simple TAPI maknyoss. 

Gimana nih? Mudah bukan? Itulah cara membuat gongso ayam simple yang bisa Anda lakukan di rumah. Selamat mencoba!
