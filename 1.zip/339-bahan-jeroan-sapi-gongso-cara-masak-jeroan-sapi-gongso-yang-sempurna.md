---
description: "Bahan Jeroan sapi gongso | Cara Masak Jeroan sapi gongso Yang Sempurna"
title: "Bahan Jeroan sapi gongso | Cara Masak Jeroan sapi gongso Yang Sempurna"
slug: 339-bahan-jeroan-sapi-gongso-cara-masak-jeroan-sapi-gongso-yang-sempurna
date: 2020-12-26T14:43:15.043Z
image: https://img-global.cpcdn.com/recipes/8db5223ecc68bbf7/751x532cq70/jeroan-sapi-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8db5223ecc68bbf7/751x532cq70/jeroan-sapi-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8db5223ecc68bbf7/751x532cq70/jeroan-sapi-gongso-foto-resep-utama.jpg
author: Johanna Marsh
ratingvalue: 4.4
reviewcount: 7
recipeingredient:
- "250 gram jeroan sapi babat usus tetelan berlemakgajih"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 batang lengkuas geprek"
- "3 sdm gula merah"
- "3 sdm kecap manis"
- "6 sdm minyak goreng"
- "500 ml air"
- " Bumbu halus ulekblender "
- "6 buah bawang merah"
- "3 buah bawang putih"
- "5 buah cabe merah"
- "1 buah kemiri"
- "1 sdt lada bubuk"
- "1/2 ruas ibu jari jahe"
- "1/2 ruas ibu jari lengkuas"
- "1/2 sdt garam"
recipeinstructions:
- "Bersihkan, potong-potong lalu rebus jeroan sampai empuk (bisa dengan cara masing-masing agar tidak bau &amp; cepat empuk) saya masak jeroannya 30 menit dengan tambahan rempah seperti ketumbar, garam, lengkuas, jahe, asem jawa. Kemudian saya diamkan selama 2 jam. Lalu dimasak kembali dengan menggunakan air baru 15 menit."
- "Ulek/blender bumbu halus, kemudian siapkan rempah lainnya yang sudah dicuci bersih"
- "Tumis bumbu halus hingga harum, kemudian masukkan bahan lainnya &amp; tambahkan air, lalu masukkan jeroan. Tutup rapat panci, tunggu hingga mendidih lalu koreksi rasa"
- "Hidangkan selagi hangat"
categories:
- Resep
tags:
- jeroan
- sapi
- gongso

katakunci: jeroan sapi gongso 
nutrition: 284 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Lunch

---


![Jeroan sapi gongso](https://img-global.cpcdn.com/recipes/8db5223ecc68bbf7/751x532cq70/jeroan-sapi-gongso-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep jeroan sapi gongso yang Sedap? Cara Memasaknya memang tidak susah dan tidak juga mudah. Jika keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal jeroan sapi gongso yang enak selayaknya memiliki aroma dan rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari jeroan sapi gongso, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tak perlu pusing jika mau menyiapkan jeroan sapi gongso enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.


Berikut ini ada beberapa cara mudah dan praktis dalam mengolah jeroan sapi gongso yang siap dikreasikan. Anda dapat membuat Jeroan sapi gongso menggunakan 17 bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Jeroan sapi gongso:

1. Sediakan 250 gram jeroan sapi (babat, usus, tetelan berlemak/gajih)
1. Ambil 2 lembar daun salam
1. Gunakan 2 lembar daun jeruk
1. Ambil 1 batang lengkuas (geprek)
1. Sediakan 3 sdm gula merah
1. Gunakan 3 sdm kecap manis
1. Ambil 6 sdm minyak goreng
1. Siapkan 500 ml air
1. Siapkan  Bumbu halus (ulek/blender) :
1. Sediakan 6 buah bawang merah
1. Sediakan 3 buah bawang putih
1. Sediakan 5 buah cabe merah
1. Gunakan 1 buah kemiri
1. Ambil 1 sdt lada bubuk
1. Sediakan 1/2 ruas ibu jari jahe
1. Siapkan 1/2 ruas ibu jari lengkuas
1. Siapkan 1/2 sdt garam




<!--inarticleads2-->

##### Cara membuat Jeroan sapi gongso:

1. Bersihkan, potong-potong lalu rebus jeroan sampai empuk (bisa dengan cara masing-masing agar tidak bau &amp; cepat empuk) saya masak jeroannya 30 menit dengan tambahan rempah seperti ketumbar, garam, lengkuas, jahe, asem jawa. Kemudian saya diamkan selama 2 jam. Lalu dimasak kembali dengan menggunakan air baru 15 menit.
1. Ulek/blender bumbu halus, kemudian siapkan rempah lainnya yang sudah dicuci bersih
1. Tumis bumbu halus hingga harum, kemudian masukkan bahan lainnya &amp; tambahkan air, lalu masukkan jeroan. Tutup rapat panci, tunggu hingga mendidih lalu koreksi rasa
1. Hidangkan selagi hangat




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan Jeroan sapi gongso yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman maupun menjadi ide untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
