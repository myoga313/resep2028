---
description: "Bumbu Gongso ati ampela | Cara Buat Gongso ati ampela Yang Lezat Sekali"
title: "Bumbu Gongso ati ampela | Cara Buat Gongso ati ampela Yang Lezat Sekali"
slug: 447-bumbu-gongso-ati-ampela-cara-buat-gongso-ati-ampela-yang-lezat-sekali
date: 2020-09-30T23:54:25.187Z
image: https://img-global.cpcdn.com/recipes/4fd9647657d529e7/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4fd9647657d529e7/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4fd9647657d529e7/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
author: Isaac McCarthy
ratingvalue: 4.7
reviewcount: 14
recipeingredient:
- "3 buah Ati ampela bersihkan"
- "1 batang Serai"
- "2 lembar daun jeruk"
- "1/3 sdt garam"
- "1 sdt Gula pasir skip"
- "1/2 sdt Kaldu bubuk skip"
- "1 sdm Kecap manis"
- "1 sdm Saos tiram"
- "1/2 gelas air matang"
- " Bahan iris "
- "3 siung Bawang merah"
- "2 siung Barang putih"
- "1 buah Cabe hijau besar me buang biji"
- "3 buah Cabe rawit skip"
recipeinstructions:
- "Rebus ati ampela hingga matang, tiriskan lalu potong2"
- "Tumis bahan iris hingga wangi, masukkan ati ampela. Aduk rata"
- "Beri air, kecap manis, saos tiram, garam, gula.Masak hingga kuah menyusut"
- "Angkat dan sajikan"
categories:
- Resep
tags:
- gongso
- ati
- ampela

katakunci: gongso ati ampela 
nutrition: 224 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Dinner

---


![Gongso ati ampela](https://img-global.cpcdn.com/recipes/4fd9647657d529e7/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg)

Kamu Sedang mencari ide resep gongso ati ampela yang Lezat? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. semisal salah mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal gongso ati ampela yang enak selayaknya mempunyai aroma dan cita rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ati ampela, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tidak usah pusing jika ingin menyiapkan gongso ati ampela enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian istimewa.




Di bawah ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah gongso ati ampela yang siap dikreasikan. Anda dapat membuat Gongso ati ampela menggunakan 14 jenis bahan dan 4 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Gongso ati ampela:

1. Gunakan 3 buah Ati ampela, bersihkan
1. Sediakan 1 batang Serai
1. Gunakan 2 lembar daun jeruk
1. Ambil 1/3 sdt garam
1. Sediakan 1 sdt Gula pasir (skip)
1. Sediakan 1/2 sdt Kaldu bubuk (skip)
1. Siapkan 1 sdm Kecap manis
1. Siapkan 1 sdm Saos tiram
1. Sediakan 1/2 gelas air matang
1. Siapkan  Bahan iris :
1. Siapkan 3 siung Bawang merah
1. Ambil 2 siung Barang putih
1. Sediakan 1 buah Cabe hijau besar (me: buang biji)
1. Ambil 3 buah Cabe rawit (skip)




<!--inarticleads2-->

##### Cara menyiapkan Gongso ati ampela:

1. Rebus ati ampela hingga matang, tiriskan lalu potong2
1. Tumis bahan iris hingga wangi, masukkan ati ampela. Aduk rata
1. Beri air, kecap manis, saos tiram, garam, gula.Masak hingga kuah menyusut
1. Angkat dan sajikan




Gimana nih? Mudah bukan? Itulah cara membuat gongso ati ampela yang bisa Anda lakukan di rumah. Selamat mencoba!
