---
description: "Resep masakan Gongso ayam sosis pedas | Cara Membuat Gongso ayam sosis pedas Yang Mudah Dan Praktis"
title: "Resep masakan Gongso ayam sosis pedas | Cara Membuat Gongso ayam sosis pedas Yang Mudah Dan Praktis"
slug: 160-resep-masakan-gongso-ayam-sosis-pedas-cara-membuat-gongso-ayam-sosis-pedas-yang-mudah-dan-praktis
date: 2021-01-07T05:50:05.836Z
image: https://img-global.cpcdn.com/recipes/9ca38b260eba0762/751x532cq70/gongso-ayam-sosis-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9ca38b260eba0762/751x532cq70/gongso-ayam-sosis-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9ca38b260eba0762/751x532cq70/gongso-ayam-sosis-pedas-foto-resep-utama.jpg
author: Jeanette Kim
ratingvalue: 4.2
reviewcount: 12
recipeingredient:
- "100 gram daging ayam potong"
- "5 sosis ayam"
- "Secukupnya sawi hijau kubis"
- "2 siung bawang putih"
- "Secukupnya cabe"
- "Secukupnya merica bubuk"
- "Secukupnya garam"
- "Secukupnya kecap manis"
- "Secukupnya penyedap"
- "Secukupnya saos sambal"
- "2-3 sdm Minyak goreng"
- "Secukupnya air"
- "  sesuai selera"
recipeinstructions:
- "Bismillahirrohmaanirrohiim 😆"
- "Rebus daging ayam 5-10 menit. Tiriskan dan potong-potong kecil*."
- "Sambil menunggu langkah 2, tumbuk bawang putih, beberapa cabe, bubuk merica, dan garam hingga halus. Kemudian iris melintang sosis dan potong-potong sayuran."
- "Tuangkan minyak ke wajan. Tumis bumbu yang sudah ditumbuk halus. Aduk rata."
- "Tuangkan saos, dan sedikit air. Tambahkan ayam, kemudian sosis. Aduk hingga mendidih."
- "Tambahkan air secukupnya, tambahkan garam, kecap, dan penyedap sesuai selera. Aduk rata."
- "Tambahkan sayuran dan cabe yang diiris*. Aduk rata."
- "Icip-icip😋. Tes rasa kalau masih ada yg perlu ditambahkan, bisa tambahkan sampai oke di lidah 😂"
- "Siap disantap. Jangan lupa berdoa sebelum makan yak😂😍"
categories:
- Resep
tags:
- gongso
- ayam
- sosis

katakunci: gongso ayam sosis 
nutrition: 287 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dessert

---


![Gongso ayam sosis pedas](https://img-global.cpcdn.com/recipes/9ca38b260eba0762/751x532cq70/gongso-ayam-sosis-pedas-foto-resep-utama.jpg)

Kamu Sedang mencari ide resep gongso ayam sosis pedas yang Bikin Ngiler? Cara membuatnya memang tidak susah dan tidak juga mudah. misalnya keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso ayam sosis pedas yang enak seharusnya memiliki aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ayam sosis pedas, mulai dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tidak usah pusing jika ingin menyiapkan gongso ayam sosis pedas yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan spesial.


Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah gongso ayam sosis pedas yang siap dikreasikan. Anda dapat menyiapkan Gongso ayam sosis pedas memakai 13 jenis bahan dan 9 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Gongso ayam sosis pedas:

1. Ambil 100 gram daging ayam potong
1. Ambil 5 sosis ayam*
1. Sediakan Secukupnya sawi hijau, kubis*
1. Gunakan 2 siung bawang putih
1. Gunakan Secukupnya cabe*
1. Sediakan Secukupnya merica bubuk
1. Ambil Secukupnya garam
1. Siapkan Secukupnya kecap manis
1. Gunakan Secukupnya penyedap
1. Ambil Secukupnya saos sambal
1. Sediakan 2-3 sdm Minyak goreng
1. Siapkan Secukupnya air
1. Sediakan  &gt; *sesuai selera




<!--inarticleads2-->

##### Cara menyiapkan Gongso ayam sosis pedas:

1. Bismillahirrohmaanirrohiim 😆
1. Rebus daging ayam 5-10 menit. Tiriskan dan potong-potong kecil*.
1. Sambil menunggu langkah 2, tumbuk bawang putih, beberapa cabe, bubuk merica, dan garam hingga halus. Kemudian iris melintang sosis dan potong-potong sayuran.
1. Tuangkan minyak ke wajan. Tumis bumbu yang sudah ditumbuk halus. Aduk rata.
1. Tuangkan saos, dan sedikit air. Tambahkan ayam, kemudian sosis. Aduk hingga mendidih.
1. Tambahkan air secukupnya, tambahkan garam, kecap, dan penyedap sesuai selera. Aduk rata.
1. Tambahkan sayuran dan cabe yang diiris*. Aduk rata.
1. Icip-icip😋. Tes rasa kalau masih ada yg perlu ditambahkan, bisa tambahkan sampai oke di lidah 😂
1. Siap disantap. Jangan lupa berdoa sebelum makan yak😂😍




Gimana nih? Mudah bukan? Itulah cara membuat gongso ayam sosis pedas yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
