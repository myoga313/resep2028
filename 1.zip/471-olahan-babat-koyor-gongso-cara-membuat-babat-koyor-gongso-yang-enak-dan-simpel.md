---
description: "Olahan Babat koyor gongso | Cara Membuat Babat koyor gongso Yang Enak dan Simpel"
title: "Olahan Babat koyor gongso | Cara Membuat Babat koyor gongso Yang Enak dan Simpel"
slug: 471-olahan-babat-koyor-gongso-cara-membuat-babat-koyor-gongso-yang-enak-dan-simpel
date: 2020-09-18T03:52:04.734Z
image: https://img-global.cpcdn.com/recipes/57b7dca07ed39006/751x532cq70/babat-koyor-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/57b7dca07ed39006/751x532cq70/babat-koyor-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/57b7dca07ed39006/751x532cq70/babat-koyor-gongso-foto-resep-utama.jpg
author: Sarah Delgado
ratingvalue: 4.6
reviewcount: 15
recipeingredient:
- "1/4 babat koyor"
- "1 buah jeruk nipis"
- "2 lbr daun salam"
- "Sejumput garam kasar"
- "Secukupnya air"
- "2 sdm kecap sesuai selera"
- " Minyak untuk menumis"
- " Bumbu iris"
- "6 buah bawang merah ukuran kecil"
- " Bumbu halus"
- "5 buah cabe keriting"
- "5 buah cabe rawit"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "3 buah kemiri"
- "Secukupnya garam"
recipeinstructions:
- "Cuci bersih babat dan koyor"
- "Masukkan daun salam, jeruk nipis, garam, dan air lalu rebus 30 menit"
- "Setelah empuk potong2 babat koyor"
- "Iris bawang merah untuk campuran gongso"
- "Sangrai kemiri"
- "Siapkan cabe besar, cabe rawit, bawang putih, bawang merah, kemiri sangrai, dan garam"
- "Potong lalu haluskan bumbu"
- "Panaskan minyak, lalu tumis bawang merah hingga layu"
- "Masukkan bumbu halus, tumis hingga harum, lalu tambahkan kecap"
- "Masukkan babat koyor, aduk2"
- "Tambahkan air, lalu masak hingga matang"
- "Sajikan dan nikmati selagi hangat bunda 😘"
categories:
- Resep
tags:
- babat
- koyor
- gongso

katakunci: babat koyor gongso 
nutrition: 171 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Dessert

---


![Babat koyor gongso](https://img-global.cpcdn.com/recipes/57b7dca07ed39006/751x532cq70/babat-koyor-gongso-foto-resep-utama.jpg)

Kamu Sedang mencari ide resep babat koyor gongso yang Enak Dan Mudah? Cara membuatnya memang susah-susah gampang. seumpama salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal babat koyor gongso yang enak seharusnya punya aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat koyor gongso, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tidak usah pusing jika mau menyiapkan babat koyor gongso enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian spesial.




Nah, kali ini kita coba, yuk, buat babat koyor gongso sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Babat koyor gongso memakai 16 bahan dan 12 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Babat koyor gongso:

1. Ambil 1/4 babat koyor
1. Siapkan 1 buah jeruk nipis
1. Siapkan 2 lbr daun salam
1. Siapkan Sejumput garam kasar
1. Sediakan Secukupnya air
1. Siapkan 2 sdm kecap (sesuai selera)
1. Siapkan  Minyak untuk menumis
1. Siapkan  Bumbu iris
1. Sediakan 6 buah bawang merah ukuran kecil
1. Ambil  Bumbu halus
1. Ambil 5 buah cabe keriting
1. Siapkan 5 buah cabe rawit
1. Sediakan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Ambil 3 buah kemiri
1. Gunakan Secukupnya garam




<!--inarticleads2-->

##### Cara membuat Babat koyor gongso:

1. Cuci bersih babat dan koyor
1. Masukkan daun salam, jeruk nipis, garam, dan air lalu rebus 30 menit
1. Setelah empuk potong2 babat koyor
1. Iris bawang merah untuk campuran gongso
1. Sangrai kemiri
1. Siapkan cabe besar, cabe rawit, bawang putih, bawang merah, kemiri sangrai, dan garam
1. Potong lalu haluskan bumbu
1. Panaskan minyak, lalu tumis bawang merah hingga layu
1. Masukkan bumbu halus, tumis hingga harum, lalu tambahkan kecap
1. Masukkan babat koyor, aduk2
1. Tambahkan air, lalu masak hingga matang
1. Sajikan dan nikmati selagi hangat bunda 😘




Bagaimana? Gampang kan? Itulah cara membuat babat koyor gongso yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
