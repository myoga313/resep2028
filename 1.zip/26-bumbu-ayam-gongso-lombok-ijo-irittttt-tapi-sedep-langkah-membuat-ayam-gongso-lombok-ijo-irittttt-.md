---
description: "Bumbu Ayam Gongso lombok ijo irittttt tapi sedep | Langkah Membuat Ayam Gongso lombok ijo irittttt tapi sedep Yang Sempurna"
title: "Bumbu Ayam Gongso lombok ijo irittttt tapi sedep | Langkah Membuat Ayam Gongso lombok ijo irittttt tapi sedep Yang Sempurna"
slug: 26-bumbu-ayam-gongso-lombok-ijo-irittttt-tapi-sedep-langkah-membuat-ayam-gongso-lombok-ijo-irittttt-tapi-sedep-yang-sempurna
date: 2020-12-15T08:04:23.043Z
image: https://img-global.cpcdn.com/recipes/09160ed4e76ce4ea/751x532cq70/ayam-gongso-lombok-ijo-irittttt-tapi-sedep-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/09160ed4e76ce4ea/751x532cq70/ayam-gongso-lombok-ijo-irittttt-tapi-sedep-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/09160ed4e76ce4ea/751x532cq70/ayam-gongso-lombok-ijo-irittttt-tapi-sedep-foto-resep-utama.jpg
author: Lulu Dawson
ratingvalue: 3.6
reviewcount: 13
recipeingredient:
- "1 kg ayam potong jd 12"
- "4 siung bawang merah"
- "3 siung bawang putih"
- "2 ruas jari Lengkuas"
- "4 lembar Daun jeruk"
- "10 buah Cabe rawit setan  karna suka pedes"
- "5 buah Cabe kriting"
- "10 buah Cabe ijo  biarr sedep khas cabe ijo kerasa"
- "1 sdt Garam"
- "1 sdm Gula"
- "3 sdt Penyedap  krn sy anti micin sy pake penyedap jamur"
- "Secukupnya Kecap  buat pemaniss n pewarnaa biar kliatan sedep"
- "2 gelas belimbing Air"
recipeinstructions:
- "Rebusss ayam 10mnt aja sesedah di rebussss siram air dingin (gunanya biar ayam tdk gampang hancur ketika di tumiss) tirissskan"
- "Tumisss bumbu2 masuk semuaaaa,,tumiss sampee harum"
- "Masukkan air tambah garam,gula,penyedap"
- "Masukkan ayam lalu kecap"
- "Masak sampee air agak surut lalu oseng2 pakee spatula biarr bumbu meresap ke ayam"
- "Setelah sekiranyaa matang n meresap"
- "Sajikan"
categories:
- Resep
tags:
- ayam
- gongso
- lombok

katakunci: ayam gongso lombok 
nutrition: 146 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Gongso lombok ijo irittttt tapi sedep](https://img-global.cpcdn.com/recipes/09160ed4e76ce4ea/751x532cq70/ayam-gongso-lombok-ijo-irittttt-tapi-sedep-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep ayam gongso lombok ijo irittttt tapi sedep yang Enak Dan Mudah? Cara Buatnya memang tidak susah dan tidak juga mudah. seandainya salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal ayam gongso lombok ijo irittttt tapi sedep yang enak harusnya sih mempunyai aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam gongso lombok ijo irittttt tapi sedep, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tak perlu pusing kalau hendak menyiapkan ayam gongso lombok ijo irittttt tapi sedep enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.




Di bawah ini ada beberapa tips dan trik praktis untuk membuat ayam gongso lombok ijo irittttt tapi sedep yang siap dikreasikan. Anda dapat membuat Ayam Gongso lombok ijo irittttt tapi sedep menggunakan 13 jenis bahan dan 7 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam Gongso lombok ijo irittttt tapi sedep:

1. Siapkan 1 kg ayam (potong jd 12)
1. Sediakan 4 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Gunakan 2 ruas jari Lengkuas
1. Gunakan 4 lembar Daun jeruk
1. Sediakan 10 buah Cabe rawit setan  (karna suka pedes)
1. Ambil 5 buah Cabe kriting
1. Gunakan 10 buah Cabe ijo  (biarr sedep khas cabe ijo kerasa)
1. Sediakan 1 sdt Garam
1. Siapkan 1 sdm Gula
1. Sediakan 3 sdt Penyedap  (krn sy anti micin sy pake penyedap jamur)
1. Siapkan Secukupnya Kecap  buat pemaniss n pewarnaa biar kliatan sedep
1. Sediakan 2 gelas belimbing Air




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Gongso lombok ijo irittttt tapi sedep:

1. Rebusss ayam 10mnt aja sesedah di rebussss siram air dingin (gunanya biar ayam tdk gampang hancur ketika di tumiss) tirissskan
1. Tumisss bumbu2 masuk semuaaaa,,tumiss sampee harum
1. Masukkan air tambah garam,gula,penyedap
1. Masukkan ayam lalu kecap
1. Masak sampee air agak surut lalu oseng2 pakee spatula biarr bumbu meresap ke ayam
1. Setelah sekiranyaa matang n meresap
1. Sajikan




Bagaimana? Mudah bukan? Itulah cara menyiapkan ayam gongso lombok ijo irittttt tapi sedep yang bisa Anda lakukan di rumah. Selamat mencoba!
