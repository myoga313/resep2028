---
description: "Resep masakan Gongso Ayam | Cara Mengolah Gongso Ayam Yang Sedap"
title: "Resep masakan Gongso Ayam | Cara Mengolah Gongso Ayam Yang Sedap"
slug: 202-resep-masakan-gongso-ayam-cara-mengolah-gongso-ayam-yang-sedap
date: 2020-09-24T09:38:19.451Z
image: https://img-global.cpcdn.com/recipes/f21c2998a30c82c5/751x532cq70/gongso-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f21c2998a30c82c5/751x532cq70/gongso-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f21c2998a30c82c5/751x532cq70/gongso-ayam-foto-resep-utama.jpg
author: Owen Todd
ratingvalue: 3.2
reviewcount: 6
recipeingredient:
- "250 gr ayam filet"
- "secukupnya kubis"
- "1 butir telur"
- "3 siung bawang putih"
- "5 buah cabe setan"
- "2 buah cabe merah"
- "1/2 buah tomat"
- "1/4 buah bawang bombay"
- "1 sdt merica bubuk"
- "2 sdm saori lada hitam"
- "5 sdm kecap manis"
- "400 ml air"
recipeinstructions:
- "Potong ayam kecil2 lalu lumuri dengan saori lada hitam, iris juga kubis,bombay dan cabai,geprek dan cincang bawang putih"
- "Panaskan minyak,tumis bumbu,setelah harum tuang air,tunggu mendidih,baru masukan ayam"
- "Setelah air tinggal setengah,masukan telur,biarkan matang,aduk,lalu masukan kubis,tunggu hingga air hampir habis,matang,siap sajikan"
categories:
- Resep
tags:
- gongso
- ayam

katakunci: gongso ayam 
nutrition: 166 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Dessert

---


![Gongso Ayam](https://img-global.cpcdn.com/recipes/f21c2998a30c82c5/751x532cq70/gongso-ayam-foto-resep-utama.jpg)

Lagi mencari ide resep gongso ayam yang Menggugah Selera? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. Jika salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso ayam yang enak seharusnya mempunyai aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ayam, pertama dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tidak usah pusing kalau hendak menyiapkan gongso ayam enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.

Lihat juga resep Gongso Ayam ala Semarangan enak lainnya. Aduuuuuh lama gak upload nih, tapi tenang aja kita bakalan rajin lagi kok hehe. kali ini kita masak gongso ayam nih, siapa tau jadi ide masak buat temen. Gongso berarti tumis dalam bahasa jawa.


Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah gongso ayam yang siap dikreasikan. Anda dapat membuat Gongso Ayam memakai 12 bahan dan 3 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Gongso Ayam:

1. Sediakan 250 gr ayam filet
1. Ambil secukupnya kubis
1. Sediakan 1 butir telur
1. Gunakan 3 siung bawang putih
1. Siapkan 5 buah cabe setan
1. Sediakan 2 buah cabe merah
1. Ambil 1/2 buah tomat
1. Gunakan 1/4 buah bawang bombay
1. Siapkan 1 sdt merica bubuk
1. Gunakan 2 sdm saori lada hitam
1. Sediakan 5 sdm kecap manis
1. Siapkan 400 ml air


Jadi Gongso Ayam kali ini bisa dikatakan dengan sebutan Gongso Ayam Suwir istimewa atau Goreng ataupun Gongso Ayam Goreng Suwir loh. Yah mungkin berbeda daerah berbeda juga. 

<!--inarticleads2-->

##### Cara menyiapkan Gongso Ayam:

1. Potong ayam kecil2 lalu lumuri dengan saori lada hitam, iris juga kubis,bombay dan cabai,geprek dan cincang bawang putih
1. Panaskan minyak,tumis bumbu,setelah harum tuang air,tunggu mendidih,baru masukan ayam
1. Setelah air tinggal setengah,masukan telur,biarkan matang,aduk,lalu masukan kubis,tunggu hingga air hampir habis,matang,siap sajikan




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Harapan kami, olahan Gongso Ayam yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman ataupun menjadi inspirasi bagi Anda yang berkeinginan untuk berbisnis kuliner. Selamat mencoba!
