---
description: "Resep Gongso Kepala Ayam | Resep Membuat Gongso Kepala Ayam Yang Sedap"
title: "Resep Gongso Kepala Ayam | Resep Membuat Gongso Kepala Ayam Yang Sedap"
slug: 230-resep-gongso-kepala-ayam-resep-membuat-gongso-kepala-ayam-yang-sedap
date: 2020-08-03T00:18:09.498Z
image: https://img-global.cpcdn.com/recipes/34f491b5ce0a6dda/751x532cq70/gongso-kepala-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/34f491b5ce0a6dda/751x532cq70/gongso-kepala-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/34f491b5ce0a6dda/751x532cq70/gongso-kepala-ayam-foto-resep-utama.jpg
author: Marie Ford
ratingvalue: 4.6
reviewcount: 5
recipeingredient:
- " Kepala Ayam"
- " Bawang Merah"
- " Bawang Putih"
- " Daun Salam"
- " Lengkuas potong agak sedang digeprek"
- " Jahe seruas jari"
- " Kunyit seruas jari"
- " Daun Salam"
- " Cabe rawit Tergantung selera jg mau pedas atau tidak"
- " Cabe Merah Besar"
- " irisan daun bawang"
- " Pete atau sesuai selera"
- " Gula Garam Penyedap Rasa"
- " Minyak goreng utk menumis"
recipeinstructions:
- "Cuci bersih kepala ayam, lalu rebus kepala ayam bersama dengan penyedap rasa, garam, kunyit (utk memberi warna pada ayam), jahe dan lengkuas, ini berfungsi untuk menghilangkan bau amis dan agar bumbu lebih meresap sempurna kedalam kepala ayam. Masak hingga empuk / matang atau kurang lebih 15menit. Setelah empuk matikan kompor, lalu angkat dan tiriskan."
- "Setelah itu haluskan bawang merah bawang putih, cabai merah dan cabai rawit (atau bisa cabainya di potong potong kecil kecil sesuai selera, karna saya suka pedas, saya lebih suka dihaluskan 😁)"
- "Siapkan wajan untuk menumis, masukkan sedikit minyak goreng setelah minyak goreng panas masukkan bumbu yang sudah dihaluskan tadii beserta 2 lembar daun salam penyedap rasa garam gula pasir sedikit tunggu hingga tercium aroma harum pada bumbu. Setelah harum masukkan ayam tadi masak sebentar / hingga matang lalu masukkan irisan daun bawang dan pete koreksi rasa. Aduk sebentar. Matikan kompor. Gongso kepala ayam siap disajikan 😊"
categories:
- Resep
tags:
- gongso
- kepala
- ayam

katakunci: gongso kepala ayam 
nutrition: 132 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Dinner

---


![Gongso Kepala Ayam](https://img-global.cpcdn.com/recipes/34f491b5ce0a6dda/751x532cq70/gongso-kepala-ayam-foto-resep-utama.jpg)

Kamu Sedang mencari inspirasi resep gongso kepala ayam yang Lezat Sekali? Cara Memasaknya memang tidak terlalu sulit namun tidak gampang juga. seumpama keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso kepala ayam yang enak seharusnya mempunyai aroma dan rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso kepala ayam, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tak perlu pusing jika mau menyiapkan gongso kepala ayam enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.




Nah, kali ini kita coba, yuk, siapkan gongso kepala ayam sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Gongso Kepala Ayam memakai 14 jenis bahan dan 3 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Gongso Kepala Ayam:

1. Siapkan  Kepala Ayam
1. Siapkan  Bawang Merah
1. Siapkan  Bawang Putih
1. Siapkan  Daun Salam
1. Sediakan  Lengkuas potong agak sedang digeprek
1. Ambil  Jahe seruas jari
1. Gunakan  Kunyit seruas jari
1. Ambil  Daun Salam
1. Siapkan  Cabe rawit (Tergantung selera jg mau pedas atau tidak)
1. Gunakan  Cabe Merah Besar
1. Ambil  irisan daun bawang
1. Siapkan  Pete (atau sesuai selera)
1. Ambil  Gula, Garam, Penyedap Rasa
1. Siapkan  Minyak goreng utk menumis




<!--inarticleads2-->

##### Cara menyiapkan Gongso Kepala Ayam:

1. Cuci bersih kepala ayam, lalu rebus kepala ayam bersama dengan penyedap rasa, garam, kunyit (utk memberi warna pada ayam), jahe dan lengkuas, ini berfungsi untuk menghilangkan bau amis dan agar bumbu lebih meresap sempurna kedalam kepala ayam. Masak hingga empuk / matang atau kurang lebih 15menit. Setelah empuk matikan kompor, lalu angkat dan tiriskan.
1. Setelah itu haluskan bawang merah bawang putih, cabai merah dan cabai rawit (atau bisa cabainya di potong potong kecil kecil sesuai selera, karna saya suka pedas, saya lebih suka dihaluskan 😁)
1. Siapkan wajan untuk menumis, masukkan sedikit minyak goreng setelah minyak goreng panas masukkan bumbu yang sudah dihaluskan tadii beserta 2 lembar daun salam penyedap rasa garam gula pasir sedikit tunggu hingga tercium aroma harum pada bumbu. Setelah harum masukkan ayam tadi masak sebentar / hingga matang lalu masukkan irisan daun bawang dan pete koreksi rasa. Aduk sebentar. Matikan kompor. Gongso kepala ayam siap disajikan 😊




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Gongso Kepala Ayam yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman maupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
