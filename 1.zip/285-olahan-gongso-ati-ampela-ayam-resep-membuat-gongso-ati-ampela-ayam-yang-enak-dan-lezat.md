---
description: "Olahan Gongso Ati Ampela Ayam | Resep Membuat Gongso Ati Ampela Ayam Yang Enak Dan Lezat"
title: "Olahan Gongso Ati Ampela Ayam | Resep Membuat Gongso Ati Ampela Ayam Yang Enak Dan Lezat"
slug: 285-olahan-gongso-ati-ampela-ayam-resep-membuat-gongso-ati-ampela-ayam-yang-enak-dan-lezat
date: 2020-11-26T19:05:11.656Z
image: https://img-global.cpcdn.com/recipes/030630ac2ccd724f/751x532cq70/gongso-ati-ampela-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/030630ac2ccd724f/751x532cq70/gongso-ati-ampela-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/030630ac2ccd724f/751x532cq70/gongso-ati-ampela-ayam-foto-resep-utama.jpg
author: Lucy Jennings
ratingvalue: 3.5
reviewcount: 12
recipeingredient:
- "5 pasang ati ampela ayam"
- "3 lembar daun salam"
- "4 siung bawang merah"
- "2 siung bawang putih"
- "sesuai selera Cabai"
- "3 lembar daun jeruk"
- "1 batang serai"
- "1 sdm kecap manis"
- "secukupnya Gula garam"
recipeinstructions:
- "Rebus ati ampela ayam dengan daun salam hingga matang"
- "Goreng sebentar ati ampela ayam"
- "Haluskan bawang merah, bawang putih, cabai"
- "Tumis bumbu halus, daun jeruk dan serai hingga harum"
- "Tambahkan kecap manis dan sedikit air"
- "Masukkan ati ampela, koreksi rasa dengan gula dan garam"
- "Masak hingga bumbu meresap"
categories:
- Resep
tags:
- gongso
- ati
- ampela

katakunci: gongso ati ampela 
nutrition: 214 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT52M"
recipeyield: "1"
recipecategory: Dessert

---


![Gongso Ati Ampela Ayam](https://img-global.cpcdn.com/recipes/030630ac2ccd724f/751x532cq70/gongso-ati-ampela-ayam-foto-resep-utama.jpg)

Lagi mencari ide resep gongso ati ampela ayam yang Sempurna? Cara membuatnya memang tidak susah dan tidak juga mudah. Jika salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso ati ampela ayam yang enak selayaknya memiliki aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ati ampela ayam, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tak perlu pusing jika hendak menyiapkan gongso ati ampela ayam enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.




Di bawah ini ada beberapa tips dan trik praktis untuk membuat gongso ati ampela ayam yang siap dikreasikan. Anda dapat membuat Gongso Ati Ampela Ayam menggunakan 9 jenis bahan dan 7 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Gongso Ati Ampela Ayam:

1. Sediakan 5 pasang ati ampela ayam
1. Gunakan 3 lembar daun salam
1. Ambil 4 siung bawang merah
1. Ambil 2 siung bawang putih
1. Sediakan sesuai selera Cabai
1. Ambil 3 lembar daun jeruk
1. Siapkan 1 batang serai
1. Sediakan 1 sdm kecap manis
1. Siapkan secukupnya Gula garam




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso Ati Ampela Ayam:

1. Rebus ati ampela ayam dengan daun salam hingga matang
1. Goreng sebentar ati ampela ayam
1. Haluskan bawang merah, bawang putih, cabai
1. Tumis bumbu halus, daun jeruk dan serai hingga harum
1. Tambahkan kecap manis dan sedikit air
1. Masukkan ati ampela, koreksi rasa dengan gula dan garam
1. Masak hingga bumbu meresap




Gimana nih? Gampang kan? Itulah cara membuat gongso ati ampela ayam yang bisa Anda lakukan di rumah. Selamat mencoba!
