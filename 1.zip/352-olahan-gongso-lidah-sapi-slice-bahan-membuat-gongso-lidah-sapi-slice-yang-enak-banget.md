---
description: "Olahan Gongso Lidah Sapi Slice | Bahan Membuat Gongso Lidah Sapi Slice Yang Enak Banget"
title: "Olahan Gongso Lidah Sapi Slice | Bahan Membuat Gongso Lidah Sapi Slice Yang Enak Banget"
slug: 352-olahan-gongso-lidah-sapi-slice-bahan-membuat-gongso-lidah-sapi-slice-yang-enak-banget
date: 2020-10-24T21:16:18.967Z
image: https://img-global.cpcdn.com/recipes/0467612dd0353347/751x532cq70/gongso-lidah-sapi-slice-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0467612dd0353347/751x532cq70/gongso-lidah-sapi-slice-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0467612dd0353347/751x532cq70/gongso-lidah-sapi-slice-foto-resep-utama.jpg
author: Marie Welch
ratingvalue: 4.1
reviewcount: 15
recipeingredient:
- " lidah sapi slice"
- " kecap manis untuk marinasi"
- " bawang merah"
- " bawang putih"
- " cabe ijo besar ukuran menyesuaikan bahan lidah sapi"
- " cabe merah besar ukuran menyesuaikan bahan lidah sapi"
- " kecap manis"
- " saus tiram"
- " kecap asin untuk mengganti garam"
- " kaldu bubuk"
- " merica hitam bubuk tambahan dari saya"
- " air"
recipeinstructions:
- "Rendam dan marinasi lidah dengan kecap manis, diamkan si kulkas selama 30-60 menit sebelum diolah"
- "Iris cabe dan bawang, tumis cabe terlebih dahulu, masukkan bawang tumis hingga mulai layu, tambahkan air"
- "Masukkan lidah sapi aduk rata, beri kecap manis, saus tiram dan kecap asin, kaldu dan lada lalu tutup wajan selama 5 menit masak hingga air mulai menyusut"
- "Buka tutup wajan, teruskan memasak hingga lidah sapi empuk dan kuah mengental, koreksi rasa, matikan kompor, siap disajikan"
categories:
- Resep
tags:
- gongso
- lidah
- sapi

katakunci: gongso lidah sapi 
nutrition: 159 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dinner

---


![Gongso Lidah Sapi Slice](https://img-global.cpcdn.com/recipes/0467612dd0353347/751x532cq70/gongso-lidah-sapi-slice-foto-resep-utama.jpg)

Bunda Sedang mencari ide resep gongso lidah sapi slice yang Bisa Manjain Lidah? Cara Bikinnya memang tidak terlalu sulit namun tidak gampang juga. semisal keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso lidah sapi slice yang enak harusnya sih punya aroma dan cita rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso lidah sapi slice, pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tidak usah pusing jika ingin menyiapkan gongso lidah sapi slice yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian istimewa.


Nah, kali ini kita coba, yuk, buat gongso lidah sapi slice sendiri di rumah. Tetap berbahan yang sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Gongso Lidah Sapi Slice menggunakan 12 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Gongso Lidah Sapi Slice:

1. Ambil  lidah sapi slice
1. Gunakan  kecap manis untuk marinasi
1. Sediakan  bawang merah
1. Gunakan  bawang putih
1. Siapkan  cabe ijo besar, ukuran menyesuaikan bahan lidah sapi
1. Ambil  cabe merah besar, ukuran menyesuaikan bahan lidah sapi
1. Gunakan  kecap manis
1. Gunakan  saus tiram
1. Gunakan  kecap asin (untuk mengganti garam)
1. Siapkan  kaldu bubuk
1. Sediakan  merica hitam bubuk (tambahan dari saya)
1. Siapkan  air




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso Lidah Sapi Slice:

1. Rendam dan marinasi lidah dengan kecap manis, diamkan si kulkas selama 30-60 menit sebelum diolah
1. Iris cabe dan bawang, tumis cabe terlebih dahulu, masukkan bawang tumis hingga mulai layu, tambahkan air
1. Masukkan lidah sapi aduk rata, beri kecap manis, saus tiram dan kecap asin, kaldu dan lada lalu tutup wajan selama 5 menit masak hingga air mulai menyusut
1. Buka tutup wajan, teruskan memasak hingga lidah sapi empuk dan kuah mengental, koreksi rasa, matikan kompor, siap disajikan




Bagaimana? Gampang kan? Itulah cara membuat gongso lidah sapi slice yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
