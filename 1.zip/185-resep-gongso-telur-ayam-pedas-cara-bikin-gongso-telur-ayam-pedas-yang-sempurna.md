---
description: "Resep Gongso Telur Ayam Pedas | Cara Bikin Gongso Telur Ayam Pedas Yang Sempurna"
title: "Resep Gongso Telur Ayam Pedas | Cara Bikin Gongso Telur Ayam Pedas Yang Sempurna"
slug: 185-resep-gongso-telur-ayam-pedas-cara-bikin-gongso-telur-ayam-pedas-yang-sempurna
date: 2020-11-11T03:04:34.281Z
image: https://img-global.cpcdn.com/recipes/9eac3e9c5fba5542/751x532cq70/gongso-telur-ayam-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9eac3e9c5fba5542/751x532cq70/gongso-telur-ayam-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9eac3e9c5fba5542/751x532cq70/gongso-telur-ayam-pedas-foto-resep-utama.jpg
author: Rosa Dennis
ratingvalue: 5
reviewcount: 6
recipeingredient:
- "1/2 kg ayam"
- "2 butir telur ayam"
- "1 bgks Caisim  Sawi Hijau"
- "2 butir tomat hijau"
- "sedikit Garam"
- "secukupnya Minyak goreng"
- "sedikit Gula pasir"
- "secukupnya Kecap manis"
- " Bumbu Halus "
- "5 siung bawang putih"
- "5 siung bawang merah"
- "1/2 ons cabai merah"
- "secukupnya Garam"
recipeinstructions:
- "Rebus ayam dan beri sedikit garam, setelah matang angkat tiriskan, kemudian suwir suwir ayam tersebut"
- "Siapkan sedikit minyak, ceplok 2 butir telur ayam, beri sedikit garam, orak arik telur tersebut, angkat, tiriskan"
- "Di wajan berbeda, siapkan minyak panas untuk menumis, masukkan bumbu halus. Tumis hingga harum, masukkan suwiran ayam dan orak arik telur, aduk hingga rata."
- "Masukkan sawi hijau yang sudah dipotong sesuai selera. Beri air secukupnya. Tambahkan gula pasir, garam, bumbu penyedap dan kecap sesuai selera. Masukkan tomat yang sudah dipotong."
- "Koreksi rasa, sajikan."
categories:
- Resep
tags:
- gongso
- telur
- ayam

katakunci: gongso telur ayam 
nutrition: 227 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Dinner

---


![Gongso Telur Ayam Pedas](https://img-global.cpcdn.com/recipes/9eac3e9c5fba5542/751x532cq70/gongso-telur-ayam-pedas-foto-resep-utama.jpg)

Sedang mencari inspirasi resep gongso telur ayam pedas yang Bisa Manjain Lidah? Cara Memasaknya memang tidak susah dan tidak juga mudah. apabila keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso telur ayam pedas yang enak harusnya sih punya aroma dan rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso telur ayam pedas, mulai dari jenis bahan, lalu pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tidak usah pusing jika mau menyiapkan gongso telur ayam pedas enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.




Nah, kali ini kita coba, yuk, siapkan gongso telur ayam pedas sendiri di rumah. Tetap berbahan yang sederhana, sajian ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Gongso Telur Ayam Pedas memakai 13 jenis bahan dan 5 tahap pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Gongso Telur Ayam Pedas:

1. Gunakan 1/2 kg ayam
1. Gunakan 2 butir telur ayam
1. Gunakan 1 bgks Caisim / Sawi Hijau
1. Siapkan 2 butir tomat hijau
1. Gunakan sedikit Garam
1. Gunakan secukupnya Minyak goreng
1. Siapkan sedikit Gula pasir
1. Gunakan secukupnya Kecap manis
1. Siapkan  Bumbu Halus :
1. Ambil 5 siung bawang putih
1. Siapkan 5 siung bawang merah
1. Sediakan 1/2 ons cabai merah
1. Siapkan secukupnya Garam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso Telur Ayam Pedas:

1. Rebus ayam dan beri sedikit garam, setelah matang angkat tiriskan, kemudian suwir suwir ayam tersebut
1. Siapkan sedikit minyak, ceplok 2 butir telur ayam, beri sedikit garam, orak arik telur tersebut, angkat, tiriskan
1. Di wajan berbeda, siapkan minyak panas untuk menumis, masukkan bumbu halus. Tumis hingga harum, masukkan suwiran ayam dan orak arik telur, aduk hingga rata.
1. Masukkan sawi hijau yang sudah dipotong sesuai selera. Beri air secukupnya. Tambahkan gula pasir, garam, bumbu penyedap dan kecap sesuai selera. Masukkan tomat yang sudah dipotong.
1. Koreksi rasa, sajikan.




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Gongso Telur Ayam Pedas yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman ataupun menjadi inspirasi bagi Anda yang berkeinginan untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
