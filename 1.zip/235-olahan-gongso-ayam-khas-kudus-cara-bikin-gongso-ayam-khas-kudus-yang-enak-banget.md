---
description: "Olahan Gongso Ayam khas Kudus | Cara Bikin Gongso Ayam khas Kudus Yang Enak Banget"
title: "Olahan Gongso Ayam khas Kudus | Cara Bikin Gongso Ayam khas Kudus Yang Enak Banget"
slug: 235-olahan-gongso-ayam-khas-kudus-cara-bikin-gongso-ayam-khas-kudus-yang-enak-banget
date: 2020-12-30T18:21:19.471Z
image: https://img-global.cpcdn.com/recipes/c37bda4ca874fa30/751x532cq70/gongso-ayam-khas-kudus-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c37bda4ca874fa30/751x532cq70/gongso-ayam-khas-kudus-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c37bda4ca874fa30/751x532cq70/gongso-ayam-khas-kudus-foto-resep-utama.jpg
author: Irene Vaughn
ratingvalue: 3.8
reviewcount: 7
recipeingredient:
- " ayam kampung bisa diganti jenis ayam yg lain"
- " sawi"
- " kolkubis"
- " tomat ukuran besar"
- " bawang merah iris tipis"
- " cabe rawit potong kecilkecil"
- " kecap manis"
- " gula merah"
- " minyak goreng untuk menumis"
- " air"
- " garam dan gula pasir"
- " bumbu halus "
- " bawang putih"
- " kemiri"
- " merica butiran"
recipeinstructions:
- "Rebus ayam sampai matang, air rebusan ayam jangan dibuang."
- "Tumis bawang merah sampai layu, masukkan bumbu halus dan tumis sampai harum."
- "Masukkan ayam beserta air rebusannya, tambahkan cabe rawit, gula merah, kecap manis, garam dan gula pasir."
- "Masak ayam sampai air menyusut dan koreksi rasa."
- "Masukkan tomat, sawi dan kol, aduk rata masak sampai sayuran layu, matikan api."
- "Pindahkan kewadah dan ayam gongso siap disajikan."
categories:
- Resep
tags:
- gongso
- ayam
- khas

katakunci: gongso ayam khas 
nutrition: 166 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dinner

---


![Gongso Ayam khas Kudus](https://img-global.cpcdn.com/recipes/c37bda4ca874fa30/751x532cq70/gongso-ayam-khas-kudus-foto-resep-utama.jpg)

Sedang mencari ide resep gongso ayam khas kudus yang Lezat Sekali? Cara Memasaknya memang tidak terlalu sulit namun tidak gampang juga. andaikata salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso ayam khas kudus yang enak harusnya sih punya aroma dan rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ayam khas kudus, mulai dari jenis bahan, kemudian pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tidak usah pusing kalau ingin menyiapkan gongso ayam khas kudus enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.


Berikut ini ada beberapa cara mudah dan praktis dalam mengolah gongso ayam khas kudus yang siap dikreasikan. Anda bisa membuat Gongso Ayam khas Kudus menggunakan 15 jenis bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Gongso Ayam khas Kudus:

1. Sediakan  ayam kampung (bisa diganti jenis ayam yg lain)
1. Ambil  sawi
1. Sediakan  kol/kubis
1. Gunakan  tomat ukuran besar
1. Gunakan  bawang merah (iris tipis)
1. Gunakan  cabe rawit (potong kecil-kecil)
1. Ambil  kecap manis
1. Ambil  gula merah
1. Siapkan  minyak goreng (untuk menumis)
1. Sediakan  air
1. Siapkan  garam dan gula pasir
1. Ambil  bumbu halus :
1. Siapkan  bawang putih
1. Ambil  kemiri
1. Sediakan  merica butiran




<!--inarticleads2-->

##### Cara menyiapkan Gongso Ayam khas Kudus:

1. Rebus ayam sampai matang, air rebusan ayam jangan dibuang.
1. Tumis bawang merah sampai layu, masukkan bumbu halus dan tumis sampai harum.
1. Masukkan ayam beserta air rebusannya, tambahkan cabe rawit, gula merah, kecap manis, garam dan gula pasir.
1. Masak ayam sampai air menyusut dan koreksi rasa.
1. Masukkan tomat, sawi dan kol, aduk rata masak sampai sayuran layu, matikan api.
1. Pindahkan kewadah dan ayam gongso siap disajikan.




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Besar harapan kami, olahan Gongso Ayam khas Kudus yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman ataupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
