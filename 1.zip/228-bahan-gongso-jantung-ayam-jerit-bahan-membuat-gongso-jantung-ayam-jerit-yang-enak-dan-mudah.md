---
description: "Bahan Gongso Jantung Ayam Jerit | Bahan Membuat Gongso Jantung Ayam Jerit Yang Enak Dan Mudah"
title: "Bahan Gongso Jantung Ayam Jerit | Bahan Membuat Gongso Jantung Ayam Jerit Yang Enak Dan Mudah"
slug: 228-bahan-gongso-jantung-ayam-jerit-bahan-membuat-gongso-jantung-ayam-jerit-yang-enak-dan-mudah
date: 2020-08-08T11:10:06.318Z
image: https://img-global.cpcdn.com/recipes/0d54b99456ee8633/751x532cq70/gongso-jantung-ayam-jerit-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0d54b99456ee8633/751x532cq70/gongso-jantung-ayam-jerit-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0d54b99456ee8633/751x532cq70/gongso-jantung-ayam-jerit-foto-resep-utama.jpg
author: Lilly Warren
ratingvalue: 4.4
reviewcount: 6
recipeingredient:
- " jantung ayam"
- " daun salam"
- " daun jeruk"
- " kecap manis"
- " Garam"
- " Gula pasir"
- " Kaldu bubuk"
- " Air"
- " Bumbu dihaluskan "
- " cabai rawit merah"
- " cabai merah keriting"
- " bawang merah"
- " bawang putih"
- " Bumbu iris "
- " cabai rawit merah"
- " cabai hijau gendut"
- " kol iris besarbesar"
recipeinstructions:
- "Cuci bersih jantung."
- "Rebus hingga matang"
- "Tumis bumbu yang dihaluskan, tambah daun salam dan daun jeruk. Masak hingga bumbu matang."
- "Lalu masukkan jantung ayam yang sudah direbus, tambahkan kecap manis, gula pasir, garam, kaldu bubuk, dan air. Aduk rata."
- "Masukkan potongan kol. Aduk rata."
- "Tambahkan potongan cabai. Aduk rata."
- "Test rasa, angkat dan sajikan."
categories:
- Resep
tags:
- gongso
- jantung
- ayam

katakunci: gongso jantung ayam 
nutrition: 155 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Dessert

---


![Gongso Jantung Ayam Jerit](https://img-global.cpcdn.com/recipes/0d54b99456ee8633/751x532cq70/gongso-jantung-ayam-jerit-foto-resep-utama.jpg)

Bunda lagi mencari inspirasi resep gongso jantung ayam jerit yang Lezat Sekali? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. sekiranya salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso jantung ayam jerit yang enak selayaknya punya aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso jantung ayam jerit, pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tidak usah pusing jika hendak menyiapkan gongso jantung ayam jerit enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.


Di bawah ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah gongso jantung ayam jerit yang siap dikreasikan. Anda bisa menyiapkan Gongso Jantung Ayam Jerit memakai 17 bahan dan 7 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Gongso Jantung Ayam Jerit:

1. Sediakan  jantung ayam
1. Ambil  daun salam
1. Gunakan  daun jeruk
1. Ambil  kecap manis
1. Gunakan  Garam
1. Gunakan  Gula pasir
1. Siapkan  Kaldu bubuk
1. Sediakan  Air
1. Siapkan  Bumbu dihaluskan :
1. Sediakan  cabai rawit merah
1. Ambil  cabai merah keriting
1. Gunakan  bawang merah
1. Gunakan  bawang putih
1. Siapkan  Bumbu iris :
1. Siapkan  cabai rawit merah
1. Siapkan  cabai hijau gendut
1. Ambil  kol iris besar-besar




<!--inarticleads2-->

##### Cara menyiapkan Gongso Jantung Ayam Jerit:

1. Cuci bersih jantung.
1. Rebus hingga matang
1. Tumis bumbu yang dihaluskan, tambah daun salam dan daun jeruk. Masak hingga bumbu matang.
1. Lalu masukkan jantung ayam yang sudah direbus, tambahkan kecap manis, gula pasir, garam, kaldu bubuk, dan air. Aduk rata.
1. Masukkan potongan kol. Aduk rata.
1. Tambahkan potongan cabai. Aduk rata.
1. Test rasa, angkat dan sajikan.




Bagaimana? Mudah bukan? Itulah cara membuat gongso jantung ayam jerit yang bisa Anda lakukan di rumah. Selamat mencoba!
