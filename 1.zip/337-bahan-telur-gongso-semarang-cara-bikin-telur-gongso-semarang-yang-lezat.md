---
description: "Bahan Telur Gongso Semarang | Cara Bikin Telur Gongso Semarang Yang Lezat"
title: "Bahan Telur Gongso Semarang | Cara Bikin Telur Gongso Semarang Yang Lezat"
slug: 337-bahan-telur-gongso-semarang-cara-bikin-telur-gongso-semarang-yang-lezat
date: 2020-12-21T22:15:59.260Z
image: https://img-global.cpcdn.com/recipes/ad1a7d2b8cfcc9cf/751x532cq70/telur-gongso-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ad1a7d2b8cfcc9cf/751x532cq70/telur-gongso-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ad1a7d2b8cfcc9cf/751x532cq70/telur-gongso-semarang-foto-resep-utama.jpg
author: Rosalie West
ratingvalue: 4.4
reviewcount: 14
recipeingredient:
- "4 butir telur"
- "1 btg daun bawang iris kasar"
- "1 buah tomat irisiris"
- "1/2 sdt garam dan gula"
- "1/2 sdt kaldu jamur tambahan saya"
- "2 sdm kecap manis"
- "1 sdm saus tomat"
- "1 sdm saus sambal"
- "2 sdm minyak untuk menumis"
- " Bawang goreng saya skip"
- " Bumbu Halus"
- "6 butir bawang merah"
- "3 butir bawang putih"
- "5 buah cabe merah keriting"
- "1 buah cabe rawit merah bisa ditambah jika suka pedas"
recipeinstructions:
- "Siapkan bahan-bahan. Telur digoreng ceplok. Sisihkan. Haluskan bumbu-bumbu."
- "Tumis bumbu halus sampai harum. Lalu masukkan tomat, bumbu-bumbu saus, kecap, kaldu jamur, garam, dan gula. Aduk-aduk. Koreksi rasanya."
- "Jika sudah pas, masukkan daun bawang dan telur ceplok, aduk rata. Angkat, taburi bawang goreng, siap disajikan."
categories:
- Resep
tags:
- telur
- gongso
- semarang

katakunci: telur gongso semarang 
nutrition: 151 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Dinner

---


![Telur Gongso Semarang](https://img-global.cpcdn.com/recipes/ad1a7d2b8cfcc9cf/751x532cq70/telur-gongso-semarang-foto-resep-utama.jpg)

Lagi mencari inspirasi resep telur gongso semarang yang Bikin Ngiler? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. kalau salah mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal telur gongso semarang yang enak harusnya sih memiliki aroma dan cita rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari telur gongso semarang, mulai dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tak perlu pusing kalau hendak menyiapkan telur gongso semarang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan spesial.




Nah, kali ini kita coba, yuk, ciptakan telur gongso semarang sendiri di rumah. Tetap berbahan sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Telur Gongso Semarang menggunakan 15 jenis bahan dan 3 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Telur Gongso Semarang:

1. Gunakan 4 butir telur
1. Sediakan 1 btg daun bawang, iris kasar
1. Siapkan 1 buah tomat, iris-iris
1. Ambil 1/2 sdt garam dan gula
1. Ambil 1/2 sdt kaldu jamur (tambahan saya)
1. Ambil 2 sdm kecap manis
1. Sediakan 1 sdm saus tomat
1. Gunakan 1 sdm saus sambal
1. Siapkan 2 sdm minyak untuk menumis
1. Sediakan  Bawang goreng (saya skip)
1. Gunakan  Bumbu Halus
1. Gunakan 6 butir bawang merah
1. Ambil 3 butir bawang putih
1. Siapkan 5 buah cabe merah keriting
1. Sediakan 1 buah cabe rawit merah (bisa ditambah jika suka pedas)




<!--inarticleads2-->

##### Cara membuat Telur Gongso Semarang:

1. Siapkan bahan-bahan. Telur digoreng ceplok. Sisihkan. Haluskan bumbu-bumbu.
1. Tumis bumbu halus sampai harum. Lalu masukkan tomat, bumbu-bumbu saus, kecap, kaldu jamur, garam, dan gula. Aduk-aduk. Koreksi rasanya.
1. Jika sudah pas, masukkan daun bawang dan telur ceplok, aduk rata. Angkat, taburi bawang goreng, siap disajikan.




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Telur Gongso Semarang yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman ataupun menjadi ide untuk berjualan makanan. Selamat mencoba!
