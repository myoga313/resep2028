---
description: "Olahan Ayam gongso | Langkah Membuat Ayam gongso Yang Enak Dan Lezat"
title: "Olahan Ayam gongso | Langkah Membuat Ayam gongso Yang Enak Dan Lezat"
slug: 257-olahan-ayam-gongso-langkah-membuat-ayam-gongso-yang-enak-dan-lezat
date: 2020-09-08T11:10:13.477Z
image: https://img-global.cpcdn.com/recipes/1139a23dc3570006/751x532cq70/ayam-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1139a23dc3570006/751x532cq70/ayam-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1139a23dc3570006/751x532cq70/ayam-gongso-foto-resep-utama.jpg
author: Bryan Stanley
ratingvalue: 3.2
reviewcount: 9
recipeingredient:
- " ayam boleh bagian apa aja siangi lalu potong kecil2"
- " Bumbu halus"
- " cabe setan opsional bagi yg suka pedes"
- " cabe merah  rawit"
- " bawang merah"
- " bawang putih"
- " gelondong kemiri"
- " merica"
- " Kunyit"
- " Jahe"
- " garam gula  penyedap"
- " Kecap sekitar"
- " Saus tiram"
- " tomat iris agak tebal"
- " daun bawang iris agak tebal"
- " bawang bombay iris2 agak tebal"
recipeinstructions:
- "Rebus ayam, lalu goreng sebentar"
- "Potong daun bawang, tomat dan bawang bombayy"
- "Panaskan wajan dan sedikit minyak, tumis bumbu halus hingga wangi"
- "Masukkan bahan yg dirajang, tumis hingga agak layu"
- "Masukkan ayam, tambahkan kecap, saus tiram, tambahkan air"
- "Tes rasa, tunggu hingga air agak susut"
- "Hidangkan"
categories:
- Resep
tags:
- ayam
- gongso

katakunci: ayam gongso 
nutrition: 246 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam gongso](https://img-global.cpcdn.com/recipes/1139a23dc3570006/751x532cq70/ayam-gongso-foto-resep-utama.jpg)

Bunda lagi mencari inspirasi resep ayam gongso yang Bisa Manjain Lidah? Cara Buatnya memang susah-susah gampang. misalnya keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal ayam gongso yang enak seharusnya punya aroma dan rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam gongso, pertama dari jenis bahan, lalu pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tak perlu pusing kalau mau menyiapkan ayam gongso yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan spesial.


Di bawah ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah ayam gongso yang siap dikreasikan. Anda bisa membuat Ayam gongso menggunakan 16 jenis bahan dan 7 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam gongso:

1. Sediakan  ayam (boleh bagian apa aja) siangi lalu potong kecil2
1. Ambil  Bumbu halus:
1. Siapkan  cabe setan (opsional bagi yg suka pedes)
1. Sediakan  cabe merah / rawit
1. Siapkan  bawang merah
1. Siapkan  bawang putih
1. Siapkan  gelondong kemiri
1. Sediakan  merica
1. Gunakan  Kunyit
1. Siapkan  Jahe
1. Siapkan  garam, gula &amp; penyedap
1. Sediakan  Kecap sekitar
1. Ambil  Saus tiram
1. Sediakan  tomat iris agak tebal
1. Sediakan  daun bawang iris agak tebal
1. Ambil  bawang bombay iris2 agak tebal




<!--inarticleads2-->

##### Cara menyiapkan Ayam gongso:

1. Rebus ayam, lalu goreng sebentar
1. Potong daun bawang, tomat dan bawang bombayy
1. Panaskan wajan dan sedikit minyak, tumis bumbu halus hingga wangi
1. Masukkan bahan yg dirajang, tumis hingga agak layu
1. Masukkan ayam, tambahkan kecap, saus tiram, tambahkan air
1. Tes rasa, tunggu hingga air agak susut
1. Hidangkan




Bagaimana? Mudah bukan? Itulah cara menyiapkan ayam gongso yang bisa Anda lakukan di rumah. Selamat mencoba!
