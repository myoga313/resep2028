---
description: "Bahan Sop gongso | Cara Masak Sop gongso Yang Lezat"
title: "Bahan Sop gongso | Cara Masak Sop gongso Yang Lezat"
slug: 288-bahan-sop-gongso-cara-masak-sop-gongso-yang-lezat
date: 2020-07-20T16:33:34.596Z
image: https://img-global.cpcdn.com/recipes/eba41d85f2e9de29/751x532cq70/sop-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/eba41d85f2e9de29/751x532cq70/sop-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/eba41d85f2e9de29/751x532cq70/sop-gongso-foto-resep-utama.jpg
author: Ora Hicks
ratingvalue: 4.5
reviewcount: 11
recipeingredient:
- "1/2 kubis diiris iris"
- "2 buah wortel iris tipis"
- "2 daun bawang iris besar"
- "2 seledri iris besar"
- "2 Bakso belah jadi 2"
- " Makaroni seplastik kecil"
- "secukupnya Air"
- " Bumbu halus"
- "6 Bawang putih"
- "1 sdt Merica"
- " Garam"
- " Bumbu pelengkap"
- " Royco"
- "secukupnya Gula"
recipeinstructions:
- "Didihkan air dipanci serta masukan makaroni dan bakso"
- "Gongso bumbu yang sudah dihaluskan sampai terciun wangi dan dengan api kecil setelah wangi masukkan ke panci yg berisi tersebut"
- "Kemudian cuci bersih kubis dan wortel kemudian gongso di bekas menggongso bumbu tadi sampai layu"
- "Setelah layu dan air mendidih baru dimasukkan sayurnya"
- "Kemudian masukan royco dan gula sedikit dan icip rasa kalau kurang pas bisa ditambahi garam sesuai selera"
- "Setelah dirasa pas baru dimasukan seledri dan daun bawang yang sebelumnya sudah dicuci"
- "Setelah itu baru dimatikan api dan siap disajikan dalam mangkok"
- "Selamat menikmati"
- "Catatan; sebaiknya bawang putih yang banyak agar masakan terasa enak"
categories:
- Resep
tags:
- sop
- gongso

katakunci: sop gongso 
nutrition: 159 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Lunch

---


![Sop gongso](https://img-global.cpcdn.com/recipes/eba41d85f2e9de29/751x532cq70/sop-gongso-foto-resep-utama.jpg)

Bunda lagi mencari inspirasi resep sop gongso yang Menggugah Selera? Cara Buatnya memang susah-susah gampang. jikalau keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal sop gongso yang enak harusnya sih mempunyai aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari sop gongso, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tidak usah pusing jika mau menyiapkan sop gongso enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian spesial.




Berikut ini ada beberapa tips dan trik praktis dalam mengolah sop gongso yang siap dikreasikan. Anda bisa menyiapkan Sop gongso memakai 14 bahan dan 9 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Sop gongso:

1. Ambil 1/2 kubis diiris iris
1. Sediakan 2 buah wortel iris tipis
1. Gunakan 2 daun bawang iris besar
1. Ambil 2 seledri iris besar
1. Ambil 2 Bakso belah jadi 2
1. Ambil  Makaroni seplastik kecil
1. Ambil secukupnya Air
1. Gunakan  Bumbu halus
1. Siapkan 6 Bawang putih
1. Siapkan 1 sdt Merica
1. Ambil  Garam
1. Gunakan  Bumbu pelengkap
1. Sediakan  Royco
1. Siapkan secukupnya Gula




<!--inarticleads2-->

##### Cara menyiapkan Sop gongso:

1. Didihkan air dipanci serta masukan makaroni dan bakso
1. Gongso bumbu yang sudah dihaluskan sampai terciun wangi dan dengan api kecil setelah wangi masukkan ke panci yg berisi tersebut
1. Kemudian cuci bersih kubis dan wortel kemudian gongso di bekas menggongso bumbu tadi sampai layu
1. Setelah layu dan air mendidih baru dimasukkan sayurnya
1. Kemudian masukan royco dan gula sedikit dan icip rasa kalau kurang pas bisa ditambahi garam sesuai selera
1. Setelah dirasa pas baru dimasukan seledri dan daun bawang yang sebelumnya sudah dicuci
1. Setelah itu baru dimatikan api dan siap disajikan dalam mangkok
1. Selamat menikmati
1. Catatan; sebaiknya bawang putih yang banyak agar masakan terasa enak




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan Sop gongso yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman maupun menjadi ide untuk berjualan makanan. Selamat mencoba!
