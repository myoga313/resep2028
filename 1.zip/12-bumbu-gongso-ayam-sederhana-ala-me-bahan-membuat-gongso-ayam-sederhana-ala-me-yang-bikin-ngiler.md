---
description: "Bumbu Gongso Ayam Sederhana Ala me 😂 | Bahan Membuat Gongso Ayam Sederhana Ala me 😂 Yang Bikin Ngiler"
title: "Bumbu Gongso Ayam Sederhana Ala me 😂 | Bahan Membuat Gongso Ayam Sederhana Ala me 😂 Yang Bikin Ngiler"
slug: 12-bumbu-gongso-ayam-sederhana-ala-me-bahan-membuat-gongso-ayam-sederhana-ala-me-yang-bikin-ngiler
date: 2020-12-24T13:50:02.669Z
image: https://img-global.cpcdn.com/recipes/b45989b8f2aba877/751x532cq70/gongso-ayam-sederhana-ala-me-😂-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b45989b8f2aba877/751x532cq70/gongso-ayam-sederhana-ala-me-😂-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b45989b8f2aba877/751x532cq70/gongso-ayam-sederhana-ala-me-😂-foto-resep-utama.jpg
author: Jacob Wright
ratingvalue: 4.2
reviewcount: 7
recipeingredient:
- "2 paha ayam"
- "5 bh cabe ijo"
- "3 bh cabe rawit merah"
- "2 siung bawang putih"
- "3 bh bawang merah"
- "1 bh Tomat "
- " Kecap"
- " Garam"
- " Gula pasir"
- " Salam"
- " Lengkuas"
- " Air"
- " Minyak untuk menumis"
recipeinstructions:
- "Rebus paha ayam, potong 2 sesuai selera. (me : agak kecil2)"
- "Haluskan cabe ijo, iris cincang bawang putih, bawang merah. tomat potong kasar."
- "Panaskan minyak tumis bawang merah, aduk sesaat. Masukkan bawang putih aduk lagi sesaat baru masukkan cabe ijo dan tomat🍅. Tumis hingga harum. Masuk daging ayam. Aduk2 tambah air, garam gula pasir, kecap, salam, lengkuas. Masak hingga air menyusut."
- "Koreksi rasa. Siap hidangkan. (me : gak pake kol / sawi. Cz masaknya pas malam tuk sahur syawal 😊)"
categories:
- Resep
tags:
- gongso
- ayam
- sederhana

katakunci: gongso ayam sederhana 
nutrition: 142 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Dinner

---


![Gongso Ayam Sederhana Ala me 😂](https://img-global.cpcdn.com/recipes/b45989b8f2aba877/751x532cq70/gongso-ayam-sederhana-ala-me-😂-foto-resep-utama.jpg)

Kamu Sedang mencari inspirasi resep gongso ayam sederhana ala me 😂 yang Enak Dan Lezat? Cara Memasaknya memang susah-susah gampang. misalnya salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gongso ayam sederhana ala me 😂 yang enak selayaknya memiliki aroma dan cita rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ayam sederhana ala me 😂, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menyajikannya. Tidak usah pusing kalau ingin menyiapkan gongso ayam sederhana ala me 😂 yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan istimewa.


Berikut ini ada beberapa tips dan trik praktis dalam mengolah gongso ayam sederhana ala me 😂 yang siap dikreasikan. Anda bisa membuat Gongso Ayam Sederhana Ala me 😂 memakai 13 jenis bahan dan 4 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Gongso Ayam Sederhana Ala me 😂:

1. Siapkan 2 paha ayam
1. Gunakan 5 bh cabe ijo
1. Siapkan 3 bh cabe rawit merah
1. Siapkan 2 siung bawang putih
1. Sediakan 3 bh bawang merah
1. Siapkan 1 bh Tomat 🍅
1. Siapkan  Kecap
1. Siapkan  Garam
1. Gunakan  Gula pasir
1. Siapkan  Salam
1. Gunakan  Lengkuas
1. Ambil  Air
1. Gunakan  Minyak untuk menumis




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso Ayam Sederhana Ala me 😂:

1. Rebus paha ayam, potong 2 sesuai selera. (me : agak kecil2)
1. Haluskan cabe ijo, iris cincang bawang putih, bawang merah. tomat potong kasar.
1. Panaskan minyak tumis bawang merah, aduk sesaat. Masukkan bawang putih aduk lagi sesaat baru masukkan cabe ijo dan tomat🍅. Tumis hingga harum. Masuk daging ayam. Aduk2 tambah air, garam gula pasir, kecap, salam, lengkuas. Masak hingga air menyusut.
1. Koreksi rasa. Siap hidangkan. (me : gak pake kol / sawi. Cz masaknya pas malam tuk sahur syawal 😊)




Gimana nih? Mudah bukan? Itulah cara menyiapkan gongso ayam sederhana ala me 😂 yang bisa Anda praktikkan di rumah. Selamat mencoba!
