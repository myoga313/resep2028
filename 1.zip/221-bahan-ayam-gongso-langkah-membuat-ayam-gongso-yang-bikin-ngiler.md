---
description: "Bahan Ayam gongso | Langkah Membuat Ayam gongso Yang Bikin Ngiler"
title: "Bahan Ayam gongso | Langkah Membuat Ayam gongso Yang Bikin Ngiler"
slug: 221-bahan-ayam-gongso-langkah-membuat-ayam-gongso-yang-bikin-ngiler
date: 2020-08-25T02:49:03.138Z
image: https://img-global.cpcdn.com/recipes/b85676350634421f/751x532cq70/ayam-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b85676350634421f/751x532cq70/ayam-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b85676350634421f/751x532cq70/ayam-gongso-foto-resep-utama.jpg
author: Randall Guerrero
ratingvalue: 3.6
reviewcount: 10
recipeingredient:
- " ayam potong kecil2"
- " bawang bombay"
- " air rebusan ayam"
- " kecap manis garam kaldu bubuk dan lada bubuk"
- " minyak"
- " Bumbu halus"
- " bawang merah"
- " bawang putih"
- " cabe rawit"
recipeinstructions:
- "Rebus ayam hingga empuk. Haluskan duo bawang dan cabe, iris bawang bombay"
- "Tumis bumbu halus, setelah matang masukkan bawang bombay. Tumis hingga harum"
- "Lalu masukkan air kaldu rebusan ayam tadi. Beri garam, kecap manis, kaldu bubuk dan lada bubuk (koreksi rasa),tunggu hingga mendidih"
- "Masukkan ayam dan tunggu hingga bumbu meresap"
categories:
- Resep
tags:
- ayam
- gongso

katakunci: ayam gongso 
nutrition: 186 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam gongso](https://img-global.cpcdn.com/recipes/b85676350634421f/751x532cq70/ayam-gongso-foto-resep-utama.jpg)

Sedang mencari inspirasi resep ayam gongso yang Sedap? Cara menyiapkannya memang susah-susah gampang. seandainya keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal ayam gongso yang enak seharusnya memiliki aroma dan rasa yang mampu memancing selera kita.

Lihat juga resep Gongso Ayam ala Semarangan enak lainnya. Gongso berarti tumis dalam bahasa jawa. Bagi penyuka pedas, ayam gongso bisa dimasak dengan tambahan cabai rawit dan paling lezat disantap bersama nasi putih.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam gongso, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tidak usah pusing kalau hendak menyiapkan ayam gongso enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.


Berikut ini ada beberapa cara mudah dan praktis dalam mengolah ayam gongso yang siap dikreasikan. Anda bisa menyiapkan Ayam gongso memakai 9 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam gongso:

1. Gunakan  ayam (potong kecil2)
1. Sediakan  bawang bombay
1. Siapkan  air rebusan ayam
1. Siapkan  kecap manis, garam, kaldu bubuk dan lada bubuk
1. Sediakan  minyak
1. Sediakan  📍Bumbu halus
1. Sediakan  bawang merah
1. Gunakan  bawang putih
1. Gunakan  cabe rawit


Masak Gongso Ati Ampela Ayam Resep Bunda Nina. Ayam gongso, makanan yg semarang yang selalu bikin rindu, bikin sendiri aja yuk,caranya gampang kok. 

<!--inarticleads2-->

##### Cara menyiapkan Ayam gongso:

1. Rebus ayam hingga empuk. Haluskan duo bawang dan cabe, iris bawang bombay
1. Tumis bumbu halus, setelah matang masukkan bawang bombay. Tumis hingga harum
1. Lalu masukkan air kaldu rebusan ayam tadi. Beri garam, kecap manis, kaldu bubuk dan lada bubuk (koreksi rasa),tunggu hingga mendidih
1. Masukkan ayam dan tunggu hingga bumbu meresap




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Harapan kami, olahan Ayam gongso yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman maupun menjadi inspirasi bagi Anda yang berkeinginan untuk berjualan makanan. Selamat mencoba!
