---
description: "Resep masakan Ayam Gongso | Cara Mengolah Ayam Gongso Yang Sedap"
title: "Resep masakan Ayam Gongso | Cara Mengolah Ayam Gongso Yang Sedap"
slug: 55-resep-masakan-ayam-gongso-cara-mengolah-ayam-gongso-yang-sedap
date: 2020-09-20T07:39:55.961Z
image: https://img-global.cpcdn.com/recipes/9c2acf1de78f9b08/751x532cq70/ayam-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9c2acf1de78f9b08/751x532cq70/ayam-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9c2acf1de78f9b08/751x532cq70/ayam-gongso-foto-resep-utama.jpg
author: Elmer Murray
ratingvalue: 4.6
reviewcount: 12
recipeingredient:
- "500 g ayam potong sesuai selera"
- "1/2 buah bawang bombay iris"
- "1 buah tomat merah potong 8"
- "2 lembar daun salam"
- "1 ruas lengkuas memarkan"
- "2 sdm kecap manis"
- "1/2 sdt lada bubuk"
- "Secukupnya garam kaldu bubuk"
- "200 ml air"
- "Secukupnya minyak untuk menumis"
- " Bumbu halus"
- "5 siung bawang putih"
- "3 siung bawang merah"
- "3 butir kemiri"
- "5 buah cabe merah"
- "5 buah cabe rawit"
recipeinstructions:
- "Bersihkan ayam dan potong sesuai selera, didihkan air, rebus ayam selama 5 menit. Tiriskan. Sisihkan."
- "Panaskan minyak tumis bawang bombay sampai layu. masukkan bumbu halus, salam, lengkuas tumis sampai harum"
- "Masukkan ayam, aduk rata. Tuang air, bumbui kecap manis, garam, lada, kaldu bubuk masak sampai bumbu meresap dan kuah menyusut. Koreksi rasa. Masukkan tomat sesaat sebelum diangkat."
- "Siap disajikan. Selamat mencoba."
categories:
- Resep
tags:
- ayam
- gongso

katakunci: ayam gongso 
nutrition: 144 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Gongso](https://img-global.cpcdn.com/recipes/9c2acf1de78f9b08/751x532cq70/ayam-gongso-foto-resep-utama.jpg)

Lagi mencari ide resep ayam gongso yang Lezat? Cara menyiapkannya memang tidak susah dan tidak juga mudah. andaikata salah mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal ayam gongso yang enak selayaknya punya aroma dan cita rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso, pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tidak usah pusing jika mau menyiapkan ayam gongso yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian spesial.


Nah, kali ini kita coba, yuk, siapkan ayam gongso sendiri di rumah. Tetap berbahan sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa membuat Ayam Gongso menggunakan 16 bahan dan 4 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Gongso:

1. Siapkan 500 g ayam, potong sesuai selera
1. Siapkan 1/2 buah bawang bombay, iris
1. Ambil 1 buah tomat merah, potong 8
1. Sediakan 2 lembar daun salam
1. Siapkan 1 ruas lengkuas, memarkan
1. Ambil 2 sdm kecap manis
1. Siapkan 1/2 sdt lada bubuk
1. Sediakan Secukupnya garam, kaldu bubuk
1. Gunakan 200 ml air
1. Ambil Secukupnya minyak untuk menumis
1. Sediakan  Bumbu halus:
1. Siapkan 5 siung bawang putih
1. Ambil 3 siung bawang merah
1. Sediakan 3 butir kemiri
1. Siapkan 5 buah cabe merah
1. Siapkan 5 buah cabe rawit




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Gongso:

1. Bersihkan ayam dan potong sesuai selera, didihkan air, rebus ayam selama 5 menit. Tiriskan. Sisihkan.
1. Panaskan minyak tumis bawang bombay sampai layu. masukkan bumbu halus, salam, lengkuas tumis sampai harum
1. Masukkan ayam, aduk rata. Tuang air, bumbui kecap manis, garam, lada, kaldu bubuk masak sampai bumbu meresap dan kuah menyusut. Koreksi rasa. Masukkan tomat sesaat sebelum diangkat.
1. Siap disajikan. Selamat mencoba.




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Ayam Gongso yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman ataupun menjadi ide dalam berjualan makanan. Selamat mencoba!
