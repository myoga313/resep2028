---
description: "Resep Gongso Balungan Ayam khas Semarang | Cara Masak Gongso Balungan Ayam khas Semarang Yang Enak Dan Mudah"
title: "Resep Gongso Balungan Ayam khas Semarang | Cara Masak Gongso Balungan Ayam khas Semarang Yang Enak Dan Mudah"
slug: 231-resep-gongso-balungan-ayam-khas-semarang-cara-masak-gongso-balungan-ayam-khas-semarang-yang-enak-dan-mudah
date: 2020-11-28T22:03:07.319Z
image: https://img-global.cpcdn.com/recipes/b0c8fffad25847bb/751x532cq70/gongso-balungan-ayam-khas-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b0c8fffad25847bb/751x532cq70/gongso-balungan-ayam-khas-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b0c8fffad25847bb/751x532cq70/gongso-balungan-ayam-khas-semarang-foto-resep-utama.jpg
author: Lou Lowe
ratingvalue: 3.9
reviewcount: 4
recipeingredient:
- " Balungan ayam"
- " tomat"
- " bawang bombay"
- " daun bawang"
- " jahe geprek"
- " margarin"
- " Minyak goreng"
- " Air"
- " Garam"
- " Gula"
- " saos tiram"
- " kecap manis"
- " Kaldu bubuk totole"
- " telur ayam"
- " Bumbu halus"
- " bawang merah"
- " bawang putih"
- " cabe keriting merah"
- " cabe rawit merah"
recipeinstructions:
- "Cuci bersih balungan ayam. Panaskan air sampai mendidih. Masukkan jahe geprek dan balungan ayam. Rebus sampai empuk. Tiriskan ayam"
- "Siapkan bumbu halus. Panaskan margarin dan tambahkan minyak secukupnya. Tumis bumbu sampai harum. Masukkan bawang bombay."
- "Kocok telur. Masukkan dalam tumisan bumbu. Aduk sampai jadi telur orak arik"
- "Tambahkan balungan dan air rebusan balungan ke dalam tumisan bumbu. Masukkan garam, gula, kaldu, saos tiram dan kecap manis. Aduk rata. Masukkan irisan daun bawang dan tomat."
- "Koreksi rasa. Aduk rata. Biarkan meresap. Gongso balungan ayam siap disajikan"
categories:
- Resep
tags:
- gongso
- balungan
- ayam

katakunci: gongso balungan ayam 
nutrition: 192 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Dinner

---


![Gongso Balungan Ayam khas Semarang](https://img-global.cpcdn.com/recipes/b0c8fffad25847bb/751x532cq70/gongso-balungan-ayam-khas-semarang-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep gongso balungan ayam khas semarang yang Bikin Ngiler? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. andaikata keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gongso balungan ayam khas semarang yang enak harusnya sih mempunyai aroma dan cita rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso balungan ayam khas semarang, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tidak usah pusing jika mau menyiapkan gongso balungan ayam khas semarang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian istimewa.


Nah, kali ini kita coba, yuk, siapkan gongso balungan ayam khas semarang sendiri di rumah. Tetap berbahan sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa membuat Gongso Balungan Ayam khas Semarang menggunakan 19 bahan dan 5 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Gongso Balungan Ayam khas Semarang:

1. Ambil  Balungan ayam
1. Ambil  tomat
1. Siapkan  bawang bombay
1. Ambil  daun bawang
1. Gunakan  jahe geprek
1. Ambil  margarin
1. Siapkan  Minyak goreng
1. Siapkan  Air
1. Gunakan  Garam
1. Gunakan  Gula
1. Gunakan  saos tiram
1. Ambil  kecap manis
1. Ambil  Kaldu bubuk totole
1. Ambil  telur ayam
1. Sediakan  Bumbu halus
1. Sediakan  bawang merah
1. Ambil  bawang putih
1. Ambil  cabe keriting merah
1. Siapkan  cabe rawit merah




<!--inarticleads2-->

##### Cara membuat Gongso Balungan Ayam khas Semarang:

1. Cuci bersih balungan ayam. Panaskan air sampai mendidih. Masukkan jahe geprek dan balungan ayam. Rebus sampai empuk. Tiriskan ayam
1. Siapkan bumbu halus. Panaskan margarin dan tambahkan minyak secukupnya. Tumis bumbu sampai harum. Masukkan bawang bombay.
1. Kocok telur. Masukkan dalam tumisan bumbu. Aduk sampai jadi telur orak arik
1. Tambahkan balungan dan air rebusan balungan ke dalam tumisan bumbu. Masukkan garam, gula, kaldu, saos tiram dan kecap manis. Aduk rata. Masukkan irisan daun bawang dan tomat.
1. Koreksi rasa. Aduk rata. Biarkan meresap. Gongso balungan ayam siap disajikan




Bagaimana? Gampang kan? Itulah cara menyiapkan gongso balungan ayam khas semarang yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
