---
description: "Resep Gongso Ayam khas Semarang | Resep Bumbu Gongso Ayam khas Semarang Yang Enak Dan Lezat"
title: "Resep Gongso Ayam khas Semarang | Resep Bumbu Gongso Ayam khas Semarang Yang Enak Dan Lezat"
slug: 269-resep-gongso-ayam-khas-semarang-resep-bumbu-gongso-ayam-khas-semarang-yang-enak-dan-lezat
date: 2020-08-17T03:12:45.223Z
image: https://img-global.cpcdn.com/recipes/d29cc9d495b60af5/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d29cc9d495b60af5/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d29cc9d495b60af5/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg
author: Ray Rodriquez
ratingvalue: 4.9
reviewcount: 3
recipeingredient:
- "6 potong ayam bagian paha"
- "1 buah bawang bombay iris tipis"
- "10 biji cabai rawit"
- "2 lembar daun salam"
- "1 ruas lengkuaslaos"
- " kecap manis"
- " garam"
- " lada bubuk"
- "secukupnya air"
- " minyak goreng untuk menumis"
- " bumbu halus "
- "5 siung bawang putih"
- "2 siung bawang merah"
- "3 buah kemiri"
- "5 biji cabai rawit"
- "1 biji cabai merah"
recipeinstructions:
- "Siapkan bahan, cuci bersih ayam beri kucuran air jeruk nipis agar menghilangkan bau amis nya. tunggu 10 menit. lalu rebus ayam, masukkan garam secukupnya. rebus ayam sekitar 30-40 menit. setelah itu tiriskan"
- "Haluskan bumbu sesuai resep yg ada. kemudian suwir2 ayam agar di gongso nanti bumbu bisa meresap. dan iris tipis bawang bombay"
- "Ambil wajan/teflon masukkan minyak lalu tumis bawang bombay sampai harum dan kecoklatan, lalu masukkan bumbu halus, daun salam, lengkuas. tumis sampai harum"
- "Masukkan ayam, gongso hingga merata dengan bumbu. masukkan kecap manis, garam, lada, penyedap rasa. masukkan air sedikit demi sedikit, gongso hingga air menyusut, koreksi rasa. dan siap disajikan dengan nasi panas 😋"
categories:
- Resep
tags:
- gongso
- ayam
- khas

katakunci: gongso ayam khas 
nutrition: 102 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dinner

---


![Gongso Ayam khas Semarang](https://img-global.cpcdn.com/recipes/d29cc9d495b60af5/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep gongso ayam khas semarang yang Enak Dan Lezat? Cara membuatnya memang susah-susah gampang. sekiranya keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso ayam khas semarang yang enak seharusnya memiliki aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ayam khas semarang, mulai dari jenis bahan, kemudian pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan gongso ayam khas semarang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.




Di bawah ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah gongso ayam khas semarang yang siap dikreasikan. Anda bisa menyiapkan Gongso Ayam khas Semarang menggunakan 16 jenis bahan dan 4 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Gongso Ayam khas Semarang:

1. Gunakan 6 potong ayam, bagian paha
1. Sediakan 1 buah bawang bombay, iris tipis
1. Siapkan 10 biji cabai rawit
1. Sediakan 2 lembar daun salam
1. Sediakan 1 ruas lengkuas/laos
1. Siapkan  kecap manis
1. Gunakan  garam
1. Sediakan  lada bubuk
1. Gunakan secukupnya air
1. Ambil  minyak goreng untuk menumis
1. Siapkan  bumbu halus :
1. Sediakan 5 siung bawang putih
1. Gunakan 2 siung bawang merah
1. Siapkan 3 buah kemiri
1. Siapkan 5 biji cabai rawit
1. Sediakan 1 biji cabai merah




<!--inarticleads2-->

##### Cara menyiapkan Gongso Ayam khas Semarang:

1. Siapkan bahan, cuci bersih ayam beri kucuran air jeruk nipis agar menghilangkan bau amis nya. tunggu 10 menit. lalu rebus ayam, masukkan garam secukupnya. rebus ayam sekitar 30-40 menit. setelah itu tiriskan
1. Haluskan bumbu sesuai resep yg ada. kemudian suwir2 ayam agar di gongso nanti bumbu bisa meresap. dan iris tipis bawang bombay
1. Ambil wajan/teflon masukkan minyak lalu tumis bawang bombay sampai harum dan kecoklatan, lalu masukkan bumbu halus, daun salam, lengkuas. tumis sampai harum
1. Masukkan ayam, gongso hingga merata dengan bumbu. masukkan kecap manis, garam, lada, penyedap rasa. masukkan air sedikit demi sedikit, gongso hingga air menyusut, koreksi rasa. dan siap disajikan dengan nasi panas 😋




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Besar harapan kami, olahan Gongso Ayam khas Semarang yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman maupun menjadi ide bagi Anda yang berkeinginan untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
