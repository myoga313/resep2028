---
description: "Olahan Gongso babat usus paru | Resep Membuat Gongso babat usus paru Yang Lezat Sekali"
title: "Olahan Gongso babat usus paru | Resep Membuat Gongso babat usus paru Yang Lezat Sekali"
slug: 85-olahan-gongso-babat-usus-paru-resep-membuat-gongso-babat-usus-paru-yang-lezat-sekali
date: 2020-12-01T14:57:12.329Z
image: https://img-global.cpcdn.com/recipes/402194068487084e/751x532cq70/gongso-babat-usus-paru-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/402194068487084e/751x532cq70/gongso-babat-usus-paru-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/402194068487084e/751x532cq70/gongso-babat-usus-paru-foto-resep-utama.jpg
author: Lucile Freeman
ratingvalue: 4.1
reviewcount: 9
recipeingredient:
- "500 gr babat usus paru"
- "1 buah Jenuk nipis"
- "2 helai daun salam"
- "1 buah bawang bombai bs skip"
- " Bumbu halus"
- "11 cabe keriting"
- "9 cabe kecil"
- "13 bawang merah"
- "5 bawang putih"
- "5 kemiri sangrai"
- " Bahan tambahan"
- "secukupnya Kecap gula garam royko daging"
- " Lada bubuk sedikit bwt tambah pedesnyaboleh skip"
- " Air 500 cc kurang lebih y bun"
recipeinstructions:
- "Rebus babat usus paru dalam waktu 1 jam 10 menit jgn lupa masukkan jeruk nipis potong jd 4 dan 2 helai daun salam, bisa kasih sedikit royko ya bun bisa jd skip. Oiya bisa jd di presto dlm waktu 20 menitan ya bun"
- "Siapkan bumbu halus dan siapkan bawang bombay di iris agak lebar ya bun"
- "Tumis bawang bombai, agak layu"
- "Masukkan bumbu halus, tumis hingga harum, tambah air 500 cc bagi yg suka nyemek(bg yg suka nanti matangnya agak kering bisa dikurangi), masukkan masukkan rebusan babat usus paru yg sudah empuk, masukkan bahan tambahan. Cek rasa (proses masak kurang lebih 15 sampai 20 menit)"
categories:
- Resep
tags:
- gongso
- babat
- usus

katakunci: gongso babat usus 
nutrition: 205 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Lunch

---


![Gongso babat usus paru](https://img-global.cpcdn.com/recipes/402194068487084e/751x532cq70/gongso-babat-usus-paru-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep gongso babat usus paru yang Sedap? Cara menyiapkannya memang susah-susah gampang. misalnya keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso babat usus paru yang enak seharusnya memiliki aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso babat usus paru, pertama dari jenis bahan, lalu pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan gongso babat usus paru yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan istimewa.

Lihat juga resep Babat Gongso ala Semarang enak lainnya. Usus dan kulit sapi sebagian diambil oleh panitua kurban untuk dimasak, buat makan bersama sama. Meski tugas mama kyna masak sop nya, dan sayang sekali tidak bisa di tampilkan, karena ada kendala.


Di bawah ini ada beberapa cara mudah dan praktis untuk membuat gongso babat usus paru yang siap dikreasikan. Anda bisa membuat Gongso babat usus paru menggunakan 14 bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Gongso babat usus paru:

1. Ambil 500 gr babat usus paru
1. Sediakan 1 buah Jenuk nipis
1. Gunakan 2 helai daun salam
1. Siapkan 1 buah bawang bombai (bs skip)
1. Ambil  Bumbu halus
1. Siapkan 11 cabe keriting
1. Siapkan 9 cabe kecil
1. Sediakan 13 bawang merah
1. Sediakan 5 bawang putih
1. Siapkan 5 kemiri (sangrai)
1. Gunakan  Bahan tambahan
1. Sediakan secukupnya Kecap, gula, garam, royko daging
1. Sediakan  Lada bubuk sedikit bwt tambah pedesnya(boleh skip)
1. Ambil  Air 500 cc kurang lebih y bun


You may take a look my old recipe of Soto Babat. Sedangkan nasi babat gongso, babat yang telah digongso disajikan panas-panas dengan sepiring nasi putih. Meski cuma nasi goreng, namun cita Selain nasi goreng babat gongso yang lezat dan beraroma harum, kamu bisa pesan menu lain yang gak kalah enak, seperti paru goreng kering atau. Babat, jeroan sapi bertekstur unik ini bisa diolah jadi banyak sajian. 

<!--inarticleads2-->

##### Langkah-langkah membuat Gongso babat usus paru:

1. Rebus babat usus paru dalam waktu 1 jam 10 menit jgn lupa masukkan jeruk nipis potong jd 4 dan 2 helai daun salam, bisa kasih sedikit royko ya bun bisa jd skip. Oiya bisa jd di presto dlm waktu 20 menitan ya bun
1. Siapkan bumbu halus dan siapkan bawang bombay di iris agak lebar ya bun
1. Tumis bawang bombai, agak layu
1. Masukkan bumbu halus, tumis hingga harum, tambah air 500 cc bagi yg suka nyemek(bg yg suka nanti matangnya agak kering bisa dikurangi), masukkan masukkan rebusan babat usus paru yg sudah empuk, masukkan bahan tambahan. Cek rasa (proses masak kurang lebih 15 sampai 20 menit)


Sajian khas Semarang ini adalah salah satunya. Kunci kelezatan sajian ini yaitu penggunaan bahan babat yang fresh. Babat pun siap untuk kemudian di-gongso atau ditumis bersama racikan bumbu. Resep Babat Gongso, Hidangan Legendaris Khas Semarang. Simpan ke bagian favorit Tersimpan di bagian favorit. 

Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Gongso babat usus paru yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman ataupun menjadi ide bagi Anda yang berkeinginan untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
