---
description: "Bumbu Gongso Babat (jeroan sapi) | Cara Mengolah Gongso Babat (jeroan sapi) Yang Sempurna"
title: "Bumbu Gongso Babat (jeroan sapi) | Cara Mengolah Gongso Babat (jeroan sapi) Yang Sempurna"
slug: 443-bumbu-gongso-babat-jeroan-sapi-cara-mengolah-gongso-babat-jeroan-sapi-yang-sempurna
date: 2021-01-12T16:24:12.029Z
image: https://img-global.cpcdn.com/recipes/08b3b4bf2bc84c6a/751x532cq70/gongso-babat-jeroan-sapi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/08b3b4bf2bc84c6a/751x532cq70/gongso-babat-jeroan-sapi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/08b3b4bf2bc84c6a/751x532cq70/gongso-babat-jeroan-sapi-foto-resep-utama.jpg
author: Ola Graves
ratingvalue: 3.6
reviewcount: 6
recipeingredient:
- "500 gram babat dan jeroan sapi"
- "5 helai kobis buang tulang daunnya"
- "1 buah tomat sedang"
- "1 tangkai daun bawang"
- " Bumbu halus"
- "2 buah kemiri"
- "1/2 sdt merica butiran"
- "4 siung bawang putih"
- "8 siung bawang merah"
- "1 ruas jahe"
- "10 buah cabe merah"
- " Bumbu geprek"
- "1 batang sereh"
- "2 ruas lengkuas"
- " Bumbu utuhan"
- "1 lembar daun salam"
- "2 lembar daun jeruk"
- "secukupnya Gula garam"
recipeinstructions:
- "Masukan jeroan saat air mendidih lalu Rebus hingga empuk, sertakan garam dan jahe sedikit. Cuci bersih bumbu ulek dan pelengkap lainnya."
- "Ulek dan geprek bumbu, iris kol, tomat dan daun bawang."
- "Setelah jeroan empuk iris sesuai selera lalu tumis sebentar kemudian sisihkan."
- "Tumis semua bumbu hingga wangi dan layu, masukan kol aduk rata..menyusul jeroan tadi. Tambahkan gula dan garam."
- "Tutup sebentar hingga bumbu meresap.. sesaat sebelum diangkat, masukan tomat dan daun bawang."
categories:
- Resep
tags:
- gongso
- babat
- jeroan

katakunci: gongso babat jeroan 
nutrition: 227 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Dinner

---


![Gongso Babat (jeroan sapi)](https://img-global.cpcdn.com/recipes/08b3b4bf2bc84c6a/751x532cq70/gongso-babat-jeroan-sapi-foto-resep-utama.jpg)

Bunda Sedang mencari ide resep gongso babat (jeroan sapi) yang Lezat? Cara Bikinnya memang tidak terlalu sulit namun tidak gampang juga. semisal keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gongso babat (jeroan sapi) yang enak harusnya sih punya aroma dan cita rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso babat (jeroan sapi), pertama dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tidak usah pusing kalau ingin menyiapkan gongso babat (jeroan sapi) enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian istimewa.




Di bawah ini ada beberapa tips dan trik praktis dalam mengolah gongso babat (jeroan sapi) yang siap dikreasikan. Anda dapat menyiapkan Gongso Babat (jeroan sapi) menggunakan 18 bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Gongso Babat (jeroan sapi):

1. Ambil 500 gram babat dan jeroan sapi
1. Siapkan 5 helai kobis buang tulang daunnya
1. Siapkan 1 buah tomat sedang
1. Siapkan 1 tangkai daun bawang
1. Siapkan  Bumbu halus
1. Gunakan 2 buah kemiri
1. Sediakan 1/2 sdt merica butiran
1. Ambil 4 siung bawang putih
1. Gunakan 8 siung bawang merah
1. Ambil 1 ruas jahe
1. Siapkan 10 buah cabe merah
1. Gunakan  Bumbu geprek
1. Sediakan 1 batang sereh
1. Sediakan 2 ruas lengkuas
1. Ambil  Bumbu utuhan
1. Siapkan 1 lembar daun salam
1. Siapkan 2 lembar daun jeruk
1. Gunakan secukupnya Gula garam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso Babat (jeroan sapi):

1. Masukan jeroan saat air mendidih lalu Rebus hingga empuk, sertakan garam dan jahe sedikit. Cuci bersih bumbu ulek dan pelengkap lainnya.
1. Ulek dan geprek bumbu, iris kol, tomat dan daun bawang.
1. Setelah jeroan empuk iris sesuai selera lalu tumis sebentar kemudian sisihkan.
1. Tumis semua bumbu hingga wangi dan layu, masukan kol aduk rata..menyusul jeroan tadi. Tambahkan gula dan garam.
1. Tutup sebentar hingga bumbu meresap.. sesaat sebelum diangkat, masukan tomat dan daun bawang.




Bagaimana? Mudah bukan? Itulah cara menyiapkan gongso babat (jeroan sapi) yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
