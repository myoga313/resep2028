---
description: "Bahan Babat Gongso ala Semarang | Langkah Membuat Babat Gongso ala Semarang Yang Mudah Dan Praktis"
title: "Bahan Babat Gongso ala Semarang | Langkah Membuat Babat Gongso ala Semarang Yang Mudah Dan Praktis"
slug: 435-bahan-babat-gongso-ala-semarang-langkah-membuat-babat-gongso-ala-semarang-yang-mudah-dan-praktis
date: 2020-08-27T04:34:28.269Z
image: https://img-global.cpcdn.com/recipes/90e4e03b66adbe56/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/90e4e03b66adbe56/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/90e4e03b66adbe56/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg
author: Sally Thompson
ratingvalue: 4
reviewcount: 7
recipeingredient:
- "1/2 kg babat sapi"
- "8 btr bawang merah"
- "2 btr bawang putih"
- "7 bh cabai merah keritingsesuai selera"
- "3 bh cabai rawit merahsesuai selera"
- "1 btr kemiri"
- "2-3 sdm kecap manissesuai selera"
- "1 sdm kecap asin1 sdt garam"
- "1 sdt kaldu jamurkaldu lainsesuai selera"
- "1/2 gelas air putih"
- "3-5 sdm minyak goreng untuk menumis"
recipeinstructions:
- "Siapkan semua bahan.. Cuci bersih babat, rebus hingga empuk, bisa dipresto atau pakai metode 5.30.7, potong/iris sesuai selera. Iris 5 btr bawang merah, sisanya haluskan bersama bawang putih+kemiri+cabai"
- "Panaskan minyak, goreng bawang merah hingga layu, masukkan bumbu halus, tumis hingga matang/agak kering, masukkan babat, aduk merata"
- "Tambahkan air+kecap manis+kecap asin/garam+kaldu jamur, aduk merata. Tunggu hingga air berkurang, cek rasa. Done.. Yuuk cobain"
categories:
- Resep
tags:
- babat
- gongso
- ala

katakunci: babat gongso ala 
nutrition: 192 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Lunch

---


![Babat Gongso ala Semarang](https://img-global.cpcdn.com/recipes/90e4e03b66adbe56/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg)

Bunda Sedang mencari ide resep babat gongso ala semarang yang Bisa Manjain Lidah? Cara Buatnya memang tidak susah dan tidak juga mudah. Jika keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal babat gongso ala semarang yang enak selayaknya punya aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari babat gongso ala semarang, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tidak usah pusing jika ingin menyiapkan babat gongso ala semarang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan istimewa.




Berikut ini ada beberapa tips dan trik praktis dalam mengolah babat gongso ala semarang yang siap dikreasikan. Anda bisa membuat Babat Gongso ala Semarang memakai 11 jenis bahan dan 3 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Babat Gongso ala Semarang:

1. Gunakan 1/2 kg babat sapi
1. Sediakan 8 btr bawang merah
1. Ambil 2 btr bawang putih
1. Sediakan 7 bh cabai merah keriting/sesuai selera
1. Ambil 3 bh cabai rawit merah/sesuai selera
1. Siapkan 1 btr kemiri
1. Gunakan 2-3 sdm kecap manis/sesuai selera
1. Sediakan 1 sdm kecap asin/1 sdt garam
1. Ambil 1 sdt kaldu jamur/kaldu lain/sesuai selera
1. Ambil 1/2 gelas air putih
1. Sediakan 3-5 sdm minyak goreng untuk menumis




<!--inarticleads2-->

##### Cara membuat Babat Gongso ala Semarang:

1. Siapkan semua bahan.. Cuci bersih babat, rebus hingga empuk, bisa dipresto atau pakai metode 5.30.7, potong/iris sesuai selera. Iris 5 btr bawang merah, sisanya haluskan bersama bawang putih+kemiri+cabai
1. Panaskan minyak, goreng bawang merah hingga layu, masukkan bumbu halus, tumis hingga matang/agak kering, masukkan babat, aduk merata
1. Tambahkan air+kecap manis+kecap asin/garam+kaldu jamur, aduk merata. Tunggu hingga air berkurang, cek rasa. Done.. Yuuk cobain




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Babat Gongso ala Semarang yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman ataupun menjadi ide untuk berjualan makanan. Selamat mencoba!
