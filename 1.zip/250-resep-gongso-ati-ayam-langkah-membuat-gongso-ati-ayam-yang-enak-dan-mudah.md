---
description: "Resep Gongso ati ayam | Langkah Membuat Gongso ati ayam Yang Enak Dan Mudah"
title: "Resep Gongso ati ayam | Langkah Membuat Gongso ati ayam Yang Enak Dan Mudah"
slug: 250-resep-gongso-ati-ayam-langkah-membuat-gongso-ati-ayam-yang-enak-dan-mudah
date: 2020-07-27T10:41:49.802Z
image: https://img-global.cpcdn.com/recipes/b4d634e82743a90b/751x532cq70/gongso-ati-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b4d634e82743a90b/751x532cq70/gongso-ati-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b4d634e82743a90b/751x532cq70/gongso-ati-ayam-foto-resep-utama.jpg
author: Edgar Miller
ratingvalue: 5
reviewcount: 12
recipeingredient:
- "8 ati ayam potong sesuai selera"
- "1/2 bawang bombayiris tipis"
- "2 bawang putih geprek cincang halus"
- "2 cabe merah keritingiris serong"
- "5 cabe rawitiris serong"
- "4 cm jahe geprek"
- "1/2 tomat ukuran sedang potong dadu"
- "1,5 sdm sambel bawang"
- "secukupnya Kecap manis"
- "secukupnya Kecap inggris"
- "secukupnya Saus tiram"
- "secukupnya Garam"
- "2 jumput gula pasir"
- " Penyedap rasa optional"
- "1 sdm margarin utk menumis"
recipeinstructions:
- "Rebus ati ayam sampai matang,tiriskan,lalu potong2 sesuai selera, sisihkan"
- "Iris2 tipis bawang bombay, bawang putih digeprek cincang halus, jahe digeprek cincang halus,cabe merah dan cabe rawit iris serong"
- "Siapkan wajan, panaskan margarin utk menumis, masukkan bawang putih tumis sampai harum, lalu bawang bombay,jahe,cabe merah, cabe rawit dan tomat, tumis sampai harum dan agak layu"
- "Masukkan ati ayam,tambahkan air secukupnya, tambahkan garam, gula pasir, kecap manis, saus tiram, kecap inggris dan penyedap rasa"
- "Aduk rata, tunggu sampai mendidih, lalu koreksi rasa"
- "Tunggu sampai kuah agak menyusut, matikan kompor,siap dihidangkan"
categories:
- Resep
tags:
- gongso
- ati
- ayam

katakunci: gongso ati ayam 
nutrition: 228 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Lunch

---


![Gongso ati ayam](https://img-global.cpcdn.com/recipes/b4d634e82743a90b/751x532cq70/gongso-ati-ayam-foto-resep-utama.jpg)

Lagi mencari ide resep gongso ati ayam yang Enak Dan Lezat? Cara Bikinnya memang susah-susah gampang. jikalau salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gongso ati ayam yang enak selayaknya memiliki aroma dan rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ati ayam, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tak perlu pusing kalau mau menyiapkan gongso ati ayam yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian spesial.


Nah, kali ini kita coba, yuk, variasikan gongso ati ayam sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Gongso ati ayam menggunakan 15 jenis bahan dan 6 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Gongso ati ayam:

1. Sediakan 8 ati ayam, potong sesuai selera
1. Sediakan 1/2 bawang bombay,iris tipis
1. Gunakan 2 bawang putih, geprek cincang halus
1. Siapkan 2 cabe merah keriting,iris serong
1. Siapkan 5 cabe rawit,iris serong
1. Gunakan 4 cm jahe, geprek
1. Gunakan 1/2 tomat ukuran sedang, potong dadu
1. Sediakan 1,5 sdm sambel bawang
1. Gunakan secukupnya Kecap manis
1. Siapkan secukupnya Kecap inggris
1. Sediakan secukupnya Saus tiram
1. Gunakan secukupnya Garam
1. Siapkan 2 jumput gula pasir
1. Sediakan  Penyedap rasa (optional)
1. Siapkan 1 sdm margarin utk menumis




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso ati ayam:

1. Rebus ati ayam sampai matang,tiriskan,lalu potong2 sesuai selera, sisihkan
1. Iris2 tipis bawang bombay, bawang putih digeprek cincang halus, jahe digeprek cincang halus,cabe merah dan cabe rawit iris serong
1. Siapkan wajan, panaskan margarin utk menumis, masukkan bawang putih tumis sampai harum, lalu bawang bombay,jahe,cabe merah, cabe rawit dan tomat, tumis sampai harum dan agak layu
1. Masukkan ati ayam,tambahkan air secukupnya, tambahkan garam, gula pasir, kecap manis, saus tiram, kecap inggris dan penyedap rasa
1. Aduk rata, tunggu sampai mendidih, lalu koreksi rasa
1. Tunggu sampai kuah agak menyusut, matikan kompor,siap dihidangkan




Bagaimana? Gampang kan? Itulah cara menyiapkan gongso ati ayam yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
