---
description: "Bahan Ayam Gongso Extra Pedas | Cara Masak Ayam Gongso Extra Pedas Yang Lezat Sekali"
title: "Bahan Ayam Gongso Extra Pedas | Cara Masak Ayam Gongso Extra Pedas Yang Lezat Sekali"
slug: 200-bahan-ayam-gongso-extra-pedas-cara-masak-ayam-gongso-extra-pedas-yang-lezat-sekali
date: 2020-07-28T21:11:56.740Z
image: https://img-global.cpcdn.com/recipes/1a8b8e4b7d6f1485/751x532cq70/ayam-gongso-extra-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1a8b8e4b7d6f1485/751x532cq70/ayam-gongso-extra-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1a8b8e4b7d6f1485/751x532cq70/ayam-gongso-extra-pedas-foto-resep-utama.jpg
author: Nannie Blair
ratingvalue: 3.2
reviewcount: 8
recipeingredient:
- " Bumbu Halus "
- "4 siung bawang putih"
- "10 siung bawang merah"
- "2 butir kemiri"
- "10 buah cabe merah keriting"
- "5 buah cabe rawit merah"
- "1 sdm lada bubuk"
- "1 sdm saus tiram"
- "3 sdm kecap manis"
- "1 buah tomat iris tipis"
- "secukupnya garam dikira2"
- "1 sachet royco dikira2"
- "500 gr ayam fillet dadapaha"
- "1 butir telur"
- "secukupnya minyak utk menumis"
- "1 btg daun bawang"
recipeinstructions:
- "Rebus fillet ayam dgn garam, setelah direbus digoreng sebentar"
- "Orak arik telur"
- "Haluskan baput, bamer, kemiri, cabecabean, lada, sisakan 2bwg merah utk diiris."
- "Tumis bumbu halus sampai matang dan berubah warna, masukan tomat iris,tumis sampai layu"
- "Setelah harum, masukan garam,royco,saus tiram dan kecap manis, aduk rata, masukan daun bawang sambil dirasakan"
- "Masukan ayam suwir yg sudah digoreng sebentar dan telur orak ariknya, lalu tambahkan sediikit air rebusan ayam tadi, lalu oseng sampai enak."
- "Selesai"
categories:
- Resep
tags:
- ayam
- gongso
- extra

katakunci: ayam gongso extra 
nutrition: 218 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Gongso Extra Pedas](https://img-global.cpcdn.com/recipes/1a8b8e4b7d6f1485/751x532cq70/ayam-gongso-extra-pedas-foto-resep-utama.jpg)

Sedang mencari ide resep ayam gongso extra pedas yang Bikin Ngiler? Cara Bikinnya memang susah-susah gampang. kalau keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal ayam gongso extra pedas yang enak seharusnya mempunyai aroma dan cita rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso extra pedas, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tak perlu pusing jika ingin menyiapkan ayam gongso extra pedas enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian istimewa.


Berikut ini ada beberapa tips dan trik praktis dalam mengolah ayam gongso extra pedas yang siap dikreasikan. Anda bisa menyiapkan Ayam Gongso Extra Pedas memakai 16 bahan dan 7 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam Gongso Extra Pedas:

1. Sediakan  Bumbu Halus :
1. Sediakan 4 siung bawang putih
1. Ambil 10 siung bawang merah
1. Sediakan 2 butir kemiri
1. Siapkan 10 buah cabe merah keriting
1. Sediakan 5 buah cabe rawit merah
1. Gunakan 1 sdm lada bubuk
1. Siapkan 1 sdm saus tiram
1. Sediakan 3 sdm kecap manis
1. Siapkan 1 buah tomat iris tipis
1. Ambil secukupnya garam dikira2
1. Siapkan 1 sachet royco dikira2
1. Sediakan 500 gr ayam fillet dada/paha
1. Gunakan 1 butir telur
1. Sediakan secukupnya minyak utk menumis
1. Gunakan 1 btg daun bawang




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Gongso Extra Pedas:

1. Rebus fillet ayam dgn garam, setelah direbus digoreng sebentar
1. Orak arik telur
1. Haluskan baput, bamer, kemiri, cabecabean, lada, sisakan 2bwg merah utk diiris.
1. Tumis bumbu halus sampai matang dan berubah warna, masukan tomat iris,tumis sampai layu
1. Setelah harum, masukan garam,royco,saus tiram dan kecap manis, aduk rata, masukan daun bawang sambil dirasakan
1. Masukan ayam suwir yg sudah digoreng sebentar dan telur orak ariknya, lalu tambahkan sediikit air rebusan ayam tadi, lalu oseng sampai enak.
1. Selesai




Gimana nih? Gampang kan? Itulah cara membuat ayam gongso extra pedas yang bisa Anda lakukan di rumah. Selamat mencoba!
