---
description: "Resep Ati Ampela Gongso | Resep Membuat Ati Ampela Gongso Yang Enak Banget"
title: "Resep Ati Ampela Gongso | Resep Membuat Ati Ampela Gongso Yang Enak Banget"
slug: 84-resep-ati-ampela-gongso-resep-membuat-ati-ampela-gongso-yang-enak-banget
date: 2020-09-16T03:24:48.060Z
image: https://img-global.cpcdn.com/recipes/df2c8479da72af14/751x532cq70/ati-ampela-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/df2c8479da72af14/751x532cq70/ati-ampela-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/df2c8479da72af14/751x532cq70/ati-ampela-gongso-foto-resep-utama.jpg
author: Michael Fox
ratingvalue: 4.7
reviewcount: 10
recipeingredient:
- "4 potong ati ampela bersihkan"
- "1 batang sereh ambil putihnya kemudian iris serong memarkan"
- "2 lembar daun jeruk"
- "120 ml air untuk tambahan saat menumis"
- "1 sdm saus tiram"
- "1 sdm kecap manis"
- "1/4 sdt lada bubuk"
- "Sejumput garam"
- "Sejumput kaldu bubuk"
- "Sejumput gula pasir"
- " Bumbu iris "
- "3 siung bawang merah"
- "2 siung bawang putih"
- "3 buah cabe rawit merah"
- "1 buah cabe hijau besar"
recipeinstructions:
- "Rebus ati ampela hingga matang, tiriskan lalu potong2"
- "Tumis bahan iris hingga wangi, masukkan ati ampela. Aduk rata"
- "Beri air, kecap manis, saos tiram, garam, gula dan lada bubuk. Masak hingga kuah menyusut"
- "Angkat dan sajikan"
categories:
- Resep
tags:
- ati
- ampela
- gongso

katakunci: ati ampela gongso 
nutrition: 250 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Dinner

---


![Ati Ampela Gongso](https://img-global.cpcdn.com/recipes/df2c8479da72af14/751x532cq70/ati-ampela-gongso-foto-resep-utama.jpg)

Sedang mencari ide resep ati ampela gongso yang Enak dan Simpel? Cara Buatnya memang susah-susah gampang. andaikan keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal ati ampela gongso yang enak seharusnya memiliki aroma dan rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ati ampela gongso, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menyajikannya. Tidak usah pusing kalau ingin menyiapkan ati ampela gongso yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan spesial.


Nah, kali ini kita coba, yuk, siapkan ati ampela gongso sendiri di rumah. Tetap berbahan sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Ati Ampela Gongso menggunakan 15 bahan dan 4 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ati Ampela Gongso:

1. Ambil 4 potong ati ampela, bersihkan
1. Gunakan 1 batang sereh, ambil putihnya kemudian iris serong/ memarkan
1. Ambil 2 lembar daun jeruk
1. Gunakan 120 ml air untuk tambahan saat menumis
1. Ambil 1 sdm saus tiram
1. Sediakan 1 sdm kecap manis
1. Gunakan 1/4 sdt lada bubuk
1. Gunakan Sejumput garam
1. Ambil Sejumput kaldu bubuk
1. Gunakan Sejumput gula pasir
1. Gunakan  Bumbu iris :
1. Gunakan 3 siung bawang merah
1. Gunakan 2 siung bawang putih
1. Gunakan 3 buah cabe rawit merah
1. Ambil 1 buah cabe hijau besar




<!--inarticleads2-->

##### Cara membuat Ati Ampela Gongso:

1. Rebus ati ampela hingga matang, tiriskan lalu potong2
1. Tumis bahan iris hingga wangi, masukkan ati ampela. Aduk rata
1. Beri air, kecap manis, saos tiram, garam, gula dan lada bubuk. Masak hingga kuah menyusut
1. Angkat dan sajikan




Bagaimana? Mudah bukan? Itulah cara menyiapkan ati ampela gongso yang bisa Anda praktikkan di rumah. Selamat mencoba!
