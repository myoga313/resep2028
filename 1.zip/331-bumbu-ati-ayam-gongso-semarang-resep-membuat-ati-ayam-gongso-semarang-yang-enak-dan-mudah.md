---
description: "Bumbu Ati Ayam Gongso Semarang | Resep Membuat Ati Ayam Gongso Semarang Yang Enak Dan Mudah"
title: "Bumbu Ati Ayam Gongso Semarang | Resep Membuat Ati Ayam Gongso Semarang Yang Enak Dan Mudah"
slug: 331-bumbu-ati-ayam-gongso-semarang-resep-membuat-ati-ayam-gongso-semarang-yang-enak-dan-mudah
date: 2020-09-10T13:52:30.443Z
image: https://img-global.cpcdn.com/recipes/e02ffeeb70583874/751x532cq70/ati-ayam-gongso-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e02ffeeb70583874/751x532cq70/ati-ayam-gongso-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e02ffeeb70583874/751x532cq70/ati-ayam-gongso-semarang-foto-resep-utama.jpg
author: Mattie Delgado
ratingvalue: 4.9
reviewcount: 13
recipeingredient:
- "12 Ati ayam"
- "3 Daun jeruk"
- "3 Salam"
- "1 ruas Lengkuas geprek"
- "1 Sereh geprek"
- "4 sdm Kecap manis"
- "Secukupnya Garam"
- "Secukupnya Kaldu jamur"
- "Secukupnya Air"
- " Minyak utk menumis"
- " Bumbu yg dihaluskan "
- "4 Bawang merah"
- "3 Bawang putih"
- "1 ruas Jahe"
- "4 Cabe merah"
- "5 Kemiri"
recipeinstructions:
- "Rebus ati ayam beri salam dan daun jeruk setelah 5 menit matikan kompor lalu tiriskan"
- "Persiapkan bahan2 yg lain. Bahan yg dihaluskan dgn blender"
- "Tumis bumbu yg dihaluskan masukan salam,sereh,lengkuas dan daun jeruk aduk2 lalu masukan air lalu masukan ati ayam aduk2 beri garam,kecap manis,kaldu jamur masak hingga bumbu meresap dan matang kuah menyusut"
- "Sajikan"
categories:
- Resep
tags:
- ati
- ayam
- gongso

katakunci: ati ayam gongso 
nutrition: 174 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Lunch

---


![Ati Ayam Gongso Semarang](https://img-global.cpcdn.com/recipes/e02ffeeb70583874/751x532cq70/ati-ayam-gongso-semarang-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep ati ayam gongso semarang yang Bisa Manjain Lidah? Cara Bikinnya memang susah-susah gampang. jikalau salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal ati ayam gongso semarang yang enak selayaknya mempunyai aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ati ayam gongso semarang, pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan ati ayam gongso semarang yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian istimewa.


Berikut ini ada beberapa tips dan trik praktis dalam mengolah ati ayam gongso semarang yang siap dikreasikan. Anda bisa menyiapkan Ati Ayam Gongso Semarang memakai 16 bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ati Ayam Gongso Semarang:

1. Gunakan 12 Ati ayam
1. Gunakan 3 Daun jeruk
1. Siapkan 3 Salam
1. Ambil 1 ruas Lengkuas geprek
1. Sediakan 1 Sereh geprek
1. Siapkan 4 sdm Kecap manis
1. Gunakan Secukupnya Garam
1. Ambil Secukupnya Kaldu jamur
1. Sediakan Secukupnya Air
1. Ambil  Minyak utk menumis
1. Ambil  Bumbu yg dihaluskan :
1. Sediakan 4 Bawang merah
1. Gunakan 3 Bawang putih
1. Siapkan 1 ruas Jahe
1. Ambil 4 Cabe merah
1. Sediakan 5 Kemiri




<!--inarticleads2-->

##### Langkah-langkah membuat Ati Ayam Gongso Semarang:

1. Rebus ati ayam beri salam dan daun jeruk setelah 5 menit matikan kompor lalu tiriskan
1. Persiapkan bahan2 yg lain. Bahan yg dihaluskan dgn blender
1. Tumis bumbu yg dihaluskan masukan salam,sereh,lengkuas dan daun jeruk aduk2 lalu masukan air lalu masukan ati ayam aduk2 beri garam,kecap manis,kaldu jamur masak hingga bumbu meresap dan matang kuah menyusut
1. Sajikan




Gimana nih? Gampang kan? Itulah cara menyiapkan ati ayam gongso semarang yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
