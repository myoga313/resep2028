---
description: "Bahan Babat Gongso | Cara Masak Babat Gongso Yang Enak Dan Mudah"
title: "Bahan Babat Gongso | Cara Masak Babat Gongso Yang Enak Dan Mudah"
slug: 64-bahan-babat-gongso-cara-masak-babat-gongso-yang-enak-dan-mudah
date: 2020-08-28T16:07:14.808Z
image: https://img-global.cpcdn.com/recipes/943c461f5a328c3c/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/943c461f5a328c3c/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/943c461f5a328c3c/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Annie Sanchez
ratingvalue: 3.8
reviewcount: 6
recipeingredient:
- "500 gr babat"
- "10 buah bawang merah iris"
- "1 btng serai"
- "5 lbr daun salam"
- "1 sachet kecil kecap bango"
- "1/2 sachet royco sapi"
- " Bumbu halus"
- "5 buah bawang merah"
- "3 siung bawang putih"
- "10 cabai merah keriting"
- "5 buah cabai rawit"
- "1 ruas jahe"
- "2 btr kemiri"
recipeinstructions:
- "Presto babat dengan secukupnya air,1 btng serai,laos dan 5 lbr daun salam selama 30 menit.Setelah uap hilang cuci kemabali babatnya dan potong kecil kecil."
- "Tumis bumbu halus hingga wangi dan matang.Masukkan irisan bawang merah.Masak sebentar hingga layu."
- "Masukkan babat,kecap manis,gula,penyedap dan garam.Masak hingga bumbu meresap."
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 175 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Dinner

---


![Babat Gongso](https://img-global.cpcdn.com/recipes/943c461f5a328c3c/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Kamu Sedang mencari inspirasi resep babat gongso yang Mudah Dan Praktis? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. semisal salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal babat gongso yang enak selayaknya punya aroma dan cita rasa yang bisa memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari babat gongso, pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menyajikannya. Tak perlu pusing kalau mau menyiapkan babat gongso enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan istimewa.


Di bawah ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah babat gongso yang siap dikreasikan. Anda dapat membuat Babat Gongso menggunakan 13 jenis bahan dan 3 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Babat Gongso:

1. Sediakan 500 gr babat
1. Gunakan 10 buah bawang merah iris
1. Ambil 1 btng serai
1. Ambil 5 lbr daun salam
1. Sediakan 1 sachet kecil kecap bango
1. Siapkan 1/2 sachet royco sapi
1. Siapkan  Bumbu halus
1. Ambil 5 buah bawang merah
1. Ambil 3 siung bawang putih
1. Sediakan 10 cabai merah keriting
1. Gunakan 5 buah cabai rawit
1. Siapkan 1 ruas jahe
1. Siapkan 2 btr kemiri




<!--inarticleads2-->

##### Langkah-langkah membuat Babat Gongso:

1. Presto babat dengan secukupnya air,1 btng serai,laos dan 5 lbr daun salam selama 30 menit.Setelah uap hilang cuci kemabali babatnya dan potong kecil kecil.
1. Tumis bumbu halus hingga wangi dan matang.Masukkan irisan bawang merah.Masak sebentar hingga layu.
1. Masukkan babat,kecap manis,gula,penyedap dan garam.Masak hingga bumbu meresap.




Gimana nih? Mudah bukan? Itulah cara menyiapkan babat gongso yang bisa Anda praktikkan di rumah. Selamat mencoba!
