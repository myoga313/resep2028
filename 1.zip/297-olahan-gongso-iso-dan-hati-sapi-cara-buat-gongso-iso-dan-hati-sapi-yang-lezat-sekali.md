---
description: "Olahan Gongso iso dan hati sapi | Cara Buat Gongso iso dan hati sapi Yang Lezat Sekali"
title: "Olahan Gongso iso dan hati sapi | Cara Buat Gongso iso dan hati sapi Yang Lezat Sekali"
slug: 297-olahan-gongso-iso-dan-hati-sapi-cara-buat-gongso-iso-dan-hati-sapi-yang-lezat-sekali
date: 2020-12-19T00:18:43.355Z
image: https://img-global.cpcdn.com/recipes/6d050aa7650ad8cb/751x532cq70/gongso-iso-dan-hati-sapi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6d050aa7650ad8cb/751x532cq70/gongso-iso-dan-hati-sapi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6d050aa7650ad8cb/751x532cq70/gongso-iso-dan-hati-sapi-foto-resep-utama.jpg
author: Steven Graves
ratingvalue: 4.2
reviewcount: 5
recipeingredient:
- "250 gram iso bersih"
- "100 gram ati sapi"
- "5 cabe rawit sesuai selera"
- "5 cabe keriting sesuai selera"
- "7 siung bawang merah"
- "4 siung bawang putih"
- "2 butir tomat agak kecil iris kecil"
- "2 ruas kecil lengkuas geprek"
- "1 lembar daun salam"
- "2 lembar daun jeruk"
- "3 butir kemiri"
- "4-5 sendok kecap manis sesuai selera"
- "Secukupnya garam gula penyedap"
recipeinstructions:
- "Rebus iso dan hati sapi kemudian potong² dan goreng sebentar aja"
- "Siapkan bumbu² kemudian tumis sampai setengah matang baru masukkan tomat"
- "Setelah dirasa bumbu matang, masukkan iso dan hati, aduk2 sebentar baru tambahkan air, kalo saya agak banyak supaya ngrebusnya lama jadi bumbu meresap"
- "Tambahkan seasoning, aduk² tunggu sampai air benar² menyusut dan minyak keluar, tes rasa jika sudah pas siap disajikan bun"
- "Selamat mencoba"
categories:
- Resep
tags:
- gongso
- iso
- dan

katakunci: gongso iso dan 
nutrition: 113 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Dessert

---


![Gongso iso dan hati sapi](https://img-global.cpcdn.com/recipes/6d050aa7650ad8cb/751x532cq70/gongso-iso-dan-hati-sapi-foto-resep-utama.jpg)

Sedang mencari ide resep gongso iso dan hati sapi yang Menggugah Selera? Cara Buatnya memang susah-susah gampang. seandainya keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gongso iso dan hati sapi yang enak harusnya sih punya aroma dan rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso iso dan hati sapi, mulai dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menyajikannya. Tak perlu pusing kalau ingin menyiapkan gongso iso dan hati sapi yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian spesial.


Di bawah ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah gongso iso dan hati sapi yang siap dikreasikan. Anda bisa membuat Gongso iso dan hati sapi menggunakan 13 bahan dan 5 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Gongso iso dan hati sapi:

1. Ambil 250 gram iso bersih
1. Gunakan 100 gram ati sapi
1. Ambil 5 cabe rawit (sesuai selera)
1. Sediakan 5 cabe keriting (sesuai selera)
1. Siapkan 7 siung bawang merah
1. Sediakan 4 siung bawang putih
1. Ambil 2 butir tomat agak kecil iris kecil²
1. Ambil 2 ruas kecil lengkuas geprek
1. Ambil 1 lembar daun salam
1. Gunakan 2 lembar daun jeruk
1. Sediakan 3 butir kemiri
1. Sediakan 4-5 sendok kecap manis (sesuai selera)
1. Ambil Secukupnya garam, gula, penyedap




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso iso dan hati sapi:

1. Rebus iso dan hati sapi kemudian potong² dan goreng sebentar aja
1. Siapkan bumbu² kemudian tumis sampai setengah matang baru masukkan tomat
1. Setelah dirasa bumbu matang, masukkan iso dan hati, aduk2 sebentar baru tambahkan air, kalo saya agak banyak supaya ngrebusnya lama jadi bumbu meresap
1. Tambahkan seasoning, aduk² tunggu sampai air benar² menyusut dan minyak keluar, tes rasa jika sudah pas siap disajikan bun
1. Selamat mencoba




Bagaimana? Gampang kan? Itulah cara menyiapkan gongso iso dan hati sapi yang bisa Anda praktikkan di rumah. Selamat mencoba!
