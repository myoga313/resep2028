---
description: "Resep masakan *Telur gongso khas Semarang* | Resep Membuat *Telur gongso khas Semarang* Yang Lezat Sekali"
title: "Resep masakan *Telur gongso khas Semarang* | Resep Membuat *Telur gongso khas Semarang* Yang Lezat Sekali"
slug: 80-resep-masakan-telur-gongso-khas-semarang-resep-membuat-telur-gongso-khas-semarang-yang-lezat-sekali
date: 2020-07-22T18:19:09.697Z
image: https://img-global.cpcdn.com/recipes/4ec68eb5fbe93cfe/751x532cq70/telur-gongso-khas-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4ec68eb5fbe93cfe/751x532cq70/telur-gongso-khas-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4ec68eb5fbe93cfe/751x532cq70/telur-gongso-khas-semarang-foto-resep-utama.jpg
author: Howard Harris
ratingvalue: 3.7
reviewcount: 5
recipeingredient:
- "4-5 butir telur"
- "2 btg daun bawang iris kasar"
- "1 buah tomat potong2"
- " Bumbu halus "
- "6 siung bawang merah"
- "4 siung bawang putih"
- "4 cabe merah keriting"
- "6 cabe rawit merah"
- " Bumbu lain "
- "2 sdm saus sambel"
- "1 sdm saus tomat"
- "1-2 sdm kecap manis"
- "1/2 sdt garam"
- "1/2 sdt gula pasir"
- "Secukupnya kaldu bubuk optionalsy skip"
- "secukupnya Air matang"
- " Bawang merah goreng secukupnya untuk taburan"
recipeinstructions:
- "Siapkan bahan. Iris daun bawang dan tomat. Sisihkan. Ceplok telur"
- "Haluskan bumbu, sy ditambah garam biar cepat halusnya..lalu tumis bumbu halus hingga matang dan harum kemudian masukkan saus sambel, saus tomat dan kecap manis, aduk rata, masukkan telur ceplok"
- "Aduk rata, beri air secukupnya, aduk lagi dan biarkan mendidih lalu masukkan gula pasir. Aduk rata, didihkan lagi. Cek rasa, setelah hampir matang masukkan potongan tomat dan daun bawang"
- "Aduk rata kembali, masak sebentar, angkat. Tuang dalam wadah saji, taburi bawang goreng"
- "Sajikan."
categories:
- Resep
tags:
- telur
- gongso
- khas

katakunci: telur gongso khas 
nutrition: 124 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dessert

---


![*Telur gongso khas Semarang*](https://img-global.cpcdn.com/recipes/4ec68eb5fbe93cfe/751x532cq70/telur-gongso-khas-semarang-foto-resep-utama.jpg)

Anda sedang mencari ide resep *telur gongso khas semarang* yang Enak Dan Mudah? Cara Memasaknya memang susah-susah gampang. bila keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal *telur gongso khas semarang* yang enak harusnya sih punya aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari *telur gongso khas semarang*, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tidak usah pusing jika mau menyiapkan *telur gongso khas semarang* enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian istimewa.

Dengan bahan seadanya kita dapat juga membuat masakan yang lezat seperti Gongso Telur ini. Masakan khas Semarang ini dibuat dari telur yang dimasak. Babat Gongso Khas Semarang Pedes Manis Gurih.


Di bawah ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah *telur gongso khas semarang* yang siap dikreasikan. Anda bisa menyiapkan *Telur gongso khas Semarang* menggunakan 17 bahan dan 5 tahap pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan *Telur gongso khas Semarang*:

1. Gunakan 4-5 butir telur
1. Siapkan 2 btg daun bawang, iris kasar
1. Sediakan 1 buah tomat, potong2
1. Siapkan  Bumbu halus :
1. Ambil 6 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Siapkan 4 cabe merah keriting
1. Ambil 6 cabe rawit merah
1. Sediakan  Bumbu lain :
1. Ambil 2 sdm saus sambel
1. Ambil 1 sdm saus tomat
1. Sediakan 1-2 sdm kecap manis
1. Ambil 1/2 sdt garam
1. Sediakan 1/2 sdt gula pasir
1. Siapkan Secukupnya kaldu bubuk (optional)sy, skip
1. Gunakan secukupnya Air matang
1. Ambil  Bawang merah goreng secukupnya, untuk taburan


Masakan khas Semarang- Babat Gongso yang seringkali juga dijadikan nasi goreng babat, dan ini enak sekali apalagi jika. Makanan khas semarang yang paling dominan antarai lain nasi ayam semarang, tahu gimbal, gulai kambis bustaman, dan babat gongso. Mangut Kepala Manyung menjadi alternatif makanan khas semarang. Makanan ini sendiri terdiri dari kepala ikan manyung, daging ikan manyung, santan, cabe. 

<!--inarticleads2-->

##### Langkah-langkah membuat *Telur gongso khas Semarang*:

1. Siapkan bahan. Iris daun bawang dan tomat. Sisihkan. Ceplok telur
1. Haluskan bumbu, sy ditambah garam biar cepat halusnya..lalu tumis bumbu halus hingga matang dan harum kemudian masukkan saus sambel, saus tomat dan kecap manis, aduk rata, masukkan telur ceplok
1. Aduk rata, beri air secukupnya, aduk lagi dan biarkan mendidih lalu masukkan gula pasir. Aduk rata, didihkan lagi. Cek rasa, setelah hampir matang masukkan potongan tomat dan daun bawang
1. Aduk rata kembali, masak sebentar, angkat. Tuang dalam wadah saji, taburi bawang goreng
1. Sajikan.


Babat gongso khas Semarang rasanya manis berkat penggunaan kecap. Kalau mau pedas, tambah takaran cabai. KOMPAS.com/Nabilla TashandraBabat gongso, salah satu menu andalan di Nasi Goreng Babat Pak Karmin di Jalan Pemuda, Semarang, yang tak pernah sepi pembeli. Babat Gongso menjadi makanan berat khas Semarang yang harus anda coba. Babat gongso terdiri dari potongan jeroan dan babat seperti ati, patu dan limpa. 

Terima kasih telah membaca resep yang tim kami tampilkan di sini. Besar harapan kami, olahan *Telur gongso khas Semarang* yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman maupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
