---
description: "Resep masakan 25. Babat gongso | Resep Bumbu 25. Babat gongso Yang Bisa Manjain Lidah"
title: "Resep masakan 25. Babat gongso | Resep Bumbu 25. Babat gongso Yang Bisa Manjain Lidah"
slug: 362-resep-masakan-25-babat-gongso-resep-bumbu-25-babat-gongso-yang-bisa-manjain-lidah
date: 2020-10-21T19:51:12.272Z
image: https://img-global.cpcdn.com/recipes/10190bc81bd192b8/751x532cq70/25-babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/10190bc81bd192b8/751x532cq70/25-babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/10190bc81bd192b8/751x532cq70/25-babat-gongso-foto-resep-utama.jpg
author: Tommy Page
ratingvalue: 3.4
reviewcount: 5
recipeingredient:
- " Bahan rebus"
- "250 gr babat"
- "250 gr kikil"
- "1 lengkuas geprek"
- "1 jahe geprek"
- "2 lembar daun salam"
- " Bumbu halus"
- "3 bawang merah"
- "3 bawang putih"
- "3 kemiri"
- "3 cabe merah"
- "20 cabe rawit"
- "2 daun jeruk"
- " Bahan lain"
- "1 serai geprek"
- "1 lengkuas geprek"
- "1 jahe geprek"
- "1 daun salam"
- "3 sdm kecap manis"
- "Secukupnya Garam gula lada"
- " Air rebusan babat"
- " Minyak untuk menumis"
recipeinstructions:
- "Siapkan bahan dan bumbu"
- "Cuci bersih babat. Rebus dengan lengkuas, jahe dan daun salam sampai empuk. Lalu potong sesuai selera"
- "Blender bumbu halus. Panaskan minyak. Tumis bumbu halus dengan lengkuas, serai, jahe dan daun salam"
- "Setelah bumbu agak menyusut, masukkan kikil dan babat. Tambahkan sedikit air kaldu rebusan babat"
- "Aduk rata. Tambahkan garam, gula dan lada secukupnya. Tunggu hingga air kaldu meresap"
- "Tambahkan kecap. Aduk rata"
categories:
- Resep
tags:
- 25
- babat
- gongso

katakunci: 25 babat gongso 
nutrition: 181 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Lunch

---


![25. Babat gongso](https://img-global.cpcdn.com/recipes/10190bc81bd192b8/751x532cq70/25-babat-gongso-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep 25. babat gongso yang Mudah Dan Praktis? Cara Memasaknya memang tidak terlalu sulit namun tidak gampang juga. Jika salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal 25. babat gongso yang enak seharusnya punya aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari 25. babat gongso, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tidak usah pusing kalau mau menyiapkan 25. babat gongso yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.




Nah, kali ini kita coba, yuk, kreasikan 25. babat gongso sendiri di rumah. Tetap berbahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan 25. Babat gongso memakai 22 bahan dan 6 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan 25. Babat gongso:

1. Ambil  Bahan rebus
1. Gunakan 250 gr babat
1. Ambil 250 gr kikil
1. Gunakan 1 lengkuas geprek
1. Gunakan 1 jahe geprek
1. Sediakan 2 lembar daun salam
1. Siapkan  Bumbu halus
1. Sediakan 3 bawang merah
1. Gunakan 3 bawang putih
1. Sediakan 3 kemiri
1. Siapkan 3 cabe merah
1. Sediakan 20 cabe rawit
1. Siapkan 2 daun jeruk
1. Ambil  Bahan lain
1. Gunakan 1 serai geprek
1. Gunakan 1 lengkuas geprek
1. Ambil 1 jahe geprek
1. Ambil 1 daun salam
1. Siapkan 3 sdm kecap manis
1. Sediakan Secukupnya Garam gula lada
1. Ambil  Air rebusan babat
1. Ambil  Minyak untuk menumis




<!--inarticleads2-->

##### Cara menyiapkan 25. Babat gongso:

1. Siapkan bahan dan bumbu
1. Cuci bersih babat. Rebus dengan lengkuas, jahe dan daun salam sampai empuk. Lalu potong sesuai selera
1. Blender bumbu halus. Panaskan minyak. Tumis bumbu halus dengan lengkuas, serai, jahe dan daun salam
1. Setelah bumbu agak menyusut, masukkan kikil dan babat. Tambahkan sedikit air kaldu rebusan babat
1. Aduk rata. Tambahkan garam, gula dan lada secukupnya. Tunggu hingga air kaldu meresap
1. Tambahkan kecap. Aduk rata




Bagaimana? Gampang kan? Itulah cara membuat 25. babat gongso yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
