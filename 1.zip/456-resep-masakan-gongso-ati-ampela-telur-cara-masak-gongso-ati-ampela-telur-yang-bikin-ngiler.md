---
description: "Resep masakan Gongso ati ampela + telur | Cara Masak Gongso ati ampela + telur Yang Bikin Ngiler"
title: "Resep masakan Gongso ati ampela + telur | Cara Masak Gongso ati ampela + telur Yang Bikin Ngiler"
slug: 456-resep-masakan-gongso-ati-ampela-telur-cara-masak-gongso-ati-ampela-telur-yang-bikin-ngiler
date: 2020-07-17T16:11:37.734Z
image: https://img-global.cpcdn.com/recipes/8ddf50b3a97c178b/751x532cq70/gongso-ati-ampela-telur-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8ddf50b3a97c178b/751x532cq70/gongso-ati-ampela-telur-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8ddf50b3a97c178b/751x532cq70/gongso-ati-ampela-telur-foto-resep-utama.jpg
author: Lula Marsh
ratingvalue: 4.5
reviewcount: 11
recipeingredient:
- " ati ampela"
- " telur rebus"
- " Kecap manis"
- " Garam gula kaldu jamur"
- " Bumbu halus "
- " bawang putih"
- " bawang merah"
- " kemiri"
- " cabe rawit merah"
- " Bumbu iris "
- " bawang bombay"
- " cabe merah besar"
- " Bumbu cemplung "
- " Lengkuas"
- " daun salam"
- " daun jeruk"
- " serai"
- " Air"
recipeinstructions:
- "Cuci ati ampela lalu rebus, dan rebus telur. Setelah matang kupas goreng sebentar, dan potong ati ampela sesuai selera."
- "Ulek bumbu halus, iris bawang bombay dan cabe merah."
- "Tumis bumbu halus dan bumbu cemplung sampai harum, lalu tambahkan air."
- "Setelah mendidih masukkan ati ampela + telur. Masukkan garam, gula, koreksi rasa."
- "Setelah matang sajikan."
categories:
- Resep
tags:
- gongso
- ati
- ampela

katakunci: gongso ati ampela 
nutrition: 285 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Dinner

---


![Gongso ati ampela + telur](https://img-global.cpcdn.com/recipes/8ddf50b3a97c178b/751x532cq70/gongso-ati-ampela-telur-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep gongso ati ampela + telur yang Bisa Manjain Lidah? Cara menyiapkannya memang tidak susah dan tidak juga mudah. kalau keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gongso ati ampela + telur yang enak selayaknya memiliki aroma dan cita rasa yang mampu memancing selera kita.

Lihat juga resep Gongso Ayam ala Semarangan enak lainnya. Cara membuat gongso ati ampela yang sedap. Isiannya telur, bakso, ati ampela, hingga sosis.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ati ampela + telur, mulai dari jenis bahan, kedua pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tidak usah pusing kalau hendak menyiapkan gongso ati ampela + telur yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.


Berikut ini ada beberapa cara mudah dan praktis dalam mengolah gongso ati ampela + telur yang siap dikreasikan. Anda dapat membuat Gongso ati ampela + telur memakai 18 bahan dan 5 tahap pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Gongso ati ampela + telur:

1. Sediakan  ati ampela
1. Sediakan  telur rebus
1. Sediakan  Kecap manis
1. Sediakan  Garam, gula, kaldu jamur
1. Sediakan  Bumbu halus :
1. Sediakan  bawang putih
1. Gunakan  bawang merah
1. Siapkan  kemiri
1. Ambil  cabe rawit merah
1. Siapkan  Bumbu iris :
1. Siapkan  bawang bombay
1. Sediakan  cabe merah besar
1. Gunakan  Bumbu cemplung :
1. Gunakan  Lengkuas
1. Siapkan  daun salam
1. Sediakan  daun jeruk
1. Gunakan  serai
1. Siapkan  Air


Ati ampela tidak harus selalu direbus sendiri, tergantung jenis masakannya. Begini cara masak ati ample sesuai jenis masakannya. KOMPAS.com - Hati ampela menjadi salah satu jenis jeroan yang banyak dijadikan bahan olahan makanan, salah satunya untuk Kari Ayam Bihun Medan. Sambal Goreng Ati Ampela CARA MEMBUAT ATI AMPELA SIMPEL, SEDERHANA DAN ENAK. 

<!--inarticleads2-->

##### Cara menyiapkan Gongso ati ampela + telur:

1. Cuci ati ampela lalu rebus, dan rebus telur. Setelah matang kupas goreng sebentar, dan potong ati ampela sesuai selera.
1. Ulek bumbu halus, iris bawang bombay dan cabe merah.
1. Tumis bumbu halus dan bumbu cemplung sampai harum, lalu tambahkan air.
1. Setelah mendidih masukkan ati ampela + telur. Masukkan garam, gula, koreksi rasa.
1. Setelah matang sajikan.


Resep Babat Gongso Khas Semarang Lifestyle Fimela Com Resep Gongso Telur Mudah, Nikmat dan Sederhana. Potong ati ampela menjadi dua bagian. Lihat juga resep Gongso rempelo ati enak lainnya. Ati Ampela Goreng Telur pasti mudah untuk dibuat tapi tetap rasanya lezat. Simak cara buatnya dengan resep berikut ini. 

Bagaimana? Gampang kan? Itulah cara membuat gongso ati ampela + telur yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
