---
description: "Resep Ayam Gongso Semarang | Resep Membuat Ayam Gongso Semarang Yang Lezat Sekali"
title: "Resep Ayam Gongso Semarang | Resep Membuat Ayam Gongso Semarang Yang Lezat Sekali"
slug: 222-resep-ayam-gongso-semarang-resep-membuat-ayam-gongso-semarang-yang-lezat-sekali
date: 2020-12-13T13:26:02.577Z
image: https://img-global.cpcdn.com/recipes/5c1cdce6c96fa5a2/751x532cq70/ayam-gongso-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5c1cdce6c96fa5a2/751x532cq70/ayam-gongso-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5c1cdce6c96fa5a2/751x532cq70/ayam-gongso-semarang-foto-resep-utama.jpg
author: Sam Lopez
ratingvalue: 3.4
reviewcount: 3
recipeingredient:
- " Ayam"
- " Daun Jeruk"
- " Daun Bawang"
- " Daun Salam"
- " Lengkuas digeprek"
- " Kecap Manis"
- " Saus Tiram"
- " Garam"
- " Bumbu Halus"
- " Bawang Putih"
- " Bawang Merah"
- " Cabe Merah"
- " Cabe Rawit"
- " Kemiri"
recipeinstructions:
- "Rebus ayam sampai empuk, lalu suwir."
- "Tumis bumbu halus sampai harum, lalu tambahkan daun salam, daun jeruk, dan lengkuas."
- "Masukkan ayam suwir dan tambahkan air secukupnya."
- "Tambahkan kecap manis dan saus tiram, serta garam secukupnya."
- "Aduk sampai merata."
- "Siap dihidangkan."
categories:
- Resep
tags:
- ayam
- gongso
- semarang

katakunci: ayam gongso semarang 
nutrition: 170 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Gongso Semarang](https://img-global.cpcdn.com/recipes/5c1cdce6c96fa5a2/751x532cq70/ayam-gongso-semarang-foto-resep-utama.jpg)

Kamu Sedang mencari inspirasi resep ayam gongso semarang yang Enak Dan Lezat? Cara Memasaknya memang susah-susah gampang. andaikan salah mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal ayam gongso semarang yang enak harusnya sih memiliki aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso semarang, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tak perlu pusing jika mau menyiapkan ayam gongso semarang yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.




Nah, kali ini kita coba, yuk, kreasikan ayam gongso semarang sendiri di rumah. Tetap berbahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Ayam Gongso Semarang menggunakan 14 jenis bahan dan 6 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam Gongso Semarang:

1. Gunakan  Ayam
1. Siapkan  Daun Jeruk
1. Siapkan  Daun Bawang
1. Ambil  Daun Salam
1. Sediakan  Lengkuas (digeprek)
1. Sediakan  Kecap Manis
1. Ambil  Saus Tiram
1. Ambil  Garam
1. Sediakan  Bumbu Halus
1. Siapkan  Bawang Putih
1. Gunakan  Bawang Merah
1. Sediakan  Cabe Merah
1. Sediakan  Cabe Rawit
1. Sediakan  Kemiri




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Gongso Semarang:

1. Rebus ayam sampai empuk, lalu suwir.
1. Tumis bumbu halus sampai harum, lalu tambahkan daun salam, daun jeruk, dan lengkuas.
1. Masukkan ayam suwir dan tambahkan air secukupnya.
1. Tambahkan kecap manis dan saus tiram, serta garam secukupnya.
1. Aduk sampai merata.
1. Siap dihidangkan.




Bagaimana? Mudah bukan? Itulah cara membuat ayam gongso semarang yang bisa Anda praktikkan di rumah. Selamat mencoba!
