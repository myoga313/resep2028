---
description: "Bumbu Ayam Gongso | Cara Membuat Ayam Gongso Yang Sedap"
title: "Bumbu Ayam Gongso | Cara Membuat Ayam Gongso Yang Sedap"
slug: 211-bumbu-ayam-gongso-cara-membuat-ayam-gongso-yang-sedap
date: 2020-08-22T00:10:48.630Z
image: https://img-global.cpcdn.com/recipes/6abd680c11ee0b62/751x532cq70/ayam-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6abd680c11ee0b62/751x532cq70/ayam-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6abd680c11ee0b62/751x532cq70/ayam-gongso-foto-resep-utama.jpg
author: Mable Ingram
ratingvalue: 4.8
reviewcount: 9
recipeingredient:
- "1/2 ekor Ayam sedang cuci bersih"
- "3 siung Bawang merah"
- "2 siung Bawang putih"
- "1/2 siung Bawang bombay"
- "7 biji Cabe rawit"
- "2 sdm Kecap manis"
- "2 sdm Saos Tiram"
- "1/3 sdt Himalaya salt"
- "1/3 sdt Lada bubuk"
- "1/2 sdt Kaldu bubuk"
- " Air untuk merebus"
recipeinstructions:
- "Potong ayah agak kecil, lalu didihkan air dan rebus hingga ayam matang. Sisihkan jangan dibuang air rebusannya"
- "Iris trio bawang dan cabe, aslinya dihaluskan ya bamer, baput n cabe nya. Lalu tumis dengan minyak hingga wangi"
- "Masukkan air rebusan, kecap, saos tiram, garam, lada, kaldu bubuk. Masak hingga mendidih"
- "Masukkan ayam, masak hingga kuah meresap ke daging ayam"
- "Angkat dan sajikan, nikmat dengan sebakul nasi"
categories:
- Resep
tags:
- ayam
- gongso

katakunci: ayam gongso 
nutrition: 137 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Gongso](https://img-global.cpcdn.com/recipes/6abd680c11ee0b62/751x532cq70/ayam-gongso-foto-resep-utama.jpg)

Anda sedang mencari ide resep ayam gongso yang Mudah Dan Praktis? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. semisal keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal ayam gongso yang enak seharusnya mempunyai aroma dan cita rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tidak usah pusing jika mau menyiapkan ayam gongso yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.




Nah, kali ini kita coba, yuk, siapkan ayam gongso sendiri di rumah. Tetap berbahan sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Ayam Gongso memakai 11 jenis bahan dan 5 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam Gongso:

1. Gunakan 1/2 ekor Ayam sedang, cuci bersih
1. Ambil 3 siung Bawang merah
1. Gunakan 2 siung Bawang putih
1. Gunakan 1/2 siung Bawang bombay
1. Siapkan 7 biji Cabe rawit
1. Ambil 2 sdm Kecap manis
1. Sediakan 2 sdm Saos Tiram
1. Sediakan 1/3 sdt Himalaya salt
1. Ambil 1/3 sdt Lada bubuk
1. Ambil 1/2 sdt Kaldu bubuk
1. Sediakan  Air untuk merebus




<!--inarticleads2-->

##### Cara menyiapkan Ayam Gongso:

1. Potong ayah agak kecil, lalu didihkan air dan rebus hingga ayam matang. Sisihkan jangan dibuang air rebusannya
1. Iris trio bawang dan cabe, aslinya dihaluskan ya bamer, baput n cabe nya. Lalu tumis dengan minyak hingga wangi
1. Masukkan air rebusan, kecap, saos tiram, garam, lada, kaldu bubuk. Masak hingga mendidih
1. Masukkan ayam, masak hingga kuah meresap ke daging ayam
1. Angkat dan sajikan, nikmat dengan sebakul nasi




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Ayam Gongso yang mudah di atas dapat membantu Anda menyiapkan makanan yang menarik untuk keluarga/teman maupun menjadi inspirasi bagi Anda yang berkeinginan untuk berjualan makanan. Selamat mencoba!
