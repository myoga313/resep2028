---
description: "Bahan Gongso ati ampela + telur | Resep Membuat Gongso ati ampela + telur Yang Enak dan Simpel"
title: "Bahan Gongso ati ampela + telur | Resep Membuat Gongso ati ampela + telur Yang Enak dan Simpel"
slug: 94-bahan-gongso-ati-ampela-telur-resep-membuat-gongso-ati-ampela-telur-yang-enak-dan-simpel
date: 2020-11-19T21:55:44.762Z
image: https://img-global.cpcdn.com/recipes/8ddf50b3a97c178b/751x532cq70/gongso-ati-ampela-telur-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8ddf50b3a97c178b/751x532cq70/gongso-ati-ampela-telur-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8ddf50b3a97c178b/751x532cq70/gongso-ati-ampela-telur-foto-resep-utama.jpg
author: Lola Gonzalez
ratingvalue: 4.6
reviewcount: 5
recipeingredient:
- "6 biji ati ampela"
- "2 butir telur rebus"
- "secukupnya Kecap manis"
- "secukupnya Garam gula kaldu jamur"
- " Bumbu halus "
- "4 siung bawang putih"
- "5 siung bawang merah"
- "3 butir kemiri"
- "5 butir cabe rawit merah"
- " Bumbu iris "
- "1/4 bawang bombay"
- "5 butir cabe merah besar"
- " Bumbu cemplung "
- "1 ruas Lengkuas"
- "1 lembar daun salam"
- "1 daun jeruk"
- "1 serai"
- "secukupnya Air"
recipeinstructions:
- "Cuci ati ampela lalu rebus, dan rebus telur. Setelah matang kupas goreng sebentar, dan potong ati ampela sesuai selera."
- "Ulek bumbu halus, iris bawang bombay dan cabe merah."
- "Tumis bumbu halus dan bumbu cemplung sampai harum, lalu tambahkan air."
- "Setelah mendidih masukkan ati ampela + telur. Masukkan garam, gula, koreksi rasa."
- "Setelah matang sajikan."
categories:
- Resep
tags:
- gongso
- ati
- ampela

katakunci: gongso ati ampela 
nutrition: 142 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Lunch

---


![Gongso ati ampela + telur](https://img-global.cpcdn.com/recipes/8ddf50b3a97c178b/751x532cq70/gongso-ati-ampela-telur-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep gongso ati ampela + telur yang Bikin Ngiler? Cara Memasaknya memang tidak susah dan tidak juga mudah. seumpama keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso ati ampela + telur yang enak harusnya sih mempunyai aroma dan cita rasa yang bisa memancing selera kita.

Lihat juga resep Gongso Ayam ala Semarangan enak lainnya. Cara membuat gongso ati ampela yang sedap. Isiannya telur, bakso, ati ampela, hingga sosis.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ati ampela + telur, pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menyajikannya. Tidak usah pusing kalau mau menyiapkan gongso ati ampela + telur yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian spesial.


Nah, kali ini kita coba, yuk, buat gongso ati ampela + telur sendiri di rumah. Tetap berbahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Gongso ati ampela + telur menggunakan 18 bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Gongso ati ampela + telur:

1. Sediakan 6 biji ati ampela
1. Siapkan 2 butir telur rebus
1. Ambil secukupnya Kecap manis
1. Siapkan secukupnya Garam, gula, kaldu jamur
1. Sediakan  Bumbu halus :
1. Siapkan 4 siung bawang putih
1. Sediakan 5 siung bawang merah
1. Sediakan 3 butir kemiri
1. Siapkan 5 butir cabe rawit merah
1. Siapkan  Bumbu iris :
1. Sediakan 1/4 bawang bombay
1. Ambil 5 butir cabe merah besar
1. Sediakan  Bumbu cemplung :
1. Gunakan 1 ruas Lengkuas
1. Gunakan 1 lembar daun salam
1. Ambil 1 daun jeruk
1. Sediakan 1 serai
1. Sediakan secukupnya Air


Ati ampela tidak harus selalu direbus sendiri, tergantung jenis masakannya. Begini cara masak ati ample sesuai jenis masakannya. KOMPAS.com - Hati ampela menjadi salah satu jenis jeroan yang banyak dijadikan bahan olahan makanan, salah satunya untuk Kari Ayam Bihun Medan. Sambal Goreng Ati Ampela CARA MEMBUAT ATI AMPELA SIMPEL, SEDERHANA DAN ENAK. 

<!--inarticleads2-->

##### Langkah-langkah membuat Gongso ati ampela + telur:

1. Cuci ati ampela lalu rebus, dan rebus telur. Setelah matang kupas goreng sebentar, dan potong ati ampela sesuai selera.
1. Ulek bumbu halus, iris bawang bombay dan cabe merah.
1. Tumis bumbu halus dan bumbu cemplung sampai harum, lalu tambahkan air.
1. Setelah mendidih masukkan ati ampela + telur. Masukkan garam, gula, koreksi rasa.
1. Setelah matang sajikan.


Resep Babat Gongso Khas Semarang Lifestyle Fimela Com Resep Gongso Telur Mudah, Nikmat dan Sederhana. Potong ati ampela menjadi dua bagian. Lihat juga resep Gongso rempelo ati enak lainnya. Ati Ampela Goreng Telur pasti mudah untuk dibuat tapi tetap rasanya lezat. Simak cara buatnya dengan resep berikut ini. 

Gimana nih? Mudah bukan? Itulah cara membuat gongso ati ampela + telur yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
