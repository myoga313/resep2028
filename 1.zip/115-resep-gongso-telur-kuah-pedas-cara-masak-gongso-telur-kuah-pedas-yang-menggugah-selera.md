---
description: "Resep Gongso Telur Kuah Pedas | Cara Masak Gongso Telur Kuah Pedas Yang Menggugah Selera"
title: "Resep Gongso Telur Kuah Pedas | Cara Masak Gongso Telur Kuah Pedas Yang Menggugah Selera"
slug: 115-resep-gongso-telur-kuah-pedas-cara-masak-gongso-telur-kuah-pedas-yang-menggugah-selera
date: 2020-12-30T20:47:43.469Z
image: https://img-global.cpcdn.com/recipes/b3ed347296472a4c/751x532cq70/gongso-telur-kuah-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b3ed347296472a4c/751x532cq70/gongso-telur-kuah-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b3ed347296472a4c/751x532cq70/gongso-telur-kuah-pedas-foto-resep-utama.jpg
author: Daisy Christensen
ratingvalue: 3.2
reviewcount: 15
recipeingredient:
- "1 butir telur"
- "2 buah sosisbakso optional iris tipis"
- "1/3 kol iris sesuai seleradaun sawi hijau"
- "2 sdm minyak sayur"
- "1/2 sdt garam"
- "Sedikit merica bubuk"
- " Penyedap rasa secukupnya optional"
- "Sedikit Gula pasir"
- "1 sdm saus tomat"
- "1 sdt kecap manisasin"
- "500 ml air sesuai selera"
- " Bumbu halus "
- "2 cabe rawit sesuai selera"
- "3 cabe merah keriting"
- "3 siung bawang putih"
- "4 siung bawang merah"
- " Bawang goreng untuk taburan optional"
recipeinstructions:
- "Uleg cabe, bawang merah dan putih sampe halus."
- "Siapkan wajan tuang minyak sayur, kemudian pecahkan 1 butir telur dan orak arik, sisihkan di pinggir wajan."
- "Masukkan bumbu halus tumis sebentar sampe harum dan agak layu. Tuang air masukkan garam, merica dan penyedap rasa aduk sampe gak mendidih."
- "Masukkan kol dan sosis, masukkan saus tomat dan kecap manis/asin, masak kol sampe agak layu aduk dan tes rasa. Segera sajikan selagi panas.."
categories:
- Resep
tags:
- gongso
- telur
- kuah

katakunci: gongso telur kuah 
nutrition: 242 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dessert

---


![Gongso Telur Kuah Pedas](https://img-global.cpcdn.com/recipes/b3ed347296472a4c/751x532cq70/gongso-telur-kuah-pedas-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep gongso telur kuah pedas yang Bikin Ngiler? Cara Memasaknya memang tidak susah dan tidak juga mudah. andaikan keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso telur kuah pedas yang enak selayaknya mempunyai aroma dan rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso telur kuah pedas, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tak perlu pusing jika mau menyiapkan gongso telur kuah pedas yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.




Nah, kali ini kita coba, yuk, ciptakan gongso telur kuah pedas sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Gongso Telur Kuah Pedas menggunakan 17 jenis bahan dan 4 tahap pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Gongso Telur Kuah Pedas:

1. Sediakan 1 butir telur
1. Ambil 2 buah sosis/bakso (optional) iris tipis
1. Siapkan 1/3 kol iris sesuai selera/daun sawi hijau
1. Ambil 2 sdm minyak sayur
1. Gunakan 1/2 sdt garam
1. Ambil Sedikit merica bubuk
1. Gunakan  Penyedap rasa secukupnya (optional)
1. Siapkan Sedikit Gula pasir
1. Gunakan 1 sdm saus tomat
1. Sediakan 1 sdt kecap manis/asin
1. Gunakan 500 ml air (sesuai selera)
1. Ambil  Bumbu halus :
1. Sediakan 2 cabe rawit (sesuai selera)
1. Sediakan 3 cabe merah keriting
1. Gunakan 3 siung bawang putih
1. Sediakan 4 siung bawang merah
1. Siapkan  Bawang goreng untuk taburan (optional)




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso Telur Kuah Pedas:

1. Uleg cabe, bawang merah dan putih sampe halus.
1. Siapkan wajan tuang minyak sayur, kemudian pecahkan 1 butir telur dan orak arik, sisihkan di pinggir wajan.
1. Masukkan bumbu halus tumis sebentar sampe harum dan agak layu. Tuang air masukkan garam, merica dan penyedap rasa aduk sampe gak mendidih.
1. Masukkan kol dan sosis, masukkan saus tomat dan kecap manis/asin, masak kol sampe agak layu aduk dan tes rasa. Segera sajikan selagi panas..




Bagaimana? Gampang kan? Itulah cara menyiapkan gongso telur kuah pedas yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
