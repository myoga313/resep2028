---
description: "Resep masakan Babat Gongso Semarang | Cara Bikin Babat Gongso Semarang Yang Bisa Manjain Lidah"
title: "Resep masakan Babat Gongso Semarang | Cara Bikin Babat Gongso Semarang Yang Bisa Manjain Lidah"
slug: 79-resep-masakan-babat-gongso-semarang-cara-bikin-babat-gongso-semarang-yang-bisa-manjain-lidah
date: 2020-09-26T05:54:02.838Z
image: https://img-global.cpcdn.com/recipes/9f1cf556cbc7cac4/751x532cq70/babat-gongso-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9f1cf556cbc7cac4/751x532cq70/babat-gongso-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9f1cf556cbc7cac4/751x532cq70/babat-gongso-semarang-foto-resep-utama.jpg
author: Wesley McDaniel
ratingvalue: 4.4
reviewcount: 6
recipeingredient:
- "150 gr babat sapi"
- "5 bh bawang merah iris tipis untuk tekstur"
- "4 bh daun jeruk"
- "2 bh daun salam"
- "1 sdm kecap manis"
- "1 sdt gula pasir"
- "1/2 sdt garam"
- "1/2 sdt kaldu jamur"
- "100 ml air"
- "5 sdm minyak untuk menumis"
- " Bumbu halus"
- "5 bh cabe merah keriting"
- "3 bh cabe rawit"
- "3 bh bawang merah"
- "2 bh bawang putih"
- "2 bh kemiri sangrai"
recipeinstructions:
- "Slow cooker babat selama 6 jam atau sampai empuk. Bisa di presto, rebus/ungkep. Potong babat sesuai selera. Ulek/ blender bumbu halus, sisihkan."
- "Tumis bawang merah sampai matang. Tambahkan bumbu halus, daun jeruk dan daun salam, masak sampai layu dan harum. Masukkan babat aduk rata, tambahkan gula garam kecap dan kaldu jamur."
- "Tambahkan air, agar bumbu tidak lengket dan gosong, koreksi rasa. Masak sampai bumbu meresap dan air surut. Sajikan dengan nasi hangat."
categories:
- Resep
tags:
- babat
- gongso
- semarang

katakunci: babat gongso semarang 
nutrition: 264 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Dinner

---


![Babat Gongso Semarang](https://img-global.cpcdn.com/recipes/9f1cf556cbc7cac4/751x532cq70/babat-gongso-semarang-foto-resep-utama.jpg)

Bunda lagi mencari ide resep babat gongso semarang yang Bisa Manjain Lidah? Cara Memasaknya memang tidak terlalu sulit namun tidak gampang juga. jikalau keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal babat gongso semarang yang enak harusnya sih punya aroma dan rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso semarang, pertama dari jenis bahan, lalu pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tidak usah pusing jika ingin menyiapkan babat gongso semarang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.




Berikut ini ada beberapa cara mudah dan praktis untuk membuat babat gongso semarang yang siap dikreasikan. Anda bisa membuat Babat Gongso Semarang memakai 16 bahan dan 3 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Babat Gongso Semarang:

1. Siapkan 150 gr babat sapi
1. Siapkan 5 bh bawang merah, iris tipis untuk tekstur
1. Ambil 4 bh daun jeruk
1. Siapkan 2 bh daun salam
1. Gunakan 1 sdm kecap manis
1. Sediakan 1 sdt gula pasir
1. Gunakan 1/2 sdt garam
1. Ambil 1/2 sdt kaldu jamur
1. Sediakan 100 ml air
1. Sediakan 5 sdm minyak untuk menumis
1. Ambil  Bumbu halus:
1. Sediakan 5 bh cabe merah keriting
1. Ambil 3 bh cabe rawit
1. Ambil 3 bh bawang merah
1. Gunakan 2 bh bawang putih
1. Ambil 2 bh kemiri sangrai




<!--inarticleads2-->

##### Cara membuat Babat Gongso Semarang:

1. Slow cooker babat selama 6 jam atau sampai empuk. Bisa di presto, rebus/ungkep. Potong babat sesuai selera. Ulek/ blender bumbu halus, sisihkan.
1. Tumis bawang merah sampai matang. Tambahkan bumbu halus, daun jeruk dan daun salam, masak sampai layu dan harum. Masukkan babat aduk rata, tambahkan gula garam kecap dan kaldu jamur.
1. Tambahkan air, agar bumbu tidak lengket dan gosong, koreksi rasa. Masak sampai bumbu meresap dan air surut. Sajikan dengan nasi hangat.




Gimana nih? Mudah bukan? Itulah cara membuat babat gongso semarang yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
