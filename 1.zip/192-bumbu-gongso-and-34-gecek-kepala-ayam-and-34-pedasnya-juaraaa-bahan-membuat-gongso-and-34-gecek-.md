---
description: "Bumbu Gongso &amp;#34;Gecek Kepala Ayam&amp;#34; pedasnya juaraaa😉 | Bahan Membuat Gongso &amp;#34;Gecek Kepala Ayam&amp;#34; pedasnya juaraaa😉 Yang Sedap"
title: "Bumbu Gongso &amp;#34;Gecek Kepala Ayam&amp;#34; pedasnya juaraaa😉 | Bahan Membuat Gongso &amp;#34;Gecek Kepala Ayam&amp;#34; pedasnya juaraaa😉 Yang Sedap"
slug: 192-bumbu-gongso-and-34-gecek-kepala-ayam-and-34-pedasnya-juaraaa-bahan-membuat-gongso-and-34-gecek-kepala-ayam-and-34-pedasnya-juaraaa-yang-sedap
date: 2020-10-07T08:25:29.901Z
image: https://img-global.cpcdn.com/recipes/ff17e7030943d795/751x532cq70/gongso-gecek-kepala-ayam-pedasnya-juaraaa😉-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ff17e7030943d795/751x532cq70/gongso-gecek-kepala-ayam-pedasnya-juaraaa😉-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ff17e7030943d795/751x532cq70/gongso-gecek-kepala-ayam-pedasnya-juaraaa😉-foto-resep-utama.jpg
author: Dylan Willis
ratingvalue: 4.3
reviewcount: 5
recipeingredient:
- "2 kepala ayam"
- "5 siung bawang putih"
- "4 siung bawang merah"
- "secukupnya Kunyit"
- "1 butir kemiri"
- " Cabe rawit merah secukupnya kalau aku suka pedas aku kasih 30 biji"
- "secukupnya Garam"
- "secukupnya Gula pasir"
- " Kecap kental manis"
- "secukupnya Penyedap rasa"
- " Minyak goreng"
recipeinstructions:
- "Cuci kepala ayam hingga bersih. Haluskan bumbu untuk menggoreng kepala ayam (2 siung bawang putih, kunyit, garam)"
- "Campurkan bumbu yg telah dihaluskan bersama kepala ayam. diamkan kira-kira 10 menit agar bumbu meresap. lalu goreng kepala ayam"
- "Haluskan bumbu untuk geceknya (3 siung bawang putih, 4 siung bawang merah, 1 butir kemiri, cabai rawit)"
- "Potong kepala ayam kira-kira 1 sampai 1 1/2 cm,"
- "Proses memasaknya nih: nyalakan kompor, siapkan wajan dengan minyak goreng.. setelah minyak panas masukan bumbu yang telah di haluskan masak hingga bumbu beraroma😍"
- "Langkah berikutnya.. masukan potongan kepala ayam yg telah di goreng kedalam wajan, tambahkan garam, gula dan penyedap rasa, aduk terus.. lalu tambahkan sedikit kecap kental manis, adukk hingga merata."
- "Selesai..... dan sajikan 😊😍😙"
categories:
- Resep
tags:
- gongso
- gecek
- kepala

katakunci: gongso gecek kepala 
nutrition: 252 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dessert

---


![Gongso &#34;Gecek Kepala Ayam&#34; pedasnya juaraaa😉](https://img-global.cpcdn.com/recipes/ff17e7030943d795/751x532cq70/gongso-gecek-kepala-ayam-pedasnya-juaraaa😉-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep gongso &#34;gecek kepala ayam&#34; pedasnya juaraaa😉 yang Enak Dan Lezat? Cara menyiapkannya memang tidak susah dan tidak juga mudah. andaikata salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso &#34;gecek kepala ayam&#34; pedasnya juaraaa😉 yang enak harusnya sih memiliki aroma dan rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso &#34;gecek kepala ayam&#34; pedasnya juaraaa😉, mulai dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan gongso &#34;gecek kepala ayam&#34; pedasnya juaraaa😉 yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan spesial.


Di bawah ini ada beberapa cara mudah dan praktis untuk membuat gongso &#34;gecek kepala ayam&#34; pedasnya juaraaa😉 yang siap dikreasikan. Anda bisa membuat Gongso &#34;Gecek Kepala Ayam&#34; pedasnya juaraaa😉 memakai 11 jenis bahan dan 7 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Gongso &#34;Gecek Kepala Ayam&#34; pedasnya juaraaa😉:

1. Gunakan 2 kepala ayam
1. Ambil 5 siung bawang putih
1. Sediakan 4 siung bawang merah
1. Ambil secukupnya Kunyit
1. Gunakan 1 butir kemiri
1. Gunakan  Cabe rawit merah secukupnya (kalau aku suka pedas aku kasih 30 biji)
1. Gunakan secukupnya Garam
1. Gunakan secukupnya Gula pasir
1. Siapkan  Kecap kental manis
1. Siapkan secukupnya Penyedap rasa
1. Ambil  Minyak goreng




<!--inarticleads2-->

##### Cara menyiapkan Gongso &#34;Gecek Kepala Ayam&#34; pedasnya juaraaa😉:

1. Cuci kepala ayam hingga bersih. Haluskan bumbu untuk menggoreng kepala ayam (2 siung bawang putih, kunyit, garam)
1. Campurkan bumbu yg telah dihaluskan bersama kepala ayam. diamkan kira-kira 10 menit agar bumbu meresap. lalu goreng kepala ayam
1. Haluskan bumbu untuk geceknya (3 siung bawang putih, 4 siung bawang merah, 1 butir kemiri, cabai rawit)
1. Potong kepala ayam kira-kira 1 sampai 1 1/2 cm,
1. Proses memasaknya nih: nyalakan kompor, siapkan wajan dengan minyak goreng.. setelah minyak panas masukan bumbu yang telah di haluskan masak hingga bumbu beraroma😍
1. Langkah berikutnya.. masukan potongan kepala ayam yg telah di goreng kedalam wajan, tambahkan garam, gula dan penyedap rasa, aduk terus.. lalu tambahkan sedikit kecap kental manis, adukk hingga merata.
1. Selesai..... dan sajikan 😊😍😙




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Harapan kami, olahan Gongso &#34;Gecek Kepala Ayam&#34; pedasnya juaraaa😉 yang mudah di atas dapat membantu Anda menyiapkan makanan yang menarik untuk keluarga/teman maupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
