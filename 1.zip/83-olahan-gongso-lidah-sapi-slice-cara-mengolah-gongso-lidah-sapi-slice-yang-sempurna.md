---
description: "Olahan Gongso Lidah Sapi Slice | Cara Mengolah Gongso Lidah Sapi Slice Yang Sempurna"
title: "Olahan Gongso Lidah Sapi Slice | Cara Mengolah Gongso Lidah Sapi Slice Yang Sempurna"
slug: 83-olahan-gongso-lidah-sapi-slice-cara-mengolah-gongso-lidah-sapi-slice-yang-sempurna
date: 2020-09-19T22:22:23.282Z
image: https://img-global.cpcdn.com/recipes/0467612dd0353347/751x532cq70/gongso-lidah-sapi-slice-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0467612dd0353347/751x532cq70/gongso-lidah-sapi-slice-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0467612dd0353347/751x532cq70/gongso-lidah-sapi-slice-foto-resep-utama.jpg
author: Vera Robinson
ratingvalue: 3.3
reviewcount: 7
recipeingredient:
- "100 gram lidah sapi slice"
- "1/2 sdt kecap manis untuk marinasi"
- "2 siung bawang merah"
- "1 siung bawang putih"
- "1 buah cabe ijo besar ukuran menyesuaikan bahan lidah sapi"
- "1 buah cabe merah besar ukuran menyesuaikan bahan lidah sapi"
- "1 sdm kecap manis"
- "1/2 sdm saus tiram"
- "1/2 sdt kecap asin untuk mengganti garam"
- "1/2 sdt kaldu bubuk"
- "1/4 sdt merica hitam bubuk tambahan dari saya"
- "50-100 ml air"
recipeinstructions:
- "Rendam dan marinasi lidah dengan kecap manis, diamkan si kulkas selama 30-60 menit sebelum diolah"
- "Iris cabe dan bawang, tumis cabe terlebih dahulu, masukkan bawang tumis hingga mulai layu, tambahkan air"
- "Masukkan lidah sapi aduk rata, beri kecap manis, saus tiram dan kecap asin, kaldu dan lada lalu tutup wajan selama 5 menit masak hingga air mulai menyusut"
- "Buka tutup wajan, teruskan memasak hingga lidah sapi empuk dan kuah mengental, koreksi rasa, matikan kompor, siap disajikan"
categories:
- Resep
tags:
- gongso
- lidah
- sapi

katakunci: gongso lidah sapi 
nutrition: 271 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dessert

---


![Gongso Lidah Sapi Slice](https://img-global.cpcdn.com/recipes/0467612dd0353347/751x532cq70/gongso-lidah-sapi-slice-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep gongso lidah sapi slice yang Bikin Ngiler? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. seumpama keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gongso lidah sapi slice yang enak seharusnya punya aroma dan rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso lidah sapi slice, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tidak usah pusing jika mau menyiapkan gongso lidah sapi slice yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan spesial.




Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah gongso lidah sapi slice yang siap dikreasikan. Anda bisa menyiapkan Gongso Lidah Sapi Slice memakai 12 bahan dan 4 tahap pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Gongso Lidah Sapi Slice:

1. Sediakan 100 gram lidah sapi slice
1. Sediakan 1/2 sdt kecap manis untuk marinasi
1. Gunakan 2 siung bawang merah
1. Gunakan 1 siung bawang putih
1. Siapkan 1 buah cabe ijo besar, ukuran menyesuaikan bahan lidah sapi
1. Sediakan 1 buah cabe merah besar, ukuran menyesuaikan bahan lidah sapi
1. Sediakan 1 sdm kecap manis
1. Sediakan 1/2 sdm saus tiram
1. Ambil 1/2 sdt kecap asin (untuk mengganti garam)
1. Ambil 1/2 sdt kaldu bubuk
1. Siapkan 1/4 sdt merica hitam bubuk (tambahan dari saya)
1. Ambil 50-100 ml air




<!--inarticleads2-->

##### Cara membuat Gongso Lidah Sapi Slice:

1. Rendam dan marinasi lidah dengan kecap manis, diamkan si kulkas selama 30-60 menit sebelum diolah
1. Iris cabe dan bawang, tumis cabe terlebih dahulu, masukkan bawang tumis hingga mulai layu, tambahkan air
1. Masukkan lidah sapi aduk rata, beri kecap manis, saus tiram dan kecap asin, kaldu dan lada lalu tutup wajan selama 5 menit masak hingga air mulai menyusut
1. Buka tutup wajan, teruskan memasak hingga lidah sapi empuk dan kuah mengental, koreksi rasa, matikan kompor, siap disajikan




Bagaimana? Gampang kan? Itulah cara membuat gongso lidah sapi slice yang bisa Anda praktikkan di rumah. Selamat mencoba!
