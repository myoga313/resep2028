---
description: "Bumbu Gongso ayam pedas | Langkah Membuat Gongso ayam pedas Yang Sempurna"
title: "Bumbu Gongso ayam pedas | Langkah Membuat Gongso ayam pedas Yang Sempurna"
slug: 180-bumbu-gongso-ayam-pedas-langkah-membuat-gongso-ayam-pedas-yang-sempurna
date: 2020-12-04T14:20:29.532Z
image: https://img-global.cpcdn.com/recipes/dea197fcaffbc521/751x532cq70/gongso-ayam-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dea197fcaffbc521/751x532cq70/gongso-ayam-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dea197fcaffbc521/751x532cq70/gongso-ayam-pedas-foto-resep-utama.jpg
author: Carolyn Chapman
ratingvalue: 3.3
reviewcount: 14
recipeingredient:
- "1/2 kg ayam di fillet"
- "3 siung bawang putih"
- "3 siung bawang merah"
- "2 butir kemiri"
- "2 biji cabe rawet merah"
- "1 buah tomat ukuran kecil"
- "3 sdmsaus tiram"
- "2 sdmkecap manis"
- "1 sdmminyak goreng"
- "Sedikit merica bubuk"
- "1 buah timun"
- "100 mlair"
- "1/2 sdtgulapadir"
- "1 sdtgaram"
recipeinstructions:
- "Haluskan bawang putih,bawang merah,kemiri."
- "Panaskan minyak lalu tubis bumbu halus sampai harum tambahkan air, merica bubuk, garam, gula, saos tiram di aduk sampai merata."
- "Kemudian masukan ayam, diamkan 10 menit sampai ayam lunak dan matang."
- "Setelah ayam lunak masukan cabe rawet dan tomat yg telah diiris memanjang. Diaduk perlahan"
- "Jika ayam sudah lunak dan air sudah agak mengering di cicipi dulu..kira2..apa yg kurang sesuai selera."
- "Setelah dirasa pass,matikan api,lalu angkat dan hidangkan bersama ketimun diiris dadu."
- "Selamat mencoba..."
categories:
- Resep
tags:
- gongso
- ayam
- pedas

katakunci: gongso ayam pedas 
nutrition: 172 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Lunch

---


![Gongso ayam pedas](https://img-global.cpcdn.com/recipes/dea197fcaffbc521/751x532cq70/gongso-ayam-pedas-foto-resep-utama.jpg)

Lagi mencari inspirasi resep gongso ayam pedas yang Bisa Manjain Lidah? Cara Bikinnya memang tidak terlalu sulit namun tidak gampang juga. jikalau salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gongso ayam pedas yang enak harusnya sih punya aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ayam pedas, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tidak usah pusing kalau ingin menyiapkan gongso ayam pedas yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian spesial.

Lihat juga resep Gongso Ayam ala Semarangan enak lainnya. Terinspirasi dari menu babat gongso, kali ini kami memasak ayam gongso. Gongso Ayam Super Pedas Indo Street Food.


Berikut ini ada beberapa cara mudah dan praktis dalam mengolah gongso ayam pedas yang siap dikreasikan. Anda dapat membuat Gongso ayam pedas memakai 14 bahan dan 7 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Gongso ayam pedas:

1. Sediakan 1/2 kg ayam di fillet
1. Ambil 3 siung bawang putih
1. Sediakan 3 siung bawang merah
1. Siapkan 2 butir kemiri
1. Siapkan 2 biji cabe rawet merah
1. Sediakan 1 buah tomat ukuran kecil
1. Gunakan 3 sdm.saus tiram
1. Gunakan 2 sdm.kecap manis
1. Ambil 1 sdm.minyak goreng
1. Siapkan Sedikit merica bubuk
1. Gunakan 1 buah timun
1. Gunakan 100 ml.air
1. Siapkan 1/2 sdt,gula.padir
1. Gunakan 1 sdt.garam


Yuk segera hidangkan masakan ayam pedas untuk keluarga. Lihat deretan resep yang brilio.net rangkum dari berbagai. Resep Gongso Ayam Super Endes Ala Ruzuqi Resep. Cara Mudah Membuat Babat Iso Gongso Pedas Menu Pilihan Saat Musim Hujan Tiba.. 

<!--inarticleads2-->

##### Cara menyiapkan Gongso ayam pedas:

1. Haluskan bawang putih,bawang merah,kemiri.
1. Panaskan minyak lalu tubis bumbu halus sampai harum tambahkan air, merica bubuk, garam, gula, saos tiram di aduk sampai merata.
1. Kemudian masukan ayam, diamkan 10 menit sampai ayam lunak dan matang.
1. Setelah ayam lunak masukan cabe rawet dan tomat yg telah diiris memanjang. Diaduk perlahan
1. Jika ayam sudah lunak dan air sudah agak mengering di cicipi dulu..kira2..apa yg kurang sesuai selera.
1. Setelah dirasa pass,matikan api,lalu angkat dan hidangkan bersama ketimun diiris dadu.
1. Selamat mencoba...


Nah mau ayam bakar madu yang manis kayak Mister, atau Gongso Ayam pedas sepedas kenyataan hidup? Hahaha becanda ding, nah lets enjoy our life and our day with special menu from Waroeng Abol. Indonesia memiliki beragam olahan ayam yang lezat. Setiap daerah memiliki menu ayam andalannya, salah Dalam Bahasa Jawa, gongso berarti ditumis. Meski berasal dari Semarang, kamu gak harus. 

Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Harapan kami, olahan Gongso ayam pedas yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman maupun menjadi inspirasi bagi Anda yang berkeinginan untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
