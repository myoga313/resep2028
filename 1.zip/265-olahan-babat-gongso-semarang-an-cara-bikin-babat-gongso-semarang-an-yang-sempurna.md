---
description: "Olahan Babat gongso Semarang-an | Cara Bikin Babat gongso Semarang-an Yang Sempurna"
title: "Olahan Babat gongso Semarang-an | Cara Bikin Babat gongso Semarang-an Yang Sempurna"
slug: 265-olahan-babat-gongso-semarang-an-cara-bikin-babat-gongso-semarang-an-yang-sempurna
date: 2020-09-10T17:33:33.389Z
image: https://img-global.cpcdn.com/recipes/20664d61657e5bd6/751x532cq70/babat-gongso-semarang-an-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/20664d61657e5bd6/751x532cq70/babat-gongso-semarang-an-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/20664d61657e5bd6/751x532cq70/babat-gongso-semarang-an-foto-resep-utama.jpg
author: Glenn Ward
ratingvalue: 3.4
reviewcount: 3
recipeingredient:
- " Babat Sapi lupa gak ditimbang"
- " tomat potong2"
- " Gula merah garam penyedap"
- " Kecap manis sesuai selera"
- " Air"
- " Minyak untuk menumis"
- " Bumbu halus"
- " Bawang Merah"
- " bawang putih"
- " cabai keriting"
- " cabai merah setan"
- " kemiri"
- " Bumbu cemplung"
- " Daun seregeprek"
- " Daun jeruk"
- " Daun salam"
- " Lengkuas geprek"
- " Jahe geprek"
recipeinstructions:
- "Cuci bersih babat, kemudian rebus dengan metode 5 30 7, setelah empuk potong2 sesuai selera"
- "Panaskan minyak untuk menumis. Tumis bumbu halus dan bumbu cemplung hingga harum. Masukkan babat yang sudah direbus tadi. Setelah itu beri sedikit air (jangan banyak2, klw bahasa jawanya nyemek2 😅)"
- "Masukkan garam, gula jawa, penyedap dan kecap manis,,,rebus sebentar sampai bumbu meresap ke dalam babat."
- "Setelah mendidih, angkat, siap disajikan."
categories:
- Resep
tags:
- babat
- gongso
- semarangan

katakunci: babat gongso semarangan 
nutrition: 184 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Lunch

---


![Babat gongso Semarang-an](https://img-global.cpcdn.com/recipes/20664d61657e5bd6/751x532cq70/babat-gongso-semarang-an-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep babat gongso semarang-an yang Mudah Dan Praktis? Cara menyiapkannya memang susah-susah gampang. seumpama keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal babat gongso semarang-an yang enak harusnya sih punya aroma dan rasa yang bisa memancing selera kita.

Lihat juga resep Babat Gongso ala Semarang enak lainnya. Babat Gongso is a legendary dish from Semarang and Solo, Central Java which is increasingly rare to be found. You may take a look my old recipe of Soto Babat.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso semarang-an, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tidak usah pusing jika mau menyiapkan babat gongso semarang-an enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.


Di bawah ini ada beberapa tips dan trik praktis dalam mengolah babat gongso semarang-an yang siap dikreasikan. Anda bisa menyiapkan Babat gongso Semarang-an menggunakan 18 bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Babat gongso Semarang-an:

1. Siapkan  Babat Sapi (lupa gak ditimbang)
1. Siapkan  tomat (potong2)
1. Sediakan  Gula merah, garam, penyedap
1. Siapkan  Kecap manis (sesuai selera)
1. Gunakan  Air
1. Siapkan  Minyak (untuk menumis)
1. Gunakan  Bumbu halus
1. Siapkan  Bawang Merah
1. Sediakan  bawang putih
1. Sediakan  cabai keriting
1. Sediakan  cabai merah setan
1. Gunakan  kemiri
1. Sediakan  Bumbu cemplung
1. Gunakan  Daun sere(geprek)
1. Sediakan  Daun jeruk
1. Sediakan  Daun salam
1. Ambil  Lengkuas geprek
1. Siapkan  Jahe geprek


Kalau mau pedas, tambah takaran cabai. KOMPAS.com/Nabilla TashandraBabat gongso, salah satu menu andalan di Nasi Goreng Babat Pak Karmin di Jalan Pemuda, Semarang, yang tak pernah sepi pembeli. Babat Gongso Terenak di Semarang Super Pedas Manis Mantap Jiwa. Babat gongso pak sabar manis TAPI enak kuliner semarang. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Babat gongso Semarang-an:

1. Cuci bersih babat, kemudian rebus dengan metode 5 30 7, setelah empuk potong2 sesuai selera
1. Panaskan minyak untuk menumis. Tumis bumbu halus dan bumbu cemplung hingga harum. Masukkan babat yang sudah direbus tadi. Setelah itu beri sedikit air (jangan banyak2, klw bahasa jawanya nyemek2 😅)
1. Masukkan garam, gula jawa, penyedap dan kecap manis,,,rebus sebentar sampai bumbu meresap ke dalam babat.
1. Setelah mendidih, angkat, siap disajikan.




Bagaimana? Mudah bukan? Itulah cara membuat babat gongso semarang-an yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
