---
description: "Resep Gongso Ayam Pedass | Cara Buat Gongso Ayam Pedass Yang Paling Enak"
title: "Resep Gongso Ayam Pedass | Cara Buat Gongso Ayam Pedass Yang Paling Enak"
slug: 187-resep-gongso-ayam-pedass-cara-buat-gongso-ayam-pedass-yang-paling-enak
date: 2020-11-01T06:00:58.756Z
image: https://img-global.cpcdn.com/recipes/a2c4cb56b1b9bbab/751x532cq70/gongso-ayam-pedass-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a2c4cb56b1b9bbab/751x532cq70/gongso-ayam-pedass-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a2c4cb56b1b9bbab/751x532cq70/gongso-ayam-pedass-foto-resep-utama.jpg
author: Terry Ortega
ratingvalue: 4.6
reviewcount: 10
recipeingredient:
- "1/2 kg ayam potong boleh ayam kampung"
- "3 siung bawang putih"
- "2 siung bawang merah"
- "1 buah bawang bombay ukuran sedang"
- "1 sdm blueband"
- "1/2 buah tomat besar"
- "5 buah cabe merah keriting"
- "5 buah cabe hijau keriting"
- "6 buah cabe rawit selera pedas bisa ditambahkan"
- "500 ml kaldu ayam"
- "secukupnya saus tiram garam gula pasir kecap manis"
recipeinstructions:
- "Siapkan semua bahan bahan diatas"
- "Rebus ayam sampai matang dan air agak menyusut, sisa rebusan ayam untuk kaldu."
- "Sambil menunggu rebusan ayam, kita siapkan bumbu2 di potong-potong dan di iris2 tipis."
- "Kemudian siapkan wajan dengan sedikit minyak dan blueband. masukkan bawang putih, bawang merah, tumis sampai layu dan harum, selanjutnya tambahkan bawang bombay. tumis sebentar sampai bawang bombay layu dan harum."
- "Setelah itu tambahkan air kaldu tadi sisa rebusan ayam. masukkan bumbu bumbu yang tersisa, garam, gula, lada bubuk, gula pasir, kaldu bubuk. masak sampai air mendidih."
- "Jika sudah mendidih, masukkan daging ayam yang sudah direbus tadi. masak hingga bumbu agak meresap"
- "Masak ayam sampai bumbu meresap. sisakan kuah gongso secukupnya sesuai selera. setelah matang siapkan sajikan Gongso Ayam Pedass untuk keluarga🤗😍"
categories:
- Resep
tags:
- gongso
- ayam
- pedass

katakunci: gongso ayam pedass 
nutrition: 218 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Dessert

---


![Gongso Ayam Pedass](https://img-global.cpcdn.com/recipes/a2c4cb56b1b9bbab/751x532cq70/gongso-ayam-pedass-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep gongso ayam pedass yang Sempurna? Cara membuatnya memang susah-susah gampang. jikalau keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso ayam pedass yang enak selayaknya mempunyai aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ayam pedass, mulai dari jenis bahan, kemudian pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan gongso ayam pedass enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.




Nah, kali ini kita coba, yuk, variasikan gongso ayam pedass sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Gongso Ayam Pedass memakai 11 jenis bahan dan 7 tahap pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Gongso Ayam Pedass:

1. Sediakan 1/2 kg ayam potong (boleh ayam kampung)
1. Gunakan 3 siung bawang putih
1. Sediakan 2 siung bawang merah
1. Sediakan 1 buah bawang bombay ukuran sedang
1. Gunakan 1 sdm blueband
1. Sediakan 1/2 buah tomat besar
1. Ambil 5 buah cabe merah keriting
1. Siapkan 5 buah cabe hijau keriting
1. Ambil 6 buah cabe rawit (selera pedas bisa ditambahkan)
1. Ambil 500 ml kaldu ayam
1. Siapkan secukupnya saus tiram, garam, gula pasir, kecap manis




<!--inarticleads2-->

##### Cara menyiapkan Gongso Ayam Pedass:

1. Siapkan semua bahan bahan diatas
1. Rebus ayam sampai matang dan air agak menyusut, sisa rebusan ayam untuk kaldu.
1. Sambil menunggu rebusan ayam, kita siapkan bumbu2 di potong-potong dan di iris2 tipis.
1. Kemudian siapkan wajan dengan sedikit minyak dan blueband. masukkan bawang putih, bawang merah, tumis sampai layu dan harum, selanjutnya tambahkan bawang bombay. tumis sebentar sampai bawang bombay layu dan harum.
1. Setelah itu tambahkan air kaldu tadi sisa rebusan ayam. masukkan bumbu bumbu yang tersisa, garam, gula, lada bubuk, gula pasir, kaldu bubuk. masak sampai air mendidih.
1. Jika sudah mendidih, masukkan daging ayam yang sudah direbus tadi. masak hingga bumbu agak meresap
1. Masak ayam sampai bumbu meresap. sisakan kuah gongso secukupnya sesuai selera. setelah matang siapkan sajikan Gongso Ayam Pedass untuk keluarga🤗😍




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Besar harapan kami, olahan Gongso Ayam Pedass yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman ataupun menjadi ide dalam berjualan makanan. Selamat mencoba!
