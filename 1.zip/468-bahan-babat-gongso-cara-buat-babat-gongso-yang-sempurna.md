---
description: "Bahan Babat Gongso | Cara Buat Babat Gongso Yang Sempurna"
title: "Bahan Babat Gongso | Cara Buat Babat Gongso Yang Sempurna"
slug: 468-bahan-babat-gongso-cara-buat-babat-gongso-yang-sempurna
date: 2020-11-25T05:18:53.099Z
image: https://img-global.cpcdn.com/recipes/4651c7d27a7911bc/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4651c7d27a7911bc/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4651c7d27a7911bc/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Mollie Parsons
ratingvalue: 5
reviewcount: 9
recipeingredient:
- "500 gram babat potong kecil saya ditambah tetelan 250 gram"
- "1 keping gula merah 30 gram iris"
- "1 buah tomat"
- "7 buah cabai rawit merah"
- "5 sendok makan kecap manis"
- " Bumbu Halus"
- "10 siung bawang merah"
- "4 siung bawang putih"
- "4 butir kemiri sangrai"
- "5 buah cabai keriting merah"
- "1/2 sendok teh ketumbar sangrai"
- " Bumbu Utuh"
- "2 batang sereh"
- "2 helai daun salam"
- "4 helai daun jeruk"
- "2 ruas lengkuas geprek"
recipeinstructions:
- "Blansir babat dan tetelan. Presto selama 30 menit hingga empuk. Sisihkan."
- "Haluskan bumbu. Tumis hingga wangi bersama bumbu utuh."
- "Masukkan babat, gula merah, kecap, garam, dan gula. Tambahkan air."
- "Masak hingga air menyusut dan bumbu meresap. Masukkan cabai rawit utuh dan irisan tomat."
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 213 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Lunch

---


![Babat Gongso](https://img-global.cpcdn.com/recipes/4651c7d27a7911bc/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Lagi mencari inspirasi resep babat gongso yang Lezat Sekali? Cara membuatnya memang susah-susah gampang. andaikata salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal babat gongso yang enak selayaknya punya aroma dan cita rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso, pertama dari jenis bahan, lalu pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tidak usah pusing kalau ingin menyiapkan babat gongso yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.




Berikut ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah babat gongso yang siap dikreasikan. Anda dapat menyiapkan Babat Gongso menggunakan 16 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Babat Gongso:

1. Ambil 500 gram babat potong kecil (saya ditambah tetelan 250 gram)
1. Siapkan 1 keping gula merah (30 gram) iris
1. Siapkan 1 buah tomat
1. Gunakan 7 buah cabai rawit merah
1. Sediakan 5 sendok makan kecap manis
1. Ambil  Bumbu Halus
1. Sediakan 10 siung bawang merah
1. Gunakan 4 siung bawang putih
1. Sediakan 4 butir kemiri sangrai
1. Ambil 5 buah cabai keriting merah
1. Gunakan 1/2 sendok teh ketumbar sangrai
1. Siapkan  Bumbu Utuh
1. Ambil 2 batang sereh
1. Siapkan 2 helai daun salam
1. Sediakan 4 helai daun jeruk
1. Ambil 2 ruas lengkuas geprek




<!--inarticleads2-->

##### Cara menyiapkan Babat Gongso:

1. Blansir babat dan tetelan. Presto selama 30 menit hingga empuk. Sisihkan.
1. Haluskan bumbu. Tumis hingga wangi bersama bumbu utuh.
1. Masukkan babat, gula merah, kecap, garam, dan gula. Tambahkan air.
1. Masak hingga air menyusut dan bumbu meresap. Masukkan cabai rawit utuh dan irisan tomat.




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Harapan kami, olahan Babat Gongso yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi ide bagi Anda yang berkeinginan untuk berbisnis kuliner. Selamat mencoba!
