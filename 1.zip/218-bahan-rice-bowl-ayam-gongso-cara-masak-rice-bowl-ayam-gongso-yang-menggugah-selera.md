---
description: "Bahan Rice Bowl Ayam Gongso | Cara Masak Rice Bowl Ayam Gongso Yang Menggugah Selera"
title: "Bahan Rice Bowl Ayam Gongso | Cara Masak Rice Bowl Ayam Gongso Yang Menggugah Selera"
slug: 218-bahan-rice-bowl-ayam-gongso-cara-masak-rice-bowl-ayam-gongso-yang-menggugah-selera
date: 2020-09-30T06:59:31.984Z
image: https://img-global.cpcdn.com/recipes/490db79f45b52317/751x532cq70/rice-bowl-ayam-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/490db79f45b52317/751x532cq70/rice-bowl-ayam-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/490db79f45b52317/751x532cq70/rice-bowl-ayam-gongso-foto-resep-utama.jpg
author: Elsie Rodriquez
ratingvalue: 4.1
reviewcount: 11
recipeingredient:
- " dada ayam"
- " kol potongpotong"
- " tomat kecil potongpotong"
- " cabe rawit utuh sesuai selera"
- " cabe merah iris serong"
- " Nasi putih"
- " telur ceplok 12 matang"
- " daun salam"
- " lengkuas geprek"
- " lada bubuk"
- " garam"
- " kaldu jamurpenyedap"
- " kecap manis"
- " air"
- " Minyak goreng"
- " Bumbu halus"
- " bawang putih"
- " bawang merah"
- " kemiri"
- " cabe rawit"
recipeinstructions:
- "Bersihkan dada ayam, rebus selama 10 menit, angkat dan tiriskan, potong dadu/suwir-suwir, sisihkan."
- "Tumis bumbu halus sampai wangi, tambahkan salam dan lengkuas, masukkan ayam suwir aduk, bumbui kecap, garam, lada dan penyedap."
- "Tuang air, masukkan kol, cabe rawit dan tomat aduk rata, masak sampai bumbu meresap dan kuah menyusut. Koreksi rasa."
- "Sajikan dengan nasi hangat dan telur ceplok 1/2 matang. Selamat menikmati. 😊"
categories:
- Resep
tags:
- rice
- bowl
- ayam

katakunci: rice bowl ayam 
nutrition: 285 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Dinner

---


![Rice Bowl Ayam Gongso](https://img-global.cpcdn.com/recipes/490db79f45b52317/751x532cq70/rice-bowl-ayam-gongso-foto-resep-utama.jpg)

Lagi mencari ide resep rice bowl ayam gongso yang Sedap? Cara menyiapkannya memang susah-susah gampang. jikalau salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal rice bowl ayam gongso yang enak selayaknya punya aroma dan cita rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari rice bowl ayam gongso, mulai dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tidak usah pusing jika ingin menyiapkan rice bowl ayam gongso yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.


Berikut ini ada beberapa tips dan trik praktis untuk membuat rice bowl ayam gongso yang siap dikreasikan. Anda bisa membuat Rice Bowl Ayam Gongso menggunakan 20 jenis bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Rice Bowl Ayam Gongso:

1. Gunakan  dada ayam
1. Ambil  kol, potong-potong
1. Sediakan  tomat kecil, potong-potong
1. Gunakan  cabe rawit utuh (sesuai selera)
1. Sediakan  cabe merah, iris serong
1. Ambil  Nasi putih
1. Ambil  telur ceplok 1/2 matang
1. Ambil  daun salam
1. Siapkan  lengkuas, geprek
1. Sediakan  lada bubuk
1. Siapkan  garam
1. Ambil  kaldu jamur/penyedap
1. Ambil  kecap manis
1. Siapkan  air
1. Gunakan  Minyak goreng
1. Siapkan  Bumbu halus
1. Ambil  bawang putih
1. Ambil  bawang merah
1. Ambil  kemiri
1. Gunakan  cabe rawit




<!--inarticleads2-->

##### Cara membuat Rice Bowl Ayam Gongso:

1. Bersihkan dada ayam, rebus selama 10 menit, angkat dan tiriskan, potong dadu/suwir-suwir, sisihkan.
1. Tumis bumbu halus sampai wangi, tambahkan salam dan lengkuas, masukkan ayam suwir aduk, bumbui kecap, garam, lada dan penyedap.
1. Tuang air, masukkan kol, cabe rawit dan tomat aduk rata, masak sampai bumbu meresap dan kuah menyusut. Koreksi rasa.
1. Sajikan dengan nasi hangat dan telur ceplok 1/2 matang. Selamat menikmati. 😊




Gimana nih? Mudah bukan? Itulah cara membuat rice bowl ayam gongso yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
