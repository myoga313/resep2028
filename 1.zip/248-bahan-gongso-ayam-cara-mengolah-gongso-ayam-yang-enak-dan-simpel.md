---
description: "Bahan Gongso ayam | Cara Mengolah Gongso ayam Yang Enak dan Simpel"
title: "Bahan Gongso ayam | Cara Mengolah Gongso ayam Yang Enak dan Simpel"
slug: 248-bahan-gongso-ayam-cara-mengolah-gongso-ayam-yang-enak-dan-simpel
date: 2020-12-13T09:08:04.395Z
image: https://img-global.cpcdn.com/recipes/ccc474ccba40ac2e/751x532cq70/gongso-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ccc474ccba40ac2e/751x532cq70/gongso-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ccc474ccba40ac2e/751x532cq70/gongso-ayam-foto-resep-utama.jpg
author: Mary Gordon
ratingvalue: 4.8
reviewcount: 5
recipeingredient:
- "300 gram daging ayam suwir"
- "2 butir telur"
- "Secukupnya kol potong"
- "1 buah tomat potong"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "5 buah cabe merah"
- "5 buah cabe rawit"
- "2 butir kemiri"
- "Secukupnya saos sambal"
- "Secukupnya kecap"
- "Secukupnya air"
- " Garam"
recipeinstructions:
- "Haluskan bawang merah, bawang putih, cabe dan kemiri."
- "Tumis bumbu halus sampai matang. Sisihkan ke pinggir wajan. Masukkan telor, orak arik. Campur dengan bumbu halus."
- "Masukkan tomat, kol, ayam suwir. Aduk rata."
- "Tambah garam, saos dan kecap. Aduk. Tambah air, masak hingga matang."
categories:
- Resep
tags:
- gongso
- ayam

katakunci: gongso ayam 
nutrition: 212 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Dinner

---


![Gongso ayam](https://img-global.cpcdn.com/recipes/ccc474ccba40ac2e/751x532cq70/gongso-ayam-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep gongso ayam yang Bikin Ngiler? Cara Buatnya memang susah-susah gampang. seandainya keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal gongso ayam yang enak harusnya sih mempunyai aroma dan cita rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ayam, pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tak perlu pusing jika ingin menyiapkan gongso ayam yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan spesial.


Nah, kali ini kita coba, yuk, buat gongso ayam sendiri di rumah. Tetap berbahan sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Gongso ayam menggunakan 13 bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Gongso ayam:

1. Sediakan 300 gram daging ayam suwir
1. Sediakan 2 butir telur
1. Sediakan Secukupnya kol, potong
1. Siapkan 1 buah tomat, potong
1. Siapkan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Gunakan 5 buah cabe merah
1. Gunakan 5 buah cabe rawit
1. Ambil 2 butir kemiri
1. Sediakan Secukupnya saos sambal
1. Siapkan Secukupnya kecap
1. Ambil Secukupnya air
1. Gunakan  Garam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso ayam:

1. Haluskan bawang merah, bawang putih, cabe dan kemiri.
1. Tumis bumbu halus sampai matang. Sisihkan ke pinggir wajan. Masukkan telor, orak arik. Campur dengan bumbu halus.
1. Masukkan tomat, kol, ayam suwir. Aduk rata.
1. Tambah garam, saos dan kecap. Aduk. Tambah air, masak hingga matang.




Bagaimana? Mudah bukan? Itulah cara membuat gongso ayam yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
