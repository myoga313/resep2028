---
description: "Bahan Gongso Ayam khas Semarang | Bahan Membuat Gongso Ayam khas Semarang Yang Enak dan Simpel"
title: "Bahan Gongso Ayam khas Semarang | Bahan Membuat Gongso Ayam khas Semarang Yang Enak dan Simpel"
slug: 270-bahan-gongso-ayam-khas-semarang-bahan-membuat-gongso-ayam-khas-semarang-yang-enak-dan-simpel
date: 2020-10-16T18:34:43.007Z
image: https://img-global.cpcdn.com/recipes/d29cc9d495b60af5/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d29cc9d495b60af5/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d29cc9d495b60af5/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg
author: Manuel Benson
ratingvalue: 4.9
reviewcount: 5
recipeingredient:
- " ayam bagian paha"
- " bawang bombay iris tipis"
- " cabai rawit"
- " daun salam"
- " lengkuaslaos"
- " kecap manis"
- " garam"
- " lada bubuk"
- " air"
- " minyak goreng untuk menumis"
- " bumbu halus "
- " bawang putih"
- " bawang merah"
- " kemiri"
- " cabai rawit"
- " cabai merah"
recipeinstructions:
- "Siapkan bahan, cuci bersih ayam beri kucuran air jeruk nipis agar menghilangkan bau amis nya. tunggu 10 menit. lalu rebus ayam, masukkan garam secukupnya. rebus ayam sekitar 30-40 menit. setelah itu tiriskan"
- "Haluskan bumbu sesuai resep yg ada. kemudian suwir2 ayam agar di gongso nanti bumbu bisa meresap. dan iris tipis bawang bombay"
- "Ambil wajan/teflon masukkan minyak lalu tumis bawang bombay sampai harum dan kecoklatan, lalu masukkan bumbu halus, daun salam, lengkuas. tumis sampai harum"
- "Masukkan ayam, gongso hingga merata dengan bumbu. masukkan kecap manis, garam, lada, penyedap rasa. masukkan air sedikit demi sedikit, gongso hingga air menyusut, koreksi rasa. dan siap disajikan dengan nasi panas 😋"
categories:
- Resep
tags:
- gongso
- ayam
- khas

katakunci: gongso ayam khas 
nutrition: 205 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Dessert

---


![Gongso Ayam khas Semarang](https://img-global.cpcdn.com/recipes/d29cc9d495b60af5/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg)

Bunda lagi mencari ide resep gongso ayam khas semarang yang Sempurna? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. kalau salah mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal gongso ayam khas semarang yang enak selayaknya memiliki aroma dan cita rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ayam khas semarang, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tak perlu pusing kalau hendak menyiapkan gongso ayam khas semarang yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan spesial.




Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah gongso ayam khas semarang yang siap dikreasikan. Anda dapat menyiapkan Gongso Ayam khas Semarang menggunakan 16 bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Gongso Ayam khas Semarang:

1. Siapkan  ayam, bagian paha
1. Siapkan  bawang bombay, iris tipis
1. Siapkan  cabai rawit
1. Gunakan  daun salam
1. Gunakan  lengkuas/laos
1. Ambil  kecap manis
1. Ambil  garam
1. Sediakan  lada bubuk
1. Sediakan  air
1. Gunakan  minyak goreng untuk menumis
1. Gunakan  bumbu halus :
1. Siapkan  bawang putih
1. Ambil  bawang merah
1. Ambil  kemiri
1. Gunakan  cabai rawit
1. Ambil  cabai merah




<!--inarticleads2-->

##### Cara menyiapkan Gongso Ayam khas Semarang:

1. Siapkan bahan, cuci bersih ayam beri kucuran air jeruk nipis agar menghilangkan bau amis nya. tunggu 10 menit. lalu rebus ayam, masukkan garam secukupnya. rebus ayam sekitar 30-40 menit. setelah itu tiriskan
1. Haluskan bumbu sesuai resep yg ada. kemudian suwir2 ayam agar di gongso nanti bumbu bisa meresap. dan iris tipis bawang bombay
1. Ambil wajan/teflon masukkan minyak lalu tumis bawang bombay sampai harum dan kecoklatan, lalu masukkan bumbu halus, daun salam, lengkuas. tumis sampai harum
1. Masukkan ayam, gongso hingga merata dengan bumbu. masukkan kecap manis, garam, lada, penyedap rasa. masukkan air sedikit demi sedikit, gongso hingga air menyusut, koreksi rasa. dan siap disajikan dengan nasi panas 😋




Gimana nih? Mudah bukan? Itulah cara membuat gongso ayam khas semarang yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
