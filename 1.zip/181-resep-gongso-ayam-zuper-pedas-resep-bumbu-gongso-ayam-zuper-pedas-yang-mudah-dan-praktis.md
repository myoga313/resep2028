---
description: "Resep Gongso Ayam Zuper Pedas | Resep Bumbu Gongso Ayam Zuper Pedas Yang Mudah Dan Praktis"
title: "Resep Gongso Ayam Zuper Pedas | Resep Bumbu Gongso Ayam Zuper Pedas Yang Mudah Dan Praktis"
slug: 181-resep-gongso-ayam-zuper-pedas-resep-bumbu-gongso-ayam-zuper-pedas-yang-mudah-dan-praktis
date: 2020-07-24T23:04:19.108Z
image: https://img-global.cpcdn.com/recipes/2e2c35e3e63e7ade/751x532cq70/gongso-ayam-zuper-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2e2c35e3e63e7ade/751x532cq70/gongso-ayam-zuper-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2e2c35e3e63e7ade/751x532cq70/gongso-ayam-zuper-pedas-foto-resep-utama.jpg
author: Randy Burgess
ratingvalue: 4
reviewcount: 6
recipeingredient:
- "1 potong dada ayampaha atas yg suka tulang potong kotak kecil"
- "1/4 buah kolkubis"
- "1 ruas jahe geprek"
- "1 ruas lengkuas geprek"
- "1 lembar daun salam dan jeruk"
- "Secukupnya gula kaldu jamur garam dan merica bubuk"
- "5 buah cabai rawit hijau potong kasar atau utuh optional"
- "3-5 sdm kecap manis"
- " Bumbu halus"
- "2 siung bawang putih"
- "2 siung bawang merah"
- "7 cabai rawit merah 3 cabai merah keriting"
- "Sedikit minyak untuk menumis"
- "1 gelas air"
recipeinstructions:
- "Tumis bumbu halus sampai harum, kemudian masukkan jahe, lengkuas, daun jeruk, dan daun salam, aduk aduk sampai daun layu"
- "Masukkan ayam tumis sampai setengah matang, bumbui dengan gula, garam/kaldu jamur, dan kecap manis, kemudian beri air"
- "Setelah mendidih tambahkan kol dan cabai, karena suka pedes jadi masih sya tambah cabai kalo gak suka porsi cabai bisa dikurangi dan tidak perlu ditambah cabai rawit ijo"
- "Masak hingga air meresap dan sajikan"
categories:
- Resep
tags:
- gongso
- ayam
- zuper

katakunci: gongso ayam zuper 
nutrition: 300 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Dessert

---


![Gongso Ayam Zuper Pedas](https://img-global.cpcdn.com/recipes/2e2c35e3e63e7ade/751x532cq70/gongso-ayam-zuper-pedas-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep gongso ayam zuper pedas yang Enak Dan Mudah? Cara menyiapkannya memang tidak susah dan tidak juga mudah. apabila keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso ayam zuper pedas yang enak harusnya sih punya aroma dan cita rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ayam zuper pedas, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tidak usah pusing jika ingin menyiapkan gongso ayam zuper pedas yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan spesial.


Nah, kali ini kita coba, yuk, buat gongso ayam zuper pedas sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Gongso Ayam Zuper Pedas memakai 14 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Gongso Ayam Zuper Pedas:

1. Gunakan 1 potong dada ayam/paha atas (yg suka tulang) potong kotak kecil
1. Sediakan 1/4 buah kol/kubis
1. Sediakan 1 ruas jahe geprek
1. Sediakan 1 ruas lengkuas geprek
1. Ambil 1 lembar daun salam dan jeruk
1. Siapkan Secukupnya gula, kaldu jamur/ garam, dan merica bubuk
1. Siapkan 5 buah cabai rawit hijau potong kasar atau utuh (optional)
1. Siapkan 3-5 sdm kecap manis
1. Sediakan  Bumbu halus
1. Gunakan 2 siung bawang putih
1. Gunakan 2 siung bawang merah
1. Gunakan 7 cabai rawit merah, 3 cabai merah keriting
1. Sediakan Sedikit minyak untuk menumis
1. Sediakan 1 gelas air




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso Ayam Zuper Pedas:

1. Tumis bumbu halus sampai harum, kemudian masukkan jahe, lengkuas, daun jeruk, dan daun salam, aduk aduk sampai daun layu
1. Masukkan ayam tumis sampai setengah matang, bumbui dengan gula, garam/kaldu jamur, dan kecap manis, kemudian beri air
1. Setelah mendidih tambahkan kol dan cabai, karena suka pedes jadi masih sya tambah cabai kalo gak suka porsi cabai bisa dikurangi dan tidak perlu ditambah cabai rawit ijo
1. Masak hingga air meresap dan sajikan




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan Gongso Ayam Zuper Pedas yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman maupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Selamat mencoba!
