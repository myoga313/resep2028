---
description: "Olahan Babat gongso | Langkah Membuat Babat gongso Yang Lezat"
title: "Olahan Babat gongso | Langkah Membuat Babat gongso Yang Lezat"
slug: 475-olahan-babat-gongso-langkah-membuat-babat-gongso-yang-lezat
date: 2020-11-15T20:44:56.977Z
image: https://img-global.cpcdn.com/recipes/ac85d7b76ca5bad5/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ac85d7b76ca5bad5/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ac85d7b76ca5bad5/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Bill Garcia
ratingvalue: 5
reviewcount: 12
recipeingredient:
- " babat rebus 2030mins"
- " cabe rawit"
- " kecap manis"
- " garam"
- " lengkuas"
- " serai"
- " daun jeruk"
- " daun salam"
- " tomat"
- " saus tiram"
- " minyak"
- " air"
- " Bawang gorengdaun bawang utk pelengkap"
- " Bumbu halus"
- " bawang merah"
- " bawang putih"
- " kemiri"
- " Merica butiran"
- " Merica butiran"
- " jahe"
- " cabe merah besarkeriting"
recipeinstructions:
- "Potong2 babat yang sudah direbus dengan potongan sesuai selera. Sisihkan."
- "Siapkan bumbu uleg/blender sampai halus"
- "Siapkan wajan beri minyak kemudian tumis bumbu halus sampai harum, masukkan serai, daun jeruk, daun salam, dan lengkuas, aduk sampai rata."
- "Masukkan air aduk, beri saus tiram, kemudian masukkan babat aduk sampai rata"
- "Beri kecap manis, sejumput garam dan diamkan sampai agak menyusut airnya. Beri cabe rawit utuh dan tomat aduk tunggu sampai cabe rawit dan tomat layu, tes rasa, masak sebentar lagi kemudian matikan kompor."
- "Beri bawang goreng/daun bawang. Sajikan"
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 286 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Lunch

---


![Babat gongso](https://img-global.cpcdn.com/recipes/ac85d7b76ca5bad5/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Bunda lagi mencari inspirasi resep babat gongso yang Sedap? Cara menyiapkannya memang tidak susah dan tidak juga mudah. andaikan keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal babat gongso yang enak selayaknya punya aroma dan rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tak perlu pusing jika mau menyiapkan babat gongso enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan istimewa.


Nah, kali ini kita coba, yuk, buat babat gongso sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Babat gongso menggunakan 21 bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Babat gongso:

1. Gunakan  babat rebus (20-30mins)
1. Siapkan  cabe rawit
1. Siapkan  kecap manis
1. Gunakan  garam
1. Siapkan  lengkuas
1. Ambil  serai
1. Siapkan  daun jeruk
1. Ambil  daun salam
1. Gunakan  tomat
1. Siapkan  saus tiram
1. Siapkan  minyak
1. Sediakan  air
1. Ambil  Bawang goreng/daun bawang utk pelengkap
1. Gunakan  Bumbu halus
1. Siapkan  bawang merah
1. Ambil  bawang putih
1. Siapkan  kemiri
1. Ambil  Merica butiran
1. Sediakan  Merica butiran
1. Gunakan  jahe
1. Sediakan  cabe merah besar/keriting




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Babat gongso:

1. Potong2 babat yang sudah direbus dengan potongan sesuai selera. Sisihkan.
1. Siapkan bumbu uleg/blender sampai halus
1. Siapkan wajan beri minyak kemudian tumis bumbu halus sampai harum, masukkan serai, daun jeruk, daun salam, dan lengkuas, aduk sampai rata.
1. Masukkan air aduk, beri saus tiram, kemudian masukkan babat aduk sampai rata
1. Beri kecap manis, sejumput garam dan diamkan sampai agak menyusut airnya. Beri cabe rawit utuh dan tomat aduk tunggu sampai cabe rawit dan tomat layu, tes rasa, masak sebentar lagi kemudian matikan kompor.
1. Beri bawang goreng/daun bawang. Sajikan




Bagaimana? Gampang kan? Itulah cara membuat babat gongso yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
