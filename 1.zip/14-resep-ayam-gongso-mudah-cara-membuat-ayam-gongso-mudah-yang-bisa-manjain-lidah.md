---
description: "Resep Ayam gongso mudah | Cara Membuat Ayam gongso mudah Yang Bisa Manjain Lidah"
title: "Resep Ayam gongso mudah | Cara Membuat Ayam gongso mudah Yang Bisa Manjain Lidah"
slug: 14-resep-ayam-gongso-mudah-cara-membuat-ayam-gongso-mudah-yang-bisa-manjain-lidah
date: 2020-09-29T15:02:08.385Z
image: https://img-global.cpcdn.com/recipes/8480b9eb392ce69b/751x532cq70/ayam-gongso-mudah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8480b9eb392ce69b/751x532cq70/ayam-gongso-mudah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8480b9eb392ce69b/751x532cq70/ayam-gongso-mudah-foto-resep-utama.jpg
author: Blake Drake
ratingvalue: 3.1
reviewcount: 10
recipeingredient:
- "2 dada ayamsesuai selera"
- "1/6 kol"
- "1 ruas sereh"
- "1 lembar salam"
- "1/2 ruas lengkuas memarkan"
- "1 lembar daun jeruk"
- "Sedikit gula jawa"
- "Secukupnya garam"
- " Kecap manis"
- "2 cabai rawit utuh"
- "2 bawang putih untuk rebus ayam"
- "1 gelas kecil air"
- " Bawang goreng"
- " Daun bawang diiris tipis"
- " Bumbu halus"
- "3 bawang putih"
- "4 bawang merah"
- "2 cabai merah keriting"
- " Secukupny kemiri"
recipeinstructions:
- "Rebus ayam dg bawang putih dan garam setelah matang disuwir"
- "Panaskan minyak lalu tumis bumbu halus sampai harum., masukan sereh, lengkuas, salam, daun jeruk dan gula jawa."
- "Masukkan suwiran ayam, kecap, garam dan tambahkan air,lalu masukkan cabe rawit utuh, koreksi rasa lalu masukkan kol."
- "Masak sampai bumbu meresap Masukkan daun bawang dan bawang goreng"
categories:
- Resep
tags:
- ayam
- gongso
- mudah

katakunci: ayam gongso mudah 
nutrition: 181 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam gongso mudah](https://img-global.cpcdn.com/recipes/8480b9eb392ce69b/751x532cq70/ayam-gongso-mudah-foto-resep-utama.jpg)

Sedang mencari inspirasi resep ayam gongso mudah yang Enak Banget? Cara Memasaknya memang tidak terlalu sulit namun tidak gampang juga. andaikata salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal ayam gongso mudah yang enak harusnya sih mempunyai aroma dan rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso mudah, mulai dari jenis bahan, kemudian pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tidak usah pusing kalau ingin menyiapkan ayam gongso mudah enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan spesial.

Gongso berarti tumis dalam bahasa jawa. Maka dari itu, sajian khas Semarang ini juga bisa diartikan ayam masak tumis. Kenampakannya gelap dan citarasanya manis mirip dengan semur yang berkuah.


Nah, kali ini kita coba, yuk, buat ayam gongso mudah sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat membuat Ayam gongso mudah memakai 19 jenis bahan dan 4 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam gongso mudah:

1. Gunakan 2 dada ayam(sesuai selera)
1. Sediakan 1/6 kol
1. Sediakan 1 ruas sereh
1. Sediakan 1 lembar salam
1. Sediakan 1/2 ruas lengkuas memarkan
1. Sediakan 1 lembar daun jeruk
1. Sediakan Sedikit gula jawa
1. Sediakan Secukupnya garam
1. Sediakan  Kecap manis
1. Ambil 2 cabai rawit utuh
1. Gunakan 2 bawang putih untuk rebus ayam
1. Ambil 1 gelas kecil air
1. Siapkan  Bawang goreng
1. Gunakan  Daun bawang diiris tipis
1. Gunakan  Bumbu halus
1. Ambil 3 bawang putih
1. Sediakan 4 bawang merah
1. Siapkan 2 cabai merah keriting
1. Ambil  Secukupny kemiri


Cara Mudah Memasak Gongso Ayam Hot Plate. Cara Mudah Membuat Babat Iso Gongso Pedas Menu Pilihan Saat Musim Hujan Tiba. Resep Babat Gongso Semarang asli (Kuliner asli Indonesia). Kalau sudah, angkat ayam gongso dan sajikan bersama nasi putih hangat. 

<!--inarticleads2-->

##### Langkah-langkah membuat Ayam gongso mudah:

1. Rebus ayam dg bawang putih dan garam setelah matang disuwir
1. Panaskan minyak lalu tumis bumbu halus sampai harum., masukan sereh, lengkuas, salam, daun jeruk dan gula jawa.
1. Masukkan suwiran ayam, kecap, garam dan tambahkan air,lalu masukkan cabe rawit utuh, koreksi rasa lalu masukkan kol.
1. Masak sampai bumbu meresap Masukkan daun bawang dan bawang goreng


Baca Juga: Resep Memasak Ayam Goreng Saus Inggris yang Mudah dan Enak. Cara Mudah Memasak Gongso Ayam Hot Plate. 

Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Ayam gongso mudah yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman maupun menjadi inspirasi untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
