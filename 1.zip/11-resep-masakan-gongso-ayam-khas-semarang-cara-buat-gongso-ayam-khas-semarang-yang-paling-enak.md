---
description: "Resep masakan Gongso Ayam Khas Semarang | Cara Buat Gongso Ayam Khas Semarang Yang Paling Enak"
title: "Resep masakan Gongso Ayam Khas Semarang | Cara Buat Gongso Ayam Khas Semarang Yang Paling Enak"
slug: 11-resep-masakan-gongso-ayam-khas-semarang-cara-buat-gongso-ayam-khas-semarang-yang-paling-enak
date: 2020-12-15T06:04:45.306Z
image: https://img-global.cpcdn.com/recipes/b00e6bd0758e0959/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b00e6bd0758e0959/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b00e6bd0758e0959/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg
author: Dora Cole
ratingvalue: 4.1
reviewcount: 13
recipeingredient:
- " Bumbu halus "
- "3 butir bawang putih"
- "5 butir bawang merah"
- "6 buah cabe merah keriting"
- "8 buah cabe setan sesuai selera"
- "secukupnya Garam"
- "1 sdt gula jawa"
- "secukupnya Kecap manis"
- "secukupnya Minyak goreng"
- "secukupnya Kaldu jamur"
- " Bahan isi "
- "1 butir Telur ayam"
- "250 g dada ayam boleh diganti pahasayap rebus suwir"
- "1 ikat sawi dipotong2 kecil"
- "25 g kol diiris tipis2"
- "1 buah timun potong dadu"
recipeinstructions:
- "Cuci bersih semua bahan, haluskan semua bumbu halus kecuali kecap manis dengan diulek (kalo saya suka ulekan karena lebih sedap)."
- "Kocok lepas telur + sedikit garam. Panaskan sedikit minyak goreng untuk membuat telur dadar, lalu digongso (diacak-acak di wajan). Dibikin seperti scramble egg. Lalu sisihkan."
- "Setelah telurnya jadi, sekarang panaskan minyak secukupnya, lalu goreng bumbu halusnya sampai tercium aroma wanginya."
- "Masukkan telur, suwiran ayam, sayuran sawi dan kol. Gongso semua bahan. Tambahkan kecap dan kaldu jamur secukupnya."
- "Pastikan sayuran yg dicampur sudah matang, lalu cek rasa."
- "Tambahkan timun yg sudah diiris dadu sebagai pelengkap."
- "Gongso ayam siap disajikan. Mudah bukan membuatnya??"
categories:
- Resep
tags:
- gongso
- ayam
- khas

katakunci: gongso ayam khas 
nutrition: 242 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Lunch

---


![Gongso Ayam Khas Semarang](https://img-global.cpcdn.com/recipes/b00e6bd0758e0959/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep gongso ayam khas semarang yang Enak Banget? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. semisal salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gongso ayam khas semarang yang enak seharusnya memiliki aroma dan cita rasa yang bisa memancing selera kita.

Babat gongso salah satu kuliner khas Semarang yang rasanya sangat gurih, jika anda ingin mencicipinya dan belum sempat ke kota Semarang bisa membuatnya sendiri. Gongso berarti tumis dalam bahasa jawa. Maka dari itu, sajian khas Semarang ini juga bisa diartikan ayam masak tumis.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ayam khas semarang, mulai dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tidak usah pusing jika hendak menyiapkan gongso ayam khas semarang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian istimewa.


Di bawah ini ada beberapa cara mudah dan praktis untuk membuat gongso ayam khas semarang yang siap dikreasikan. Anda dapat menyiapkan Gongso Ayam Khas Semarang menggunakan 16 bahan dan 7 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Gongso Ayam Khas Semarang:

1. Sediakan  Bumbu halus :
1. Gunakan 3 butir bawang putih
1. Gunakan 5 butir bawang merah
1. Sediakan 6 buah cabe merah keriting
1. Siapkan 8 buah cabe setan (sesuai selera)
1. Sediakan secukupnya Garam
1. Ambil 1 sdt gula jawa
1. Siapkan secukupnya Kecap manis
1. Ambil secukupnya Minyak goreng
1. Sediakan secukupnya Kaldu jamur
1. Siapkan  Bahan isi :
1. Siapkan 1 butir Telur ayam
1. Sediakan 250 g dada ayam (boleh diganti paha/sayap) rebus suwir
1. Gunakan 1 ikat sawi (dipotong2 kecil)
1. Ambil 25 g kol (diiris tipis2)
1. Sediakan 1 buah timun (potong dadu)


Mana nih yang kalian coba dulu. Semarang merupakan kota terbesar kelima di Indonesia setelah Jakarta, Surabaya, Medan, dan Bandung. Babat gongso, hidangan kebanggaan warga Semarang kini bisa kamu buat sendiri di rumah. Ayam Seafood Daging Sayuran Nasi Mie Telur Tahu Tempe. 

<!--inarticleads2-->

##### Cara menyiapkan Gongso Ayam Khas Semarang:

1. Cuci bersih semua bahan, haluskan semua bumbu halus kecuali kecap manis dengan diulek (kalo saya suka ulekan karena lebih sedap).
1. Kocok lepas telur + sedikit garam. Panaskan sedikit minyak goreng untuk membuat telur dadar, lalu digongso (diacak-acak di wajan). Dibikin seperti scramble egg. Lalu sisihkan.
1. Setelah telurnya jadi, sekarang panaskan minyak secukupnya, lalu goreng bumbu halusnya sampai tercium aroma wanginya.
1. Masukkan telur, suwiran ayam, sayuran sawi dan kol. Gongso semua bahan. Tambahkan kecap dan kaldu jamur secukupnya.
1. Pastikan sayuran yg dicampur sudah matang, lalu cek rasa.
1. Tambahkan timun yg sudah diiris dadu sebagai pelengkap.
1. Gongso ayam siap disajikan. Mudah bukan membuatnya??


Resep Babat Gongso, Hidangan Legendaris Khas Semarang. Simpan ke bagian favorit Tersimpan di bagian favorit. Masakan khas Semarang- Babat Gongso yang seringkali juga dijadikan nasi goreng babat, dan ini enak sekali apalagi jika. Gongso merupakan bahasa jawa dari kata tumis ya food lovers. Jadi gongso ayam artinya tumis ayam yg khas dari Kota. 

Bagaimana? Mudah bukan? Itulah cara menyiapkan gongso ayam khas semarang yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
