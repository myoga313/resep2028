---
description: "Resep masakan Gongso Ati Ampela Ayam | Resep Bumbu Gongso Ati Ampela Ayam Yang Enak Banget"
title: "Resep masakan Gongso Ati Ampela Ayam | Resep Bumbu Gongso Ati Ampela Ayam Yang Enak Banget"
slug: 63-resep-masakan-gongso-ati-ampela-ayam-resep-bumbu-gongso-ati-ampela-ayam-yang-enak-banget
date: 2021-01-11T04:12:47.215Z
image: https://img-global.cpcdn.com/recipes/030630ac2ccd724f/751x532cq70/gongso-ati-ampela-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/030630ac2ccd724f/751x532cq70/gongso-ati-ampela-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/030630ac2ccd724f/751x532cq70/gongso-ati-ampela-ayam-foto-resep-utama.jpg
author: Wayne Mason
ratingvalue: 4.8
reviewcount: 8
recipeingredient:
- "5 pasang ati ampela ayam"
- "3 lembar daun salam"
- "4 siung bawang merah"
- "2 siung bawang putih"
- "sesuai selera Cabai"
- "3 lembar daun jeruk"
- "1 batang serai"
- "1 sdm kecap manis"
- "secukupnya Gula garam"
recipeinstructions:
- "Rebus ati ampela ayam dengan daun salam hingga matang"
- "Goreng sebentar ati ampela ayam"
- "Haluskan bawang merah, bawang putih, cabai"
- "Tumis bumbu halus, daun jeruk dan serai hingga harum"
- "Tambahkan kecap manis dan sedikit air"
- "Masukkan ati ampela, koreksi rasa dengan gula dan garam"
- "Masak hingga bumbu meresap"
categories:
- Resep
tags:
- gongso
- ati
- ampela

katakunci: gongso ati ampela 
nutrition: 288 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Lunch

---


![Gongso Ati Ampela Ayam](https://img-global.cpcdn.com/recipes/030630ac2ccd724f/751x532cq70/gongso-ati-ampela-ayam-foto-resep-utama.jpg)

Bunda lagi mencari inspirasi resep gongso ati ampela ayam yang Enak dan Simpel? Cara Bikinnya memang tidak terlalu sulit namun tidak gampang juga. andaikata salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gongso ati ampela ayam yang enak seharusnya memiliki aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ati ampela ayam, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan gongso ati ampela ayam enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan istimewa.


Nah, kali ini kita coba, yuk, siapkan gongso ati ampela ayam sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Gongso Ati Ampela Ayam memakai 9 jenis bahan dan 7 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Gongso Ati Ampela Ayam:

1. Sediakan 5 pasang ati ampela ayam
1. Ambil 3 lembar daun salam
1. Sediakan 4 siung bawang merah
1. Ambil 2 siung bawang putih
1. Gunakan sesuai selera Cabai
1. Ambil 3 lembar daun jeruk
1. Siapkan 1 batang serai
1. Ambil 1 sdm kecap manis
1. Sediakan secukupnya Gula garam




<!--inarticleads2-->

##### Cara menyiapkan Gongso Ati Ampela Ayam:

1. Rebus ati ampela ayam dengan daun salam hingga matang
1. Goreng sebentar ati ampela ayam
1. Haluskan bawang merah, bawang putih, cabai
1. Tumis bumbu halus, daun jeruk dan serai hingga harum
1. Tambahkan kecap manis dan sedikit air
1. Masukkan ati ampela, koreksi rasa dengan gula dan garam
1. Masak hingga bumbu meresap




Bagaimana? Gampang kan? Itulah cara membuat gongso ati ampela ayam yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
