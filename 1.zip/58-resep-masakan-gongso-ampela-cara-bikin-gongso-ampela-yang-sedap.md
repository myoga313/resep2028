---
description: "Resep masakan Gongso Ampela | Cara Bikin Gongso Ampela Yang Sedap"
title: "Resep masakan Gongso Ampela | Cara Bikin Gongso Ampela Yang Sedap"
slug: 58-resep-masakan-gongso-ampela-cara-bikin-gongso-ampela-yang-sedap
date: 2020-11-23T01:39:18.000Z
image: https://img-global.cpcdn.com/recipes/c17d1b0231749e06/751x532cq70/gongso-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c17d1b0231749e06/751x532cq70/gongso-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c17d1b0231749e06/751x532cq70/gongso-ampela-foto-resep-utama.jpg
author: Anthony McGee
ratingvalue: 3.6
reviewcount: 8
recipeingredient:
- "500 gram ampela"
- " Bumbu Rebusan"
- "2 lembar Daun salam"
- "1 batang Sereh"
- "3 lembar daun jeruk"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1 sdt ketumbar bubuk"
- "750 ml air"
- " Bumbu dihaluskan"
- "1 buah cabe"
- "7 siung bawang merah"
- "7 siung bawang putih"
- "1 ruas kunyit"
- " Bumbu lainya"
- "4 siung bawang merah diiris"
- "7 buah cabe jablay"
- "3 lembar daun jeruk"
- "1 batang sereh"
- "1 lembar daun salam"
- "2 sdm kecap manis"
- "sesuai selera Garam"
- "200 ml air"
- " Minyak untuk menggoreng"
recipeinstructions:
- "Didihkan air, kemudian masukan daun salam, daun jeruk, sereh, jahe, lengkuas dan ketumbar bubuk aduk. Kemudian masukkan ampela. Rebus sampai matang, kemudian angkat dan potong potong"
- "Goreng bawang merah iris sampai wangi, masukkan potongan ampela. Goreng hingga setengah kering, angkat"
- "Tumis bumbu halus sampai wangi, tambahkan air masak sampai air mendidih masukkan ampela, tambahkan kecap, garam, penyedap rasa koreksi rasa, matikan kompor dan angkat"
- "Siap disantap dengan nasi hangat 😘"
categories:
- Resep
tags:
- gongso
- ampela

katakunci: gongso ampela 
nutrition: 284 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dessert

---


![Gongso Ampela](https://img-global.cpcdn.com/recipes/c17d1b0231749e06/751x532cq70/gongso-ampela-foto-resep-utama.jpg)

Sedang mencari inspirasi resep gongso ampela yang Menggugah Selera? Cara Memasaknya memang tidak terlalu sulit namun tidak gampang juga. seandainya keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal gongso ampela yang enak harusnya sih mempunyai aroma dan cita rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ampela, pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara membuat dan menyajikannya. Tidak usah pusing kalau mau menyiapkan gongso ampela yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.


Berikut ini ada beberapa tips dan trik praktis dalam mengolah gongso ampela yang siap dikreasikan. Anda dapat membuat Gongso Ampela menggunakan 24 bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Gongso Ampela:

1. Siapkan 500 gram ampela
1. Siapkan  Bumbu Rebusan
1. Sediakan 2 lembar Daun salam
1. Siapkan 1 batang Sereh
1. Sediakan 3 lembar daun jeruk
1. Siapkan 1 ruas jahe
1. Siapkan 1 ruas lengkuas
1. Sediakan 1 sdt ketumbar bubuk
1. Gunakan 750 ml air
1. Gunakan  Bumbu dihaluskan
1. Ambil 1 buah cabe
1. Siapkan 7 siung bawang merah
1. Ambil 7 siung bawang putih
1. Gunakan 1 ruas kunyit
1. Gunakan  Bumbu lainya
1. Sediakan 4 siung bawang merah, diiris
1. Gunakan 7 buah cabe jablay
1. Siapkan 3 lembar daun jeruk
1. Sediakan 1 batang sereh
1. Sediakan 1 lembar daun salam
1. Sediakan 2 sdm kecap manis
1. Siapkan sesuai selera Garam
1. Siapkan 200 ml air
1. Sediakan  Minyak untuk menggoreng




<!--inarticleads2-->

##### Cara membuat Gongso Ampela:

1. Didihkan air, kemudian masukan daun salam, daun jeruk, sereh, jahe, lengkuas dan ketumbar bubuk aduk. Kemudian masukkan ampela. Rebus sampai matang, kemudian angkat dan potong potong
1. Goreng bawang merah iris sampai wangi, masukkan potongan ampela. Goreng hingga setengah kering, angkat
1. Tumis bumbu halus sampai wangi, tambahkan air masak sampai air mendidih masukkan ampela, tambahkan kecap, garam, penyedap rasa koreksi rasa, matikan kompor dan angkat
1. Siap disantap dengan nasi hangat 😘




Bagaimana? Gampang kan? Itulah cara menyiapkan gongso ampela yang bisa Anda lakukan di rumah. Selamat mencoba!
