---
description: "Bahan Gongso Ceker Ayam Setan | Resep Membuat Gongso Ceker Ayam Setan Yang Lezat Sekali"
title: "Bahan Gongso Ceker Ayam Setan | Resep Membuat Gongso Ceker Ayam Setan Yang Lezat Sekali"
slug: 190-bahan-gongso-ceker-ayam-setan-resep-membuat-gongso-ceker-ayam-setan-yang-lezat-sekali
date: 2020-08-04T17:14:19.983Z
image: https://img-global.cpcdn.com/recipes/c5ab39f9ec15bcff/751x532cq70/gongso-ceker-ayam-setan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c5ab39f9ec15bcff/751x532cq70/gongso-ceker-ayam-setan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c5ab39f9ec15bcff/751x532cq70/gongso-ceker-ayam-setan-foto-resep-utama.jpg
author: Calvin Bowers
ratingvalue: 4.6
reviewcount: 10
recipeingredient:
- "10 ceker ayam"
- "4 siung bawang merah"
- "1 siung bawang putih"
- "4 buah cabai merah keriting"
- "6 buah cabai rawit setan merah"
- "1 lembar daun salam"
- "1 lembar daun jeruk wangi"
- "2 sendok makan kecap manis"
- "250 ml air"
- "Secukupnya lada bubuk gula merah garam penyedap"
recipeinstructions:
- "Rebus ceker ayam, tiriskan"
- "Haluskan bawang merah, bawang putih, cabai merah keriting, cabai rawit setan."
- "Tumis bumbu halus dan daun salam hingga harum, masukan ceker ayam, daun jeruk wangi, kecap, aduk rata."
- "Tambahkan lada bubuk, gula merah, garam, penyedap secukupnya."
- "Dirasa telah tercampur rata, masukan air. Masak hingga bumbu meresap."
- "Ready to serve."
categories:
- Resep
tags:
- gongso
- ceker
- ayam

katakunci: gongso ceker ayam 
nutrition: 125 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Dessert

---


![Gongso Ceker Ayam Setan](https://img-global.cpcdn.com/recipes/c5ab39f9ec15bcff/751x532cq70/gongso-ceker-ayam-setan-foto-resep-utama.jpg)

Bunda lagi mencari ide resep gongso ceker ayam setan yang Bisa Manjain Lidah? Cara membuatnya memang tidak susah dan tidak juga mudah. sekiranya keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso ceker ayam setan yang enak selayaknya mempunyai aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ceker ayam setan, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan gongso ceker ayam setan enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.




Di bawah ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah gongso ceker ayam setan yang siap dikreasikan. Anda bisa menyiapkan Gongso Ceker Ayam Setan menggunakan 10 jenis bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Gongso Ceker Ayam Setan:

1. Siapkan 10 ceker ayam
1. Sediakan 4 siung bawang merah
1. Sediakan 1 siung bawang putih
1. Gunakan 4 buah cabai merah keriting
1. Sediakan 6 buah cabai rawit setan/ merah
1. Gunakan 1 lembar daun salam
1. Sediakan 1 lembar daun jeruk wangi
1. Ambil 2 sendok makan kecap manis
1. Ambil 250 ml air
1. Ambil Secukupnya lada bubuk, gula merah, garam, penyedap




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso Ceker Ayam Setan:

1. Rebus ceker ayam, tiriskan
1. Haluskan bawang merah, bawang putih, cabai merah keriting, cabai rawit setan.
1. Tumis bumbu halus dan daun salam hingga harum, masukan ceker ayam, daun jeruk wangi, kecap, aduk rata.
1. Tambahkan lada bubuk, gula merah, garam, penyedap secukupnya.
1. Dirasa telah tercampur rata, masukan air. Masak hingga bumbu meresap.
1. Ready to serve.




Gimana nih? Mudah bukan? Itulah cara menyiapkan gongso ceker ayam setan yang bisa Anda lakukan di rumah. Selamat mencoba!
