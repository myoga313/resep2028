---
description: "Resep Urab kelapa gongso | Cara Mengolah Urab kelapa gongso Yang Enak dan Simpel"
title: "Resep Urab kelapa gongso | Cara Mengolah Urab kelapa gongso Yang Enak dan Simpel"
slug: 22-resep-urab-kelapa-gongso-cara-mengolah-urab-kelapa-gongso-yang-enak-dan-simpel
date: 2021-01-10T06:16:08.487Z
image: https://img-global.cpcdn.com/recipes/9a056da2d537fc79/751x532cq70/urab-kelapa-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9a056da2d537fc79/751x532cq70/urab-kelapa-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9a056da2d537fc79/751x532cq70/urab-kelapa-gongso-foto-resep-utama.jpg
author: Lettie McKinney
ratingvalue: 4.2
reviewcount: 9
recipeingredient:
- "1 btr kelapa parut setengah tua kupas kulitnya"
- "1 ons kencur"
- "5 siung bawang merah"
- "5 siung bawang putih"
- "2 btr kemiri"
- "10 batang cabe merah besar"
- "5 batang cabe rawitsesuai selera"
- "1 sdt Garam"
- "1 sdt gula"
recipeinstructions:
- "Bakar kelapa yang sudah di buang kulitnya, lalu parut"
- "Ulek atau haluskan semua bumbu"
- "Panaskan wajan, beri sedikit minyak lalu oseng bumbu hingga matang"
- "Masukkan kelapa parut, aduk hingga rata, masak hingga matang sempurna"
- "Kalo saya pakai api kecil, masak lama, karna kelapa mudah basi, jadi kalau utuk seharian sebaiknya masak hingga benar benar tanak, biar tidak cepat basi"
- "Koreksi rasa, siap hidangkan bersama sayur sayur yang telah direbus"
categories:
- Resep
tags:
- urab
- kelapa
- gongso

katakunci: urab kelapa gongso 
nutrition: 137 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Lunch

---


![Urab kelapa gongso](https://img-global.cpcdn.com/recipes/9a056da2d537fc79/751x532cq70/urab-kelapa-gongso-foto-resep-utama.jpg)

Bunda lagi mencari inspirasi resep urab kelapa gongso yang Lezat Sekali? Cara Buatnya memang susah-susah gampang. sekiranya keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal urab kelapa gongso yang enak harusnya sih mempunyai aroma dan rasa yang mampu memancing selera kita.

Bakar kelapa yang sudah di buang kulitnya, lalu parut. Kelapa Parut Kering berasal dari kelapa tua yang nyaris tidak mempunyai kandungan santan lagi. Akibatnya bahan ini akan menghasilkan Bumbu Urap yang kering dan terasa hambar.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari urab kelapa gongso, pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tidak usah pusing kalau ingin menyiapkan urab kelapa gongso yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.


Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah urab kelapa gongso yang siap dikreasikan. Anda dapat menyiapkan Urab kelapa gongso memakai 9 bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Urab kelapa gongso:

1. Sediakan 1 btr kelapa parut (setengah tua) kupas kulitnya
1. Sediakan 1 ons kencur
1. Gunakan 5 siung bawang merah
1. Sediakan 5 siung bawang putih
1. Ambil 2 btr kemiri
1. Sediakan 10 batang cabe merah besar
1. Sediakan 5 batang cabe rawit(sesuai selera)
1. Ambil 1 sdt Garam
1. Ambil 1 sdt gula


Dari ibu-ibu yang setiap hari pergi ke pasar tahu betul. Kelapa adalah tanaman yang terkenal karena manfaatnya yang luar biasa, semua bagian dari tanaman ini bisa digunakan untuk berbagai keperluan manusia. Kelapa aslinya berasal dari Asia, pesisir. 

<!--inarticleads2-->

##### Cara menyiapkan Urab kelapa gongso:

1. Bakar kelapa yang sudah di buang kulitnya, lalu parut
1. Ulek atau haluskan semua bumbu
1. Panaskan wajan, beri sedikit minyak lalu oseng bumbu hingga matang
1. Masukkan kelapa parut, aduk hingga rata, masak hingga matang sempurna
1. Kalo saya pakai api kecil, masak lama, karna kelapa mudah basi, jadi kalau utuk seharian sebaiknya masak hingga benar benar tanak, biar tidak cepat basi
1. Koreksi rasa, siap hidangkan bersama sayur sayur yang telah direbus




Gimana nih? Gampang kan? Itulah cara menyiapkan urab kelapa gongso yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
