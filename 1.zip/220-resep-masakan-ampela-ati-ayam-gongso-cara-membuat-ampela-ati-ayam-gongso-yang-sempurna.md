---
description: "Resep masakan Ampela ati ayam gongso | Cara Membuat Ampela ati ayam gongso Yang Sempurna"
title: "Resep masakan Ampela ati ayam gongso | Cara Membuat Ampela ati ayam gongso Yang Sempurna"
slug: 220-resep-masakan-ampela-ati-ayam-gongso-cara-membuat-ampela-ati-ayam-gongso-yang-sempurna
date: 2020-10-13T05:00:20.489Z
image: https://img-global.cpcdn.com/recipes/eb1eba078d044037/751x532cq70/ampela-ati-ayam-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/eb1eba078d044037/751x532cq70/ampela-ati-ayam-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/eb1eba078d044037/751x532cq70/ampela-ati-ayam-gongso-foto-resep-utama.jpg
author: Landon Watkins
ratingvalue: 4.7
reviewcount: 6
recipeingredient:
- " ati ampela ayam kampung"
- " bawang merah"
- " bawang putih"
- " cabai rawit"
- " cabai merah keriting"
- " daun jeruk"
- " daun salam"
- " lengkuas digeprek"
- " kunyit"
- " kecap"
- " Gula garam penyedap jamur"
- " Cabai merah  tomat untuk irisan secukupnya"
recipeinstructions:
- "Cuci bersih ati ampela buang lemaknya, didihkan kurang lebih 10 menit campur sedikit garam &amp; 1 lembar daun jeruk supaya tidak amis"
- "Tiriskan ampela ati, goreng sebentar boleh juga langsung dimasak ya"
- "Uleg/blender bumbu kecuali daun2an dan lengkuas lalu tumis hingga harum tambahkan daun salam &amp; jeruk masukkan kecap aduk sebentar masukkan ampela ati tmbhkan air masak sampai bumbu meresap, terakhir masukkan cabai utuh &amp; tomat iris"
- "Sajikan sama nasi anget plus kerupuk &amp; lalapan dijamin maknyus bunda tadi nemu telur kukus aq masukkan sekalian 😄"
categories:
- Resep
tags:
- ampela
- ati
- ayam

katakunci: ampela ati ayam 
nutrition: 247 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Lunch

---


![Ampela ati ayam gongso](https://img-global.cpcdn.com/recipes/eb1eba078d044037/751x532cq70/ampela-ati-ayam-gongso-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep ampela ati ayam gongso yang Enak Banget? Cara Bikinnya memang tidak susah dan tidak juga mudah. jikalau keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal ampela ati ayam gongso yang enak harusnya sih mempunyai aroma dan rasa yang bisa memancing selera kita.

Lihat juga resep Gongso Ayam ala Semarangan enak lainnya. Cara membuat gongso ati ampela yang sedap. Ati ayam punya citarasa yang gurih manis, sementara ampela punya tektstur kenyal yang bikin nagih.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ampela ati ayam gongso, pertama dari jenis bahan, lalu pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan ampela ati ayam gongso yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian spesial.


Berikut ini ada beberapa cara mudah dan praktis dalam mengolah ampela ati ayam gongso yang siap dikreasikan. Anda bisa menyiapkan Ampela ati ayam gongso memakai 12 jenis bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ampela ati ayam gongso:

1. Siapkan  ati ampela (ayam kampung)
1. Ambil  bawang merah
1. Siapkan  bawang putih
1. Gunakan  cabai rawit
1. Sediakan  cabai merah keriting
1. Siapkan  daun jeruk
1. Siapkan  daun salam
1. Sediakan  lengkuas digeprek
1. Ambil  kunyit
1. Ambil  kecap
1. Ambil  Gula garam penyedap jamur
1. Gunakan  Cabai merah &amp; tomat untuk irisan secukupnya


Olahan ati ampela juga beragam, mulai dari gurih, pedas, dan manis. Ati ampela juga bisa diolah dengan digoreng, direbus, atau dipadukan dengan bahan makanan lain. Nah, jika kamu bosan dengan olahan hati ayam biasanya, ada baiknya untuk mencoba resep-resep baru ini. Ati ampela ayam ungkep ini menggunakan bumbu yang sedap. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ampela ati ayam gongso:

1. Cuci bersih ati ampela buang lemaknya, didihkan kurang lebih 10 menit campur sedikit garam &amp; 1 lembar daun jeruk supaya tidak amis
1. Tiriskan ampela ati, goreng sebentar boleh juga langsung dimasak ya
1. Uleg/blender bumbu kecuali daun2an dan lengkuas lalu tumis hingga harum tambahkan daun salam &amp; jeruk masukkan kecap aduk sebentar masukkan ampela ati tmbhkan air masak sampai bumbu meresap, terakhir masukkan cabai utuh &amp; tomat iris
1. Sajikan sama nasi anget plus kerupuk &amp; lalapan dijamin maknyus bunda tadi nemu telur kukus aq masukkan sekalian 😄


Pakai gula merah, kunyit bakar, bawang putih, bawang merah Coba digoreng saja. Ati ampela goreng dengan bumbu garam, kaldu ayam, bawang putih, kunyit, dan ketumbar bisa jadi lauk yang nikmat untuk disantap dengan nasi putih. Masakan berbahan dasar ati ampela ayam dipadukan dengan bumbu dan rempah khas yang membuat rasanya semakin lezatt. Cara Membuat Ati Ampela Goreng Bumbu Ungkep Yang Praktis - Dapur Aneka.hati ayam biasanya pahit,namun kalau anda bisa. Dalam video tersebut, ia mengatakan bahwa ati ampela tersebut didapatkan dari seorang rekan kerjanya. 

Bagaimana? Mudah bukan? Itulah cara menyiapkan ampela ati ayam gongso yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
