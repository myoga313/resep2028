---
description: "Bumbu Gongso ati ampla pedas | Cara Masak Gongso ati ampla pedas Yang Enak Dan Mudah"
title: "Bumbu Gongso ati ampla pedas | Cara Masak Gongso ati ampla pedas Yang Enak Dan Mudah"
slug: 299-bumbu-gongso-ati-ampla-pedas-cara-masak-gongso-ati-ampla-pedas-yang-enak-dan-mudah
date: 2020-10-22T06:53:19.920Z
image: https://img-global.cpcdn.com/recipes/e90dbb9a393478e9/751x532cq70/gongso-ati-ampla-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e90dbb9a393478e9/751x532cq70/gongso-ati-ampla-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e90dbb9a393478e9/751x532cq70/gongso-ati-ampla-pedas-foto-resep-utama.jpg
author: Olga Parker
ratingvalue: 4.2
reviewcount: 10
recipeingredient:
- "10 pasang ati ampla"
- " Bumbu halus"
- "25 buah cabe rawit merahtergantung selera ya Bun"
- "10 cabe merah keriting"
- "2 buah cabe merah besar buang biji"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "1 ruas kunyit"
- " Bumbu cemplung"
- "5 lembar daun jeruk buang batang tengahnya"
- "Secukupnya lengkoas geprek"
- "4 lembar daun salam"
- "1 sdt lada bubuk"
- "4 sdm kecap manis"
- "Secukup nya garam"
- "Secukupnya kaldu bubuk"
- "1 sdt gula pasir"
- " Setngh gelas belimbing air"
- "Sedikit minyak untuk menumis"
recipeinstructions:
- "Bersihkan ati ampla lalu cuci dan rebus,beri sedikit garam,jeruk nipis dan sedikit kecap Inggris,rebus sampai matang dan sisihkan"
- "Panaskan minyak tumis bumbu halus sampai harum tambahkan bumbu cemplung aduk rata"
- "Masukkan ati ampla yg sudah direbus td,beri sedikit air,garam,gula pasir, penyedap rasa,lada dan kecap aduk rata"
- "Masak sampai matang dan sedikit kental lalu koreksi rasa,jika sudah pas dan matang segera angkat dan sajikan"
categories:
- Resep
tags:
- gongso
- ati
- ampla

katakunci: gongso ati ampla 
nutrition: 189 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dessert

---


![Gongso ati ampla pedas](https://img-global.cpcdn.com/recipes/e90dbb9a393478e9/751x532cq70/gongso-ati-ampla-pedas-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep gongso ati ampla pedas yang Enak dan Simpel? Cara menyiapkannya memang susah-susah gampang. sekiranya keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gongso ati ampla pedas yang enak seharusnya punya aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ati ampla pedas, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tidak usah pusing jika hendak menyiapkan gongso ati ampla pedas yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan spesial.




Berikut ini ada beberapa tips dan trik praktis dalam mengolah gongso ati ampla pedas yang siap dikreasikan. Anda bisa menyiapkan Gongso ati ampla pedas memakai 19 bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Gongso ati ampla pedas:

1. Ambil 10 pasang ati ampla
1. Ambil  Bumbu halus
1. Ambil 25 buah cabe rawit merah(tergantung selera ya Bun)
1. Gunakan 10 cabe merah keriting
1. Siapkan 2 buah cabe merah besar buang biji
1. Gunakan 10 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Ambil 1 ruas kunyit
1. Gunakan  Bumbu cemplung
1. Gunakan 5 lembar daun jeruk buang batang tengahnya
1. Siapkan Secukupnya lengkoas geprek
1. Siapkan 4 lembar daun salam
1. Ambil 1 sdt lada bubuk
1. Siapkan 4 sdm kecap manis
1. Sediakan Secukup nya garam
1. Ambil Secukupnya kaldu bubuk
1. Siapkan 1 sdt gula pasir
1. Gunakan  Setngh gelas belimbing air
1. Siapkan Sedikit minyak untuk menumis




<!--inarticleads2-->

##### Cara menyiapkan Gongso ati ampla pedas:

1. Bersihkan ati ampla lalu cuci dan rebus,beri sedikit garam,jeruk nipis dan sedikit kecap Inggris,rebus sampai matang dan sisihkan
1. Panaskan minyak tumis bumbu halus sampai harum tambahkan bumbu cemplung aduk rata
1. Masukkan ati ampla yg sudah direbus td,beri sedikit air,garam,gula pasir, penyedap rasa,lada dan kecap aduk rata
1. Masak sampai matang dan sedikit kental lalu koreksi rasa,jika sudah pas dan matang segera angkat dan sajikan




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Gongso ati ampla pedas yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman maupun menjadi inspirasi dalam berjualan makanan. Semoga bermanfaat dan selamat mencoba!
