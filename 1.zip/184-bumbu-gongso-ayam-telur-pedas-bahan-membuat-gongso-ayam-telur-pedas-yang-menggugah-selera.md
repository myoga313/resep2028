---
description: "Bumbu Gongso ayam telur pedas | Bahan Membuat Gongso ayam telur pedas Yang Menggugah Selera"
title: "Bumbu Gongso ayam telur pedas | Bahan Membuat Gongso ayam telur pedas Yang Menggugah Selera"
slug: 184-bumbu-gongso-ayam-telur-pedas-bahan-membuat-gongso-ayam-telur-pedas-yang-menggugah-selera
date: 2021-01-12T09:21:28.453Z
image: https://img-global.cpcdn.com/recipes/d2b780d17e51e643/751x532cq70/gongso-ayam-telur-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d2b780d17e51e643/751x532cq70/gongso-ayam-telur-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d2b780d17e51e643/751x532cq70/gongso-ayam-telur-pedas-foto-resep-utama.jpg
author: Fred Reeves
ratingvalue: 3.8
reviewcount: 13
recipeingredient:
- "250 g daging ayam"
- "1 telur"
- " Daun kubis"
- "1 buah wortel"
- "Sedikit daun seledri"
- "1 buah bawang putih"
- "Sedikit jahe"
- " Kecap manis"
- " Kecap asin"
- "Secukupnya gula pasir"
- "Secukupnya garam"
- " Merica bubuk"
- " Micin"
- "50 ml air"
- " Bumbu halus "
- "10 cabe rawit"
- "3 cabe merah keriting"
- "6 bawang merah"
- "2 bawang putih"
- "1 kemiri"
recipeinstructions:
- "Rebus daging dengan bumbu 1 bawang putih geprek dan jahe, rebus hingga air habis"
- "Uleg semua bahan bumbu halus"
- "Iris kubis,wortel dan daun seledri"
- "Tumis bumbu halus hingga wangi, sisihkan di tepi wajan"
- "Masukkan telur dan di orak arik, aduk bersama bumbu yang sudah ditumis"
- "Masukkan daging yg telah disuwir suwir dan tambahkan kecap asin dan kecap manis"
- "Masukkan kubis, wortel dan daun seledri,tambahkan gula,garam,micin, merica"
- "Aduk hingga merata dan tunggu sampai matang"
categories:
- Resep
tags:
- gongso
- ayam
- telur

katakunci: gongso ayam telur 
nutrition: 258 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Dessert

---


![Gongso ayam telur pedas](https://img-global.cpcdn.com/recipes/d2b780d17e51e643/751x532cq70/gongso-ayam-telur-pedas-foto-resep-utama.jpg)

Kamu Sedang mencari ide resep gongso ayam telur pedas yang Enak Banget? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. semisal salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso ayam telur pedas yang enak harusnya sih memiliki aroma dan cita rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ayam telur pedas, mulai dari jenis bahan, kemudian pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tidak usah pusing kalau mau menyiapkan gongso ayam telur pedas yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan spesial.




Nah, kali ini kita coba, yuk, variasikan gongso ayam telur pedas sendiri di rumah. Tetap berbahan yang sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Gongso ayam telur pedas menggunakan 20 jenis bahan dan 8 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Gongso ayam telur pedas:

1. Gunakan 250 g daging ayam
1. Siapkan 1 telur
1. Sediakan  Daun kubis
1. Siapkan 1 buah wortel
1. Siapkan Sedikit daun seledri
1. Siapkan 1 buah bawang putih
1. Gunakan Sedikit jahe
1. Gunakan  Kecap manis
1. Sediakan  Kecap asin
1. Ambil Secukupnya gula pasir
1. Sediakan Secukupnya garam
1. Gunakan  Merica bubuk
1. Ambil  Micin
1. Gunakan 50 ml air
1. Ambil  Bumbu halus :
1. Ambil 10 cabe rawit
1. Gunakan 3 cabe merah keriting
1. Sediakan 6 bawang merah
1. Siapkan 2 bawang putih
1. Siapkan 1 kemiri




<!--inarticleads2-->

##### Cara membuat Gongso ayam telur pedas:

1. Rebus daging dengan bumbu 1 bawang putih geprek dan jahe, rebus hingga air habis
1. Uleg semua bahan bumbu halus
1. Iris kubis,wortel dan daun seledri
1. Tumis bumbu halus hingga wangi, sisihkan di tepi wajan
1. Masukkan telur dan di orak arik, aduk bersama bumbu yang sudah ditumis
1. Masukkan daging yg telah disuwir suwir dan tambahkan kecap asin dan kecap manis
1. Masukkan kubis, wortel dan daun seledri,tambahkan gula,garam,micin, merica
1. Aduk hingga merata dan tunggu sampai matang




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Harapan kami, olahan Gongso ayam telur pedas yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi inspirasi dalam berbisnis kuliner. Selamat mencoba!
