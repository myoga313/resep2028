---
description: "Bahan Ayam Gongso Pedas | Cara Masak Ayam Gongso Pedas Yang Paling Enak"
title: "Bahan Ayam Gongso Pedas | Cara Masak Ayam Gongso Pedas Yang Paling Enak"
slug: 197-bahan-ayam-gongso-pedas-cara-masak-ayam-gongso-pedas-yang-paling-enak
date: 2020-09-24T07:51:16.505Z
image: https://img-global.cpcdn.com/recipes/9d45ecdd92cdcfa0/751x532cq70/ayam-gongso-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9d45ecdd92cdcfa0/751x532cq70/ayam-gongso-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9d45ecdd92cdcfa0/751x532cq70/ayam-gongso-pedas-foto-resep-utama.jpg
author: Amanda Castillo
ratingvalue: 3.1
reviewcount: 14
recipeingredient:
- "1/2 kg ayam me ayam kampung"
- "secukupnya Jahe"
- "5 siung bawang merah"
- "2 siung bawang putih"
- "secukupnya Lada bubuk"
- "1 biji bawang bombay"
- "secukupnya Garam"
- "secukupnya Kecap manis"
- "3 lembar daun jeruk"
- "1 lembar daun salam"
- "secukupnya Air"
- "6 biji cabe rawit sesuai selera"
- " Penyedap rasa bila suka"
- "1 biji tomat"
recipeinstructions:
- "Bersihkan ayam, lalu rebus terlebih dahulu ayam yang sudah dibersihkan (me : saya fresto karena ayam kampung,biar cepet empuk) masukkan daun jeruk,daun salam dan jahe digeprek, biar tidak amis. Rebus sampai ayam empuk"
- "Sambil menunggu rebusan ayam, buatlah bumbu halusnya, haluskan bawang merah,bawang putih, cabe, lalu tambahkan garam."
- "Angkat dan tiriskan ayam yang sudah matang direbus tadi. Potong kecil&#34; agar ketika di gongso bumbu bisa meresap."
- "Siapkan wajan dengan sedikit minyak, tumis bumbu halus sampai harum. Kemudian tambahkan bawang bombay yang telah diiris- iris. Tumis sampai harum. Tambahkan air rebusan ayam tadi secukupnya, setelah mendidih, masukkan ayam. Tambahkan garam secukupnya, penyedap rasa,lada bubuk secukupnya, dan kecap manis. Koreksi rasa, tunggu hingga air menyusut. Ayam gongso siap dihidangkan. Tambahkan irisan tomat"
categories:
- Resep
tags:
- ayam
- gongso
- pedas

katakunci: ayam gongso pedas 
nutrition: 250 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Gongso Pedas](https://img-global.cpcdn.com/recipes/9d45ecdd92cdcfa0/751x532cq70/ayam-gongso-pedas-foto-resep-utama.jpg)

Anda sedang mencari ide resep ayam gongso pedas yang Bikin Ngiler? Cara Bikinnya memang tidak susah dan tidak juga mudah. bila keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal ayam gongso pedas yang enak seharusnya mempunyai aroma dan cita rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso pedas, pertama dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menyajikannya. Tak perlu pusing jika hendak menyiapkan ayam gongso pedas enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.


Nah, kali ini kita coba, yuk, kreasikan ayam gongso pedas sendiri di rumah. Tetap berbahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Ayam Gongso Pedas menggunakan 14 bahan dan 4 tahap pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam Gongso Pedas:

1. Gunakan 1/2 kg ayam (me ayam kampung)
1. Ambil secukupnya Jahe
1. Siapkan 5 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Sediakan secukupnya Lada bubuk
1. Ambil 1 biji bawang bombay
1. Ambil secukupnya Garam
1. Sediakan secukupnya Kecap manis
1. Ambil 3 lembar daun jeruk
1. Ambil 1 lembar daun salam
1. Gunakan secukupnya Air
1. Siapkan 6 biji cabe rawit (sesuai selera)
1. Ambil  Penyedap rasa (bila suka)
1. Gunakan 1 biji tomat




<!--inarticleads2-->

##### Cara membuat Ayam Gongso Pedas:

1. Bersihkan ayam, lalu rebus terlebih dahulu ayam yang sudah dibersihkan (me : saya fresto karena ayam kampung,biar cepet empuk) masukkan daun jeruk,daun salam dan jahe digeprek, biar tidak amis. Rebus sampai ayam empuk
1. Sambil menunggu rebusan ayam, buatlah bumbu halusnya, haluskan bawang merah,bawang putih, cabe, lalu tambahkan garam.
1. Angkat dan tiriskan ayam yang sudah matang direbus tadi. Potong kecil&#34; agar ketika di gongso bumbu bisa meresap.
1. Siapkan wajan dengan sedikit minyak, tumis bumbu halus sampai harum. Kemudian tambahkan bawang bombay yang telah diiris- iris. Tumis sampai harum. Tambahkan air rebusan ayam tadi secukupnya, setelah mendidih, masukkan ayam. Tambahkan garam secukupnya, penyedap rasa,lada bubuk secukupnya, dan kecap manis. Koreksi rasa, tunggu hingga air menyusut. Ayam gongso siap dihidangkan. Tambahkan irisan tomat




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Ayam Gongso Pedas yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman ataupun menjadi ide bagi Anda yang berkeinginan untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
