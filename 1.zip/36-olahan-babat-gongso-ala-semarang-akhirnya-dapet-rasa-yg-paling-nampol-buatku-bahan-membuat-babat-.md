---
description: "Olahan Babat Gongso ala Semarang - akhirnya dapet rasa yg paling nampol buatku ;) | Bahan Membuat Babat Gongso ala Semarang - akhirnya dapet rasa yg paling nampol buatku ;) Yang Lezat"
title: "Olahan Babat Gongso ala Semarang - akhirnya dapet rasa yg paling nampol buatku ;) | Bahan Membuat Babat Gongso ala Semarang - akhirnya dapet rasa yg paling nampol buatku ;) Yang Lezat"
slug: 36-olahan-babat-gongso-ala-semarang-akhirnya-dapet-rasa-yg-paling-nampol-buatku-bahan-membuat-babat-gongso-ala-semarang-akhirnya-dapet-rasa-yg-paling-nampol-buatku-yang-lezat
date: 2020-09-04T15:29:49.932Z
image: https://img-global.cpcdn.com/recipes/2ec6d212f38088bb/751x532cq70/babat-gongso-ala-semarang-akhirnya-dapet-rasa-yg-paling-nampol-buatku-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2ec6d212f38088bb/751x532cq70/babat-gongso-ala-semarang-akhirnya-dapet-rasa-yg-paling-nampol-buatku-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2ec6d212f38088bb/751x532cq70/babat-gongso-ala-semarang-akhirnya-dapet-rasa-yg-paling-nampol-buatku-foto-resep-utama.jpg
author: Jay Nguyen
ratingvalue: 4.5
reviewcount: 5
recipeingredient:
- "500 gr Babat  bole anduksumpingusus bersihkan"
- "2 butir Jeruk Nipis  belah 2"
- "4 helai Daun Salam"
- "2 sdm Garam"
- " Bumbu Halus "
- "15 Cabai merah keriting"
- "7 Cabai rawit merah"
- "10 btr Bawang merah"
- "4 btr Bawang Putih"
- "6 btr Kemirisangrai"
- " Bumbu yang ditumis"
- "7 btr Bawang merah iris serong rada tebel  untuk textur"
- "Sesuai Selera GaramKaldu bubukGula PasirKecap"
recipeinstructions:
- "Bersihkan babat,Presto kurleb 20 menit.beri air scukupnya,potongan jeruk nipis+daun salam+garam Note: pilih babat yg FRESH,kenyal,baunya normal,pasti seger nanti jadinya."
- "Tiriskan,Potong2 sesuai selera.kalo aku rada gede2 motongnya..kalo pengen ky bapak2 babat ya kecil2 bingit.."
- "Tiriskan,Potong2 sesuai selera.kalo aku rada gede2 motongnya..kalo pengen ky bapak2 babat ya kecil2 bingit.."
- "Tumis minyak bersama Bawang merah yg uda dpotong kasar,minyak banyakkin ya soalnya nanti masuk bumbu Halus) Tumis sampai harum aja jangan tumis lama2.."
- "Masukkan gula,kecap,garam,kaldu masako sesuai selera..masukkan babat.. aduk2 terus.. tambahkan air skitar 100cc+supaya juga bumbu ga mengerak di dasar wajan."
- "Setelah keliatan tercampur+sedap,matikan api.(jangan tumis terlalu lama soale babat uda empuk,bumbu gampang merasuk)angkat,sajikan dengan Nasi hangat,bawang merah goreng+krupuk..mantap jaya.."
- "Hihi sampe nambah 2x enak bingit XD puas banget biasa kalo beli di bapak lewat rumah babatnya di itung per Slice,ini jadinya banyakk. Hahaha.."
- ""
- "Pedesss,nampol..#tisue mana tisue.. wkwkw.."
- ""
categories:
- Resep
tags:
- babat
- gongso
- ala

katakunci: babat gongso ala 
nutrition: 239 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dinner

---


![Babat Gongso ala Semarang - akhirnya dapet rasa yg paling nampol buatku ;)](https://img-global.cpcdn.com/recipes/2ec6d212f38088bb/751x532cq70/babat-gongso-ala-semarang-akhirnya-dapet-rasa-yg-paling-nampol-buatku-foto-resep-utama.jpg)

Bunda lagi mencari inspirasi resep babat gongso ala semarang - akhirnya dapet rasa yg paling nampol buatku ;) yang Enak Banget? Cara menyiapkannya memang susah-susah gampang. seumpama keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal babat gongso ala semarang - akhirnya dapet rasa yg paling nampol buatku ;) yang enak selayaknya mempunyai aroma dan rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso ala semarang - akhirnya dapet rasa yg paling nampol buatku ;), mulai dari jenis bahan, kedua pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tak perlu pusing jika mau menyiapkan babat gongso ala semarang - akhirnya dapet rasa yg paling nampol buatku ;) yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.


Berikut ini ada beberapa cara mudah dan praktis untuk membuat babat gongso ala semarang - akhirnya dapet rasa yg paling nampol buatku ;) yang siap dikreasikan. Anda bisa membuat Babat Gongso ala Semarang - akhirnya dapet rasa yg paling nampol buatku ;) menggunakan 13 bahan dan 10 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Babat Gongso ala Semarang - akhirnya dapet rasa yg paling nampol buatku ;):

1. Ambil 500 gr Babat ( bole anduk,sumping,usus)- bersihkan
1. Siapkan 2 butir Jeruk Nipis - belah 2
1. Ambil 4 helai Daun Salam
1. Sediakan 2 sdm Garam
1. Siapkan  Bumbu Halus :
1. Sediakan 15 Cabai merah keriting
1. Ambil 7 Cabai rawit merah
1. Sediakan 10 btr Bawang merah
1. Siapkan 4 btr Bawang Putih
1. Siapkan 6 btr Kemiri,sangrai
1. Ambil  Bumbu yang ditumis:
1. Gunakan 7 btr Bawang merah iris serong rada tebel ( untuk textur)
1. Gunakan Sesuai Selera Garam,Kaldu bubuk,Gula Pasir,Kecap




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Babat Gongso ala Semarang - akhirnya dapet rasa yg paling nampol buatku ;):

1. Bersihkan babat,Presto kurleb 20 menit.beri air scukupnya,potongan jeruk nipis+daun salam+garam Note: pilih babat yg FRESH,kenyal,baunya normal,pasti seger nanti jadinya.
1. Tiriskan,Potong2 sesuai selera.kalo aku rada gede2 motongnya..kalo pengen ky bapak2 babat ya kecil2 bingit..
1. Tiriskan,Potong2 sesuai selera.kalo aku rada gede2 motongnya..kalo pengen ky bapak2 babat ya kecil2 bingit..
1. Tumis minyak bersama Bawang merah yg uda dpotong kasar,minyak banyakkin ya soalnya nanti masuk bumbu Halus) Tumis sampai harum aja jangan tumis lama2..
1. Masukkan gula,kecap,garam,kaldu masako sesuai selera..masukkan babat.. aduk2 terus.. tambahkan air skitar 100cc+supaya juga bumbu ga mengerak di dasar wajan.
1. Setelah keliatan tercampur+sedap,matikan api.(jangan tumis terlalu lama soale babat uda empuk,bumbu gampang merasuk)angkat,sajikan dengan Nasi hangat,bawang merah goreng+krupuk..mantap jaya..
1. Hihi sampe nambah 2x enak bingit XD puas banget biasa kalo beli di bapak lewat rumah babatnya di itung per Slice,ini jadinya banyakk. Hahaha..
1. 
1. Pedesss,nampol..#tisue mana tisue.. wkwkw..
1. 




Bagaimana? Mudah bukan? Itulah cara menyiapkan babat gongso ala semarang - akhirnya dapet rasa yg paling nampol buatku ;) yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
