---
description: "Bahan Gongso Babat Paru Sapi | Cara Masak Gongso Babat Paru Sapi Yang Paling Enak"
title: "Bahan Gongso Babat Paru Sapi | Cara Masak Gongso Babat Paru Sapi Yang Paling Enak"
slug: 306-bahan-gongso-babat-paru-sapi-cara-masak-gongso-babat-paru-sapi-yang-paling-enak
date: 2020-09-04T23:08:51.189Z
image: https://img-global.cpcdn.com/recipes/d2cbd470a1ee9cf7/751x532cq70/gongso-babat-paru-sapi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d2cbd470a1ee9cf7/751x532cq70/gongso-babat-paru-sapi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d2cbd470a1ee9cf7/751x532cq70/gongso-babat-paru-sapi-foto-resep-utama.jpg
author: Francis Frank
ratingvalue: 3
reviewcount: 9
recipeingredient:
- " Babat Sapi"
- " Paru Sapi"
- "1 cm Jahe Geprek"
- "1 cm Lengkuas Geprek"
- "2 Lembar Daun Jeruk"
- "2 Sdm Kecap Manis"
- "Secukupnya Garam"
- "Secukupnya Gula Pasir"
- "Secukupnya Penyedap Rasa"
- " Bumbu Halus"
- "2 Butir Kemiri"
- "4 Buah Cabe Rawit"
- "4 Buah Cabe Merah Keriting"
- "4 Siung bawang Merah"
- "2 Siung Bawang Putih"
- " Sayuran"
- " Kol optional"
recipeinstructions:
- "Rebus babat dan paru hingga empuk"
- "Tumis bumbu halus, jahe, lengkuas, daun jeruk"
- "Beri sedikit air,kemudian masukkan kol"
- "Jika kol sudah mulai layu, tambahkan kecap manis, garam, gula, penyedap rasa"
- "Koreksi rasa, lalu masukkan babat dan paru"
- "Aduk hingga bumbu tercampur merata dan air menyusut"
- "Angkat dan sajikan"
categories:
- Resep
tags:
- gongso
- babat
- paru

katakunci: gongso babat paru 
nutrition: 232 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Lunch

---


![Gongso Babat Paru Sapi](https://img-global.cpcdn.com/recipes/d2cbd470a1ee9cf7/751x532cq70/gongso-babat-paru-sapi-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep gongso babat paru sapi yang Lezat Sekali? Cara menyiapkannya memang tidak susah dan tidak juga mudah. apabila keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso babat paru sapi yang enak harusnya sih memiliki aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso babat paru sapi, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tak perlu pusing kalau mau menyiapkan gongso babat paru sapi enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan istimewa.




Di bawah ini ada beberapa cara mudah dan praktis untuk membuat gongso babat paru sapi yang siap dikreasikan. Anda bisa menyiapkan Gongso Babat Paru Sapi menggunakan 17 bahan dan 7 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Gongso Babat Paru Sapi:

1. Gunakan  Babat Sapi
1. Ambil  Paru Sapi
1. Siapkan 1 cm Jahe Geprek
1. Gunakan 1 cm Lengkuas Geprek
1. Gunakan 2 Lembar Daun Jeruk
1. Siapkan 2 Sdm Kecap Manis
1. Gunakan Secukupnya Garam
1. Sediakan Secukupnya Gula Pasir
1. Sediakan Secukupnya Penyedap Rasa
1. Sediakan  Bumbu Halus
1. Gunakan 2 Butir Kemiri
1. Ambil 4 Buah Cabe Rawit
1. Ambil 4 Buah Cabe Merah Keriting
1. Gunakan 4 Siung bawang Merah
1. Gunakan 2 Siung Bawang Putih
1. Sediakan  Sayuran
1. Siapkan  Kol (optional)




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso Babat Paru Sapi:

1. Rebus babat dan paru hingga empuk
1. Tumis bumbu halus, jahe, lengkuas, daun jeruk
1. Beri sedikit air,kemudian masukkan kol
1. Jika kol sudah mulai layu, tambahkan kecap manis, garam, gula, penyedap rasa
1. Koreksi rasa, lalu masukkan babat dan paru
1. Aduk hingga bumbu tercampur merata dan air menyusut
1. Angkat dan sajikan




Bagaimana? Mudah bukan? Itulah cara membuat gongso babat paru sapi yang bisa Anda praktikkan di rumah. Selamat mencoba!
