---
description: "Bahan Gongso Tahu Ati Ampela | Resep Bumbu Gongso Tahu Ati Ampela Yang Enak Dan Lezat"
title: "Bahan Gongso Tahu Ati Ampela | Resep Bumbu Gongso Tahu Ati Ampela Yang Enak Dan Lezat"
slug: 261-bahan-gongso-tahu-ati-ampela-resep-bumbu-gongso-tahu-ati-ampela-yang-enak-dan-lezat
date: 2020-11-25T00:52:38.541Z
image: https://img-global.cpcdn.com/recipes/50bcd2527176ae55/751x532cq70/gongso-tahu-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/50bcd2527176ae55/751x532cq70/gongso-tahu-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/50bcd2527176ae55/751x532cq70/gongso-tahu-ati-ampela-foto-resep-utama.jpg
author: Mattie Bridges
ratingvalue: 3.8
reviewcount: 5
recipeingredient:
- " ati ampela"
- " tahu putih besar potongpotong"
- " bawang merah"
- " bawang putih"
- " daun bawang"
- " gula merah"
- " kecap manis"
- " garam dan kaldu bubuk"
- " air"
- " Bumbu ungkep "
- " bawang merah"
- " bawang putih"
- " jahe geprek"
- " kunyit bakar geprek"
- " ketumbar bubuk"
- " daun salam"
- " serai"
- " Bumbu halus"
- " cabai merah keriting"
- " bawang putih"
- " bawang merah"
- " kunyit bakar"
recipeinstructions:
- "Rebus ati ampela dengan bumbu ungkep biarkan meresap sisihkan. Setelah dingin potong kecil. Goreng tahu sisihkan"
- "Tumis bawang putih, bawang merah, daun bawang kemudian masukkan ati ampela tumis sampai agak kering. angkat sisihkan"
- "Haluskan bumbu halus saya di blender saja kemudian tumis sampai bumbu matang"
- "Masukkan ati ampela, tahu kemudian tuang air beri kecap manis bumbui dengan gula garam dan kaldu bubuk aduk rata."
- "Masak api sedang saja tunggu bumbu meresap koreksi rasa angkat sajikan. Saya bikin yang kering atau kalau suka yang berkuah boleh saja."
categories:
- Resep
tags:
- gongso
- tahu
- ati

katakunci: gongso tahu ati 
nutrition: 268 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Lunch

---


![Gongso Tahu Ati Ampela](https://img-global.cpcdn.com/recipes/50bcd2527176ae55/751x532cq70/gongso-tahu-ati-ampela-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep gongso tahu ati ampela yang Paling Enak? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. bila salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso tahu ati ampela yang enak selayaknya punya aroma dan rasa yang mampu memancing selera kita.

Halodoc, Jakarta - Ati ampela merupakan bagian jeroan alias organ pencernaan ayam yang sering diolah menjadi makanan. Lantas, apakah jeroan ati ampela hanya memiliki kandungan yang berbahaya saja? Agar lebih jelas, yuk cari tahu fakta kandungan nutrisi yang.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso tahu ati ampela, mulai dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tidak usah pusing jika ingin menyiapkan gongso tahu ati ampela yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian spesial.


Nah, kali ini kita coba, yuk, kreasikan gongso tahu ati ampela sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Gongso Tahu Ati Ampela menggunakan 22 jenis bahan dan 5 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Gongso Tahu Ati Ampela:

1. Siapkan  ati ampela
1. Gunakan  tahu putih besar potong-potong
1. Siapkan  bawang merah
1. Ambil  bawang putih
1. Gunakan  daun bawang
1. Ambil  gula merah
1. Ambil  kecap manis
1. Ambil  garam dan kaldu bubuk
1. Siapkan  air
1. Ambil  Bumbu ungkep :
1. Siapkan  bawang merah
1. Sediakan  bawang putih
1. Siapkan  jahe geprek
1. Sediakan  kunyit bakar geprek
1. Sediakan  ketumbar bubuk
1. Ambil  daun salam
1. Siapkan  serai
1. Gunakan  Bumbu halus:
1. Sediakan  cabai merah keriting
1. Siapkan  bawang putih
1. Siapkan  bawang merah
1. Gunakan  kunyit bakar


Sebelum mengolah ati ampela, anda tentu harus membersihkannya terlebih dahulu agar masakan yang anda buat lebih higenis dan sehat. MASAKAN serba gongso mempunyai penampilan dan cita rasa khas. Selain daging ayam, bahan lain seperti babat iso, ati ampela dan telur juga cocok dimasak gongso. Sebelum dimasak, aneka bahan ini dimasak bacem dulu dengan bumbu-bumbu bacem. 

<!--inarticleads2-->

##### Cara membuat Gongso Tahu Ati Ampela:

1. Rebus ati ampela dengan bumbu ungkep biarkan meresap sisihkan. Setelah dingin potong kecil. Goreng tahu sisihkan
1. Tumis bawang putih, bawang merah, daun bawang kemudian masukkan ati ampela tumis sampai agak kering. angkat sisihkan
1. Haluskan bumbu halus saya di blender saja kemudian tumis sampai bumbu matang
1. Masukkan ati ampela, tahu kemudian tuang air beri kecap manis bumbui dengan gula garam dan kaldu bubuk aduk rata.
1. Masak api sedang saja tunggu bumbu meresap koreksi rasa angkat sajikan. Saya bikin yang kering atau kalau suka yang berkuah boleh saja.


Masak Gongso Ati Ampela Ayam - Resep Bunda Nina. Kuncinya yaitu merebus ati ampela dengan rempah-rempah aromatik. Karena ati ampela bisa mengeras bila dimasak terlalu lama, sebelum mengolahnya kamu harus pastikan untuk menumis racikan bumbu halus sampai benar-benar matang dan tidak berbau langu. Aduk ati ampela dengan minyak goreng, lalu tusuk selang seling antara hati dan ampela dengan menggunakan tusuk sate. Panggang di atas bara api yang panas sampai matang dan angkat. 

Bagaimana? Gampang kan? Itulah cara membuat gongso tahu ati ampela yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
