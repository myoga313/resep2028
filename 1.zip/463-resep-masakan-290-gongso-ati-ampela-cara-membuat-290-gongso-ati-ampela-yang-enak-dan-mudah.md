---
description: "Resep masakan 290. Gongso Ati Ampela | Cara Membuat 290. Gongso Ati Ampela Yang Enak Dan Mudah"
title: "Resep masakan 290. Gongso Ati Ampela | Cara Membuat 290. Gongso Ati Ampela Yang Enak Dan Mudah"
slug: 463-resep-masakan-290-gongso-ati-ampela-cara-membuat-290-gongso-ati-ampela-yang-enak-dan-mudah
date: 2020-11-05T14:30:29.777Z
image: https://img-global.cpcdn.com/recipes/6f4de9049109358f/751x532cq70/290-gongso-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6f4de9049109358f/751x532cq70/290-gongso-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6f4de9049109358f/751x532cq70/290-gongso-ati-ampela-foto-resep-utama.jpg
author: Alex Dunn
ratingvalue: 3.3
reviewcount: 4
recipeingredient:
- "6 pasang ati ampela"
- "2 sdm kecap manis"
- "2 lb daun jeruk"
- "1 btg serai"
- "1 lb daun salam"
- " Gula garam penyedap jamur"
- "secukupnya Cabe rawit"
- "Secukupnya air"
- " Bumbu dihaluskan "
- "6 btr bawang merah"
- "4 siung bawang putih"
- "5 bh cabe keriting"
- "5 bh cabe rawit orange"
recipeinstructions:
- "Rebus ati ampela yg sdh dibersihkan, tiriskan potong2 sesuai selera"
- "Tumis bumbu halus hingga bumbu tanak, tambahakan bumbu daun salam, daun jeruk, serai, beri kecap manis"
- "Tambahkan air secukupnya, beri bumbu perasa, tuang ati ampelanya"
- "Masak hingga air asat dan bumbu menyerap, beri tambahan cabe rawit"
categories:
- Resep
tags:
- 290
- gongso
- ati

katakunci: 290 gongso ati 
nutrition: 150 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Dinner

---


![290. Gongso Ati Ampela](https://img-global.cpcdn.com/recipes/6f4de9049109358f/751x532cq70/290-gongso-ati-ampela-foto-resep-utama.jpg)

Sedang mencari ide resep 290. gongso ati ampela yang Mudah Dan Praktis? Cara menyiapkannya memang susah-susah gampang. misalnya salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal 290. gongso ati ampela yang enak selayaknya memiliki aroma dan cita rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari 290. gongso ati ampela, mulai dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tak perlu pusing kalau mau menyiapkan 290. gongso ati ampela enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian spesial.




Berikut ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah 290. gongso ati ampela yang siap dikreasikan. Anda bisa membuat 290. Gongso Ati Ampela memakai 13 bahan dan 4 tahap pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan 290. Gongso Ati Ampela:

1. Sediakan 6 pasang ati ampela
1. Sediakan 2 sdm kecap manis
1. Sediakan 2 lb daun jeruk
1. Siapkan 1 btg serai
1. Sediakan 1 lb daun salam
1. Gunakan  Gula, garam, penyedap jamur
1. Ambil secukupnya Cabe rawit
1. Sediakan Secukupnya air
1. Ambil  Bumbu dihaluskan :
1. Siapkan 6 btr bawang merah
1. Gunakan 4 siung bawang putih
1. Gunakan 5 bh cabe keriting
1. Gunakan 5 bh cabe rawit orange




<!--inarticleads2-->

##### Langkah-langkah membuat 290. Gongso Ati Ampela:

1. Rebus ati ampela yg sdh dibersihkan, tiriskan potong2 sesuai selera
1. Tumis bumbu halus hingga bumbu tanak, tambahakan bumbu daun salam, daun jeruk, serai, beri kecap manis
1. Tambahkan air secukupnya, beri bumbu perasa, tuang ati ampelanya
1. Masak hingga air asat dan bumbu menyerap, beri tambahan cabe rawit




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan 290. Gongso Ati Ampela yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman maupun menjadi inspirasi dalam berjualan makanan. Semoga bermanfaat dan selamat mencoba!
