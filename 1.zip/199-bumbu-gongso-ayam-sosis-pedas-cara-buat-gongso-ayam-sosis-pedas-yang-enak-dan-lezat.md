---
description: "Bumbu Gongso ayam sosis pedas | Cara Buat Gongso ayam sosis pedas Yang Enak Dan Lezat"
title: "Bumbu Gongso ayam sosis pedas | Cara Buat Gongso ayam sosis pedas Yang Enak Dan Lezat"
slug: 199-bumbu-gongso-ayam-sosis-pedas-cara-buat-gongso-ayam-sosis-pedas-yang-enak-dan-lezat
date: 2020-08-26T09:46:09.569Z
image: https://img-global.cpcdn.com/recipes/9ca38b260eba0762/751x532cq70/gongso-ayam-sosis-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9ca38b260eba0762/751x532cq70/gongso-ayam-sosis-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9ca38b260eba0762/751x532cq70/gongso-ayam-sosis-pedas-foto-resep-utama.jpg
author: Marie Nguyen
ratingvalue: 4.3
reviewcount: 5
recipeingredient:
- "100 gram daging ayam potong"
- "5 sosis ayam"
- "Secukupnya sawi hijau kubis"
- "2 siung bawang putih"
- "Secukupnya cabe"
- "Secukupnya merica bubuk"
- "Secukupnya garam"
- "Secukupnya kecap manis"
- "Secukupnya penyedap"
- "Secukupnya saos sambal"
- "2-3 sdm Minyak goreng"
- "Secukupnya air"
- "  sesuai selera"
recipeinstructions:
- "Bismillahirrohmaanirrohiim 😆"
- "Rebus daging ayam 5-10 menit. Tiriskan dan potong-potong kecil*."
- "Sambil menunggu langkah 2, tumbuk bawang putih, beberapa cabe, bubuk merica, dan garam hingga halus. Kemudian iris melintang sosis dan potong-potong sayuran."
- "Tuangkan minyak ke wajan. Tumis bumbu yang sudah ditumbuk halus. Aduk rata."
- "Tuangkan saos, dan sedikit air. Tambahkan ayam, kemudian sosis. Aduk hingga mendidih."
- "Tambahkan air secukupnya, tambahkan garam, kecap, dan penyedap sesuai selera. Aduk rata."
- "Tambahkan sayuran dan cabe yang diiris*. Aduk rata."
- "Icip-icip😋. Tes rasa kalau masih ada yg perlu ditambahkan, bisa tambahkan sampai oke di lidah 😂"
- "Siap disantap. Jangan lupa berdoa sebelum makan yak😂😍"
categories:
- Resep
tags:
- gongso
- ayam
- sosis

katakunci: gongso ayam sosis 
nutrition: 215 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Dessert

---


![Gongso ayam sosis pedas](https://img-global.cpcdn.com/recipes/9ca38b260eba0762/751x532cq70/gongso-ayam-sosis-pedas-foto-resep-utama.jpg)

Sedang mencari ide resep gongso ayam sosis pedas yang Lezat Sekali? Cara Bikinnya memang susah-susah gampang. andaikan salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gongso ayam sosis pedas yang enak selayaknya punya aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ayam sosis pedas, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tak perlu pusing kalau mau menyiapkan gongso ayam sosis pedas enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan spesial.

Hai Kancakenthel semua, di manapun Anda berada, semoga sehat-sehat saja dan jangan lupa memasak. Lihat juga resep Gongso Ayam ala Semarangan enak lainnya. Gongso dalam bahasa Jawa artinya adalah ditumis dalam waktu yang agak lama.


Berikut ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah gongso ayam sosis pedas yang siap dikreasikan. Anda dapat menyiapkan Gongso ayam sosis pedas memakai 13 jenis bahan dan 9 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Gongso ayam sosis pedas:

1. Gunakan 100 gram daging ayam potong
1. Sediakan 5 sosis ayam*
1. Siapkan Secukupnya sawi hijau, kubis*
1. Ambil 2 siung bawang putih
1. Sediakan Secukupnya cabe*
1. Siapkan Secukupnya merica bubuk
1. Ambil Secukupnya garam
1. Ambil Secukupnya kecap manis
1. Siapkan Secukupnya penyedap
1. Sediakan Secukupnya saos sambal
1. Sediakan 2-3 sdm Minyak goreng
1. Sediakan Secukupnya air
1. Gunakan  &gt; *sesuai selera


Kenampakannya gelap dan citarasanya manis mirip dengan semur yang berkuah sedikit. MASAKAN serba gongso mempunyai penampilan dan cita rasa khas. Selain daging ayam, bahan lain seperti babat iso, ati ampela dan telur juga cocok dimasak gongso. Sebelum dimasak, aneka bahan ini dimasak bacem dulu dengan bumbu-bumbu bacem. 

<!--inarticleads2-->

##### Cara membuat Gongso ayam sosis pedas:

1. Bismillahirrohmaanirrohiim 😆
1. Rebus daging ayam 5-10 menit. Tiriskan dan potong-potong kecil*.
1. Sambil menunggu langkah 2, tumbuk bawang putih, beberapa cabe, bubuk merica, dan garam hingga halus. Kemudian iris melintang sosis dan potong-potong sayuran.
1. Tuangkan minyak ke wajan. Tumis bumbu yang sudah ditumbuk halus. Aduk rata.
1. Tuangkan saos, dan sedikit air. Tambahkan ayam, kemudian sosis. Aduk hingga mendidih.
1. Tambahkan air secukupnya, tambahkan garam, kecap, dan penyedap sesuai selera. Aduk rata.
1. Tambahkan sayuran dan cabe yang diiris*. Aduk rata.
1. Icip-icip😋. Tes rasa kalau masih ada yg perlu ditambahkan, bisa tambahkan sampai oke di lidah 😂
1. Siap disantap. Jangan lupa berdoa sebelum makan yak😂😍


Tika dan Firda berkesempatan menjajal gongso pedas babat, gongso pedas ceker, gongso pedas iga, dan gongso pedas ayam. Nah seperti apa review makanan mereka? Simak selengkapnya dalam video di atas. (*) ARTIKEL POPULER: Ditanya Pilih Jokowi atau Prabowo, Begini Jawaban dan Saran. Babat Gongso Terenak di Semarang - Super Pedas Manis Mantap Jiwa. Gongso Ayam Super Pedas Indo Street Food. 

Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Gongso ayam sosis pedas yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman maupun menjadi ide dalam berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
