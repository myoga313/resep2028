---
description: "Olahan Gongso Bakso Pedas | Langkah Membuat Gongso Bakso Pedas Yang Enak dan Simpel"
title: "Olahan Gongso Bakso Pedas | Langkah Membuat Gongso Bakso Pedas Yang Enak dan Simpel"
slug: 173-olahan-gongso-bakso-pedas-langkah-membuat-gongso-bakso-pedas-yang-enak-dan-simpel
date: 2020-11-20T05:26:42.581Z
image: https://img-global.cpcdn.com/recipes/2534043_623064d59ca3892e/751x532cq70/gongso-bakso-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2534043_623064d59ca3892e/751x532cq70/gongso-bakso-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2534043_623064d59ca3892e/751x532cq70/gongso-bakso-pedas-foto-resep-utama.jpg
author: Lillian Curry
ratingvalue: 4
reviewcount: 13
recipeingredient:
- "10 butir Bakso sapi  iris bagi 3"
- "2 butir Sosis sapi  iris serong"
- "1 butir Telur ayam  kocok lepas"
- "5 lbr Daun sawi hijau"
- "1/2 buah Bawang bombay  cincang halus"
- "2 siung Bawang putih  cincang halus"
- "1 Siung Bawang merah  iris tipis"
- "5 buah Cabai domba  iris tipis"
- "1 batang Daun Bawang  iris serong"
- "2 sdt Kaldu ayam"
- "1/2 sdt Merica bubuk"
- "1 sdt Gula pasir"
- "3 sdm kecap manis"
- "1 sdm Saus tiram"
- "2 sdm Saus sambal"
- "250 ml Air"
- "3 sdm Minyak goreng"
recipeinstructions:
- "Panaskan minyak goreng, tumis bawang putih, bawang merah, bawang bombay dan cabai sampai harum. sisihkan samping"
- "Masukkan telur kemudian orak arik, tambahkan bakso dan sosis aduk sampai merata dengan bumbu"
- "Tambahkan air, bumbui dg kaldu bubuk, gula pasir, merica bubuk, kecap manis, saus sambal dan saus tiram. Tunggu sampai air mendidih"
- "Masukkan daun sawi hijau, aduk-aduk dan masak sampai matang. Matikan kompor, dan siap disajikan."
categories:
- Resep
tags:
- gongso
- bakso
- pedas

katakunci: gongso bakso pedas 
nutrition: 211 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT30M"
recipeyield: "1"
recipecategory: Dinner

---


![Gongso Bakso Pedas](https://img-global.cpcdn.com/recipes/2534043_623064d59ca3892e/751x532cq70/gongso-bakso-pedas-foto-resep-utama.jpg)

Anda sedang mencari ide resep gongso bakso pedas yang Mudah Dan Praktis? Cara membuatnya memang tidak susah dan tidak juga mudah. bila keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gongso bakso pedas yang enak selayaknya punya aroma dan cita rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso bakso pedas, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tak perlu pusing jika hendak menyiapkan gongso bakso pedas enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.




Di bawah ini ada beberapa tips dan trik praktis untuk membuat gongso bakso pedas yang siap dikreasikan. Anda dapat menyiapkan Gongso Bakso Pedas menggunakan 17 bahan dan 4 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Gongso Bakso Pedas:

1. Ambil 10 butir Bakso sapi - iris bagi 3
1. Sediakan 2 butir Sosis sapi - iris serong
1. Sediakan 1 butir Telur ayam - kocok lepas
1. Siapkan 5 lbr Daun sawi hijau
1. Gunakan 1/2 buah Bawang bombay - cincang halus
1. Ambil 2 siung Bawang putih - cincang halus
1. Sediakan 1 Siung Bawang merah - iris tipis
1. Sediakan 5 buah Cabai domba - iris tipis
1. Sediakan 1 batang Daun Bawang - iris serong
1. Sediakan 2 sdt Kaldu ayam
1. Siapkan 1/2 sdt Merica bubuk
1. Gunakan 1 sdt Gula pasir
1. Siapkan 3 sdm kecap manis
1. Sediakan 1 sdm Saus tiram
1. Gunakan 2 sdm Saus sambal
1. Siapkan 250 ml Air
1. Sediakan 3 sdm Minyak goreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso Bakso Pedas:

1. Panaskan minyak goreng, tumis bawang putih, bawang merah, bawang bombay dan cabai sampai harum. sisihkan samping
1. Masukkan telur kemudian orak arik, tambahkan bakso dan sosis aduk sampai merata dengan bumbu
1. Tambahkan air, bumbui dg kaldu bubuk, gula pasir, merica bubuk, kecap manis, saus sambal dan saus tiram. Tunggu sampai air mendidih
1. Masukkan daun sawi hijau, aduk-aduk dan masak sampai matang. Matikan kompor, dan siap disajikan.




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan Gongso Bakso Pedas yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman ataupun menjadi inspirasi dalam berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
