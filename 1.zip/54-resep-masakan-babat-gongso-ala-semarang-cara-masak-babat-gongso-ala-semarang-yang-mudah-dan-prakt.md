---
description: "Resep masakan Babat Gongso ala Semarang | Cara Masak Babat Gongso ala Semarang Yang Mudah Dan Praktis"
title: "Resep masakan Babat Gongso ala Semarang | Cara Masak Babat Gongso ala Semarang Yang Mudah Dan Praktis"
slug: 54-resep-masakan-babat-gongso-ala-semarang-cara-masak-babat-gongso-ala-semarang-yang-mudah-dan-praktis
date: 2020-08-01T01:48:23.203Z
image: https://img-global.cpcdn.com/recipes/90e4e03b66adbe56/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/90e4e03b66adbe56/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/90e4e03b66adbe56/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg
author: Helen May
ratingvalue: 3.6
reviewcount: 14
recipeingredient:
- "1/2 kg babat sapi"
- "8 btr bawang merah"
- "2 btr bawang putih"
- "7 bh cabai merah keritingsesuai selera"
- "3 bh cabai rawit merahsesuai selera"
- "1 btr kemiri"
- "2-3 sdm kecap manissesuai selera"
- "1 sdm kecap asin1 sdt garam"
- "1 sdt kaldu jamurkaldu lainsesuai selera"
- "1/2 gelas air putih"
- "3-5 sdm minyak goreng untuk menumis"
recipeinstructions:
- "Siapkan semua bahan.. Cuci bersih babat, rebus hingga empuk, bisa dipresto atau pakai metode 5.30.7, potong/iris sesuai selera. Iris 5 btr bawang merah, sisanya haluskan bersama bawang putih+kemiri+cabai"
- "Panaskan minyak, goreng bawang merah hingga layu, masukkan bumbu halus, tumis hingga matang/agak kering, masukkan babat, aduk merata"
- "Tambahkan air+kecap manis+kecap asin/garam+kaldu jamur, aduk merata. Tunggu hingga air berkurang, cek rasa. Done.. Yuuk cobain"
categories:
- Resep
tags:
- babat
- gongso
- ala

katakunci: babat gongso ala 
nutrition: 246 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Dessert

---


![Babat Gongso ala Semarang](https://img-global.cpcdn.com/recipes/90e4e03b66adbe56/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg)

Bunda Sedang mencari ide resep babat gongso ala semarang yang Mudah Dan Praktis? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. andaikata salah mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal babat gongso ala semarang yang enak seharusnya memiliki aroma dan cita rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari babat gongso ala semarang, pertama dari jenis bahan, lalu pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tidak usah pusing kalau hendak menyiapkan babat gongso ala semarang yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian istimewa.


Nah, kali ini kita coba, yuk, buat babat gongso ala semarang sendiri di rumah. Tetap dengan bahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Babat Gongso ala Semarang memakai 11 jenis bahan dan 3 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Babat Gongso ala Semarang:

1. Sediakan 1/2 kg babat sapi
1. Ambil 8 btr bawang merah
1. Gunakan 2 btr bawang putih
1. Sediakan 7 bh cabai merah keriting/sesuai selera
1. Ambil 3 bh cabai rawit merah/sesuai selera
1. Siapkan 1 btr kemiri
1. Sediakan 2-3 sdm kecap manis/sesuai selera
1. Gunakan 1 sdm kecap asin/1 sdt garam
1. Siapkan 1 sdt kaldu jamur/kaldu lain/sesuai selera
1. Ambil 1/2 gelas air putih
1. Siapkan 3-5 sdm minyak goreng untuk menumis




<!--inarticleads2-->

##### Langkah-langkah membuat Babat Gongso ala Semarang:

1. Siapkan semua bahan.. Cuci bersih babat, rebus hingga empuk, bisa dipresto atau pakai metode 5.30.7, potong/iris sesuai selera. Iris 5 btr bawang merah, sisanya haluskan bersama bawang putih+kemiri+cabai
1. Panaskan minyak, goreng bawang merah hingga layu, masukkan bumbu halus, tumis hingga matang/agak kering, masukkan babat, aduk merata
1. Tambahkan air+kecap manis+kecap asin/garam+kaldu jamur, aduk merata. Tunggu hingga air berkurang, cek rasa. Done.. Yuuk cobain




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Babat Gongso ala Semarang yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman ataupun menjadi inspirasi untuk berjualan makanan. Selamat mencoba!
