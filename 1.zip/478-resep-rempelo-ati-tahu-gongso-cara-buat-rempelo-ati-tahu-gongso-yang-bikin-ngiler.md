---
description: "Resep Rempelo Ati Tahu Gongso | Cara Buat Rempelo Ati Tahu Gongso Yang Bikin Ngiler"
title: "Resep Rempelo Ati Tahu Gongso | Cara Buat Rempelo Ati Tahu Gongso Yang Bikin Ngiler"
slug: 478-resep-rempelo-ati-tahu-gongso-cara-buat-rempelo-ati-tahu-gongso-yang-bikin-ngiler
date: 2020-10-24T11:57:43.967Z
image: https://img-global.cpcdn.com/recipes/3e59deb502343af1/751x532cq70/rempelo-ati-tahu-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3e59deb502343af1/751x532cq70/rempelo-ati-tahu-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3e59deb502343af1/751x532cq70/rempelo-ati-tahu-gongso-foto-resep-utama.jpg
author: Etta Lane
ratingvalue: 3.4
reviewcount: 11
recipeingredient:
- "500 Gram Rempelo Ati ayam"
- "2 Papan Tahu"
- " Bahan Cemplung "
- "2 Daun Salam"
- "2 Daun Jeruk Purut"
- "2 Batang Sereh"
- "1 Ruas Jahe"
- " Bahan Halus "
- "4 Bawang Merah"
- "2 Bawang Putih"
- "2 Cabe Merah Buang Biji"
- "3 Cabe Rawit"
- "1 Ruas Kunyit  Kunyit Bubuk"
- "Secukupnya Minyak Goreng"
- "Secukupnya Gula Merah Garam Kecap Manis"
- "Secukupnya Kaldu Jamur"
- "Secukupnya Air"
recipeinstructions:
- "Pertama kita siapkan semua bahan, bersihkan cuci bersih ati ampela nya lalu rebus dg air dan tambahkan jahe, daun jeruk, daun salam, sereh dan sedikit garam. Lalu siapkan bahan lainnya"
- "Setelah ampela ati matang, iris sesuai selera lalu goreng, api sedang / kecil saja agar tidak meletup² kemana mana ampel ati yg di goreng."
- "Potong tahu kotak kotak / terserah mau dipotong seperti apa, goreng sampai kecoklatan dan sisihkan."
- "Panaskan wajan dan tumis bumbu yg sudah dihaluskan, tumis sampai matang lalu masukkan ati ampel yg sudah digoreng td, jangan lupa tambahkan kaldu jamur / masako jika suka. Lalu masukkan tahu dan tambahkan kecap, gongso sampai semua tercampur rata."
- "Terakhir tes rasa, jika dirasa sudah pas angkat dan sajikan."
categories:
- Resep
tags:
- rempelo
- ati
- tahu

katakunci: rempelo ati tahu 
nutrition: 141 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Dinner

---


![Rempelo Ati Tahu Gongso](https://img-global.cpcdn.com/recipes/3e59deb502343af1/751x532cq70/rempelo-ati-tahu-gongso-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep rempelo ati tahu gongso yang Menggugah Selera? Cara membuatnya memang tidak susah dan tidak juga mudah. Jika salah mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal rempelo ati tahu gongso yang enak seharusnya mempunyai aroma dan cita rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari rempelo ati tahu gongso, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan rempelo ati tahu gongso enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.




Di bawah ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah rempelo ati tahu gongso yang siap dikreasikan. Anda bisa membuat Rempelo Ati Tahu Gongso menggunakan 17 bahan dan 5 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Rempelo Ati Tahu Gongso:

1. Ambil 500 Gram Rempelo Ati ayam
1. Gunakan 2 Papan Tahu
1. Ambil  Bahan Cemplung 🌻
1. Ambil 2 Daun Salam
1. Sediakan 2 Daun Jeruk Purut
1. Gunakan 2 Batang Sereh
1. Ambil 1 Ruas Jahe
1. Gunakan  Bahan Halus 🌻
1. Gunakan 4 Bawang Merah
1. Siapkan 2 Bawang Putih
1. Siapkan 2 Cabe Merah (Buang Biji)
1. Ambil 3 Cabe Rawit
1. Gunakan 1 Ruas Kunyit / Kunyit Bubuk
1. Siapkan Secukupnya Minyak Goreng
1. Sediakan Secukupnya Gula Merah, Garam, Kecap Manis
1. Siapkan Secukupnya Kaldu Jamur
1. Sediakan Secukupnya Air




<!--inarticleads2-->

##### Langkah-langkah membuat Rempelo Ati Tahu Gongso:

1. Pertama kita siapkan semua bahan, bersihkan cuci bersih ati ampela nya lalu rebus dg air dan tambahkan jahe, daun jeruk, daun salam, sereh dan sedikit garam. Lalu siapkan bahan lainnya
1. Setelah ampela ati matang, iris sesuai selera lalu goreng, api sedang / kecil saja agar tidak meletup² kemana mana ampel ati yg di goreng.
1. Potong tahu kotak kotak / terserah mau dipotong seperti apa, goreng sampai kecoklatan dan sisihkan.
1. Panaskan wajan dan tumis bumbu yg sudah dihaluskan, tumis sampai matang lalu masukkan ati ampel yg sudah digoreng td, jangan lupa tambahkan kaldu jamur / masako jika suka. Lalu masukkan tahu dan tambahkan kecap, gongso sampai semua tercampur rata.
1. Terakhir tes rasa, jika dirasa sudah pas angkat dan sajikan.




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Harapan kami, olahan Rempelo Ati Tahu Gongso yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman ataupun menjadi inspirasi bagi Anda yang berkeinginan untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
