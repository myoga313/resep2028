---
description: "Bahan Ayam gongso | Resep Membuat Ayam gongso Yang Lezat Sekali"
title: "Bahan Ayam gongso | Resep Membuat Ayam gongso Yang Lezat Sekali"
slug: 165-bahan-ayam-gongso-resep-membuat-ayam-gongso-yang-lezat-sekali
date: 2020-10-31T01:08:26.953Z
image: https://img-global.cpcdn.com/recipes/96c44aa7fd28230c/751x532cq70/ayam-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/96c44aa7fd28230c/751x532cq70/ayam-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/96c44aa7fd28230c/751x532cq70/ayam-gongso-foto-resep-utama.jpg
author: Ivan Howell
ratingvalue: 3.9
reviewcount: 5
recipeingredient:
- "2 ptg ayam fillet fillet supermarket kurang tau brapa gram"
- "1 buah sosis bratwurst potong sesuai selera"
- "1/4 buah bombay iris tipis"
- "2 siung bawang putih iris tipis"
- "2 buah bawang merah iris tipis"
- "5 buah cabe rawit irishaluskan"
- "1/2 bungkus kaldu ayam bubuk masako"
- "1 sdt gula pasir"
- "1 sdm gula merah"
- "secukupnya Kecap"
- "1/2 sdt lada putih bubuk"
- "secukupnya Penyedap rasa"
- "secukupnya Air"
- " Minyak goreng untuk menumis"
- "1 buah tomat ukuran kecil Potong menjadi 4 bagian"
- "secukupnya Bawang goreng"
recipeinstructions:
- "Panaskan minyak, tumis bawang merah + bawang putih + cabe sampai harum"
- "Masukan ayam dan sosis yang telah di potong potong, aduk hingga rata"
- "Tambahkan bumbu masako,lada,penyedap rasa, gula merah, kecap dan gula pasir"
- "Aduk sampai bumbu menyerupai karamel"
- "Lalu tambahkan sedikit air agar bumbu bisa meresap ke daging ayam"
- "Masukan tomat yang sudah di potong, tumis sebentar saja agar tomat masih segar saat di sajikan"
- "Sajikan dengan taburan bawang goreng/daun bawang. Sesuai selera"
categories:
- Resep
tags:
- ayam
- gongso

katakunci: ayam gongso 
nutrition: 128 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam gongso](https://img-global.cpcdn.com/recipes/96c44aa7fd28230c/751x532cq70/ayam-gongso-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep ayam gongso yang Enak Dan Mudah? Cara Bikinnya memang susah-susah gampang. Jika keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal ayam gongso yang enak harusnya sih memiliki aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan ayam gongso yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.




Berikut ini ada beberapa tips dan trik praktis untuk membuat ayam gongso yang siap dikreasikan. Anda bisa membuat Ayam gongso menggunakan 16 bahan dan 7 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam gongso:

1. Gunakan 2 ptg ayam fillet (fillet supermarket) kurang tau brapa gram
1. Gunakan 1 buah sosis bratwurst (potong sesuai selera)
1. Siapkan 1/4 buah bombay (iris tipis)
1. Siapkan 2 siung bawang putih (iris tipis)
1. Gunakan 2 buah bawang merah (iris tipis)
1. Ambil 5 buah cabe rawit (iris/haluskan)
1. Siapkan 1/2 bungkus kaldu ayam bubuk (masako)
1. Gunakan 1 sdt gula pasir
1. Sediakan 1 sdm gula merah
1. Gunakan secukupnya Kecap
1. Sediakan 1/2 sdt lada putih bubuk
1. Ambil secukupnya Penyedap rasa
1. Gunakan secukupnya Air
1. Sediakan  Minyak goreng untuk menumis
1. Ambil 1 buah tomat ukuran kecil. Potong menjadi 4 bagian
1. Ambil secukupnya Bawang goreng




<!--inarticleads2-->

##### Cara membuat Ayam gongso:

1. Panaskan minyak, tumis bawang merah + bawang putih + cabe sampai harum
1. Masukan ayam dan sosis yang telah di potong potong, aduk hingga rata
1. Tambahkan bumbu masako,lada,penyedap rasa, gula merah, kecap dan gula pasir
1. Aduk sampai bumbu menyerupai karamel
1. Lalu tambahkan sedikit air agar bumbu bisa meresap ke daging ayam
1. Masukan tomat yang sudah di potong, tumis sebentar saja agar tomat masih segar saat di sajikan
1. Sajikan dengan taburan bawang goreng/daun bawang. Sesuai selera




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Ayam gongso yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman maupun menjadi ide untuk berjualan makanan. Selamat mencoba!
