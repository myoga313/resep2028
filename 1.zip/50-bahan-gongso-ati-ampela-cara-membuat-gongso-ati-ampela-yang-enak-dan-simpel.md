---
description: "Bahan Gongso Ati Ampela | Cara Membuat Gongso Ati Ampela Yang Enak dan Simpel"
title: "Bahan Gongso Ati Ampela | Cara Membuat Gongso Ati Ampela Yang Enak dan Simpel"
slug: 50-bahan-gongso-ati-ampela-cara-membuat-gongso-ati-ampela-yang-enak-dan-simpel
date: 2020-09-16T21:04:59.453Z
image: https://img-global.cpcdn.com/recipes/8785e6fff3e6573e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8785e6fff3e6573e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8785e6fff3e6573e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
author: Emma Sims
ratingvalue: 3
reviewcount: 6
recipeingredient:
- "5 pasang ati ampela"
- "3 siung bawang merah iris"
- "1 sdt garam"
- "1 sdm gula pasir"
- "1/2 sdt kunyit bubuk"
- "2 sdm kecap manis"
- "100 ml air"
- " Bumbu cemplung "
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 batang sereh geprek"
- "1 jempol jahe geprek"
- "1 jempol laos geprek"
- "1 sdt ketumbar bubuk"
- " Bumbu halus "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "5 buah cabe merah keriting"
- "3 buah cabe rawit"
recipeinstructions:
- "Rebus ati ampela dengan bumbu cemplung. Angkat &amp; tiriskan kemudian potong-potong"
- "Tumis irisan bawang merah hingga harum kemudian masukkan irisan ati ampela. Angkat &amp; sisihkan"
- "Tumis bumbu halus dengan minyak bekas menumis tadi hingga harum"
- "Masukkan air kemudian bumbui dengan garam, gula, kecap manis &amp; kunyit bubuk kemudian tes rasa. Masukkan ati ampela, masak sebentar hingga air menyusut agar bumbu meresap"
- "Gongso ati ampela siap disajikan ❤"
categories:
- Resep
tags:
- gongso
- ati
- ampela

katakunci: gongso ati ampela 
nutrition: 160 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Dessert

---


![Gongso Ati Ampela](https://img-global.cpcdn.com/recipes/8785e6fff3e6573e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep gongso ati ampela yang Paling Enak? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. seumpama keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso ati ampela yang enak harusnya sih memiliki aroma dan rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ati ampela, pertama dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menyajikannya. Tak perlu pusing jika hendak menyiapkan gongso ati ampela yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian istimewa.


Nah, kali ini kita coba, yuk, variasikan gongso ati ampela sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Gongso Ati Ampela memakai 19 jenis bahan dan 5 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Gongso Ati Ampela:

1. Gunakan 5 pasang ati ampela
1. Siapkan 3 siung bawang merah, iris
1. Gunakan 1 sdt garam
1. Ambil 1 sdm gula pasir
1. Sediakan 1/2 sdt kunyit bubuk
1. Ambil 2 sdm kecap manis
1. Siapkan 100 ml air
1. Gunakan  Bumbu cemplung :
1. Ambil 2 lembar daun salam
1. Sediakan 3 lembar daun jeruk
1. Siapkan 1 batang sereh, geprek
1. Siapkan 1 jempol jahe, geprek
1. Ambil 1 jempol laos, geprek
1. Gunakan 1 sdt ketumbar bubuk
1. Gunakan  Bumbu halus :
1. Gunakan 5 siung bawang merah
1. Ambil 3 siung bawang putih
1. Ambil 5 buah cabe merah keriting
1. Siapkan 3 buah cabe rawit




<!--inarticleads2-->

##### Cara membuat Gongso Ati Ampela:

1. Rebus ati ampela dengan bumbu cemplung. Angkat &amp; tiriskan kemudian potong-potong
1. Tumis irisan bawang merah hingga harum kemudian masukkan irisan ati ampela. Angkat &amp; sisihkan
1. Tumis bumbu halus dengan minyak bekas menumis tadi hingga harum
1. Masukkan air kemudian bumbui dengan garam, gula, kecap manis &amp; kunyit bubuk kemudian tes rasa. Masukkan ati ampela, masak sebentar hingga air menyusut agar bumbu meresap
1. Gongso ati ampela siap disajikan ❤




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Harapan kami, olahan Gongso Ati Ampela yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman maupun menjadi ide bagi Anda yang berkeinginan untuk berbisnis kuliner. Selamat mencoba!
