---
description: "Bahan Gongso ceker super pedas simple | Cara Membuat Gongso ceker super pedas simple Yang Lezat Sekali"
title: "Bahan Gongso ceker super pedas simple | Cara Membuat Gongso ceker super pedas simple Yang Lezat Sekali"
slug: 242-bahan-gongso-ceker-super-pedas-simple-cara-membuat-gongso-ceker-super-pedas-simple-yang-lezat-sekali
date: 2020-12-13T05:27:31.967Z
image: https://img-global.cpcdn.com/recipes/2873ca3e2942f2b3/751x532cq70/gongso-ceker-super-pedas-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2873ca3e2942f2b3/751x532cq70/gongso-ceker-super-pedas-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2873ca3e2942f2b3/751x532cq70/gongso-ceker-super-pedas-simple-foto-resep-utama.jpg
author: Allen Pratt
ratingvalue: 3.5
reviewcount: 15
recipeingredient:
- "1/4 kg ayam aku pakai ceker sayap kepala"
- "4 butir bawang merah"
- "2 butir bawang putih"
- "1/2 btr kemiri"
- "1 sct masako penyedap"
- "Secukupnya ketumbar bubuk"
- "1/4 gula jawa"
- "secukupnya Kecap manis"
- "sesuai selera Cabai"
- "secukupnya Air"
recipeinstructions:
- "Cuci bersih ayam lalu rebus hingga empuk"
- "Cuci semua bumbu lalu tumbuk halus bawang merah, bawang putih, ketumbar, kemiri, cabai"
- "Panaskan minyak, lalu tumis hingga harum bumbu halus. Lalu beri sedikit air, masukan masako, gula jawa, kecap manis aduk aduk. Lalu masukan ayam yg sudah empuk. Tutup sebentar cicipi jika sudah pas bisa disajikan 😊"
categories:
- Resep
tags:
- gongso
- ceker
- super

katakunci: gongso ceker super 
nutrition: 108 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Lunch

---


![Gongso ceker super pedas simple](https://img-global.cpcdn.com/recipes/2873ca3e2942f2b3/751x532cq70/gongso-ceker-super-pedas-simple-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep gongso ceker super pedas simple yang Lezat? Cara Bikinnya memang tidak susah dan tidak juga mudah. andaikan salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso ceker super pedas simple yang enak selayaknya mempunyai aroma dan cita rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ceker super pedas simple, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tak perlu pusing kalau hendak menyiapkan gongso ceker super pedas simple enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.




Nah, kali ini kita coba, yuk, ciptakan gongso ceker super pedas simple sendiri di rumah. Tetap berbahan sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Gongso ceker super pedas simple memakai 10 bahan dan 3 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Gongso ceker super pedas simple:

1. Ambil 1/4 kg ayam (aku pakai ceker, sayap, kepala)
1. Sediakan 4 butir bawang merah
1. Sediakan 2 butir bawang putih
1. Ambil 1/2 btr kemiri
1. Gunakan 1 sct masako (penyedap)
1. Ambil Secukupnya ketumbar bubuk
1. Siapkan 1/4 gula jawa
1. Ambil secukupnya Kecap manis
1. Siapkan sesuai selera Cabai
1. Sediakan secukupnya Air




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso ceker super pedas simple:

1. Cuci bersih ayam lalu rebus hingga empuk
1. Cuci semua bumbu lalu tumbuk halus bawang merah, bawang putih, ketumbar, kemiri, cabai
1. Panaskan minyak, lalu tumis hingga harum bumbu halus. Lalu beri sedikit air, masukan masako, gula jawa, kecap manis aduk aduk. Lalu masukan ayam yg sudah empuk. Tutup sebentar cicipi jika sudah pas bisa disajikan 😊




Gimana nih? Gampang kan? Itulah cara menyiapkan gongso ceker super pedas simple yang bisa Anda lakukan di rumah. Selamat mencoba!
