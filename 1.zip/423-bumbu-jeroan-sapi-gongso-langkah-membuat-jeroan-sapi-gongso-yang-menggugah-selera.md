---
description: "Bumbu Jeroan sapi gongso | Langkah Membuat Jeroan sapi gongso Yang Menggugah Selera"
title: "Bumbu Jeroan sapi gongso | Langkah Membuat Jeroan sapi gongso Yang Menggugah Selera"
slug: 423-bumbu-jeroan-sapi-gongso-langkah-membuat-jeroan-sapi-gongso-yang-menggugah-selera
date: 2020-10-24T15:40:12.533Z
image: https://img-global.cpcdn.com/recipes/8db5223ecc68bbf7/751x532cq70/jeroan-sapi-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8db5223ecc68bbf7/751x532cq70/jeroan-sapi-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8db5223ecc68bbf7/751x532cq70/jeroan-sapi-gongso-foto-resep-utama.jpg
author: Estelle Harmon
ratingvalue: 3.7
reviewcount: 12
recipeingredient:
- "250 gram jeroan sapi babat usus tetelan berlemakgajih"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 batang lengkuas geprek"
- "3 sdm gula merah"
- "3 sdm kecap manis"
- "6 sdm minyak goreng"
- "500 ml air"
- " Bumbu halus ulekblender "
- "6 buah bawang merah"
- "3 buah bawang putih"
- "5 buah cabe merah"
- "1 buah kemiri"
- "1 sdt lada bubuk"
- "1/2 ruas ibu jari jahe"
- "1/2 ruas ibu jari lengkuas"
- "1/2 sdt garam"
recipeinstructions:
- "Bersihkan, potong-potong lalu rebus jeroan sampai empuk (bisa dengan cara masing-masing agar tidak bau &amp; cepat empuk) saya masak jeroannya 30 menit dengan tambahan rempah seperti ketumbar, garam, lengkuas, jahe, asem jawa. Kemudian saya diamkan selama 2 jam. Lalu dimasak kembali dengan menggunakan air baru 15 menit."
- "Ulek/blender bumbu halus, kemudian siapkan rempah lainnya yang sudah dicuci bersih"
- "Tumis bumbu halus hingga harum, kemudian masukkan bahan lainnya &amp; tambahkan air, lalu masukkan jeroan. Tutup rapat panci, tunggu hingga mendidih lalu koreksi rasa"
- "Hidangkan selagi hangat"
categories:
- Resep
tags:
- jeroan
- sapi
- gongso

katakunci: jeroan sapi gongso 
nutrition: 177 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Dinner

---


![Jeroan sapi gongso](https://img-global.cpcdn.com/recipes/8db5223ecc68bbf7/751x532cq70/jeroan-sapi-gongso-foto-resep-utama.jpg)

Lagi mencari inspirasi resep jeroan sapi gongso yang Sedap? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. kalau salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal jeroan sapi gongso yang enak seharusnya punya aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari jeroan sapi gongso, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tak perlu pusing jika mau menyiapkan jeroan sapi gongso enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.

Tips Memasak Jeroan Biar Enggak Bau ala Fatmah Bahalwan dari NCC, Wajib Dipraktikan! Com - Tips Memasak Babat Gongso. Lihat juga resep Oseng Jeroan Sapi dan Kambing enak lainnya.


Berikut ini ada beberapa cara mudah dan praktis untuk membuat jeroan sapi gongso yang siap dikreasikan. Anda bisa menyiapkan Jeroan sapi gongso menggunakan 17 bahan dan 4 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Jeroan sapi gongso:

1. Gunakan 250 gram jeroan sapi (babat, usus, tetelan berlemak/gajih)
1. Sediakan 2 lembar daun salam
1. Siapkan 2 lembar daun jeruk
1. Ambil 1 batang lengkuas (geprek)
1. Gunakan 3 sdm gula merah
1. Ambil 3 sdm kecap manis
1. Siapkan 6 sdm minyak goreng
1. Sediakan 500 ml air
1. Ambil  Bumbu halus (ulek/blender) :
1. Siapkan 6 buah bawang merah
1. Gunakan 3 buah bawang putih
1. Ambil 5 buah cabe merah
1. Siapkan 1 buah kemiri
1. Sediakan 1 sdt lada bubuk
1. Siapkan 1/2 ruas ibu jari jahe
1. Gunakan 1/2 ruas ibu jari lengkuas
1. Siapkan 1/2 sdt garam


Babat gongso khas Semarang rasanya manis berkat penggunaan kecap. KOMPAS.com/Nabilla TashandraBabat gongso, salah satu menu andalan di Nasi Goreng Babat Pak Karmin di Jalan. Babat gongso merupakan jeroan sapi berupa babat yang dimasak dan disajikan dengan kuah Babat gongso yang terkenal di Semarang adalah babat gongso Pak Karmin yang terletak di Jl. ResepSimple #BabatGongso #AutoNgiler Babat, adalah jeroan sapi bertekstur unik yang dapat diolah menjadi banyak sajian. 

<!--inarticleads2-->

##### Langkah-langkah membuat Jeroan sapi gongso:

1. Bersihkan, potong-potong lalu rebus jeroan sampai empuk (bisa dengan cara masing-masing agar tidak bau &amp; cepat empuk) saya masak jeroannya 30 menit dengan tambahan rempah seperti ketumbar, garam, lengkuas, jahe, asem jawa. Kemudian saya diamkan selama 2 jam. Lalu dimasak kembali dengan menggunakan air baru 15 menit.
1. Ulek/blender bumbu halus, kemudian siapkan rempah lainnya yang sudah dicuci bersih
1. Tumis bumbu halus hingga harum, kemudian masukkan bahan lainnya &amp; tambahkan air, lalu masukkan jeroan. Tutup rapat panci, tunggu hingga mendidih lalu koreksi rasa
1. Hidangkan selagi hangat


Aku buatkan menu lain daripada yang lain GONGSO KOYOR SAPI. Babat Gongso Khas Semarang, Pedes, Manis, Gurih. RESEP Babat gongso menu masakan khas semarang yang super nikmat 

Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Jeroan sapi gongso yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman ataupun menjadi inspirasi untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
