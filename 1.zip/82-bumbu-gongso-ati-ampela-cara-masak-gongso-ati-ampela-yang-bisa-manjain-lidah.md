---
description: "Bumbu Gongso ati ampela | Cara Masak Gongso ati ampela Yang Bisa Manjain Lidah"
title: "Bumbu Gongso ati ampela | Cara Masak Gongso ati ampela Yang Bisa Manjain Lidah"
slug: 82-bumbu-gongso-ati-ampela-cara-masak-gongso-ati-ampela-yang-bisa-manjain-lidah
date: 2020-09-10T17:51:42.696Z
image: https://img-global.cpcdn.com/recipes/4fd9647657d529e7/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4fd9647657d529e7/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4fd9647657d529e7/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
author: Scott Cortez
ratingvalue: 3.8
reviewcount: 5
recipeingredient:
- "3 buah Ati ampela bersihkan"
- "1 batang Serai"
- "2 lembar daun jeruk"
- "1/3 sdt garam"
- "1 sdt Gula pasir skip"
- "1/2 sdt Kaldu bubuk skip"
- "1 sdm Kecap manis"
- "1 sdm Saos tiram"
- "1/2 gelas air matang"
- " Bahan iris "
- "3 siung Bawang merah"
- "2 siung Barang putih"
- "1 buah Cabe hijau besar me buang biji"
- "3 buah Cabe rawit skip"
recipeinstructions:
- "Rebus ati ampela hingga matang, tiriskan lalu potong2"
- "Tumis bahan iris hingga wangi, masukkan ati ampela. Aduk rata"
- "Beri air, kecap manis, saos tiram, garam, gula.Masak hingga kuah menyusut"
- "Angkat dan sajikan"
categories:
- Resep
tags:
- gongso
- ati
- ampela

katakunci: gongso ati ampela 
nutrition: 165 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Dessert

---


![Gongso ati ampela](https://img-global.cpcdn.com/recipes/4fd9647657d529e7/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg)

Lagi mencari inspirasi resep gongso ati ampela yang Lezat Sekali? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. jikalau keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal gongso ati ampela yang enak seharusnya mempunyai aroma dan rasa yang dapat memancing selera kita.

Brilio.net - Ati ampela merupakan salah satu bahan makanan yang banyak digemari. Meski masuk dalam kategori jeroan, makanan ini dipercaya memiliki kandungan yang baik bagi tubuh. Biasanya nasi goreng gongso disajikan dengan babat, tapi racikan Nasi Goreng Gongso Mas Kamto berbeda.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ati ampela, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menyajikannya. Tidak usah pusing jika ingin menyiapkan gongso ati ampela enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.


Di bawah ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah gongso ati ampela yang siap dikreasikan. Anda dapat menyiapkan Gongso ati ampela memakai 14 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Gongso ati ampela:

1. Siapkan 3 buah Ati ampela, bersihkan
1. Gunakan 1 batang Serai
1. Siapkan 2 lembar daun jeruk
1. Ambil 1/3 sdt garam
1. Ambil 1 sdt Gula pasir (skip)
1. Sediakan 1/2 sdt Kaldu bubuk (skip)
1. Ambil 1 sdm Kecap manis
1. Siapkan 1 sdm Saos tiram
1. Siapkan 1/2 gelas air matang
1. Ambil  Bahan iris :
1. Sediakan 3 siung Bawang merah
1. Ambil 2 siung Barang putih
1. Gunakan 1 buah Cabe hijau besar (me: buang biji)
1. Sediakan 3 buah Cabe rawit (skip)


Masak Gongso Ati Ampela Ayam Resep Bunda Nina. Nasi Amblas Karena Gongso Koyor Terganas. MASAKAN serba gongso mempunyai penampilan dan cita rasa khas. Selain daging ayam, bahan lain seperti babat iso, ati ampela dan telur juga cocok dimasak gongso. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso ati ampela:

1. Rebus ati ampela hingga matang, tiriskan lalu potong2
1. Tumis bahan iris hingga wangi, masukkan ati ampela. Aduk rata
1. Beri air, kecap manis, saos tiram, garam, gula.Masak hingga kuah menyusut
1. Angkat dan sajikan




Terima kasih telah membaca resep yang kami tampilkan di sini. Harapan kami, olahan Gongso ati ampela yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman ataupun menjadi inspirasi dalam berbisnis kuliner. Selamat mencoba!
