---
description: "Resep masakan Gongso ati ampla pedas | Cara Masak Gongso ati ampla pedas Yang Enak Dan Mudah"
title: "Resep masakan Gongso ati ampla pedas | Cara Masak Gongso ati ampla pedas Yang Enak Dan Mudah"
slug: 445-resep-masakan-gongso-ati-ampla-pedas-cara-masak-gongso-ati-ampla-pedas-yang-enak-dan-mudah
date: 2020-09-19T12:59:52.881Z
image: https://img-global.cpcdn.com/recipes/e90dbb9a393478e9/751x532cq70/gongso-ati-ampla-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e90dbb9a393478e9/751x532cq70/gongso-ati-ampla-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e90dbb9a393478e9/751x532cq70/gongso-ati-ampla-pedas-foto-resep-utama.jpg
author: Myrtle Roy
ratingvalue: 4.6
reviewcount: 3
recipeingredient:
- "10 pasang ati ampla"
- " Bumbu halus"
- "25 buah cabe rawit merahtergantung selera ya Bun"
- "10 cabe merah keriting"
- "2 buah cabe merah besar buang biji"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "1 ruas kunyit"
- " Bumbu cemplung"
- "5 lembar daun jeruk buang batang tengahnya"
- "Secukupnya lengkoas geprek"
- "4 lembar daun salam"
- "1 sdt lada bubuk"
- "4 sdm kecap manis"
- "Secukup nya garam"
- "Secukupnya kaldu bubuk"
- "1 sdt gula pasir"
- " Setngh gelas belimbing air"
- "Sedikit minyak untuk menumis"
recipeinstructions:
- "Bersihkan ati ampla lalu cuci dan rebus,beri sedikit garam,jeruk nipis dan sedikit kecap Inggris,rebus sampai matang dan sisihkan"
- "Panaskan minyak tumis bumbu halus sampai harum tambahkan bumbu cemplung aduk rata"
- "Masukkan ati ampla yg sudah direbus td,beri sedikit air,garam,gula pasir, penyedap rasa,lada dan kecap aduk rata"
- "Masak sampai matang dan sedikit kental lalu koreksi rasa,jika sudah pas dan matang segera angkat dan sajikan"
categories:
- Resep
tags:
- gongso
- ati
- ampla

katakunci: gongso ati ampla 
nutrition: 178 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT57M"
recipeyield: "1"
recipecategory: Lunch

---


![Gongso ati ampla pedas](https://img-global.cpcdn.com/recipes/e90dbb9a393478e9/751x532cq70/gongso-ati-ampla-pedas-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep gongso ati ampla pedas yang Paling Enak? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. semisal salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso ati ampla pedas yang enak seharusnya punya aroma dan rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ati ampla pedas, pertama dari jenis bahan, kemudian pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tak perlu pusing kalau mau menyiapkan gongso ati ampla pedas enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian spesial.


Di bawah ini ada beberapa tips dan trik praktis untuk membuat gongso ati ampla pedas yang siap dikreasikan. Anda bisa membuat Gongso ati ampla pedas menggunakan 19 bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Gongso ati ampla pedas:

1. Ambil 10 pasang ati ampla
1. Sediakan  Bumbu halus
1. Siapkan 25 buah cabe rawit merah(tergantung selera ya Bun)
1. Gunakan 10 cabe merah keriting
1. Sediakan 2 buah cabe merah besar buang biji
1. Gunakan 10 siung bawang merah
1. Sediakan 5 siung bawang putih
1. Sediakan 1 ruas kunyit
1. Siapkan  Bumbu cemplung
1. Sediakan 5 lembar daun jeruk buang batang tengahnya
1. Siapkan Secukupnya lengkoas geprek
1. Siapkan 4 lembar daun salam
1. Siapkan 1 sdt lada bubuk
1. Gunakan 4 sdm kecap manis
1. Gunakan Secukup nya garam
1. Sediakan Secukupnya kaldu bubuk
1. Siapkan 1 sdt gula pasir
1. Sediakan  Setngh gelas belimbing air
1. Siapkan Sedikit minyak untuk menumis




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso ati ampla pedas:

1. Bersihkan ati ampla lalu cuci dan rebus,beri sedikit garam,jeruk nipis dan sedikit kecap Inggris,rebus sampai matang dan sisihkan
1. Panaskan minyak tumis bumbu halus sampai harum tambahkan bumbu cemplung aduk rata
1. Masukkan ati ampla yg sudah direbus td,beri sedikit air,garam,gula pasir, penyedap rasa,lada dan kecap aduk rata
1. Masak sampai matang dan sedikit kental lalu koreksi rasa,jika sudah pas dan matang segera angkat dan sajikan




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Harapan kami, olahan Gongso ati ampla pedas yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman maupun menjadi inspirasi bagi Anda yang berkeinginan untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
