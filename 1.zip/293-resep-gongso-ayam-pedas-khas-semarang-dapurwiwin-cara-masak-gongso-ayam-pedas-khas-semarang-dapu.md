---
description: "Resep Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳 | Cara Masak Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳 Yang Mudah Dan Praktis"
title: "Resep Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳 | Cara Masak Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳 Yang Mudah Dan Praktis"
slug: 293-resep-gongso-ayam-pedas-khas-semarang-dapurwiwin-cara-masak-gongso-ayam-pedas-khas-semarang-dapurwiwin-yang-mudah-dan-praktis
date: 2020-10-11T07:14:50.911Z
image: https://img-global.cpcdn.com/recipes/805edecca99c9ca2/751x532cq70/gongso-ayam-pedas-khas-semarang-dapurwiwin-👩🏻🍳-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/805edecca99c9ca2/751x532cq70/gongso-ayam-pedas-khas-semarang-dapurwiwin-👩🏻🍳-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/805edecca99c9ca2/751x532cq70/gongso-ayam-pedas-khas-semarang-dapurwiwin-👩🏻🍳-foto-resep-utama.jpg
author: Lester Rogers
ratingvalue: 3.1
reviewcount: 3
recipeingredient:
- " Bahan"
- " ayam kampung suwirsuwir"
- " Cabe Rawit Setan"
- " Kobis"
- " Tomat"
- " Bawang Bombay"
- " Daun BawangLoncang"
- " lengkuas"
- " Kecap Manis"
- " Gula Garam"
- " Air"
- " Bahan Bumbu Halus"
- " Bawang Merah"
- " Bawang Putih"
- " Cabe Merah"
- " Kemiri"
recipeinstructions:
- "Siapkan bahan."
- "Uleg bumbu halus."
- "Suwir-suwir ayam sesuai selera, geprek lengkuas, cincang bombay, iris-iris (kobis, daun bawang, cabe merah, tomat)."
- "Tumis bombay cincang + bumbu halus hingga harum, masukkan ayam suwir, tambahkan air, kemudian kobis, daun bawang, tomat dan cabe rawit utuh."
- "Aduk-aduk sebentar tunggu hingga airnya meresap biar mantap, kemudian hidangkan."
categories:
- Resep
tags:
- gongso
- ayam
- pedas

katakunci: gongso ayam pedas 
nutrition: 261 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Dessert

---


![Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳](https://img-global.cpcdn.com/recipes/805edecca99c9ca2/751x532cq70/gongso-ayam-pedas-khas-semarang-dapurwiwin-👩🏻🍳-foto-resep-utama.jpg)

Lagi mencari ide resep gongso ayam pedas khas semarang #dapurwiwin 👩🏻‍🍳 yang Lezat Sekali? Cara membuatnya memang susah-susah gampang. misalnya keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso ayam pedas khas semarang #dapurwiwin 👩🏻‍🍳 yang enak harusnya sih punya aroma dan cita rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ayam pedas khas semarang #dapurwiwin 👩🏻‍🍳, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tidak usah pusing kalau ingin menyiapkan gongso ayam pedas khas semarang #dapurwiwin 👩🏻‍🍳 yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan istimewa.




Nah, kali ini kita coba, yuk, buat gongso ayam pedas khas semarang #dapurwiwin 👩🏻‍🍳 sendiri di rumah. Tetap berbahan sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳 menggunakan 16 jenis bahan dan 5 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳:

1. Sediakan  Bahan
1. Gunakan  ayam kampung (suwir-suwir)
1. Gunakan  Cabe Rawit Setan
1. Sediakan  Kobis
1. Gunakan  Tomat
1. Sediakan  Bawang Bombay
1. Ambil  Daun Bawang/Loncang
1. Sediakan  lengkuas
1. Siapkan  Kecap Manis
1. Siapkan  Gula Garam
1. Gunakan  Air
1. Siapkan  Bahan Bumbu Halus
1. Siapkan  Bawang Merah
1. Siapkan  Bawang Putih
1. Gunakan  Cabe Merah
1. Sediakan  Kemiri




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳:

1. Siapkan bahan.
1. Uleg bumbu halus.
1. Suwir-suwir ayam sesuai selera, geprek lengkuas, cincang bombay, iris-iris (kobis, daun bawang, cabe merah, tomat).
1. Tumis bombay cincang + bumbu halus hingga harum, masukkan ayam suwir, tambahkan air, kemudian kobis, daun bawang, tomat dan cabe rawit utuh.
1. Aduk-aduk sebentar tunggu hingga airnya meresap biar mantap, kemudian hidangkan.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳">



Bagaimana? Gampang kan? Itulah cara membuat gongso ayam pedas khas semarang #dapurwiwin 👩🏻‍🍳 yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
