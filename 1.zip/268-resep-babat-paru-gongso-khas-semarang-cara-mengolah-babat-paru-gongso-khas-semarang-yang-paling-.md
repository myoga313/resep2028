---
description: "Resep Babat Paru Gongso khas Semarang | Cara Mengolah Babat Paru Gongso khas Semarang Yang Paling Enak"
title: "Resep Babat Paru Gongso khas Semarang | Cara Mengolah Babat Paru Gongso khas Semarang Yang Paling Enak"
slug: 268-resep-babat-paru-gongso-khas-semarang-cara-mengolah-babat-paru-gongso-khas-semarang-yang-paling-enak
date: 2020-08-30T16:24:50.263Z
image: https://img-global.cpcdn.com/recipes/d79c3af7cd266475/751x532cq70/babat-paru-gongso-khas-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d79c3af7cd266475/751x532cq70/babat-paru-gongso-khas-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d79c3af7cd266475/751x532cq70/babat-paru-gongso-khas-semarang-foto-resep-utama.jpg
author: Irene Roberts
ratingvalue: 3.8
reviewcount: 9
recipeingredient:
- " Paru  Babat"
- " Daun Salam"
- " Daun Jeruk"
- " Serai"
- " Lengkuas"
- " Jahe geprek"
- " Bahan Halus"
- " Bawang Merah"
- " Bawang Putih"
- " Cabe Merah sesuai selera"
- " Cabe Rawit sesuaI selera"
- " Bumbu Masak"
- " Garam"
- " Gula"
- " Kecap Manis"
- " Minyak untuk menumis"
- " Penyedap Masakan Kaldu Jamur  Micin atau"
recipeinstructions:
- "Rebus/Presto daging Paru &amp; Babat agar empuk dengan daun salam, lengkuas &amp; daun serai. Jika sudah matang &amp; empuk tiriskan."
- "Haluskan (saya pakai blender) Bumbu² Halus dan sisakan 4 siung bawang merah untuk dicincang."
- "Panaskan minyak, masukan bawang merah yang sudah dicincang, jahe geprek, daun jeruk dan 1 batang serai sampai harum. Kemudian masukan bumbu halus, aduk² sampai matang baru tambahkan air dan kecap. Masukan paru &amp; babat, tambahkan garam, gula, bumbu penyedap. Koreksi rasa"
- "Masak sampe bumbu meresap dan air berkurang. Sajikan"
categories:
- Resep
tags:
- babat
- paru
- gongso

katakunci: babat paru gongso 
nutrition: 132 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dinner

---


![Babat Paru Gongso khas Semarang](https://img-global.cpcdn.com/recipes/d79c3af7cd266475/751x532cq70/babat-paru-gongso-khas-semarang-foto-resep-utama.jpg)

Sedang mencari ide resep babat paru gongso khas semarang yang Enak Banget? Cara membuatnya memang susah-susah gampang. kalau salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal babat paru gongso khas semarang yang enak seharusnya memiliki aroma dan rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat paru gongso khas semarang, mulai dari jenis bahan, kemudian pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tidak usah pusing kalau hendak menyiapkan babat paru gongso khas semarang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.




Berikut ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah babat paru gongso khas semarang yang siap dikreasikan. Anda bisa membuat Babat Paru Gongso khas Semarang menggunakan 17 bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Babat Paru Gongso khas Semarang:

1. Sediakan  Paru &amp; Babat
1. Ambil  Daun Salam
1. Siapkan  Daun Jeruk
1. Gunakan  Serai
1. Siapkan  Lengkuas
1. Ambil  Jahe (geprek)
1. Sediakan  Bahan Halus
1. Siapkan  Bawang Merah
1. Sediakan  Bawang Putih
1. Sediakan  Cabe Merah (sesuai selera)
1. Gunakan  Cabe Rawit (sesuaI selera)
1. Sediakan  Bumbu Masak
1. Ambil  Garam
1. Ambil  Gula
1. Sediakan  Kecap Manis
1. Sediakan  Minyak untuk menumis
1. Sediakan  Penyedap Masakan (Kaldu Jamur &amp; Micin) atau




<!--inarticleads2-->

##### Cara membuat Babat Paru Gongso khas Semarang:

1. Rebus/Presto daging Paru &amp; Babat agar empuk dengan daun salam, lengkuas &amp; daun serai. Jika sudah matang &amp; empuk tiriskan.
1. Haluskan (saya pakai blender) Bumbu² Halus dan sisakan 4 siung bawang merah untuk dicincang.
1. Panaskan minyak, masukan bawang merah yang sudah dicincang, jahe geprek, daun jeruk dan 1 batang serai sampai harum. Kemudian masukan bumbu halus, aduk² sampai matang baru tambahkan air dan kecap. Masukan paru &amp; babat, tambahkan garam, gula, bumbu penyedap. Koreksi rasa
1. Masak sampe bumbu meresap dan air berkurang. Sajikan




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Harapan kami, olahan Babat Paru Gongso khas Semarang yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman maupun menjadi inspirasi dalam berbisnis kuliner. Selamat mencoba!
