---
description: "Resep Ayam Tepung Gongso Pedas | Cara Bikin Ayam Tepung Gongso Pedas Yang Sempurna"
title: "Resep Ayam Tepung Gongso Pedas | Cara Bikin Ayam Tepung Gongso Pedas Yang Sempurna"
slug: 198-resep-ayam-tepung-gongso-pedas-cara-bikin-ayam-tepung-gongso-pedas-yang-sempurna
date: 2020-11-11T02:31:07.972Z
image: https://img-global.cpcdn.com/recipes/e35259d0626257b7/751x532cq70/ayam-tepung-gongso-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e35259d0626257b7/751x532cq70/ayam-tepung-gongso-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e35259d0626257b7/751x532cq70/ayam-tepung-gongso-pedas-foto-resep-utama.jpg
author: Darrell Estrada
ratingvalue: 4.5
reviewcount: 12
recipeingredient:
- "2 buah Fillet Dada Ayam"
- "1 butir Telur Ayam"
- "3 sdm Tepung bumbuTepung serbaguna"
- "1 buah Bawang bombay"
- "5 buah Cabe rawit"
- "1 sdt Saos tiram"
- "1/2 sdt Merica bubuk"
- "Secukupnya Garam"
- "Secukupnya Minyak goreng"
recipeinstructions:
- "Potong-potong ayam menjadi dadu kecil, tambahkan telur dan tepung bumbu, aduk hingga rata."
- "Goreng ayam hingga kuning keemasan, angkat dan tiriskan"
- "Tumis bawang bombay dan cabe rawit yang telah dipotong-potong dengan 1 sdm minyak goreng. Setelah layu, tambahkan saus tiram, garam dan merica."
- "Masukkan ayam, tumis sebentar. Siap disajikan bersama nasi hangat dan sayur bayam ❤️"
categories:
- Resep
tags:
- ayam
- tepung
- gongso

katakunci: ayam tepung gongso 
nutrition: 169 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Tepung Gongso Pedas](https://img-global.cpcdn.com/recipes/e35259d0626257b7/751x532cq70/ayam-tepung-gongso-pedas-foto-resep-utama.jpg)

Lagi mencari ide resep ayam tepung gongso pedas yang Bikin Ngiler? Cara Bikinnya memang tidak terlalu sulit namun tidak gampang juga. Jika keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal ayam tepung gongso pedas yang enak selayaknya punya aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam tepung gongso pedas, pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan ayam tepung gongso pedas yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.


Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah ayam tepung gongso pedas yang siap dikreasikan. Anda bisa menyiapkan Ayam Tepung Gongso Pedas memakai 9 bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Tepung Gongso Pedas:

1. Gunakan 2 buah (Fillet Dada Ayam)
1. Siapkan 1 butir (Telur Ayam)
1. Gunakan 3 sdm (Tepung bumbu/Tepung serbaguna)
1. Sediakan 1 buah (Bawang bombay)
1. Siapkan 5 buah (Cabe rawit)
1. Gunakan 1 sdt (Saos tiram)
1. Sediakan 1/2 sdt (Merica bubuk)
1. Gunakan Secukupnya (Garam)
1. Siapkan Secukupnya (Minyak goreng)




<!--inarticleads2-->

##### Cara menyiapkan Ayam Tepung Gongso Pedas:

1. Potong-potong ayam menjadi dadu kecil, tambahkan telur dan tepung bumbu, aduk hingga rata.
1. Goreng ayam hingga kuning keemasan, angkat dan tiriskan
1. Tumis bawang bombay dan cabe rawit yang telah dipotong-potong dengan 1 sdm minyak goreng. Setelah layu, tambahkan saus tiram, garam dan merica.
1. Masukkan ayam, tumis sebentar. Siap disajikan bersama nasi hangat dan sayur bayam ❤️




Bagaimana? Mudah bukan? Itulah cara menyiapkan ayam tepung gongso pedas yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
