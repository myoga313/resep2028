---
description: "Olahan 290. Gongso Ati Ampela | Cara Membuat 290. Gongso Ati Ampela Yang Enak Dan Lezat"
title: "Olahan 290. Gongso Ati Ampela | Cara Membuat 290. Gongso Ati Ampela Yang Enak Dan Lezat"
slug: 310-olahan-290-gongso-ati-ampela-cara-membuat-290-gongso-ati-ampela-yang-enak-dan-lezat
date: 2020-10-23T09:06:40.939Z
image: https://img-global.cpcdn.com/recipes/6f4de9049109358f/751x532cq70/290-gongso-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6f4de9049109358f/751x532cq70/290-gongso-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6f4de9049109358f/751x532cq70/290-gongso-ati-ampela-foto-resep-utama.jpg
author: Fannie Horton
ratingvalue: 4
reviewcount: 14
recipeingredient:
- "6 pasang ati ampela"
- "2 sdm kecap manis"
- "2 lb daun jeruk"
- "1 btg serai"
- "1 lb daun salam"
- " Gula garam penyedap jamur"
- "secukupnya Cabe rawit"
- "Secukupnya air"
- " Bumbu dihaluskan "
- "6 btr bawang merah"
- "4 siung bawang putih"
- "5 bh cabe keriting"
- "5 bh cabe rawit orange"
recipeinstructions:
- "Rebus ati ampela yg sdh dibersihkan, tiriskan potong2 sesuai selera"
- "Tumis bumbu halus hingga bumbu tanak, tambahakan bumbu daun salam, daun jeruk, serai, beri kecap manis"
- "Tambahkan air secukupnya, beri bumbu perasa, tuang ati ampelanya"
- "Masak hingga air asat dan bumbu menyerap, beri tambahan cabe rawit"
categories:
- Resep
tags:
- 290
- gongso
- ati

katakunci: 290 gongso ati 
nutrition: 105 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dinner

---


![290. Gongso Ati Ampela](https://img-global.cpcdn.com/recipes/6f4de9049109358f/751x532cq70/290-gongso-ati-ampela-foto-resep-utama.jpg)

Sedang mencari ide resep 290. gongso ati ampela yang Lezat? Cara Memasaknya memang tidak susah dan tidak juga mudah. misalnya salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal 290. gongso ati ampela yang enak selayaknya memiliki aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari 290. gongso ati ampela, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tak perlu pusing jika mau menyiapkan 290. gongso ati ampela yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.




Di bawah ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah 290. gongso ati ampela yang siap dikreasikan. Anda dapat membuat 290. Gongso Ati Ampela memakai 13 bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan 290. Gongso Ati Ampela:

1. Ambil 6 pasang ati ampela
1. Siapkan 2 sdm kecap manis
1. Ambil 2 lb daun jeruk
1. Siapkan 1 btg serai
1. Ambil 1 lb daun salam
1. Sediakan  Gula, garam, penyedap jamur
1. Sediakan secukupnya Cabe rawit
1. Sediakan Secukupnya air
1. Sediakan  Bumbu dihaluskan :
1. Ambil 6 btr bawang merah
1. Siapkan 4 siung bawang putih
1. Siapkan 5 bh cabe keriting
1. Siapkan 5 bh cabe rawit orange




<!--inarticleads2-->

##### Cara menyiapkan 290. Gongso Ati Ampela:

1. Rebus ati ampela yg sdh dibersihkan, tiriskan potong2 sesuai selera
1. Tumis bumbu halus hingga bumbu tanak, tambahakan bumbu daun salam, daun jeruk, serai, beri kecap manis
1. Tambahkan air secukupnya, beri bumbu perasa, tuang ati ampelanya
1. Masak hingga air asat dan bumbu menyerap, beri tambahan cabe rawit




Gimana nih? Gampang kan? Itulah cara membuat 290. gongso ati ampela yang bisa Anda lakukan di rumah. Selamat mencoba!
