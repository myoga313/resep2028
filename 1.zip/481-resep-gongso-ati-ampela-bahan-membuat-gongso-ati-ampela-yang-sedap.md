---
description: "Resep Gongso ati ampela | Bahan Membuat Gongso ati ampela Yang Sedap"
title: "Resep Gongso ati ampela | Bahan Membuat Gongso ati ampela Yang Sedap"
slug: 481-resep-gongso-ati-ampela-bahan-membuat-gongso-ati-ampela-yang-sedap
date: 2020-11-14T10:04:50.096Z
image: https://img-global.cpcdn.com/recipes/f129450ce067d03e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f129450ce067d03e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f129450ce067d03e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
author: Steven Guzman
ratingvalue: 3.2
reviewcount: 12
recipeingredient:
- " ati ampela"
- " Bumbu rebusan "
- " Daun salam"
- " Daun jeruk"
- " serai"
- " jahe"
- " Lengkuas"
- " ketumbar bubuk"
- " Blender"
- " bawang merah"
- " bawang putih"
- " Cabe merah keriting"
- " rawit selera"
- " Kunyit giling"
- " Bumbu lainnya "
- " Bawang merah"
- " Kecap manis"
- " air"
- " Garam dan totole"
- " Minyak"
- " Pelengkap "
- " Bawang goreng"
recipeinstructions:
- "Geprek jahe, Lengkuas dan serai, satukan dengan daun salam dan daun jeruk, lalu masukkan kedalam ati ampela yang sudah dibersihkan, rebus angkat dan potong&#34;, sisihkan"
- "Iris&#34; bawang merah, blender bumbu halus, siapkan bumbu lainnya"
- "Goreng bawang merah hingga harum, kemudian masukkan ati ampela, goreng hingga agak kering, angkat tiriskan"
- "Tumis bumbu halus hingga wangi, bubuhi garam dan totole, beri air biarkan mendidih dan bumbu agak kental"
- "Masukkan ati - ampela, tambahkan kecap manis, aduk&#34; tes rasa jika sudah pas matikan kompor"
- "Tuang ke atas piring, taburi dgn bawang merah goreng. Hidangkan"
categories:
- Resep
tags:
- gongso
- ati
- ampela

katakunci: gongso ati ampela 
nutrition: 154 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dessert

---


![Gongso ati ampela](https://img-global.cpcdn.com/recipes/f129450ce067d03e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg)

Sedang mencari inspirasi resep gongso ati ampela yang Bisa Manjain Lidah? Cara menyiapkannya memang susah-susah gampang. apabila keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gongso ati ampela yang enak seharusnya mempunyai aroma dan cita rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ati ampela, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tidak usah pusing jika mau menyiapkan gongso ati ampela enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan spesial.


Di bawah ini ada beberapa cara mudah dan praktis untuk membuat gongso ati ampela yang siap dikreasikan. Anda dapat membuat Gongso ati ampela menggunakan 22 jenis bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Gongso ati ampela:

1. Gunakan  ati ampela
1. Gunakan  Bumbu rebusan :
1. Siapkan  Daun salam
1. Sediakan  Daun jeruk
1. Gunakan  serai
1. Ambil  jahe
1. Ambil  Lengkuas
1. Siapkan  ketumbar bubuk
1. Sediakan  Blender
1. Gunakan  bawang merah
1. Gunakan  bawang putih
1. Sediakan  Cabe merah keriting
1. Sediakan  rawit (selera)
1. Ambil  Kunyit giling
1. Gunakan  Bumbu lainnya :
1. Sediakan  Bawang merah
1. Sediakan  Kecap manis
1. Siapkan  air
1. Siapkan  Garam dan totole
1. Ambil  Minyak
1. Siapkan  Pelengkap :
1. Sediakan  Bawang goreng




<!--inarticleads2-->

##### Cara menyiapkan Gongso ati ampela:

1. Geprek jahe, Lengkuas dan serai, satukan dengan daun salam dan daun jeruk, lalu masukkan kedalam ati ampela yang sudah dibersihkan, rebus angkat dan potong&#34;, sisihkan
1. Iris&#34; bawang merah, blender bumbu halus, siapkan bumbu lainnya
1. Goreng bawang merah hingga harum, kemudian masukkan ati ampela, goreng hingga agak kering, angkat tiriskan
1. Tumis bumbu halus hingga wangi, bubuhi garam dan totole, beri air biarkan mendidih dan bumbu agak kental
1. Masukkan ati - ampela, tambahkan kecap manis, aduk&#34; tes rasa jika sudah pas matikan kompor
1. Tuang ke atas piring, taburi dgn bawang merah goreng. Hidangkan




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Harapan kami, olahan Gongso ati ampela yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman maupun menjadi inspirasi dalam berjualan makanan. Semoga bermanfaat dan selamat mencoba!
