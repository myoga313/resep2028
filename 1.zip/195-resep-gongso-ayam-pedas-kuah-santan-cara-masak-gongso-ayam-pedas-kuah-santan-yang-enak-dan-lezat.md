---
description: "Resep Gongso ayam pedas kuah santan | Cara Masak Gongso ayam pedas kuah santan Yang Enak Dan Lezat"
title: "Resep Gongso ayam pedas kuah santan | Cara Masak Gongso ayam pedas kuah santan Yang Enak Dan Lezat"
slug: 195-resep-gongso-ayam-pedas-kuah-santan-cara-masak-gongso-ayam-pedas-kuah-santan-yang-enak-dan-lezat
date: 2020-12-18T03:33:29.757Z
image: https://img-global.cpcdn.com/recipes/c88fc4463cfc81d8/751x532cq70/gongso-ayam-pedas-kuah-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c88fc4463cfc81d8/751x532cq70/gongso-ayam-pedas-kuah-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c88fc4463cfc81d8/751x532cq70/gongso-ayam-pedas-kuah-santan-foto-resep-utama.jpg
author: Louise Berry
ratingvalue: 3.2
reviewcount: 12
recipeingredient:
- " Bahan Utama"
- "1/2 kg dada ayam"
- "Iris Bumbu"
- "6 siung bawang merah"
- "secukupnya Cabe hijau"
- " Bumbu Halus"
- "3 siung bawang putih"
- "5 buah cabai merah"
- "10 buah cabai setan"
- "4 ruas kunyit"
- "4 buah kemiri"
- " Sayuran Pelengkap"
- "1/2 kol ukuran kecil"
- "2 buah daun bawang"
- "1 buah Tomat"
- " Lainlain"
- " Garam"
- " Gula"
- " Merica bubuk"
- " Minyak untuk menumis"
- "400 ml santan 2 gelas dr 12 butir kelapa tua  bs diganti Sun"
recipeinstructions:
- "Cuci ayam sampai bersih, rebus sampai setengah matang. Boleh ditambahi bumbu. Tp di sini sy tdk menambahi apa2."
- "Setelah ayam matang, goreng ayam hingga kecoklatan. Angkat, sisihkan."
- "Iris bawang merah dan cabai hijau. Iris juga sayuran pelengkap, kol, daun bawang, dan tomat."
- "Di minyak bekas menggoreng ayam, goreng bawang putih, cabai merah, cabai setan, dan kunyit. Setelah harum, haluskan beserta kemiri."
- "Tumis bawang merah dan cabai hijau sampai layu, setelah layu tambahkan bumbu halus. Tumis hingga harum, lalu tambahkan ayam. Setelah ayam masuk, tambahkan santan encer. Tambahkan gula, garam, dan merica. Koreksi rasa."
- "Masak hingga ayam empuk dan matang. Setelah empuk, masukkan kol dan daun bawang. Tunggu hingga sayuran matang, baru masukkan tomat dan santan kental, aduk2 jangan sampai pecah. Masak hingga tomat sedikit layu, lalu sajikan."
categories:
- Resep
tags:
- gongso
- ayam
- pedas

katakunci: gongso ayam pedas 
nutrition: 230 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Dessert

---


![Gongso ayam pedas kuah santan](https://img-global.cpcdn.com/recipes/c88fc4463cfc81d8/751x532cq70/gongso-ayam-pedas-kuah-santan-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep gongso ayam pedas kuah santan yang Paling Enak? Cara Buatnya memang susah-susah gampang. Jika keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal gongso ayam pedas kuah santan yang enak selayaknya memiliki aroma dan cita rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ayam pedas kuah santan, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tidak usah pusing jika mau menyiapkan gongso ayam pedas kuah santan yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian spesial.


Di bawah ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah gongso ayam pedas kuah santan yang siap dikreasikan. Anda dapat membuat Gongso ayam pedas kuah santan menggunakan 21 jenis bahan dan 6 tahap pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Gongso ayam pedas kuah santan:

1. Ambil  Bahan Utama
1. Ambil 1/2 kg dada ayam
1. Ambil Iris Bumbu
1. Sediakan 6 siung bawang merah
1. Gunakan secukupnya Cabe hijau
1. Sediakan  Bumbu Halus
1. Siapkan 3 siung bawang putih
1. Ambil 5 buah cabai merah
1. Ambil 10 buah cabai setan
1. Gunakan 4 ruas kunyit
1. Ambil 4 buah kemiri
1. Ambil  Sayuran Pelengkap
1. Sediakan 1/2 kol ukuran kecil
1. Gunakan 2 buah daun bawang
1. Gunakan 1 buah Tomat
1. Sediakan  Lain-lain
1. Siapkan  Garam
1. Gunakan  Gula
1. Sediakan  Merica bubuk
1. Siapkan  Minyak untuk menumis
1. Siapkan 400 ml santan (2 gelas) dr 1/2 butir kelapa tua - bs diganti Sun




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso ayam pedas kuah santan:

1. Cuci ayam sampai bersih, rebus sampai setengah matang. Boleh ditambahi bumbu. Tp di sini sy tdk menambahi apa2.
1. Setelah ayam matang, goreng ayam hingga kecoklatan. Angkat, sisihkan.
1. Iris bawang merah dan cabai hijau. Iris juga sayuran pelengkap, kol, daun bawang, dan tomat.
1. Di minyak bekas menggoreng ayam, goreng bawang putih, cabai merah, cabai setan, dan kunyit. Setelah harum, haluskan beserta kemiri.
1. Tumis bawang merah dan cabai hijau sampai layu, setelah layu tambahkan bumbu halus. Tumis hingga harum, lalu tambahkan ayam. Setelah ayam masuk, tambahkan santan encer. Tambahkan gula, garam, dan merica. Koreksi rasa.
1. Masak hingga ayam empuk dan matang. Setelah empuk, masukkan kol dan daun bawang. Tunggu hingga sayuran matang, baru masukkan tomat dan santan kental, aduk2 jangan sampai pecah. Masak hingga tomat sedikit layu, lalu sajikan.




Bagaimana? Mudah bukan? Itulah cara membuat gongso ayam pedas kuah santan yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
