---
description: "Resep Gongso Telur Semarangan | Resep Membuat Gongso Telur Semarangan Yang Enak dan Simpel"
title: "Resep Gongso Telur Semarangan | Resep Membuat Gongso Telur Semarangan Yang Enak dan Simpel"
slug: 335-resep-gongso-telur-semarangan-resep-membuat-gongso-telur-semarangan-yang-enak-dan-simpel
date: 2020-07-21T23:50:35.357Z
image: https://img-global.cpcdn.com/recipes/dfee5358f79e1c7e/751x532cq70/gongso-telur-semarangan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dfee5358f79e1c7e/751x532cq70/gongso-telur-semarangan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dfee5358f79e1c7e/751x532cq70/gongso-telur-semarangan-foto-resep-utama.jpg
author: Willie Arnold
ratingvalue: 3.7
reviewcount: 3
recipeingredient:
- "10 buah telur"
- "6 bawang merah"
- "4 siung bawang putih"
- "3 buah cabe merah"
- "1 buah tomat"
- "1 batang daun bawang"
- "1 sdm kecap manis"
- "2 sdm saos tomat"
- "1/2 sdt lada bubuk"
- "1/2 sdt garam"
- "200 ml air matang"
recipeinstructions:
- "Ceplok telur, sisihkan."
- "Siapkan bahan."
- "Tumis bawang merah, bawang putih sampai harum. Masukkan cabe dan tomat. Aduk rata."
- "Tambahkan saos tomat dan kecap manis, garam, lada bubuk, garam. Aduk rata."
- "Masukkan air. Tunggu mendidih."
- "Masukkan telur ceplok. Tunggu hingga kuah mengental."
- "Angkat dan tata dipiring."
categories:
- Resep
tags:
- gongso
- telur
- semarangan

katakunci: gongso telur semarangan 
nutrition: 244 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Lunch

---


![Gongso Telur Semarangan](https://img-global.cpcdn.com/recipes/dfee5358f79e1c7e/751x532cq70/gongso-telur-semarangan-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep gongso telur semarangan yang Sempurna? Cara Buatnya memang tidak susah dan tidak juga mudah. misalnya keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso telur semarangan yang enak harusnya sih memiliki aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso telur semarangan, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan gongso telur semarangan yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.




Nah, kali ini kita coba, yuk, ciptakan gongso telur semarangan sendiri di rumah. Tetap berbahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Gongso Telur Semarangan menggunakan 11 bahan dan 7 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Gongso Telur Semarangan:

1. Gunakan 10 buah telur
1. Sediakan 6 bawang merah
1. Sediakan 4 siung bawang putih
1. Ambil 3 buah cabe merah
1. Gunakan 1 buah tomat
1. Siapkan 1 batang daun bawang
1. Gunakan 1 sdm kecap manis
1. Ambil 2 sdm saos tomat
1. Gunakan 1/2 sdt lada bubuk
1. Ambil 1/2 sdt garam
1. Siapkan 200 ml air matang




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso Telur Semarangan:

1. Ceplok telur, sisihkan.
1. Siapkan bahan.
1. Tumis bawang merah, bawang putih sampai harum. Masukkan cabe dan tomat. Aduk rata.
1. Tambahkan saos tomat dan kecap manis, garam, lada bubuk, garam. Aduk rata.
1. Masukkan air. Tunggu mendidih.
1. Masukkan telur ceplok. Tunggu hingga kuah mengental.
1. Angkat dan tata dipiring.




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Harapan kami, olahan Gongso Telur Semarangan yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman ataupun menjadi inspirasi dalam berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
