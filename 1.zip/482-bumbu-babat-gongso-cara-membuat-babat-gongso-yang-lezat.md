---
description: "Bumbu Babat Gongso | Cara Membuat Babat Gongso Yang Lezat"
title: "Bumbu Babat Gongso | Cara Membuat Babat Gongso Yang Lezat"
slug: 482-bumbu-babat-gongso-cara-membuat-babat-gongso-yang-lezat
date: 2020-11-12T12:29:40.429Z
image: https://img-global.cpcdn.com/recipes/a545fff477a63798/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a545fff477a63798/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a545fff477a63798/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Ray Klein
ratingvalue: 5
reviewcount: 3
recipeingredient:
- " Babatrebus hingga empuk"
- " Jahe"
- " Serai"
- " Daun Jeruk"
- " Kecap manis"
- " Gula merahkurleb"
- " Garam"
- " Gula pasir"
- " Bahan yang dihaluskan"
- " Cabe merah keriting"
- " Bawang Merah"
- " Bawang Putih"
- " Kemiri"
- " Ketumbar bubuk"
- " Daun Salam"
recipeinstructions:
- "Cuci bersih Babat,rebus dengan Jahe,Serai,daun Jeruk hingga empuk.Kurleb 30 menit dengan panci presto. Klo saya,saya beri 1sdt kunyit bubuk,1 sdm garam di dalam rebusan. Optional ya. Hanya untuk menghilangkan &#34;bau&#34;jerohan 😊"
- "Setelah empuk,buang air nya. Potong2 babat sesuai selera(saya potong2 kurleb 2cm)."
- "Tumis bahan yang sudah dihaluskan hingga matang,harum. Masukkan babat yang sudah di potong2,beri air kurleb 1 gelas. Beri kecap manis,gula merah,garam,gula pasir,biarkan mendidih,bumbu menyerap dan air menyusut.Tes rasa."
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 113 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dessert

---


![Babat Gongso](https://img-global.cpcdn.com/recipes/a545fff477a63798/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Bunda lagi mencari ide resep babat gongso yang Enak Dan Mudah? Cara Memasaknya memang tidak terlalu sulit namun tidak gampang juga. sekiranya salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal babat gongso yang enak seharusnya memiliki aroma dan cita rasa yang dapat memancing selera kita.

Com - Babat Gongso kali ini special karena ada isonya. Babat Gongso yang menjadi tujuan kuliner setiap orang yang ke Semarang, merupakan setidaknya primadona dari sekian banyak makanan yang ada di Semarang. Yuk, belajar membuat Babat Gongso di rumah Anda!

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan babat gongso enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.


Berikut ini ada beberapa tips dan trik praktis untuk membuat babat gongso yang siap dikreasikan. Anda bisa menyiapkan Babat Gongso menggunakan 15 bahan dan 3 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Babat Gongso:

1. Siapkan  Babat,rebus hingga empuk
1. Siapkan  Jahe
1. Gunakan  Serai
1. Gunakan  Daun Jeruk
1. Ambil  Kecap manis
1. Sediakan  Gula merah,kurleb
1. Ambil  Garam
1. Siapkan  Gula pasir
1. Sediakan  Bahan yang dihaluskan:
1. Sediakan  Cabe merah keriting
1. Sediakan  Bawang Merah
1. Gunakan  Bawang Putih
1. Sediakan  Kemiri
1. Siapkan  Ketumbar bubuk
1. Sediakan  Daun Salam




<!--inarticleads2-->

##### Cara membuat Babat Gongso:

1. Cuci bersih Babat,rebus dengan Jahe,Serai,daun Jeruk hingga empuk.Kurleb 30 menit dengan panci presto. Klo saya,saya beri 1sdt kunyit bubuk,1 sdm garam di dalam rebusan. Optional ya. Hanya untuk menghilangkan &#34;bau&#34;jerohan 😊
1. Setelah empuk,buang air nya. Potong2 babat sesuai selera(saya potong2 kurleb 2cm).
1. Tumis bahan yang sudah dihaluskan hingga matang,harum. Masukkan babat yang sudah di potong2,beri air kurleb 1 gelas. Beri kecap manis,gula merah,garam,gula pasir,biarkan mendidih,bumbu menyerap dan air menyusut.Tes rasa.




Bagaimana? Gampang kan? Itulah cara menyiapkan babat gongso yang bisa Anda praktikkan di rumah. Selamat mencoba!
