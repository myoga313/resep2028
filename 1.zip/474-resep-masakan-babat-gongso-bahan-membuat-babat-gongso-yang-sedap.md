---
description: "Resep masakan Babat gongso | Bahan Membuat Babat gongso Yang Sedap"
title: "Resep masakan Babat gongso | Bahan Membuat Babat gongso Yang Sedap"
slug: 474-resep-masakan-babat-gongso-bahan-membuat-babat-gongso-yang-sedap
date: 2020-09-18T21:09:07.945Z
image: https://img-global.cpcdn.com/recipes/ac85d7b76ca5bad5/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ac85d7b76ca5bad5/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ac85d7b76ca5bad5/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Ruth Burns
ratingvalue: 3
reviewcount: 5
recipeingredient:
- "200 gr babat rebus 2030mins"
- "5 buah cabe rawit"
- "2 sdm kecap manis"
- "Sejumput garam"
- "3 cm lengkuas"
- "1 batang serai"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "1 buah tomat"
- "1 sdm saus tiram"
- "2 sdm minyak"
- "200 ml air"
- " Bawang gorengdaun bawang utk pelengkap"
- " Bumbu halus"
- "4 siung bawang merah"
- "3 siung bawang putih"
- "2 butir kemiri"
- "1 sdt Merica butiran"
- "1 sdt Merica butiran"
- "2 cm jahe"
- "4 buah cabe merah besarkeriting"
recipeinstructions:
- "Potong2 babat yang sudah direbus dengan potongan sesuai selera. Sisihkan."
- "Siapkan bumbu uleg/blender sampai halus"
- "Siapkan wajan beri minyak kemudian tumis bumbu halus sampai harum, masukkan serai, daun jeruk, daun salam, dan lengkuas, aduk sampai rata."
- "Masukkan air aduk, beri saus tiram, kemudian masukkan babat aduk sampai rata"
- "Beri kecap manis, sejumput garam dan diamkan sampai agak menyusut airnya. Beri cabe rawit utuh dan tomat aduk tunggu sampai cabe rawit dan tomat layu, tes rasa, masak sebentar lagi kemudian matikan kompor."
- "Beri bawang goreng/daun bawang. Sajikan"
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 190 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Lunch

---


![Babat gongso](https://img-global.cpcdn.com/recipes/ac85d7b76ca5bad5/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Sedang mencari ide resep babat gongso yang Lezat? Cara Memasaknya memang susah-susah gampang. jikalau keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal babat gongso yang enak harusnya sih punya aroma dan cita rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tidak usah pusing jika hendak menyiapkan babat gongso enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan spesial.




Di bawah ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah babat gongso yang siap dikreasikan. Anda dapat membuat Babat gongso memakai 21 bahan dan 6 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Babat gongso:

1. Ambil 200 gr babat rebus (20-30mins)
1. Sediakan 5 buah cabe rawit
1. Sediakan 2 sdm kecap manis
1. Ambil Sejumput garam
1. Siapkan 3 cm lengkuas
1. Ambil 1 batang serai
1. Siapkan 2 lembar daun jeruk
1. Ambil 2 lembar daun salam
1. Gunakan 1 buah tomat
1. Siapkan 1 sdm saus tiram
1. Ambil 2 sdm minyak
1. Sediakan 200 ml air
1. Ambil  Bawang goreng/daun bawang utk pelengkap
1. Ambil  Bumbu halus
1. Ambil 4 siung bawang merah
1. Sediakan 3 siung bawang putih
1. Siapkan 2 butir kemiri
1. Gunakan 1 sdt Merica butiran
1. Ambil 1 sdt Merica butiran
1. Ambil 2 cm jahe
1. Siapkan 4 buah cabe merah besar/keriting




<!--inarticleads2-->

##### Langkah-langkah membuat Babat gongso:

1. Potong2 babat yang sudah direbus dengan potongan sesuai selera. Sisihkan.
1. Siapkan bumbu uleg/blender sampai halus
1. Siapkan wajan beri minyak kemudian tumis bumbu halus sampai harum, masukkan serai, daun jeruk, daun salam, dan lengkuas, aduk sampai rata.
1. Masukkan air aduk, beri saus tiram, kemudian masukkan babat aduk sampai rata
1. Beri kecap manis, sejumput garam dan diamkan sampai agak menyusut airnya. Beri cabe rawit utuh dan tomat aduk tunggu sampai cabe rawit dan tomat layu, tes rasa, masak sebentar lagi kemudian matikan kompor.
1. Beri bawang goreng/daun bawang. Sajikan




Terima kasih telah membaca resep yang kami tampilkan di sini. Besar harapan kami, olahan Babat gongso yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman maupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
