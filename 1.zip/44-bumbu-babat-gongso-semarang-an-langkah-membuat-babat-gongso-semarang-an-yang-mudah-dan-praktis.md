---
description: "Bumbu Babat gongso Semarang-an | Langkah Membuat Babat gongso Semarang-an Yang Mudah Dan Praktis"
title: "Bumbu Babat gongso Semarang-an | Langkah Membuat Babat gongso Semarang-an Yang Mudah Dan Praktis"
slug: 44-bumbu-babat-gongso-semarang-an-langkah-membuat-babat-gongso-semarang-an-yang-mudah-dan-praktis
date: 2020-08-13T02:08:34.235Z
image: https://img-global.cpcdn.com/recipes/20664d61657e5bd6/751x532cq70/babat-gongso-semarang-an-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/20664d61657e5bd6/751x532cq70/babat-gongso-semarang-an-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/20664d61657e5bd6/751x532cq70/babat-gongso-semarang-an-foto-resep-utama.jpg
author: Alberta Greene
ratingvalue: 4.7
reviewcount: 10
recipeingredient:
- " Babat Sapi lupa gak ditimbang"
- "1 buah tomat potong2"
- " Gula merah garam penyedap"
- " Kecap manis sesuai selera"
- "Secukupnya Air"
- " Minyak untuk menumis"
- " Bumbu halus"
- "7 buah Bawang Merah"
- "4 buah bawang putih"
- "3 buah cabai keriting"
- "7 buah cabai merah setan"
- "3 buah kemiri"
- " Bumbu cemplung"
- "2 buah Daun seregeprek"
- " Daun jeruk"
- " Daun salam"
- " Lengkuas geprek"
- " Jahe geprek"
recipeinstructions:
- "Cuci bersih babat, kemudian rebus dengan metode 5 30 7, setelah empuk potong2 sesuai selera"
- "Panaskan minyak untuk menumis. Tumis bumbu halus dan bumbu cemplung hingga harum. Masukkan babat yang sudah direbus tadi. Setelah itu beri sedikit air (jangan banyak2, klw bahasa jawanya nyemek2 😅)"
- "Masukkan garam, gula jawa, penyedap dan kecap manis,,,rebus sebentar sampai bumbu meresap ke dalam babat."
- "Setelah mendidih, angkat, siap disajikan."
categories:
- Resep
tags:
- babat
- gongso
- semarangan

katakunci: babat gongso semarangan 
nutrition: 273 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Dessert

---


![Babat gongso Semarang-an](https://img-global.cpcdn.com/recipes/20664d61657e5bd6/751x532cq70/babat-gongso-semarang-an-foto-resep-utama.jpg)

Sedang mencari inspirasi resep babat gongso semarang-an yang Sedap? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. semisal salah mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal babat gongso semarang-an yang enak selayaknya memiliki aroma dan cita rasa yang mampu memancing selera kita.

Lihat juga resep Babat Gongso ala Semarang enak lainnya. Babat Gongso is a legendary dish from Semarang and Solo, Central Java which is increasingly rare to be found. You may take a look my old recipe of Soto Babat.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso semarang-an, pertama dari jenis bahan, lalu pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tidak usah pusing kalau ingin menyiapkan babat gongso semarang-an yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.


Berikut ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah babat gongso semarang-an yang siap dikreasikan. Anda bisa menyiapkan Babat gongso Semarang-an menggunakan 18 bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Babat gongso Semarang-an:

1. Siapkan  Babat Sapi (lupa gak ditimbang)
1. Gunakan 1 buah tomat (potong2)
1. Siapkan  Gula merah, garam, penyedap
1. Sediakan  Kecap manis (sesuai selera)
1. Sediakan Secukupnya Air
1. Ambil  Minyak (untuk menumis)
1. Ambil  Bumbu halus
1. Ambil 7 buah Bawang Merah
1. Gunakan 4 buah bawang putih
1. Sediakan 3 buah cabai keriting
1. Gunakan 7 buah cabai merah setan
1. Siapkan 3 buah kemiri
1. Gunakan  Bumbu cemplung
1. Ambil 2 buah Daun sere(geprek)
1. Sediakan  Daun jeruk
1. Ambil  Daun salam
1. Ambil  Lengkuas geprek
1. Ambil  Jahe geprek


Kalau mau pedas, tambah takaran cabai. KOMPAS.com/Nabilla TashandraBabat gongso, salah satu menu andalan di Nasi Goreng Babat Pak Karmin di Jalan Pemuda, Semarang, yang tak pernah sepi pembeli. Babat Gongso Terenak di Semarang Super Pedas Manis Mantap Jiwa. Babat gongso pak sabar manis TAPI enak kuliner semarang. 

<!--inarticleads2-->

##### Cara menyiapkan Babat gongso Semarang-an:

1. Cuci bersih babat, kemudian rebus dengan metode 5 30 7, setelah empuk potong2 sesuai selera
1. Panaskan minyak untuk menumis. Tumis bumbu halus dan bumbu cemplung hingga harum. Masukkan babat yang sudah direbus tadi. Setelah itu beri sedikit air (jangan banyak2, klw bahasa jawanya nyemek2 😅)
1. Masukkan garam, gula jawa, penyedap dan kecap manis,,,rebus sebentar sampai bumbu meresap ke dalam babat.
1. Setelah mendidih, angkat, siap disajikan.




Bagaimana? Gampang kan? Itulah cara membuat babat gongso semarang-an yang bisa Anda lakukan di rumah. Selamat mencoba!
