---
description: "Bumbu Gongso ampela ati Ayam | Cara Mengolah Gongso ampela ati Ayam Yang Sedap"
title: "Bumbu Gongso ampela ati Ayam | Cara Mengolah Gongso ampela ati Ayam Yang Sedap"
slug: 210-bumbu-gongso-ampela-ati-ayam-cara-mengolah-gongso-ampela-ati-ayam-yang-sedap
date: 2020-12-04T22:55:11.517Z
image: https://img-global.cpcdn.com/recipes/32a497c23c0bca3b/751x532cq70/gongso-ampela-ati-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/32a497c23c0bca3b/751x532cq70/gongso-ampela-ati-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/32a497c23c0bca3b/751x532cq70/gongso-ampela-ati-ayam-foto-resep-utama.jpg
author: William Stevenson
ratingvalue: 4.8
reviewcount: 10
recipeingredient:
- "10 pasang ampla ati ayam"
- "10 biji cabe ijo tw"
- " Bumbu"
- "10 cabe rawit galak"
- "5 cabe merah kriting"
- "5 butir bawang merah"
- "3 butir bawang putih"
- "3 buah tomat"
- "1 ruas jari lengkuas"
- "1 lembar daun salam"
- "1 bungkus bumbu kaldu"
- "1 sdt gula pasir"
- "1 sdt garam"
- "1 SDM minyak goreng"
recipeinstructions:
- "Cuci bersih ampla ati lalu rebus dan potong2 menurut selera"
- "Haluskan bumbu dan potong2 cabe ijonya..lalu tumis bumbu halus sampe wangi dan masukkan ampla atinya"
- "Setelah ampla masuk lalu masukkan cabe ijonya aduk rata tambahkan semua bumbu tambahannya..tambahkan sedikit air..cek rasa..setelah matang angkat hidang kan dengan nasi panaa"
categories:
- Resep
tags:
- gongso
- ampela
- ati

katakunci: gongso ampela ati 
nutrition: 270 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Dessert

---


![Gongso ampela ati Ayam](https://img-global.cpcdn.com/recipes/32a497c23c0bca3b/751x532cq70/gongso-ampela-ati-ayam-foto-resep-utama.jpg)

Kamu Sedang mencari ide resep gongso ampela ati ayam yang Enak dan Simpel? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. sekiranya salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso ampela ati ayam yang enak harusnya sih punya aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ampela ati ayam, pertama dari jenis bahan, lalu pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan gongso ampela ati ayam enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.




Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah gongso ampela ati ayam yang siap dikreasikan. Anda dapat menyiapkan Gongso ampela ati Ayam memakai 14 bahan dan 3 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Gongso ampela ati Ayam:

1. Sediakan 10 pasang ampla ati ayam
1. Sediakan 10 biji cabe ijo tw
1. Siapkan  Bumbu
1. Gunakan 10 cabe rawit galak
1. Siapkan 5 cabe merah kriting
1. Sediakan 5 butir bawang merah
1. Sediakan 3 butir bawang putih
1. Siapkan 3 buah tomat
1. Ambil 1 ruas jari lengkuas
1. Sediakan 1 lembar daun salam
1. Ambil 1 bungkus bumbu kaldu
1. Gunakan 1 sdt gula pasir
1. Ambil 1 sdt garam
1. Sediakan 1 SDM minyak goreng




<!--inarticleads2-->

##### Cara menyiapkan Gongso ampela ati Ayam:

1. Cuci bersih ampla ati lalu rebus dan potong2 menurut selera
1. Haluskan bumbu dan potong2 cabe ijonya..lalu tumis bumbu halus sampe wangi dan masukkan ampla atinya
1. Setelah ampla masuk lalu masukkan cabe ijonya aduk rata tambahkan semua bumbu tambahannya..tambahkan sedikit air..cek rasa..setelah matang angkat hidang kan dengan nasi panaa




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Harapan kami, olahan Gongso ampela ati Ayam yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman maupun menjadi inspirasi dalam berjualan makanan. Semoga bermanfaat dan selamat mencoba!
