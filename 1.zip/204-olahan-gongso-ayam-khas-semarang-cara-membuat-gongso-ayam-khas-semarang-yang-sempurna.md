---
description: "Olahan Gongso Ayam khas Semarang | Cara Membuat Gongso Ayam khas Semarang Yang Sempurna"
title: "Olahan Gongso Ayam khas Semarang | Cara Membuat Gongso Ayam khas Semarang Yang Sempurna"
slug: 204-olahan-gongso-ayam-khas-semarang-cara-membuat-gongso-ayam-khas-semarang-yang-sempurna
date: 2020-11-05T03:42:57.193Z
image: https://img-global.cpcdn.com/recipes/d29cc9d495b60af5/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d29cc9d495b60af5/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d29cc9d495b60af5/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg
author: Sylvia May
ratingvalue: 4.3
reviewcount: 14
recipeingredient:
- "6 potong ayam bagian paha"
- "1 buah bawang bombay iris tipis"
- "10 biji cabai rawit"
- "2 lembar daun salam"
- "1 ruas lengkuaslaos"
- " kecap manis"
- " garam"
- " lada bubuk"
- "secukupnya air"
- " minyak goreng untuk menumis"
- " bumbu halus "
- "5 siung bawang putih"
- "2 siung bawang merah"
- "3 buah kemiri"
- "5 biji cabai rawit"
- "1 biji cabai merah"
recipeinstructions:
- "Siapkan bahan, cuci bersih ayam beri kucuran air jeruk nipis agar menghilangkan bau amis nya. tunggu 10 menit. lalu rebus ayam, masukkan garam secukupnya. rebus ayam sekitar 30-40 menit. setelah itu tiriskan"
- "Haluskan bumbu sesuai resep yg ada. kemudian suwir2 ayam agar di gongso nanti bumbu bisa meresap. dan iris tipis bawang bombay"
- "Ambil wajan/teflon masukkan minyak lalu tumis bawang bombay sampai harum dan kecoklatan, lalu masukkan bumbu halus, daun salam, lengkuas. tumis sampai harum"
- "Masukkan ayam, gongso hingga merata dengan bumbu. masukkan kecap manis, garam, lada, penyedap rasa. masukkan air sedikit demi sedikit, gongso hingga air menyusut, koreksi rasa. dan siap disajikan dengan nasi panas 😋"
categories:
- Resep
tags:
- gongso
- ayam
- khas

katakunci: gongso ayam khas 
nutrition: 108 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Dinner

---


![Gongso Ayam khas Semarang](https://img-global.cpcdn.com/recipes/d29cc9d495b60af5/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep gongso ayam khas semarang yang Sedap? Cara membuatnya memang tidak susah dan tidak juga mudah. seumpama salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gongso ayam khas semarang yang enak selayaknya mempunyai aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ayam khas semarang, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tak perlu pusing kalau mau menyiapkan gongso ayam khas semarang yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.




Nah, kali ini kita coba, yuk, variasikan gongso ayam khas semarang sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Gongso Ayam khas Semarang menggunakan 16 bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Gongso Ayam khas Semarang:

1. Ambil 6 potong ayam, bagian paha
1. Siapkan 1 buah bawang bombay, iris tipis
1. Sediakan 10 biji cabai rawit
1. Siapkan 2 lembar daun salam
1. Sediakan 1 ruas lengkuas/laos
1. Ambil  kecap manis
1. Sediakan  garam
1. Sediakan  lada bubuk
1. Siapkan secukupnya air
1. Ambil  minyak goreng untuk menumis
1. Gunakan  bumbu halus :
1. Gunakan 5 siung bawang putih
1. Gunakan 2 siung bawang merah
1. Siapkan 3 buah kemiri
1. Sediakan 5 biji cabai rawit
1. Gunakan 1 biji cabai merah




<!--inarticleads2-->

##### Cara menyiapkan Gongso Ayam khas Semarang:

1. Siapkan bahan, cuci bersih ayam beri kucuran air jeruk nipis agar menghilangkan bau amis nya. tunggu 10 menit. lalu rebus ayam, masukkan garam secukupnya. rebus ayam sekitar 30-40 menit. setelah itu tiriskan
1. Haluskan bumbu sesuai resep yg ada. kemudian suwir2 ayam agar di gongso nanti bumbu bisa meresap. dan iris tipis bawang bombay
1. Ambil wajan/teflon masukkan minyak lalu tumis bawang bombay sampai harum dan kecoklatan, lalu masukkan bumbu halus, daun salam, lengkuas. tumis sampai harum
1. Masukkan ayam, gongso hingga merata dengan bumbu. masukkan kecap manis, garam, lada, penyedap rasa. masukkan air sedikit demi sedikit, gongso hingga air menyusut, koreksi rasa. dan siap disajikan dengan nasi panas 😋




Gimana nih? Gampang kan? Itulah cara menyiapkan gongso ayam khas semarang yang bisa Anda lakukan di rumah. Selamat mencoba!
