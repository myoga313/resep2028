---
description: "Bumbu Ayam Gongso Semarang | Cara Mengolah Ayam Gongso Semarang Yang Lezat Sekali"
title: "Bumbu Ayam Gongso Semarang | Cara Mengolah Ayam Gongso Semarang Yang Lezat Sekali"
slug: 326-bumbu-ayam-gongso-semarang-cara-mengolah-ayam-gongso-semarang-yang-lezat-sekali
date: 2020-11-17T04:55:37.995Z
image: https://img-global.cpcdn.com/recipes/8b46a3b964139c66/751x532cq70/ayam-gongso-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8b46a3b964139c66/751x532cq70/ayam-gongso-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8b46a3b964139c66/751x532cq70/ayam-gongso-semarang-foto-resep-utama.jpg
author: Henrietta Fields
ratingvalue: 4.6
reviewcount: 3
recipeingredient:
- " ayam negeri"
- " jeruk nipis"
- " daun bawang iris"
- " daun jeruk"
- " daun salam"
- " kayu manis"
- " bunga lawang"
- " kapulaga"
- " cengkeh"
- " lada bubuk"
- " asam Jawa larutkan dgn sedikit air"
- " kecap manissesuai selera"
- " air"
- " minyak untuk menumis"
- " garam gula pasir dan kaldu bubuk"
- " Bumbu halus"
- " bawang putih"
- " bawang merah"
- " kemiri"
- " jahe"
- " lengkuas"
- " serai"
- " gula merahgula aren"
recipeinstructions:
- "Beri ayam perasan jeruk nipis. Biarkan selama 5 menit."
- "Haluskan semua bumbu halus."
- "Siapkan wajan dan panaskan minyak. Tumis hingga harum bumbu halus, tambahkan lada bubuk, daun jeruk, daun salam, kapulaga, cengkeh, kayu manis, dan bunga lawang."
- "Masukkan ayam, kecap, dan air. Aduk rata, bumbui dengan garam, sedikit gulpas, dan kaldu bubuk. Lalu tutup, masak hingga ayam matang. Ini aku ga punya tutup yg gede, maklum lagi ga di rumah, seadanya aja😁🙏."
- "Masukkan irisan daun bawang, aduk-aduk hingga cukup layu. Jangan lupa koreksi rasa."
- "Sajikan bersama nasi hangat ☺️🤩❤️. Selamat mencoba."
categories:
- Resep
tags:
- ayam
- gongso
- semarang

katakunci: ayam gongso semarang 
nutrition: 173 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Gongso Semarang](https://img-global.cpcdn.com/recipes/8b46a3b964139c66/751x532cq70/ayam-gongso-semarang-foto-resep-utama.jpg)

Lagi mencari inspirasi resep ayam gongso semarang yang Lezat? Cara membuatnya memang tidak susah dan tidak juga mudah. seumpama keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal ayam gongso semarang yang enak selayaknya memiliki aroma dan rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso semarang, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tidak usah pusing jika mau menyiapkan ayam gongso semarang yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan spesial.




Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah ayam gongso semarang yang siap dikreasikan. Anda dapat menyiapkan Ayam Gongso Semarang memakai 23 bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Gongso Semarang:

1. Ambil  ayam negeri
1. Gunakan  jeruk nipis
1. Ambil  daun bawang, iris
1. Gunakan  daun jeruk
1. Gunakan  daun salam
1. Sediakan  kayu manis
1. Sediakan  bunga lawang
1. Sediakan  kapulaga
1. Ambil  cengkeh
1. Gunakan  lada bubuk
1. Ambil  asam Jawa, larutkan dgn sedikit air
1. Ambil  kecap manis/sesuai selera
1. Ambil  air
1. Sediakan  minyak untuk menumis
1. Ambil  garam, gula pasir, dan kaldu bubuk
1. Gunakan  Bumbu halus:
1. Siapkan  bawang putih
1. Gunakan  bawang merah
1. Ambil  kemiri
1. Siapkan  jahe
1. Siapkan  lengkuas
1. Gunakan  serai
1. Ambil  gula merah/gula aren




<!--inarticleads2-->

##### Cara menyiapkan Ayam Gongso Semarang:

1. Beri ayam perasan jeruk nipis. Biarkan selama 5 menit.
1. Haluskan semua bumbu halus.
1. Siapkan wajan dan panaskan minyak. Tumis hingga harum bumbu halus, tambahkan lada bubuk, daun jeruk, daun salam, kapulaga, cengkeh, kayu manis, dan bunga lawang.
1. Masukkan ayam, kecap, dan air. Aduk rata, bumbui dengan garam, sedikit gulpas, dan kaldu bubuk. Lalu tutup, masak hingga ayam matang. Ini aku ga punya tutup yg gede, maklum lagi ga di rumah, seadanya aja😁🙏.
1. Masukkan irisan daun bawang, aduk-aduk hingga cukup layu. Jangan lupa koreksi rasa.
1. Sajikan bersama nasi hangat ☺️🤩❤️. Selamat mencoba.




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Ayam Gongso Semarang yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman ataupun menjadi inspirasi dalam berjualan makanan. Selamat mencoba!
