---
description: "Resep Jengkol Goreng Kecap | Cara Mengolah Jengkol Goreng Kecap Yang Sedap"
title: "Resep Jengkol Goreng Kecap | Cara Mengolah Jengkol Goreng Kecap Yang Sedap"
slug: 365-resep-jengkol-goreng-kecap-cara-mengolah-jengkol-goreng-kecap-yang-sedap
date: 2020-12-26T15:55:09.607Z
image: https://img-global.cpcdn.com/recipes/fbd61a63d66754cd/751x532cq70/jengkol-goreng-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fbd61a63d66754cd/751x532cq70/jengkol-goreng-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fbd61a63d66754cd/751x532cq70/jengkol-goreng-kecap-foto-resep-utama.jpg
author: Susie Brewer
ratingvalue: 3.1
reviewcount: 15
recipeingredient:
- "500 gr Jengkol"
- "2 batang serai"
- "5 lembar daun salam"
- "5 lembar daun jeruk"
- "1 potong sedang lengkuas"
- "1 liter air untuk merebus"
- " Bumbu Iris"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1/2 buah bawang bombay"
- "8 buah cabe rawit"
- "2 buah tomat"
- "  Bumbu lainnya"
- "1 1/2 sdm kaldu ayam"
- "1/2 sdt garam"
- "4 sdm kecap manis"
recipeinstructions:
- "Cuci bersih jengkol, masukkan dalam panci beri air dan tambahkan serai, daun salam, daun jeruk dan lengkuas, rebus kurang lebih 30 menit/sampai jengkol empuk. Sambil menunggu rebusan jengkol, siapkan bumbu iris."
- "Setelah empuk, angkat tiriskan, kupas dan buang kulit jengkol, cuci bersih, lalu belah jengkol jadi dua bagian dan potong lagi setiap jengkol jadi dua bagian."
- "Selanjutnya panaskan minyak goreng secukupnya, tumis Jengkol hingga agak mengering saja, lalu masukkan bawang merah, putih dan bombay aduk merata, lalu tambahkan bumbu kecap manis, kaldu ayam bubuk dan garam, masukkan juga irisan tomat dan cabe rawit."
- "Masak jengkol sampai kuah mengental (bisa ditambahkan sedikit air, saya tidak tambah air, selera ya) jangan lupa koreksi rasa dan sesuaikan selera."
- "Angkat dan sajikan.. Jengkol Goreng Kecap siap dinikmati dengan pelengkap lainnya (sambal lalapan ikan asin) 🤤👍🤗"
categories:
- Resep
tags:
- jengkol
- goreng
- kecap

katakunci: jengkol goreng kecap 
nutrition: 170 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Dinner

---


![Jengkol Goreng Kecap](https://img-global.cpcdn.com/recipes/fbd61a63d66754cd/751x532cq70/jengkol-goreng-kecap-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep jengkol goreng kecap yang Enak Dan Lezat? Cara Bikinnya memang susah-susah gampang. seumpama salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal jengkol goreng kecap yang enak selayaknya memiliki aroma dan cita rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari jengkol goreng kecap, pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tidak usah pusing jika ingin menyiapkan jengkol goreng kecap enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.


Berikut ini ada beberapa cara mudah dan praktis dalam mengolah jengkol goreng kecap yang siap dikreasikan. Anda bisa membuat Jengkol Goreng Kecap memakai 16 jenis bahan dan 5 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Jengkol Goreng Kecap:

1. Ambil 500 gr Jengkol
1. Ambil 2 batang serai
1. Gunakan 5 lembar daun salam
1. Gunakan 5 lembar daun jeruk
1. Siapkan 1 potong sedang lengkuas
1. Ambil 1 liter air untuk merebus
1. Sediakan  🍄Bumbu Iris
1. Siapkan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Siapkan 1/2 buah bawang bombay
1. Ambil 8 buah cabe rawit
1. Ambil 2 buah tomat
1. Gunakan  🍄 Bumbu lainnya
1. Gunakan 1 1/2 sdm kaldu ayam
1. Siapkan 1/2 sdt garam
1. Ambil 4 sdm kecap manis




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Jengkol Goreng Kecap:

1. Cuci bersih jengkol, masukkan dalam panci beri air dan tambahkan serai, daun salam, daun jeruk dan lengkuas, rebus kurang lebih 30 menit/sampai jengkol empuk. Sambil menunggu rebusan jengkol, siapkan bumbu iris.
1. Setelah empuk, angkat tiriskan, kupas dan buang kulit jengkol, cuci bersih, lalu belah jengkol jadi dua bagian dan potong lagi setiap jengkol jadi dua bagian.
1. Selanjutnya panaskan minyak goreng secukupnya, tumis Jengkol hingga agak mengering saja, lalu masukkan bawang merah, putih dan bombay aduk merata, lalu tambahkan bumbu kecap manis, kaldu ayam bubuk dan garam, masukkan juga irisan tomat dan cabe rawit.
1. Masak jengkol sampai kuah mengental (bisa ditambahkan sedikit air, saya tidak tambah air, selera ya) jangan lupa koreksi rasa dan sesuaikan selera.
1. Angkat dan sajikan.. Jengkol Goreng Kecap siap dinikmati dengan pelengkap lainnya (sambal lalapan ikan asin) 🤤👍🤗




Gimana nih? Mudah bukan? Itulah cara menyiapkan jengkol goreng kecap yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
