---
description: "Resep Babat Gongso | Cara Buat Babat Gongso Yang Mudah Dan Praktis"
title: "Resep Babat Gongso | Cara Buat Babat Gongso Yang Mudah Dan Praktis"
slug: 74-resep-babat-gongso-cara-buat-babat-gongso-yang-mudah-dan-praktis
date: 2020-07-15T19:57:38.771Z
image: https://img-global.cpcdn.com/recipes/ee5bcdd1cc0acb12/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ee5bcdd1cc0acb12/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ee5bcdd1cc0acb12/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Bertha Mathis
ratingvalue: 3.3
reviewcount: 12
recipeingredient:
- "300 gram babat"
- "2 sdm gula merah sisir"
- "3 sdm kecap manis"
- "3 lembar daun jeruk"
- "4 lembar daun salam"
- "1 batang sereh"
- "1 ruas lengkuas"
- "1 sdt garam"
- "500 ml air"
- "1 buah tomat"
- "8 buah cabe rawit sesuai selera"
- " Bumbu halus"
- "5 siung bawang merah"
- "5 siung bawang putih"
- "1 cm jahe"
- "3 buah kemiri"
- "1 sdt ketumbar"
- "1/2 sdt merica bubuk"
- "100 ml air"
recipeinstructions:
- "Uleg bumbu halus. Sisihkan."
- "Rebus babat. Buang airnya dan potong- potong babanya sesuai selera."
- "Tumis bumbu halus sampai beraroma. Tambahkan daun salam, daun jeruk, serai dan lengkuas. Tambahkan 100 ml air. Masak sampai bumbu keluar minyak kembali."
- "Masukkan air 500 ml dan potongan babat. Masak sampai air agak menyusut, tambahkan gula jawa, kecap manis dan garam."
- "Kalau kuahnya tinggal sepertiga, masukkan irisan tomat dan cabe rawit utuh. Masak sampai kuah menyusut dan meresap ke babat. Matikan kompor."
- "Angkat dan sajikan..."
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 108 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Lunch

---


![Babat Gongso](https://img-global.cpcdn.com/recipes/ee5bcdd1cc0acb12/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep babat gongso yang Bisa Manjain Lidah? Cara membuatnya memang susah-susah gampang. kalau salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal babat gongso yang enak harusnya sih mempunyai aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari babat gongso, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tak perlu pusing kalau hendak menyiapkan babat gongso yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian istimewa.

Com - Babat Gongso kali ini special karena ada isonya. Babat Gongso yang menjadi tujuan kuliner setiap orang yang ke Semarang, merupakan setidaknya primadona dari sekian banyak makanan yang ada di Semarang. Yuk, belajar membuat Babat Gongso di rumah Anda!


Berikut ini ada beberapa tips dan trik praktis untuk membuat babat gongso yang siap dikreasikan. Anda bisa menyiapkan Babat Gongso memakai 19 jenis bahan dan 6 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Babat Gongso:

1. Gunakan 300 gram babat
1. Siapkan 2 sdm gula merah sisir
1. Gunakan 3 sdm kecap manis
1. Siapkan 3 lembar daun jeruk
1. Sediakan 4 lembar daun salam
1. Gunakan 1 batang sereh
1. Gunakan 1 ruas lengkuas
1. Siapkan 1 sdt garam
1. Siapkan 500 ml air
1. Sediakan 1 buah tomat
1. Siapkan 8 buah cabe rawit (sesuai selera)
1. Siapkan  Bumbu halus
1. Siapkan 5 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Ambil 1 cm jahe
1. Gunakan 3 buah kemiri
1. Gunakan 1 sdt ketumbar
1. Gunakan 1/2 sdt merica bubuk
1. Gunakan 100 ml air




<!--inarticleads2-->

##### Cara menyiapkan Babat Gongso:

1. Uleg bumbu halus. Sisihkan.
1. Rebus babat. Buang airnya dan potong- potong babanya sesuai selera.
1. Tumis bumbu halus sampai beraroma. Tambahkan daun salam, daun jeruk, serai dan lengkuas. Tambahkan 100 ml air. Masak sampai bumbu keluar minyak kembali.
1. Masukkan air 500 ml dan potongan babat. Masak sampai air agak menyusut, tambahkan gula jawa, kecap manis dan garam.
1. Kalau kuahnya tinggal sepertiga, masukkan irisan tomat dan cabe rawit utuh. Masak sampai kuah menyusut dan meresap ke babat. Matikan kompor.
1. Angkat dan sajikan...




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Harapan kami, olahan Babat Gongso yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman ataupun menjadi inspirasi untuk berbisnis kuliner. Selamat mencoba!
