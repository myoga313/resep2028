---
description: "Bahan Ayam gongso pedas | Cara Mengolah Ayam gongso pedas Yang Lezat Sekali"
title: "Bahan Ayam gongso pedas | Cara Mengolah Ayam gongso pedas Yang Lezat Sekali"
slug: 183-bahan-ayam-gongso-pedas-cara-mengolah-ayam-gongso-pedas-yang-lezat-sekali
date: 2020-09-01T01:44:11.873Z
image: https://img-global.cpcdn.com/recipes/9f4a7c3223c478e6/751x532cq70/ayam-gongso-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9f4a7c3223c478e6/751x532cq70/ayam-gongso-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9f4a7c3223c478e6/751x532cq70/ayam-gongso-pedas-foto-resep-utama.jpg
author: Richard Fuller
ratingvalue: 3.6
reviewcount: 8
recipeingredient:
- "4 paha ayam"
- " Bumbu"
- "4 butir bawang putih"
- "4 butir bawang merah"
- "4 cabai merah"
- "5 cabai rawit"
- "5 cabai hijau kecil"
- "2 tomat merah kecil"
- " Daun bawang"
- " Kol"
- " Wortel"
- " Bumbu dapur"
- "2 cm jahe"
- "2 lbr Daun salam"
- "secukupnya Kecap"
- "secukupnya Saos tomat"
- "1 sdt gula pasir"
- "1 sdk kecil garam"
- " Merica bubuk"
recipeinstructions:
- "Rebus ayam kurleb 10 menit beri sedikit garam dan 2 lbr daun salam"
- "Sambil menunggu ayam empuk, iris bawang putih bawang merah dan cabai"
- "Kemudian persiapkan wajan dan tumis bawang merah putih tunggu sampai agak layu, kemudian masukkan cabai"
- "Kemudian masukkan ayam yg sudah matang dan beri air sedikit kemudian masukkan wortel yg sudah diiris agak tipis"
- "Tunggu sampai mendidih kemudian masukkan garam gula dan jahe, beri kecap dan saus tomat serta sedikit merica bubuk"
- "Masukkan kol yg sudah diiris dan daun bawang, dan kemudian tomat yg sudah diris"
- "Aduk dan cicipi, tmbhakan penyedap supaya lebih enak dan juga bawang goreng serta sledri di atasnya"
- "Tunggu sampai matang dan masakan siap disajikan. Happy Cooking ibu ibu 😍"
categories:
- Resep
tags:
- ayam
- gongso
- pedas

katakunci: ayam gongso pedas 
nutrition: 170 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam gongso pedas](https://img-global.cpcdn.com/recipes/9f4a7c3223c478e6/751x532cq70/ayam-gongso-pedas-foto-resep-utama.jpg)

Kamu Sedang mencari inspirasi resep ayam gongso pedas yang Paling Enak? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. kalau keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal ayam gongso pedas yang enak selayaknya punya aroma dan cita rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso pedas, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan ayam gongso pedas yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.




Berikut ini ada beberapa tips dan trik praktis dalam mengolah ayam gongso pedas yang siap dikreasikan. Anda bisa menyiapkan Ayam gongso pedas memakai 19 bahan dan 8 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam gongso pedas:

1. Sediakan 4 paha ayam
1. Ambil  Bumbu
1. Siapkan 4 butir bawang putih
1. Ambil 4 butir bawang merah
1. Siapkan 4 cabai merah
1. Gunakan 5 cabai rawit
1. Gunakan 5 cabai hijau kecil
1. Sediakan 2 tomat merah kecil
1. Ambil  Daun bawang
1. Siapkan  Kol
1. Gunakan  Wortel
1. Ambil  Bumbu dapur
1. Sediakan 2 cm jahe
1. Sediakan 2 lbr Daun salam
1. Siapkan secukupnya Kecap
1. Siapkan secukupnya Saos tomat
1. Sediakan 1 sdt gula pasir
1. Ambil 1 sdk kecil garam
1. Ambil  Merica bubuk




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam gongso pedas:

1. Rebus ayam kurleb 10 menit beri sedikit garam dan 2 lbr daun salam
1. Sambil menunggu ayam empuk, iris bawang putih bawang merah dan cabai
1. Kemudian persiapkan wajan dan tumis bawang merah putih tunggu sampai agak layu, kemudian masukkan cabai
1. Kemudian masukkan ayam yg sudah matang dan beri air sedikit kemudian masukkan wortel yg sudah diiris agak tipis
1. Tunggu sampai mendidih kemudian masukkan garam gula dan jahe, beri kecap dan saus tomat serta sedikit merica bubuk
1. Masukkan kol yg sudah diiris dan daun bawang, dan kemudian tomat yg sudah diris
1. Aduk dan cicipi, tmbhakan penyedap supaya lebih enak dan juga bawang goreng serta sledri di atasnya
1. Tunggu sampai matang dan masakan siap disajikan. Happy Cooking ibu ibu 😍




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Besar harapan kami, olahan Ayam gongso pedas yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi inspirasi bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
