---
description: "Resep Ayam Gongso | Cara Masak Ayam Gongso Yang Enak Banget"
title: "Resep Ayam Gongso | Cara Masak Ayam Gongso Yang Enak Banget"
slug: 305-resep-ayam-gongso-cara-masak-ayam-gongso-yang-enak-banget
date: 2020-07-24T06:49:08.820Z
image: https://img-global.cpcdn.com/recipes/6abd680c11ee0b62/751x532cq70/ayam-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6abd680c11ee0b62/751x532cq70/ayam-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6abd680c11ee0b62/751x532cq70/ayam-gongso-foto-resep-utama.jpg
author: Mary Howard
ratingvalue: 3
reviewcount: 12
recipeingredient:
- " Ayam sedang cuci bersih"
- " Bawang merah"
- " Bawang putih"
- " Bawang bombay"
- " Cabe rawit"
- " Kecap manis"
- " Saos Tiram"
- " Himalaya salt"
- " Lada bubuk"
- " Kaldu bubuk"
- " Air untuk merebus"
recipeinstructions:
- "Potong ayah agak kecil, lalu didihkan air dan rebus hingga ayam matang. Sisihkan jangan dibuang air rebusannya"
- "Iris trio bawang dan cabe, aslinya dihaluskan ya bamer, baput n cabe nya. Lalu tumis dengan minyak hingga wangi"
- "Masukkan air rebusan, kecap, saos tiram, garam, lada, kaldu bubuk. Masak hingga mendidih"
- "Masukkan ayam, masak hingga kuah meresap ke daging ayam"
- "Angkat dan sajikan, nikmat dengan sebakul nasi"
categories:
- Resep
tags:
- ayam
- gongso

katakunci: ayam gongso 
nutrition: 232 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Gongso](https://img-global.cpcdn.com/recipes/6abd680c11ee0b62/751x532cq70/ayam-gongso-foto-resep-utama.jpg)

Sedang mencari inspirasi resep ayam gongso yang Enak dan Simpel? Cara Bikinnya memang tidak susah dan tidak juga mudah. Jika salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal ayam gongso yang enak selayaknya punya aroma dan rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam gongso, mulai dari jenis bahan, lalu pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tidak usah pusing jika ingin menyiapkan ayam gongso yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.




Berikut ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah ayam gongso yang siap dikreasikan. Anda bisa menyiapkan Ayam Gongso menggunakan 11 bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam Gongso:

1. Ambil  Ayam sedang, cuci bersih
1. Sediakan  Bawang merah
1. Sediakan  Bawang putih
1. Sediakan  Bawang bombay
1. Siapkan  Cabe rawit
1. Siapkan  Kecap manis
1. Sediakan  Saos Tiram
1. Siapkan  Himalaya salt
1. Siapkan  Lada bubuk
1. Siapkan  Kaldu bubuk
1. Gunakan  Air untuk merebus




<!--inarticleads2-->

##### Cara menyiapkan Ayam Gongso:

1. Potong ayah agak kecil, lalu didihkan air dan rebus hingga ayam matang. Sisihkan jangan dibuang air rebusannya
1. Iris trio bawang dan cabe, aslinya dihaluskan ya bamer, baput n cabe nya. Lalu tumis dengan minyak hingga wangi
1. Masukkan air rebusan, kecap, saos tiram, garam, lada, kaldu bubuk. Masak hingga mendidih
1. Masukkan ayam, masak hingga kuah meresap ke daging ayam
1. Angkat dan sajikan, nikmat dengan sebakul nasi




Bagaimana? Gampang kan? Itulah cara menyiapkan ayam gongso yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
