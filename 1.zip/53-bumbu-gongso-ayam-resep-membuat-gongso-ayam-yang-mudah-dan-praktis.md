---
description: "Bumbu Gongso Ayam | Resep Membuat Gongso Ayam Yang Mudah Dan Praktis"
title: "Bumbu Gongso Ayam | Resep Membuat Gongso Ayam Yang Mudah Dan Praktis"
slug: 53-bumbu-gongso-ayam-resep-membuat-gongso-ayam-yang-mudah-dan-praktis
date: 2020-12-22T02:07:55.275Z
image: https://img-global.cpcdn.com/recipes/5c87525a3444e3d3/751x532cq70/gongso-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5c87525a3444e3d3/751x532cq70/gongso-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5c87525a3444e3d3/751x532cq70/gongso-ayam-foto-resep-utama.jpg
author: Iva Wilson
ratingvalue: 3.8
reviewcount: 4
recipeingredient:
- " Bahan "
- "600 gr ayam fillet potongpotong"
- "2 sdm saus turam"
- "4 sdm kecap manis"
- "1/2 sdt lada hitam remah"
- "250 ml air"
- "Secukupnya garam"
- "Secukupnya gula"
- "Secukupnya kaldu bubuk"
- "3 sdm minyak untuk menumis"
- " Bumbu iris  boleh dihaluskan"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "1 buah bombay kecil"
- "1 buah cabe merah"
recipeinstructions:
- "Tumis bumbu iris dengan sedikit minyak sampai harum, lalu masukkan potongan ayam, aduk rata, masak sampai ayam agak berubah warna"
- "Masukkan saus tiram, kecap manis, dan air, aduk rata"
- "Tambahkan lada hitam remah dan bumbu bumbu lainnya"
- "Masak sampai matang mendidih, ayam empuk dan kuah menyusut"
- "Jika sudah matang pindahkan ke wadah untuk disajikan"
categories:
- Resep
tags:
- gongso
- ayam

katakunci: gongso ayam 
nutrition: 182 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Dinner

---


![Gongso Ayam](https://img-global.cpcdn.com/recipes/5c87525a3444e3d3/751x532cq70/gongso-ayam-foto-resep-utama.jpg)

Anda sedang mencari ide resep gongso ayam yang Lezat Sekali? Cara Bikinnya memang susah-susah gampang. sekiranya keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gongso ayam yang enak seharusnya memiliki aroma dan rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ayam, mulai dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tak perlu pusing jika mau menyiapkan gongso ayam enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.

Lihat juga resep Gongso Ayam ala Semarangan enak lainnya. Aduuuuuh lama gak upload nih, tapi tenang aja kita bakalan rajin lagi kok hehe. kali ini kita masak gongso ayam nih, siapa tau jadi ide masak buat temen. Gongso berarti tumis dalam bahasa jawa.


Nah, kali ini kita coba, yuk, ciptakan gongso ayam sendiri di rumah. Tetap dengan bahan sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa membuat Gongso Ayam memakai 15 bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Gongso Ayam:

1. Siapkan  Bahan :
1. Sediakan 600 gr ayam fillet, potong-potong
1. Ambil 2 sdm saus turam
1. Siapkan 4 sdm kecap manis
1. Ambil 1/2 sdt lada hitam remah
1. Sediakan 250 ml air
1. Siapkan Secukupnya garam
1. Siapkan Secukupnya gula
1. Sediakan Secukupnya kaldu bubuk
1. Siapkan 3 sdm minyak untuk menumis
1. Siapkan  Bumbu iris : (boleh dihaluskan)
1. Gunakan 6 siung bawang merah
1. Ambil 3 siung bawang putih
1. Sediakan 1 buah bombay kecil
1. Sediakan 1 buah cabe merah


Jadi Gongso Ayam kali ini bisa dikatakan dengan sebutan Gongso Ayam Suwir istimewa atau Goreng ataupun Gongso Ayam Goreng Suwir loh. Yah mungkin berbeda daerah berbeda juga. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso Ayam:

1. Tumis bumbu iris dengan sedikit minyak sampai harum, lalu masukkan potongan ayam, aduk rata, masak sampai ayam agak berubah warna
1. Masukkan saus tiram, kecap manis, dan air, aduk rata
1. Tambahkan lada hitam remah dan bumbu bumbu lainnya
1. Masak sampai matang mendidih, ayam empuk dan kuah menyusut
1. Jika sudah matang pindahkan ke wadah untuk disajikan




Gimana nih? Mudah bukan? Itulah cara membuat gongso ayam yang bisa Anda praktikkan di rumah. Selamat mencoba!
