---
description: "Olahan Ayam Gongso Pangkep Semarang | Langkah Membuat Ayam Gongso Pangkep Semarang Yang Enak dan Simpel"
title: "Olahan Ayam Gongso Pangkep Semarang | Langkah Membuat Ayam Gongso Pangkep Semarang Yang Enak dan Simpel"
slug: 226-olahan-ayam-gongso-pangkep-semarang-langkah-membuat-ayam-gongso-pangkep-semarang-yang-enak-dan-simpel
date: 2020-08-25T09:52:06.267Z
image: https://img-global.cpcdn.com/recipes/27e83ff96d56e782/751x532cq70/ayam-gongso-pangkep-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/27e83ff96d56e782/751x532cq70/ayam-gongso-pangkep-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/27e83ff96d56e782/751x532cq70/ayam-gongso-pangkep-semarang-foto-resep-utama.jpg
author: Vincent Phelps
ratingvalue: 3.3
reviewcount: 7
recipeingredient:
- " dada ayam"
- " Bumbu Halus"
- " garam"
- " gula"
- " lada bubuk"
- " cabai keriting"
- " cabai Rawit"
- " bawang merah"
- " bawang putih"
- " tomat"
- " Bahan bahan"
- " kentang Potong kotak2"
- " wortel potong kotak2"
- " lmbar daun jeruk"
- " daun salam"
- " serei geprek"
- " dewasa Jahe Geprek"
- " Kecap manis"
- " minyak kelapa"
- " Air"
recipeinstructions:
- "Nyalahkan Api lalu siapkan panci yg sudah di isi air 1/2 liter, masukan Ayam daun salam, daun jeruk, serei, jahe, kentang dan wortel.. masak ayam hingga Empuk"
- "Sembari menunggu ayam empuk haluskan semua bumbu Halus,"
- "Setelah ayam sdh empuk angkat ayam dan potong2 atau suir2 ayam..."
- "Tumis bumbu halus yg sdh d haluskan tadi hingga Harum.. jika sdh harus masukan Air bekas ukepan ayam tadi beserta bumbu2 dan sayurannya.. aduk rata dan masukan ayam.."
- "Setelah semua tercamput rata tunggu hingga Air menyurut dan koreksi rasa beri kecap dan siap di hidangkan..."
categories:
- Resep
tags:
- ayam
- gongso
- pangkep

katakunci: ayam gongso pangkep 
nutrition: 100 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Gongso Pangkep Semarang](https://img-global.cpcdn.com/recipes/27e83ff96d56e782/751x532cq70/ayam-gongso-pangkep-semarang-foto-resep-utama.jpg)

Bunda lagi mencari inspirasi resep ayam gongso pangkep semarang yang Lezat? Cara Buatnya memang susah-susah gampang. seandainya keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal ayam gongso pangkep semarang yang enak selayaknya punya aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso pangkep semarang, pertama dari jenis bahan, lalu pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tidak usah pusing kalau hendak menyiapkan ayam gongso pangkep semarang yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.




Di bawah ini ada beberapa tips dan trik praktis untuk membuat ayam gongso pangkep semarang yang siap dikreasikan. Anda dapat menyiapkan Ayam Gongso Pangkep Semarang memakai 20 jenis bahan dan 5 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Gongso Pangkep Semarang:

1. Ambil  dada ayam
1. Sediakan  Bumbu Halus
1. Siapkan  garam
1. Sediakan  gula
1. Gunakan  lada bubuk
1. Gunakan  cabai keriting
1. Siapkan  cabai Rawit
1. Siapkan  bawang merah
1. Gunakan  bawang putih
1. Sediakan  tomat
1. Gunakan  Bahan bahan
1. Gunakan  kentang (Potong kotak2)
1. Sediakan  wortel (potong kotak2)
1. Gunakan  lmbar daun jeruk
1. Ambil  daun salam
1. Ambil  serei geprek
1. Gunakan  dewasa Jahe Geprek
1. Gunakan  Kecap manis
1. Sediakan  minyak kelapa
1. Ambil  Air




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Gongso Pangkep Semarang:

1. Nyalahkan Api lalu siapkan panci yg sudah di isi air 1/2 liter, masukan Ayam daun salam, daun jeruk, serei, jahe, kentang dan wortel.. masak ayam hingga Empuk
1. Sembari menunggu ayam empuk haluskan semua bumbu Halus,
1. Setelah ayam sdh empuk angkat ayam dan potong2 atau suir2 ayam...
1. Tumis bumbu halus yg sdh d haluskan tadi hingga Harum.. jika sdh harus masukan Air bekas ukepan ayam tadi beserta bumbu2 dan sayurannya.. aduk rata dan masukan ayam..
1. Setelah semua tercamput rata tunggu hingga Air menyurut dan koreksi rasa beri kecap dan siap di hidangkan...




Bagaimana? Mudah bukan? Itulah cara menyiapkan ayam gongso pangkep semarang yang bisa Anda lakukan di rumah. Selamat mencoba!
