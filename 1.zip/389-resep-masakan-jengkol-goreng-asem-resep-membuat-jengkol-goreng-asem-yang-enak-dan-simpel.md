---
description: "Resep masakan Jengkol goreng asem | Resep Membuat Jengkol goreng asem Yang Enak dan Simpel"
title: "Resep masakan Jengkol goreng asem | Resep Membuat Jengkol goreng asem Yang Enak dan Simpel"
slug: 389-resep-masakan-jengkol-goreng-asem-resep-membuat-jengkol-goreng-asem-yang-enak-dan-simpel
date: 2020-09-12T12:11:02.652Z
image: https://img-global.cpcdn.com/recipes/8436236854e83a24/751x532cq70/jengkol-goreng-asem-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8436236854e83a24/751x532cq70/jengkol-goreng-asem-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8436236854e83a24/751x532cq70/jengkol-goreng-asem-foto-resep-utama.jpg
author: Michael Smith
ratingvalue: 5
reviewcount: 3
recipeingredient:
- "1/4 kg jengkol belah 4"
- "1 bungkus asam jawa dilarutkan dengan air 14 gelas"
- " Air Rebusan "
- "1 tangkai sereh geprek"
- "1 lembar daun jeruk"
- "1 lembar daun salam"
- " Lengkuas geprek"
- "2 sdt bubuk kopi hitam"
- "2 sdt garam"
- " Bumbu halus"
- "20 buah cabai merah"
- "10 buah cabai rawit merah"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "secukupnya Minyak"
recipeinstructions:
- "Rendam terlebih dahulu jengkol, kemudian belah 4 bagian."
- "Rebus jengkol dengan air rebusan sampai jengkol empuk, kurang lebih 1/2 jam. Jika di rasa masih kurang empuk, bisa lebih lama lagi. (Rebusan ini di maksudkan agar jengkol hilang bau nya dan legit rasa jengkolnya, jika kepingin rasa jengkolnya gurih, bisa langsung di goreng)"
- "Angkat dan buang kulitnya. Cuci kembali, lalu goreng jengkol dgn minyak panas. Angkat dan tiriskan"
- "Siapkan bumbu dan tumis hingga harum dan matang, kemudian masukkan air asam jawa, aduk2 lalu masukkan jengkol, aduk hingga meresap."
- "Angkat, dan sajikan. Lebih nikmat dimakan dengan nasi hangat"
- "Selamat makaaaannn🤗🍽"
categories:
- Resep
tags:
- jengkol
- goreng
- asem

katakunci: jengkol goreng asem 
nutrition: 257 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Lunch

---


![Jengkol goreng asem](https://img-global.cpcdn.com/recipes/8436236854e83a24/751x532cq70/jengkol-goreng-asem-foto-resep-utama.jpg)

Sedang mencari inspirasi resep jengkol goreng asem yang Enak dan Simpel? Cara menyiapkannya memang tidak susah dan tidak juga mudah. andaikan keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal jengkol goreng asem yang enak selayaknya punya aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari jengkol goreng asem, mulai dari jenis bahan, kedua pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tidak usah pusing jika ingin menyiapkan jengkol goreng asem yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan istimewa.


Berikut ini ada beberapa cara mudah dan praktis untuk membuat jengkol goreng asem yang siap dikreasikan. Anda bisa membuat Jengkol goreng asem memakai 15 jenis bahan dan 6 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Jengkol goreng asem:

1. Siapkan 1/4 kg jengkol belah 4
1. Gunakan 1 bungkus asam jawa dilarutkan dengan air 1/4 gelas
1. Ambil  Air Rebusan :
1. Ambil 1 tangkai sereh (geprek)
1. Ambil 1 lembar daun jeruk
1. Sediakan 1 lembar daun salam
1. Sediakan  Lengkuas (geprek)
1. Sediakan 2 sdt bubuk kopi hitam
1. Siapkan 2 sdt garam
1. Sediakan  Bumbu halus
1. Gunakan 20 buah cabai merah
1. Gunakan 10 buah cabai rawit merah
1. Gunakan 6 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Ambil secukupnya Minyak




<!--inarticleads2-->

##### Langkah-langkah membuat Jengkol goreng asem:

1. Rendam terlebih dahulu jengkol, kemudian belah 4 bagian.
1. Rebus jengkol dengan air rebusan sampai jengkol empuk, kurang lebih 1/2 jam. Jika di rasa masih kurang empuk, bisa lebih lama lagi. (Rebusan ini di maksudkan agar jengkol hilang bau nya dan legit rasa jengkolnya, jika kepingin rasa jengkolnya gurih, bisa langsung di goreng)
1. Angkat dan buang kulitnya. Cuci kembali, lalu goreng jengkol dgn minyak panas. Angkat dan tiriskan
1. Siapkan bumbu dan tumis hingga harum dan matang, kemudian masukkan air asam jawa, aduk2 lalu masukkan jengkol, aduk hingga meresap.
1. Angkat, dan sajikan. Lebih nikmat dimakan dengan nasi hangat
1. Selamat makaaaannn🤗🍽




Gimana nih? Gampang kan? Itulah cara membuat jengkol goreng asem yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
