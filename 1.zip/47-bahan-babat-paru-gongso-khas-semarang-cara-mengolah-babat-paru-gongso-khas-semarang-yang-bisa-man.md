---
description: "Bahan Babat Paru Gongso khas Semarang | Cara Mengolah Babat Paru Gongso khas Semarang Yang Bisa Manjain Lidah"
title: "Bahan Babat Paru Gongso khas Semarang | Cara Mengolah Babat Paru Gongso khas Semarang Yang Bisa Manjain Lidah"
slug: 47-bahan-babat-paru-gongso-khas-semarang-cara-mengolah-babat-paru-gongso-khas-semarang-yang-bisa-manjain-lidah
date: 2020-07-27T03:10:15.138Z
image: https://img-global.cpcdn.com/recipes/d79c3af7cd266475/751x532cq70/babat-paru-gongso-khas-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d79c3af7cd266475/751x532cq70/babat-paru-gongso-khas-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d79c3af7cd266475/751x532cq70/babat-paru-gongso-khas-semarang-foto-resep-utama.jpg
author: Jack Soto
ratingvalue: 3.8
reviewcount: 5
recipeingredient:
- "500 gr Paru  Babat"
- "2 Lembar Daun Salam"
- "2 Lembar Daun Jeruk"
- "1 Tangkai Serai"
- "2 Ruas Lengkuas"
- "1 Ruas Jahe geprek"
- " Bahan Halus"
- "7 Siung Bawang Merah"
- "5 Siung Bawang Putih"
- "5 Buah Cabe Merah sesuai selera"
- "5 Buah Cabe Rawit sesuaI selera"
- " Bumbu Masak"
- " Garam"
- " Gula"
- " Kecap Manis"
- " Minyak untuk menumis"
- "sesuai selera Penyedap Masakan Kaldu Jamur  Micin atau"
recipeinstructions:
- "Rebus/Presto daging Paru &amp; Babat agar empuk dengan daun salam, lengkuas &amp; daun serai. Jika sudah matang &amp; empuk tiriskan."
- "Haluskan (saya pakai blender) Bumbu² Halus dan sisakan 4 siung bawang merah untuk dicincang."
- "Panaskan minyak, masukan bawang merah yang sudah dicincang, jahe geprek, daun jeruk dan 1 batang serai sampai harum. Kemudian masukan bumbu halus, aduk² sampai matang baru tambahkan air dan kecap. Masukan paru &amp; babat, tambahkan garam, gula, bumbu penyedap. Koreksi rasa"
- "Masak sampe bumbu meresap dan air berkurang. Sajikan"
categories:
- Resep
tags:
- babat
- paru
- gongso

katakunci: babat paru gongso 
nutrition: 116 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Dessert

---


![Babat Paru Gongso khas Semarang](https://img-global.cpcdn.com/recipes/d79c3af7cd266475/751x532cq70/babat-paru-gongso-khas-semarang-foto-resep-utama.jpg)

Lagi mencari inspirasi resep babat paru gongso khas semarang yang Enak dan Simpel? Cara Memasaknya memang susah-susah gampang. seumpama keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal babat paru gongso khas semarang yang enak selayaknya punya aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari babat paru gongso khas semarang, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tidak usah pusing kalau ingin menyiapkan babat paru gongso khas semarang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.




Nah, kali ini kita coba, yuk, variasikan babat paru gongso khas semarang sendiri di rumah. Tetap berbahan sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Babat Paru Gongso khas Semarang menggunakan 17 jenis bahan dan 4 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Babat Paru Gongso khas Semarang:

1. Gunakan 500 gr Paru &amp; Babat
1. Siapkan 2 Lembar Daun Salam
1. Gunakan 2 Lembar Daun Jeruk
1. Gunakan 1 Tangkai Serai
1. Gunakan 2 Ruas Lengkuas
1. Siapkan 1 Ruas Jahe (geprek)
1. Sediakan  Bahan Halus
1. Ambil 7 Siung Bawang Merah
1. Ambil 5 Siung Bawang Putih
1. Siapkan 5 Buah Cabe Merah (sesuai selera)
1. Ambil 5 Buah Cabe Rawit (sesuaI selera)
1. Gunakan  Bumbu Masak
1. Sediakan  Garam
1. Ambil  Gula
1. Gunakan  Kecap Manis
1. Gunakan  Minyak untuk menumis
1. Sediakan sesuai selera Penyedap Masakan (Kaldu Jamur &amp; Micin) atau




<!--inarticleads2-->

##### Cara membuat Babat Paru Gongso khas Semarang:

1. Rebus/Presto daging Paru &amp; Babat agar empuk dengan daun salam, lengkuas &amp; daun serai. Jika sudah matang &amp; empuk tiriskan.
1. Haluskan (saya pakai blender) Bumbu² Halus dan sisakan 4 siung bawang merah untuk dicincang.
1. Panaskan minyak, masukan bawang merah yang sudah dicincang, jahe geprek, daun jeruk dan 1 batang serai sampai harum. Kemudian masukan bumbu halus, aduk² sampai matang baru tambahkan air dan kecap. Masukan paru &amp; babat, tambahkan garam, gula, bumbu penyedap. Koreksi rasa
1. Masak sampe bumbu meresap dan air berkurang. Sajikan




Bagaimana? Mudah bukan? Itulah cara membuat babat paru gongso khas semarang yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
