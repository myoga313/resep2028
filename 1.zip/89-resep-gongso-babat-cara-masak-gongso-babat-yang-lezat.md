---
description: "Resep Gongso Babat | Cara Masak Gongso Babat Yang Lezat"
title: "Resep Gongso Babat | Cara Masak Gongso Babat Yang Lezat"
slug: 89-resep-gongso-babat-cara-masak-gongso-babat-yang-lezat
date: 2020-09-27T20:05:25.192Z
image: https://img-global.cpcdn.com/recipes/b864884112d65000/751x532cq70/gongso-babat-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b864884112d65000/751x532cq70/gongso-babat-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b864884112d65000/751x532cq70/gongso-babat-foto-resep-utama.jpg
author: Clifford McGee
ratingvalue: 3.2
reviewcount: 3
recipeingredient:
- "200 gr babat sapi"
- "200 gr otot sapi"
- "200 gr has dalamtenderloin"
- " Bahan kering "
- "1 ruas jahe iris tipis"
- "2 batang sereh geprek"
- "1 ruas lengkuasgeprek"
- "3 lembar daun salam"
- "4 lembar daun jeruk"
- "10 biji cabe utuh"
- "2 buah tomatpotong2"
- "1 sdm saus tiram"
- "2 sdm kecap manis"
- "1 sachet masako sapi"
- "2 sdm gula merah"
- "1/2 sdt garam"
- " Bumbu Halus "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "6 biji cabe"
- "5 butir kemiri"
- "1 sdt ketumbar"
- "1 sdt merica"
recipeinstructions:
- "Rebus otot sapi, has dalam n babat hingga empuk lalu potong sesuai selera."
- "Haluskan bumbu lalu tumis masukkan bahan kering kecuali tomat, masukkam tomat nanti wktu udh matang biar tomatnya gak hancur. Lalu bumbui dgn garam,saus tiram,kecap manis,gula merah,masako. Aduk rata. Beri air secukupnya. Lalu masukkan tomat. Aduk. Cek rasa. Angkat. Sajikan."
categories:
- Resep
tags:
- gongso
- babat

katakunci: gongso babat 
nutrition: 269 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Dinner

---


![Gongso Babat](https://img-global.cpcdn.com/recipes/b864884112d65000/751x532cq70/gongso-babat-foto-resep-utama.jpg)

Lagi mencari inspirasi resep gongso babat yang Sempurna? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. seumpama keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gongso babat yang enak harusnya sih punya aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso babat, mulai dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tak perlu pusing kalau mau menyiapkan gongso babat yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.




Nah, kali ini kita coba, yuk, variasikan gongso babat sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Gongso Babat memakai 23 jenis bahan dan 2 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Gongso Babat:

1. Gunakan 200 gr babat sapi
1. Gunakan 200 gr otot sapi
1. Gunakan 200 gr has dalam/tenderloin
1. Gunakan  Bahan kering :
1. Sediakan 1 ruas jahe, iris tipis
1. Ambil 2 batang sereh geprek
1. Gunakan 1 ruas lengkuas,geprek
1. Ambil 3 lembar daun salam
1. Ambil 4 lembar daun jeruk
1. Sediakan 10 biji cabe utuh
1. Ambil 2 buah tomat,potong2
1. Ambil 1 sdm saus tiram
1. Gunakan 2 sdm kecap manis
1. Gunakan 1 sachet masako sapi
1. Sediakan 2 sdm gula merah
1. Ambil 1/2 sdt garam
1. Sediakan  Bumbu Halus :
1. Gunakan 5 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Siapkan 6 biji cabe
1. Siapkan 5 butir kemiri
1. Siapkan 1 sdt ketumbar
1. Ambil 1 sdt merica




<!--inarticleads2-->

##### Cara membuat Gongso Babat:

1. Rebus otot sapi, has dalam n babat hingga empuk lalu potong sesuai selera.
1. Haluskan bumbu lalu tumis masukkan bahan kering kecuali tomat, masukkam tomat nanti wktu udh matang biar tomatnya gak hancur. Lalu bumbui dgn garam,saus tiram,kecap manis,gula merah,masako. Aduk rata. Beri air secukupnya. Lalu masukkan tomat. Aduk. Cek rasa. Angkat. Sajikan.




Bagaimana? Gampang kan? Itulah cara membuat gongso babat yang bisa Anda lakukan di rumah. Selamat mencoba!
