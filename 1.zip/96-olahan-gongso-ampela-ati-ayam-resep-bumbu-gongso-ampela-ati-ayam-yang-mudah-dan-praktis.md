---
description: "Olahan Gongso ampela ati Ayam | Resep Bumbu Gongso ampela ati Ayam Yang Mudah Dan Praktis"
title: "Olahan Gongso ampela ati Ayam | Resep Bumbu Gongso ampela ati Ayam Yang Mudah Dan Praktis"
slug: 96-olahan-gongso-ampela-ati-ayam-resep-bumbu-gongso-ampela-ati-ayam-yang-mudah-dan-praktis
date: 2020-08-10T15:30:55.179Z
image: https://img-global.cpcdn.com/recipes/32a497c23c0bca3b/751x532cq70/gongso-ampela-ati-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/32a497c23c0bca3b/751x532cq70/gongso-ampela-ati-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/32a497c23c0bca3b/751x532cq70/gongso-ampela-ati-ayam-foto-resep-utama.jpg
author: Essie Armstrong
ratingvalue: 3.1
reviewcount: 5
recipeingredient:
- "10 pasang ampla ati ayam"
- "10 biji cabe ijo tw"
- " Bumbu"
- "10 cabe rawit galak"
- "5 cabe merah kriting"
- "5 butir bawang merah"
- "3 butir bawang putih"
- "3 buah tomat"
- "1 ruas jari lengkuas"
- "1 lembar daun salam"
- "1 bungkus bumbu kaldu"
- "1 sdt gula pasir"
- "1 sdt garam"
- "1 SDM minyak goreng"
recipeinstructions:
- "Cuci bersih ampla ati lalu rebus dan potong2 menurut selera"
- "Haluskan bumbu dan potong2 cabe ijonya..lalu tumis bumbu halus sampe wangi dan masukkan ampla atinya"
- "Setelah ampla masuk lalu masukkan cabe ijonya aduk rata tambahkan semua bumbu tambahannya..tambahkan sedikit air..cek rasa..setelah matang angkat hidang kan dengan nasi panaa"
categories:
- Resep
tags:
- gongso
- ampela
- ati

katakunci: gongso ampela ati 
nutrition: 116 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Dinner

---


![Gongso ampela ati Ayam](https://img-global.cpcdn.com/recipes/32a497c23c0bca3b/751x532cq70/gongso-ampela-ati-ayam-foto-resep-utama.jpg)

Kamu Sedang mencari ide resep gongso ampela ati ayam yang Sempurna? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. apabila keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal gongso ampela ati ayam yang enak harusnya sih mempunyai aroma dan cita rasa yang mampu memancing selera kita.

Lihat juga resep Gongso Ayam ala Semarangan enak lainnya. Cara membuat gongso ati ampela yang sedap. Ati ayam punya citarasa yang gurih manis, sementara ampela punya tektstur kenyal yang bikin nagih.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ampela ati ayam, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan gongso ampela ati ayam yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan istimewa.


Berikut ini ada beberapa cara mudah dan praktis dalam mengolah gongso ampela ati ayam yang siap dikreasikan. Anda bisa membuat Gongso ampela ati Ayam memakai 14 jenis bahan dan 3 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Gongso ampela ati Ayam:

1. Siapkan 10 pasang ampla ati ayam
1. Gunakan 10 biji cabe ijo tw
1. Ambil  Bumbu
1. Siapkan 10 cabe rawit galak
1. Siapkan 5 cabe merah kriting
1. Sediakan 5 butir bawang merah
1. Sediakan 3 butir bawang putih
1. Ambil 3 buah tomat
1. Sediakan 1 ruas jari lengkuas
1. Sediakan 1 lembar daun salam
1. Ambil 1 bungkus bumbu kaldu
1. Gunakan 1 sdt gula pasir
1. Gunakan 1 sdt garam
1. Gunakan 1 SDM minyak goreng


Nah, jika kamu bosan dengan olahan hati ayam biasanya, ada baiknya untuk mencoba resep-resep baru ini. Meski pemula sekalipun, langkah-langkah memasak ini juga mudah untuk dipraktikkan. Kalau diolah dengan tepat, ati ampela ayam bisa menjadi hidangan yang super nikmat, tidak bau dan empuk. Kuncinya yaitu merebus ati ampela dengan rempah-rempah aromatik. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso ampela ati Ayam:

1. Cuci bersih ampla ati lalu rebus dan potong2 menurut selera
1. Haluskan bumbu dan potong2 cabe ijonya..lalu tumis bumbu halus sampe wangi dan masukkan ampla atinya
1. Setelah ampla masuk lalu masukkan cabe ijonya aduk rata tambahkan semua bumbu tambahannya..tambahkan sedikit air..cek rasa..setelah matang angkat hidang kan dengan nasi panaa


Karena ati ampela bisa mengeras bila dimasak terlalu lama, sebelum mengolahnya kamu harus pastikan untuk menumis. Selain daging ayam, gongso juga bisa menggunakan bahan lain seperti usus sapi, babat, ati ampela, hingga ceker ayam. Jika Teman Traveler ingin mencoba kuliner Solo, jangan lupa untuk mampir ke sini ya. Sama seperti bagian ayam lainnya, ampela ayam memiliki banyak kandungan nutrisi dan juga rasa yang sangat lezat, tidak hanya mengandung kolesterol. Resep Masak Ati Ampela Ayam Kecap Pedas Manis rasanya dijamin enak banget pedasnya bikin makan pengen nambah terus. 

Gimana nih? Gampang kan? Itulah cara membuat gongso ampela ati ayam yang bisa Anda praktikkan di rumah. Selamat mencoba!
