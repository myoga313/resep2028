---
description: "Bahan Ayam Gongso 🐥🌶🥘 | Langkah Membuat Ayam Gongso 🐥🌶🥘 Yang Lezat"
title: "Bahan Ayam Gongso 🐥🌶🥘 | Langkah Membuat Ayam Gongso 🐥🌶🥘 Yang Lezat"
slug: 208-bahan-ayam-gongso-langkah-membuat-ayam-gongso-yang-lezat
date: 2020-11-25T14:19:17.669Z
image: https://img-global.cpcdn.com/recipes/286617cd649333d8/751x532cq70/ayam-gongso-🐥🌶🥘-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/286617cd649333d8/751x532cq70/ayam-gongso-🐥🌶🥘-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/286617cd649333d8/751x532cq70/ayam-gongso-🐥🌶🥘-foto-resep-utama.jpg
author: Nathaniel Black
ratingvalue: 4.2
reviewcount: 9
recipeingredient:
- "1/4 kg paha ayam fillet"
- "1 sdm mentegamargarin"
- "Secukupnya kecap manis"
- " Bumbu Halus "
- "2 siung bawang merah"
- "1 siung bawang putih"
- "1 buah kemiri"
- "2 buah cabe merah keriting"
- "5 buah cabe rawit merah optional"
- "1/4 keping gula merah"
- "1 sachet royco"
- "Secukupnya gula pasir"
- "Secukupnya garam"
- " Bumbu Iris "
- "4 siung bawang merah"
- "5 buah cabe rawit merah optional"
recipeinstructions:
- "Bersihkan ayam, lalu potong ayam bentuk kotak/dadu, sisihkan."
- "Haluskan bumbu halus, kecuali gula merah, royco, garam dan gula pasir."
- "Panaskan sedikit minyak dan mentega/margarin pada wajan/penggorengan. Lalu masukkan irisan bawang merah, tumis sebentar, kemudian masukkan bumbu halus. Tumis kembali bumbu sampai setengah matang."
- "Setelah bumbu hampir matang, masukkan irisan gula merah dan irisan cabe rawit merah. Tumis kembali bumbu sampai matang."
- "Setelah bumbu matang, masukkan ayam, aduk rata sampai semua tercampur. Setelah itu, masukkan kecap manis, royco dan gula pasir. Cek rasa. Apabila kurang asin, bisa tambahkan garam. Disesuaikan dengan selera masing-masing."
- "Masak ayam sampai benar-benar ter (gongso), sampai agak kecoklatan/karamelisasi."
- "Setelah matang, angkat dan sajikan dengan nasi hangat. 🍚☺"
categories:
- Resep
tags:
- ayam
- gongso

katakunci: ayam gongso 
nutrition: 211 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Gongso 🐥🌶🥘](https://img-global.cpcdn.com/recipes/286617cd649333d8/751x532cq70/ayam-gongso-🐥🌶🥘-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep ayam gongso 🐥🌶🥘 yang Sempurna? Cara menyiapkannya memang tidak susah dan tidak juga mudah. semisal keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal ayam gongso 🐥🌶🥘 yang enak harusnya sih memiliki aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam gongso 🐥🌶🥘, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tidak usah pusing jika hendak menyiapkan ayam gongso 🐥🌶🥘 enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.




Di bawah ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah ayam gongso 🐥🌶🥘 yang siap dikreasikan. Anda bisa membuat Ayam Gongso 🐥🌶🥘 menggunakan 16 bahan dan 7 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam Gongso 🐥🌶🥘:

1. Siapkan 1/4 kg paha ayam fillet
1. Gunakan 1 sdm mentega/margarin
1. Sediakan Secukupnya kecap manis
1. Siapkan  Bumbu Halus :
1. Ambil 2 siung bawang merah
1. Siapkan 1 siung bawang putih
1. Siapkan 1 buah kemiri
1. Ambil 2 buah cabe merah keriting
1. Ambil 5 buah cabe rawit merah (optional)
1. Siapkan 1/4 keping gula merah
1. Sediakan 1 sachet royco
1. Siapkan Secukupnya gula pasir
1. Ambil Secukupnya garam
1. Gunakan  Bumbu Iris :
1. Sediakan 4 siung bawang merah
1. Gunakan 5 buah cabe rawit merah (optional)




<!--inarticleads2-->

##### Cara menyiapkan Ayam Gongso 🐥🌶🥘:

1. Bersihkan ayam, lalu potong ayam bentuk kotak/dadu, sisihkan.
1. Haluskan bumbu halus, kecuali gula merah, royco, garam dan gula pasir.
1. Panaskan sedikit minyak dan mentega/margarin pada wajan/penggorengan. Lalu masukkan irisan bawang merah, tumis sebentar, kemudian masukkan bumbu halus. Tumis kembali bumbu sampai setengah matang.
1. Setelah bumbu hampir matang, masukkan irisan gula merah dan irisan cabe rawit merah. Tumis kembali bumbu sampai matang.
1. Setelah bumbu matang, masukkan ayam, aduk rata sampai semua tercampur. Setelah itu, masukkan kecap manis, royco dan gula pasir. Cek rasa. Apabila kurang asin, bisa tambahkan garam. Disesuaikan dengan selera masing-masing.
1. Masak ayam sampai benar-benar ter (gongso), sampai agak kecoklatan/karamelisasi.
1. Setelah matang, angkat dan sajikan dengan nasi hangat. 🍚☺




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Harapan kami, olahan Ayam Gongso 🐥🌶🥘 yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman ataupun menjadi ide untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
