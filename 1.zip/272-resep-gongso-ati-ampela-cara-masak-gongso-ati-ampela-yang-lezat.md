---
description: "Resep Gongso Ati Ampela | Cara Masak Gongso Ati Ampela Yang Lezat"
title: "Resep Gongso Ati Ampela | Cara Masak Gongso Ati Ampela Yang Lezat"
slug: 272-resep-gongso-ati-ampela-cara-masak-gongso-ati-ampela-yang-lezat
date: 2020-09-03T05:30:24.662Z
image: https://img-global.cpcdn.com/recipes/8785e6fff3e6573e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8785e6fff3e6573e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8785e6fff3e6573e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
author: Corey Powers
ratingvalue: 3.8
reviewcount: 3
recipeingredient:
- " ati ampela"
- " bawang merah iris"
- " garam"
- " gula pasir"
- " kunyit bubuk"
- " kecap manis"
- " air"
- " Bumbu cemplung "
- " daun salam"
- " daun jeruk"
- " sereh geprek"
- " jahe geprek"
- " laos geprek"
- " ketumbar bubuk"
- " Bumbu halus "
- " bawang merah"
- " bawang putih"
- " cabe merah keriting"
- " cabe rawit"
recipeinstructions:
- "Rebus ati ampela dengan bumbu cemplung. Angkat &amp; tiriskan kemudian potong-potong"
- "Tumis irisan bawang merah hingga harum kemudian masukkan irisan ati ampela. Angkat &amp; sisihkan"
- "Tumis bumbu halus dengan minyak bekas menumis tadi hingga harum"
- "Masukkan air kemudian bumbui dengan garam, gula, kecap manis &amp; kunyit bubuk kemudian tes rasa. Masukkan ati ampela, masak sebentar hingga air menyusut agar bumbu meresap"
- "Gongso ati ampela siap disajikan ❤"
categories:
- Resep
tags:
- gongso
- ati
- ampela

katakunci: gongso ati ampela 
nutrition: 230 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Lunch

---


![Gongso Ati Ampela](https://img-global.cpcdn.com/recipes/8785e6fff3e6573e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep gongso ati ampela yang Lezat? Cara menyiapkannya memang susah-susah gampang. seandainya keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso ati ampela yang enak seharusnya mempunyai aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ati ampela, pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara membuat dan menyajikannya. Tak perlu pusing kalau hendak menyiapkan gongso ati ampela enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian istimewa.


Di bawah ini ada beberapa tips dan trik praktis untuk membuat gongso ati ampela yang siap dikreasikan. Anda bisa menyiapkan Gongso Ati Ampela menggunakan 19 jenis bahan dan 5 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Gongso Ati Ampela:

1. Gunakan  ati ampela
1. Ambil  bawang merah, iris
1. Sediakan  garam
1. Sediakan  gula pasir
1. Sediakan  kunyit bubuk
1. Gunakan  kecap manis
1. Gunakan  air
1. Gunakan  Bumbu cemplung :
1. Ambil  daun salam
1. Gunakan  daun jeruk
1. Sediakan  sereh, geprek
1. Sediakan  jahe, geprek
1. Siapkan  laos, geprek
1. Gunakan  ketumbar bubuk
1. Ambil  Bumbu halus :
1. Gunakan  bawang merah
1. Sediakan  bawang putih
1. Sediakan  cabe merah keriting
1. Ambil  cabe rawit




<!--inarticleads2-->

##### Cara menyiapkan Gongso Ati Ampela:

1. Rebus ati ampela dengan bumbu cemplung. Angkat &amp; tiriskan kemudian potong-potong
1. Tumis irisan bawang merah hingga harum kemudian masukkan irisan ati ampela. Angkat &amp; sisihkan
1. Tumis bumbu halus dengan minyak bekas menumis tadi hingga harum
1. Masukkan air kemudian bumbui dengan garam, gula, kecap manis &amp; kunyit bubuk kemudian tes rasa. Masukkan ati ampela, masak sebentar hingga air menyusut agar bumbu meresap
1. Gongso ati ampela siap disajikan ❤




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Harapan kami, olahan Gongso Ati Ampela yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman maupun menjadi ide dalam berbisnis kuliner. Selamat mencoba!
