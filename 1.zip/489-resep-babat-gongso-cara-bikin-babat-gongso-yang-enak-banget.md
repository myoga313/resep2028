---
description: "Resep Babat gongso | Cara Bikin Babat gongso Yang Enak Banget"
title: "Resep Babat gongso | Cara Bikin Babat gongso Yang Enak Banget"
slug: 489-resep-babat-gongso-cara-bikin-babat-gongso-yang-enak-banget
date: 2020-07-15T21:36:38.490Z
image: https://img-global.cpcdn.com/recipes/d238cf7f716b3d76/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d238cf7f716b3d76/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d238cf7f716b3d76/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Maggie Pope
ratingvalue: 4.3
reviewcount: 13
recipeingredient:
- " babat handuk dan tetelan"
- " daun salam"
- " daun jeruk"
- " garam"
- " sereh di geprek"
- " lengkuas di geprek"
- " gula merah me skip"
- " kecap manis me skip"
- " Kaldu bubuk"
- " kapir sirih utk membersihkan babat"
- " Bumbu halus"
- " bawang merah"
- " bawang putih"
- " cabe merah keriting me merah besar"
- " rawit merah me skip"
- " lada bubuk"
- " kemiri"
- " bawang merah iris kasar untuk di tumis me skip"
recipeinstructions:
- "Bersihkan babat nya, cara saya : siapkan air baskom, isi dengan air panas tambahkan kapur sirih, aduk rata, kemudian masukkan babat nya (cuci babat terlebih dahulu) biarkan babat terendam kurang lebih 15 menit, kmudian tarik lapisan yg handuknya. Ini cara supaya bagian bulu handuknya lepas,"
- "Setelah babat di bersihkan, potobg-potong sesuai selera, kemudian rebus dgn tambahan daun salam, hingga empuk. (Saya di presto 10 menit) angkat, tiriskan babat."
- "Tumis irisan bawang merah hingga harum kemudian masukkan bumbu halus dan bahan lainnya, masak hingga bumbu matang, tambahkan kecap manis dan gula merah jika pakai."
- "Tambahkan sedikit air, masukkan potongan babat. Masak hingga bumbu meresap. Tambahkan gula garam dan kaldu bubuk, tes rasa. Siap disajikan"
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 119 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dessert

---


![Babat gongso](https://img-global.cpcdn.com/recipes/d238cf7f716b3d76/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Lagi mencari ide resep babat gongso yang Enak dan Simpel? Cara menyiapkannya memang tidak susah dan tidak juga mudah. sekiranya salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal babat gongso yang enak selayaknya punya aroma dan rasa yang dapat memancing selera kita.

Com - Babat Gongso kali ini special karena ada isonya. Babat Gongso yang menjadi tujuan kuliner setiap orang yang ke Semarang, merupakan setidaknya primadona dari sekian banyak makanan yang ada di Semarang. Yuk, belajar membuat Babat Gongso di rumah Anda!

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso, pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara membuat dan menyajikannya. Tidak usah pusing kalau mau menyiapkan babat gongso yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan istimewa.


Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah babat gongso yang siap dikreasikan. Anda dapat menyiapkan Babat gongso menggunakan 18 jenis bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Babat gongso:

1. Siapkan  babat handuk dan tetelan
1. Ambil  daun salam
1. Gunakan  daun jeruk
1. Sediakan  garam
1. Ambil  sereh di geprek
1. Ambil  lengkuas, di geprek
1. Sediakan  gula merah (me skip)
1. Sediakan  kecap manis (me skip)
1. Gunakan  Kaldu bubuk
1. Gunakan  kapir sirih utk membersihkan babat
1. Ambil  Bumbu halus
1. Siapkan  bawang merah
1. Gunakan  bawang putih
1. Siapkan  cabe merah keriting (me :merah besar)
1. Sediakan  rawit merah (me skip)
1. Sediakan  lada bubuk
1. Ambil  kemiri
1. Sediakan  bawang merah, iris kasar untuk di tumis (me skip)




<!--inarticleads2-->

##### Cara membuat Babat gongso:

1. Bersihkan babat nya, cara saya : siapkan air baskom, isi dengan air panas tambahkan kapur sirih, aduk rata, kemudian masukkan babat nya (cuci babat terlebih dahulu) biarkan babat terendam kurang lebih 15 menit, kmudian tarik lapisan yg handuknya. Ini cara supaya bagian bulu handuknya lepas,
1. Setelah babat di bersihkan, potobg-potong sesuai selera, kemudian rebus dgn tambahan daun salam, hingga empuk. (Saya di presto 10 menit) angkat, tiriskan babat.
1. Tumis irisan bawang merah hingga harum kemudian masukkan bumbu halus dan bahan lainnya, masak hingga bumbu matang, tambahkan kecap manis dan gula merah jika pakai.
1. Tambahkan sedikit air, masukkan potongan babat. Masak hingga bumbu meresap. Tambahkan gula garam dan kaldu bubuk, tes rasa. Siap disajikan




Bagaimana? Gampang kan? Itulah cara membuat babat gongso yang bisa Anda praktikkan di rumah. Selamat mencoba!
