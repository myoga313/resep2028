---
description: "Resep Gongso Ampela | Bahan Membuat Gongso Ampela Yang Enak Dan Lezat"
title: "Resep Gongso Ampela | Bahan Membuat Gongso Ampela Yang Enak Dan Lezat"
slug: 279-resep-gongso-ampela-bahan-membuat-gongso-ampela-yang-enak-dan-lezat
date: 2020-12-01T16:44:58.682Z
image: https://img-global.cpcdn.com/recipes/c17d1b0231749e06/751x532cq70/gongso-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c17d1b0231749e06/751x532cq70/gongso-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c17d1b0231749e06/751x532cq70/gongso-ampela-foto-resep-utama.jpg
author: Mathilda Jefferson
ratingvalue: 4
reviewcount: 3
recipeingredient:
- "500 gram ampela"
- " Bumbu Rebusan"
- "2 lembar Daun salam"
- "1 batang Sereh"
- "3 lembar daun jeruk"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1 sdt ketumbar bubuk"
- "750 ml air"
- " Bumbu dihaluskan"
- "1 buah cabe"
- "7 siung bawang merah"
- "7 siung bawang putih"
- "1 ruas kunyit"
- " Bumbu lainya"
- "4 siung bawang merah diiris"
- "7 buah cabe jablay"
- "3 lembar daun jeruk"
- "1 batang sereh"
- "1 lembar daun salam"
- "2 sdm kecap manis"
- "sesuai selera Garam"
- "200 ml air"
- " Minyak untuk menggoreng"
recipeinstructions:
- "Didihkan air, kemudian masukan daun salam, daun jeruk, sereh, jahe, lengkuas dan ketumbar bubuk aduk. Kemudian masukkan ampela. Rebus sampai matang, kemudian angkat dan potong potong"
- "Goreng bawang merah iris sampai wangi, masukkan potongan ampela. Goreng hingga setengah kering, angkat"
- "Tumis bumbu halus sampai wangi, tambahkan air masak sampai air mendidih masukkan ampela, tambahkan kecap, garam, penyedap rasa koreksi rasa, matikan kompor dan angkat"
- "Siap disantap dengan nasi hangat 😘"
categories:
- Resep
tags:
- gongso
- ampela

katakunci: gongso ampela 
nutrition: 250 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Dessert

---


![Gongso Ampela](https://img-global.cpcdn.com/recipes/c17d1b0231749e06/751x532cq70/gongso-ampela-foto-resep-utama.jpg)

Sedang mencari inspirasi resep gongso ampela yang Sempurna? Cara Memasaknya memang susah-susah gampang. bila salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso ampela yang enak harusnya sih mempunyai aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ampela, mulai dari jenis bahan, kemudian pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tidak usah pusing kalau ingin menyiapkan gongso ampela enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.




Nah, kali ini kita coba, yuk, ciptakan gongso ampela sendiri di rumah. Tetap berbahan yang sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Gongso Ampela memakai 24 bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Gongso Ampela:

1. Siapkan 500 gram ampela
1. Ambil  Bumbu Rebusan
1. Gunakan 2 lembar Daun salam
1. Gunakan 1 batang Sereh
1. Siapkan 3 lembar daun jeruk
1. Ambil 1 ruas jahe
1. Sediakan 1 ruas lengkuas
1. Sediakan 1 sdt ketumbar bubuk
1. Siapkan 750 ml air
1. Gunakan  Bumbu dihaluskan
1. Sediakan 1 buah cabe
1. Siapkan 7 siung bawang merah
1. Ambil 7 siung bawang putih
1. Gunakan 1 ruas kunyit
1. Ambil  Bumbu lainya
1. Gunakan 4 siung bawang merah, diiris
1. Sediakan 7 buah cabe jablay
1. Siapkan 3 lembar daun jeruk
1. Gunakan 1 batang sereh
1. Gunakan 1 lembar daun salam
1. Sediakan 2 sdm kecap manis
1. Ambil sesuai selera Garam
1. Siapkan 200 ml air
1. Sediakan  Minyak untuk menggoreng




<!--inarticleads2-->

##### Cara menyiapkan Gongso Ampela:

1. Didihkan air, kemudian masukan daun salam, daun jeruk, sereh, jahe, lengkuas dan ketumbar bubuk aduk. Kemudian masukkan ampela. Rebus sampai matang, kemudian angkat dan potong potong
1. Goreng bawang merah iris sampai wangi, masukkan potongan ampela. Goreng hingga setengah kering, angkat
1. Tumis bumbu halus sampai wangi, tambahkan air masak sampai air mendidih masukkan ampela, tambahkan kecap, garam, penyedap rasa koreksi rasa, matikan kompor dan angkat
1. Siap disantap dengan nasi hangat 😘




Bagaimana? Mudah bukan? Itulah cara menyiapkan gongso ampela yang bisa Anda praktikkan di rumah. Selamat mencoba!
