---
description: "Bahan Gongso Ati Ayam | Resep Bumbu Gongso Ati Ayam Yang Menggugah Selera"
title: "Bahan Gongso Ati Ayam | Resep Bumbu Gongso Ati Ayam Yang Menggugah Selera"
slug: 224-bahan-gongso-ati-ayam-resep-bumbu-gongso-ati-ayam-yang-menggugah-selera
date: 2020-11-03T08:42:17.151Z
image: https://img-global.cpcdn.com/recipes/306856a41c356983/751x532cq70/gongso-ati-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/306856a41c356983/751x532cq70/gongso-ati-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/306856a41c356983/751x532cq70/gongso-ati-ayam-foto-resep-utama.jpg
author: Chase Ortiz
ratingvalue: 4.7
reviewcount: 13
recipeingredient:
- "2 buah ati ampela ayam"
- "1 lembar daun salam"
- "2 lembar daun jeruk"
- "1 ruas lengkuas"
- " Tomat"
- " Ladaku"
- " Garam"
- " Gula"
- " Kaldu jamur"
- " Kecap"
- " Kunyit bubuk"
- " Margarin"
- " Minyak goreng"
- " Air"
- " Bumbu halus"
- "1 siung bawang putih"
- "2 siung bawang merah"
- "10 cabe rawit"
- "Sedikit kemiri"
recipeinstructions:
- "Ati ampela yang sudah direbus dipotong dadu"
- "Panaskan minyak goreng dan sedikit margarin, masukkan bumbu halus, daun salam, lengkuas, daun jeruk, lalu masukkan potongan ati ampela, aduk-aduk"
- "Masukkan air secukupnya, potongan tomat, beri garam, gula pasir, ladaku, kecap, kaldu jamur, kunyit bubuk, aduk-aduk, diamkan hingga air mendidih dan menyusut"
- "Taraaaaa gongso ati ayam super pedas siap disantap"
categories:
- Resep
tags:
- gongso
- ati
- ayam

katakunci: gongso ati ayam 
nutrition: 222 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Dessert

---


![Gongso Ati Ayam](https://img-global.cpcdn.com/recipes/306856a41c356983/751x532cq70/gongso-ati-ayam-foto-resep-utama.jpg)

Sedang mencari ide resep gongso ati ayam yang Lezat? Cara Buatnya memang susah-susah gampang. apabila keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gongso ati ayam yang enak seharusnya memiliki aroma dan cita rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ati ayam, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan gongso ati ayam enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.




Nah, kali ini kita coba, yuk, siapkan gongso ati ayam sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Gongso Ati Ayam menggunakan 19 bahan dan 4 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Gongso Ati Ayam:

1. Siapkan 2 buah ati ampela ayam
1. Sediakan 1 lembar daun salam
1. Gunakan 2 lembar daun jeruk
1. Siapkan 1 ruas lengkuas
1. Sediakan  Tomat
1. Ambil  Ladaku
1. Ambil  Garam
1. Gunakan  Gula
1. Ambil  Kaldu jamur
1. Ambil  Kecap
1. Sediakan  Kunyit bubuk
1. Ambil  Margarin
1. Ambil  Minyak goreng
1. Gunakan  Air
1. Siapkan  Bumbu halus
1. Siapkan 1 siung bawang putih
1. Siapkan 2 siung bawang merah
1. Siapkan 10 cabe rawit
1. Siapkan Sedikit kemiri




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso Ati Ayam:

1. Ati ampela yang sudah direbus dipotong dadu
1. Panaskan minyak goreng dan sedikit margarin, masukkan bumbu halus, daun salam, lengkuas, daun jeruk, lalu masukkan potongan ati ampela, aduk-aduk
1. Masukkan air secukupnya, potongan tomat, beri garam, gula pasir, ladaku, kecap, kaldu jamur, kunyit bubuk, aduk-aduk, diamkan hingga air mendidih dan menyusut
1. Taraaaaa gongso ati ayam super pedas siap disantap




Gimana nih? Mudah bukan? Itulah cara membuat gongso ati ayam yang bisa Anda lakukan di rumah. Selamat mencoba!
