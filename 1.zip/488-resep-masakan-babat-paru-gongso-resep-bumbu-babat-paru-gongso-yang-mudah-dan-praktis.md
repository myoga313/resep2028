---
description: "Resep masakan Babat Paru Gongso | Resep Bumbu Babat Paru Gongso Yang Mudah Dan Praktis"
title: "Resep masakan Babat Paru Gongso | Resep Bumbu Babat Paru Gongso Yang Mudah Dan Praktis"
slug: 488-resep-masakan-babat-paru-gongso-resep-bumbu-babat-paru-gongso-yang-mudah-dan-praktis
date: 2020-08-29T22:06:10.818Z
image: https://img-global.cpcdn.com/recipes/84fddc1db7fa6aa8/751x532cq70/babat-paru-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/84fddc1db7fa6aa8/751x532cq70/babat-paru-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/84fddc1db7fa6aa8/751x532cq70/babat-paru-gongso-foto-resep-utama.jpg
author: Phillip Burton
ratingvalue: 5
reviewcount: 14
recipeingredient:
- " Babat Sapi"
- " Paru Sapi"
- " kunyit bubuk"
- " garam dapur"
- " jahe dimemarkan"
- " daun salam"
- " air buat merebus"
- " Bumbu halus "
- " bawang merah"
- " bawang putih"
- " Bahan Lainnya "
- " bawang merah di iris tipis"
- " batang serai ambil bagian putihnya memarkan"
- " lengkuas memarkan"
- " daun jeruk"
- " cabai rawit merah"
- " gula jawa"
- " kaldu bubuk"
- " garam"
- " lada bubuk"
- " gula pasir"
- " minyak goreng"
recipeinstructions:
- "Rebus sebentar babat dan paru utuh agar sisa darah dan kotorannya terangkat, lalu buang airnya"
- "Potong babat dan paru sesuai selera, lalu rebus dengan air agak banyak sampai terendam, tambahkan kunyit, jahe, daun salam dan garam, rebus hingga empuk, tiriskan"
- "Tumis bumbu halus hingga harum, tambahkan irisan bawang merah, serai, lengkuas, daun jeruk, tumis sampai agak layu"
- "Lalu tambahkan lagi sedikit minyak goreng masukkan potongan babat dan paru yg sudah direbus tadi tambahkan irisan gula jawa, gula pasir, garam, kaldu bubuk, lada dan cabai rawit merah aduk terus agar tidak gosong, masak hingga minyak goreng sat, koreksi rasa, siap dihidangkan"
categories:
- Resep
tags:
- babat
- paru
- gongso

katakunci: babat paru gongso 
nutrition: 201 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Dinner

---


![Babat Paru Gongso](https://img-global.cpcdn.com/recipes/84fddc1db7fa6aa8/751x532cq70/babat-paru-gongso-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep babat paru gongso yang Lezat? Cara menyiapkannya memang susah-susah gampang. seandainya salah mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal babat paru gongso yang enak seharusnya punya aroma dan rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari babat paru gongso, mulai dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tidak usah pusing jika hendak menyiapkan babat paru gongso enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.




Nah, kali ini kita coba, yuk, ciptakan babat paru gongso sendiri di rumah. Tetap berbahan sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa membuat Babat Paru Gongso menggunakan 22 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Babat Paru Gongso:

1. Sediakan  Babat Sapi
1. Siapkan  Paru Sapi
1. Sediakan  kunyit bubuk
1. Gunakan  garam dapur
1. Gunakan  jahe, dimemarkan
1. Gunakan  daun salam
1. Siapkan  air buat merebus
1. Siapkan  Bumbu halus :
1. Sediakan  bawang merah
1. Siapkan  bawang putih
1. Ambil  Bahan Lainnya :
1. Ambil  bawang merah di iris tipis
1. Sediakan  batang serai, ambil bagian putihnya, memarkan
1. Ambil  lengkuas, memarkan
1. Sediakan  daun jeruk
1. Ambil  cabai rawit merah
1. Sediakan  gula jawa
1. Siapkan  kaldu bubuk
1. Sediakan  garam
1. Siapkan  lada bubuk
1. Ambil  gula pasir
1. Sediakan  minyak goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Babat Paru Gongso:

1. Rebus sebentar babat dan paru utuh agar sisa darah dan kotorannya terangkat, lalu buang airnya
1. Potong babat dan paru sesuai selera, lalu rebus dengan air agak banyak sampai terendam, tambahkan kunyit, jahe, daun salam dan garam, rebus hingga empuk, tiriskan
1. Tumis bumbu halus hingga harum, tambahkan irisan bawang merah, serai, lengkuas, daun jeruk, tumis sampai agak layu
1. Lalu tambahkan lagi sedikit minyak goreng masukkan potongan babat dan paru yg sudah direbus tadi tambahkan irisan gula jawa, gula pasir, garam, kaldu bubuk, lada dan cabai rawit merah aduk terus agar tidak gosong, masak hingga minyak goreng sat, koreksi rasa, siap dihidangkan




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Harapan kami, olahan Babat Paru Gongso yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi ide untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
