---
description: "Bahan Babat Gongso Semarang ala Mbak Dyah | Resep Bumbu Babat Gongso Semarang ala Mbak Dyah Yang Enak Dan Lezat"
title: "Bahan Babat Gongso Semarang ala Mbak Dyah | Resep Bumbu Babat Gongso Semarang ala Mbak Dyah Yang Enak Dan Lezat"
slug: 491-bahan-babat-gongso-semarang-ala-mbak-dyah-resep-bumbu-babat-gongso-semarang-ala-mbak-dyah-yang-enak-dan-lezat
date: 2020-08-28T02:17:45.787Z
image: https://img-global.cpcdn.com/recipes/19bd68cd1e8a86d1/751x532cq70/babat-gongso-semarang-ala-mbak-dyah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/19bd68cd1e8a86d1/751x532cq70/babat-gongso-semarang-ala-mbak-dyah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/19bd68cd1e8a86d1/751x532cq70/babat-gongso-semarang-ala-mbak-dyah-foto-resep-utama.jpg
author: Marion Scott
ratingvalue: 3.2
reviewcount: 15
recipeingredient:
- " Babat yang sudah dicuci bersih bisa juga dicampur jerohan"
- " serai"
- " daun jeruk"
- " jahe"
- " Bumbu halus"
- " bawang putih"
- " bawang merah"
- " cabe merah besar"
- " cabe rawit"
- " kemiri"
- " jahe"
recipeinstructions:
- "Cuci bersih babat, kerok bagian hitamnya dengan pisau tumpul atau sendok. Lalu rebus dengan air yang sudah diberi sedikit garam dan tambahkan sejempol jahe geprek supaya nanti babatnya tidak berbau ataupun amis."
- "Setelah 20 - 30 menit angkat, lalu potong² babatnya dan taruh di wadah bersih."
- "Haluskan bumbu, lalu tumis beserta serai dan daun jeruk sampai harum."
- "Masukkan babat yang sudah direbus tadi kedalam tumisan bumbu. Tambahkan gula, garam dan penyedap rasa. Bisa ditambahkan juga kecap bila suka."
- "Aduk babat dan bumbu sampai tercampur rata. Masak kira² 15 menit sampai agak kering lalu angkat."
- "Sajikan kedalam wadah bersih dan beri taburan bawang goreng."
- "Babat gongso siap disantap dengan nasi hangat."
categories:
- Resep
tags:
- babat
- gongso
- semarang

katakunci: babat gongso semarang 
nutrition: 209 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dinner

---


![Babat Gongso Semarang ala Mbak Dyah](https://img-global.cpcdn.com/recipes/19bd68cd1e8a86d1/751x532cq70/babat-gongso-semarang-ala-mbak-dyah-foto-resep-utama.jpg)

Kamu Sedang mencari ide resep babat gongso semarang ala mbak dyah yang Enak Dan Mudah? Cara menyiapkannya memang susah-susah gampang. andaikan keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal babat gongso semarang ala mbak dyah yang enak selayaknya mempunyai aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari babat gongso semarang ala mbak dyah, pertama dari jenis bahan, kemudian pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tidak usah pusing jika ingin menyiapkan babat gongso semarang ala mbak dyah enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan spesial.


Nah, kali ini kita coba, yuk, siapkan babat gongso semarang ala mbak dyah sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Babat Gongso Semarang ala Mbak Dyah memakai 11 jenis bahan dan 7 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Babat Gongso Semarang ala Mbak Dyah:

1. Sediakan  Babat yang sudah dicuci bersih, bisa juga dicampur jerohan
1. Siapkan  serai
1. Ambil  daun jeruk
1. Ambil  jahe
1. Sediakan  Bumbu halus
1. Ambil  bawang putih
1. Sediakan  bawang merah
1. Sediakan  cabe merah besar
1. Gunakan  cabe rawit
1. Sediakan  kemiri
1. Sediakan  jahe




<!--inarticleads2-->

##### Cara membuat Babat Gongso Semarang ala Mbak Dyah:

1. Cuci bersih babat, kerok bagian hitamnya dengan pisau tumpul atau sendok. Lalu rebus dengan air yang sudah diberi sedikit garam dan tambahkan sejempol jahe geprek supaya nanti babatnya tidak berbau ataupun amis.
1. Setelah 20 - 30 menit angkat, lalu potong² babatnya dan taruh di wadah bersih.
1. Haluskan bumbu, lalu tumis beserta serai dan daun jeruk sampai harum.
1. Masukkan babat yang sudah direbus tadi kedalam tumisan bumbu. Tambahkan gula, garam dan penyedap rasa. Bisa ditambahkan juga kecap bila suka.
1. Aduk babat dan bumbu sampai tercampur rata. Masak kira² 15 menit sampai agak kering lalu angkat.
1. Sajikan kedalam wadah bersih dan beri taburan bawang goreng.
1. Babat gongso siap disantap dengan nasi hangat.




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Besar harapan kami, olahan Babat Gongso Semarang ala Mbak Dyah yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman ataupun menjadi inspirasi dalam berbisnis kuliner. Selamat mencoba!
