---
description: "Resep Gongso Semarangan | Cara Bikin Gongso Semarangan Yang Menggugah Selera"
title: "Resep Gongso Semarangan | Cara Bikin Gongso Semarangan Yang Menggugah Selera"
slug: 163-resep-gongso-semarangan-cara-bikin-gongso-semarangan-yang-menggugah-selera
date: 2021-01-02T01:42:50.860Z
image: https://img-global.cpcdn.com/recipes/296d9a0ac1fb0ed7/751x532cq70/gongso-semarangan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/296d9a0ac1fb0ed7/751x532cq70/gongso-semarangan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/296d9a0ac1fb0ed7/751x532cq70/gongso-semarangan-foto-resep-utama.jpg
author: Sally Vasquez
ratingvalue: 4.6
reviewcount: 9
recipeingredient:
- "1 butir telur"
- "1/2 pohon sawi putih"
- "2 buah sosis ayam"
- "5 butir bakso ukuran sedang potong jadi 2 bagian"
- "200 ml air"
- " Bumbu halus"
- "4 cabai merah"
- "1 cabai setan"
- "2 butir bawang merah"
- "2 butir bawang putih"
- "1/2 sdm kecap manis"
- " Seuprit lada halus"
- "Secukupnya garam"
- " Seuprit penyedap rasa bisa di skip"
recipeinstructions:
- "Siapkan minyak sedikit di wajan tunggu panas, gongso bumbu yang sudah dihaluskan (cabai, bawang putih, bawang merah)"
- "Setelah tercium harum, tambahkan air, tunggu sampai mendidih, ceplok telor sedikit di orak-arik"
- "Tambahkan sawi, bakso, dan sosis"
- "Masukkan garam, lada, kecap kemudian tes rasa (apabila sudah pas tidak perlu ditambahkan penyedap rasa)"
- "Gongso siap disajikan hangat-hangat"
categories:
- Resep
tags:
- gongso
- semarangan

katakunci: gongso semarangan 
nutrition: 255 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Lunch

---


![Gongso Semarangan](https://img-global.cpcdn.com/recipes/296d9a0ac1fb0ed7/751x532cq70/gongso-semarangan-foto-resep-utama.jpg)

Anda sedang mencari ide resep gongso semarangan yang Enak dan Simpel? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. sekiranya salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gongso semarangan yang enak seharusnya memiliki aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso semarangan, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tidak usah pusing kalau hendak menyiapkan gongso semarangan yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan spesial.




Nah, kali ini kita coba, yuk, siapkan gongso semarangan sendiri di rumah. Tetap berbahan sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Gongso Semarangan menggunakan 14 jenis bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Gongso Semarangan:

1. Sediakan 1 butir telur
1. Gunakan 1/2 pohon sawi putih
1. Siapkan 2 buah sosis ayam
1. Ambil 5 butir bakso ukuran sedang potong jadi 2 bagian
1. Sediakan 200 ml air
1. Siapkan  Bumbu halus
1. Gunakan 4 cabai merah
1. Siapkan 1 cabai setan
1. Sediakan 2 butir bawang merah
1. Ambil 2 butir bawang putih
1. Sediakan 1/2 sdm kecap manis
1. Siapkan  Seuprit lada halus
1. Siapkan Secukupnya garam
1. Sediakan  Seuprit penyedap rasa (bisa di skip)




<!--inarticleads2-->

##### Cara membuat Gongso Semarangan:

1. Siapkan minyak sedikit di wajan tunggu panas, gongso bumbu yang sudah dihaluskan (cabai, bawang putih, bawang merah)
1. Setelah tercium harum, tambahkan air, tunggu sampai mendidih, ceplok telor sedikit di orak-arik
1. Tambahkan sawi, bakso, dan sosis
1. Masukkan garam, lada, kecap kemudian tes rasa (apabila sudah pas tidak perlu ditambahkan penyedap rasa)
1. Gongso siap disajikan hangat-hangat




Gimana nih? Mudah bukan? Itulah cara membuat gongso semarangan yang bisa Anda lakukan di rumah. Selamat mencoba!
