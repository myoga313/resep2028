---
description: "Bumbu Ayam Bumbu Gongso | Langkah Membuat Ayam Bumbu Gongso Yang Lezat"
title: "Bumbu Ayam Bumbu Gongso | Langkah Membuat Ayam Bumbu Gongso Yang Lezat"
slug: 219-bumbu-ayam-bumbu-gongso-langkah-membuat-ayam-bumbu-gongso-yang-lezat
date: 2020-07-18T13:37:13.600Z
image: https://img-global.cpcdn.com/recipes/47fc1965f5d92b0a/751x532cq70/ayam-bumbu-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/47fc1965f5d92b0a/751x532cq70/ayam-bumbu-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/47fc1965f5d92b0a/751x532cq70/ayam-bumbu-gongso-foto-resep-utama.jpg
author: Maggie Rivera
ratingvalue: 4.1
reviewcount: 7
recipeingredient:
- " ayam bagian dada sayap dan paha bawah"
- " tomat merah"
- " daun bawang"
- " bawang merah iris tipis"
- " daun salam"
- " daun jeruk"
- " lengkuas"
- " saos sambal"
- " kecap manis"
- " saus tiram"
- " Bumbu Halus"
- " bawang merah"
- " bawang putih"
- " kemiri"
- " cabai keriting merah"
- " cabai rawit merah"
recipeinstructions:
- "Siapkan daging ayam, rebus hingga matang lalu suwir kasar, sisihkan"
- "Tumis irisan bawang merah hingga harum, kemudian masukkan bumbu halus, daun jeruk, lengkuas, daun salam. tumis hingga wangi"
- "Masukkan irisan tomat, aduk sebentar lalu masukkan ayam. beri air secukupnya"
- "Bumbui dengan kecap manis, saus tiram, dan secukupnya saus sambal. beri kaldu bubuk, tunggu hingga kuah meresap, tes rasa"
- "Jika rasa sudah pas, matikan api, taburi dengan potongan daun bawang"
- "Ayam bumbu gongso siap disajikan"
categories:
- Resep
tags:
- ayam
- bumbu
- gongso

katakunci: ayam bumbu gongso 
nutrition: 196 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Bumbu Gongso](https://img-global.cpcdn.com/recipes/47fc1965f5d92b0a/751x532cq70/ayam-bumbu-gongso-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep ayam bumbu gongso yang Sempurna? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. semisal keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal ayam bumbu gongso yang enak harusnya sih mempunyai aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam bumbu gongso, mulai dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan ayam bumbu gongso yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian istimewa.




Nah, kali ini kita coba, yuk, siapkan ayam bumbu gongso sendiri di rumah. Tetap berbahan sederhana, sajian ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Ayam Bumbu Gongso menggunakan 16 bahan dan 6 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Bumbu Gongso:

1. Gunakan  ayam bagian dada, sayap, dan paha bawah
1. Gunakan  tomat merah
1. Sediakan  daun bawang
1. Sediakan  bawang merah, iris tipis
1. Ambil  daun salam
1. Siapkan  daun jeruk
1. Siapkan  lengkuas
1. Siapkan  saos sambal
1. Gunakan  kecap manis
1. Sediakan  saus tiram
1. Ambil  Bumbu Halus:
1. Siapkan  bawang merah
1. Ambil  bawang putih
1. Siapkan  kemiri
1. Ambil  cabai keriting merah
1. Gunakan  cabai rawit merah




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Bumbu Gongso:

1. Siapkan daging ayam, rebus hingga matang lalu suwir kasar, sisihkan
1. Tumis irisan bawang merah hingga harum, kemudian masukkan bumbu halus, daun jeruk, lengkuas, daun salam. tumis hingga wangi
1. Masukkan irisan tomat, aduk sebentar lalu masukkan ayam. beri air secukupnya
1. Bumbui dengan kecap manis, saus tiram, dan secukupnya saus sambal. beri kaldu bubuk, tunggu hingga kuah meresap, tes rasa
1. Jika rasa sudah pas, matikan api, taburi dengan potongan daun bawang
1. Ayam bumbu gongso siap disajikan




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Harapan kami, olahan Ayam Bumbu Gongso yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman ataupun menjadi ide bagi Anda yang berkeinginan untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
