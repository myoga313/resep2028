---
description: "Bumbu Gongso Babat Sederhana | Cara Bikin Gongso Babat Sederhana Yang Enak Banget"
title: "Bumbu Gongso Babat Sederhana | Cara Bikin Gongso Babat Sederhana Yang Enak Banget"
slug: 29-bumbu-gongso-babat-sederhana-cara-bikin-gongso-babat-sederhana-yang-enak-banget
date: 2020-08-11T22:03:38.079Z
image: https://img-global.cpcdn.com/recipes/99c1e03738aa965a/751x532cq70/gongso-babat-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/99c1e03738aa965a/751x532cq70/gongso-babat-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/99c1e03738aa965a/751x532cq70/gongso-babat-sederhana-foto-resep-utama.jpg
author: Glen Harvey
ratingvalue: 4.2
reviewcount: 3
recipeingredient:
- "1/4 babat sapi"
- "6 siung bawang putih"
- "7 siung bawang merah"
- "10 buah cabe rawit"
- "3 buah kemiri"
- "1 sachet kecap bangau"
- "1 sdt ketumbar bubuk"
- "1 lembar daun salam"
- "1 lembar daun jeruk"
- "1 buah lengkuas"
- "secukupnya garam"
- "secukupnya gula"
recipeinstructions:
- "Rebus babat dengan air mendidih sampai benar-benar empuk"
- "Siapkan bumbu halus, bawang merah, bawang putih, kemiri, cabe rawit dan garam"
- "Tumis bumbu dan tambahkan sedikit air kemudian masukkan daun salam, daun jeruk, lengkuas dan kecap"
- "Masukkan babat pada bumbu halus, aduk sampai bumbu tercampur dan meresap"
- "Gongso babat sederhana siap disajikan. 😊"
categories:
- Resep
tags:
- gongso
- babat
- sederhana

katakunci: gongso babat sederhana 
nutrition: 210 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Dessert

---


![Gongso Babat Sederhana](https://img-global.cpcdn.com/recipes/99c1e03738aa965a/751x532cq70/gongso-babat-sederhana-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep gongso babat sederhana yang Bisa Manjain Lidah? Cara menyiapkannya memang susah-susah gampang. semisal keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso babat sederhana yang enak seharusnya memiliki aroma dan cita rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso babat sederhana, pertama dari jenis bahan, lalu pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan gongso babat sederhana enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian istimewa.




Nah, kali ini kita coba, yuk, ciptakan gongso babat sederhana sendiri di rumah. Tetap dengan bahan sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat membuat Gongso Babat Sederhana menggunakan 12 bahan dan 5 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Gongso Babat Sederhana:

1. Siapkan 1/4 babat sapi
1. Sediakan 6 siung bawang putih
1. Sediakan 7 siung bawang merah
1. Sediakan 10 buah cabe rawit
1. Siapkan 3 buah kemiri
1. Gunakan 1 sachet kecap bangau
1. Gunakan 1 sdt ketumbar bubuk
1. Sediakan 1 lembar daun salam
1. Siapkan 1 lembar daun jeruk
1. Siapkan 1 buah lengkuas
1. Ambil secukupnya garam
1. Gunakan secukupnya gula




<!--inarticleads2-->

##### Cara membuat Gongso Babat Sederhana:

1. Rebus babat dengan air mendidih sampai benar-benar empuk
1. Siapkan bumbu halus, bawang merah, bawang putih, kemiri, cabe rawit dan garam
1. Tumis bumbu dan tambahkan sedikit air kemudian masukkan daun salam, daun jeruk, lengkuas dan kecap
1. Masukkan babat pada bumbu halus, aduk sampai bumbu tercampur dan meresap
1. Gongso babat sederhana siap disajikan. 😊




Bagaimana? Mudah bukan? Itulah cara membuat gongso babat sederhana yang bisa Anda lakukan di rumah. Selamat mencoba!
