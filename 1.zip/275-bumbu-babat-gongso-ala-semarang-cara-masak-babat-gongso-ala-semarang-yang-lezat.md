---
description: "Bumbu Babat Gongso ala Semarang | Cara Masak Babat Gongso ala Semarang Yang Lezat"
title: "Bumbu Babat Gongso ala Semarang | Cara Masak Babat Gongso ala Semarang Yang Lezat"
slug: 275-bumbu-babat-gongso-ala-semarang-cara-masak-babat-gongso-ala-semarang-yang-lezat
date: 2020-09-02T00:12:12.827Z
image: https://img-global.cpcdn.com/recipes/90e4e03b66adbe56/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/90e4e03b66adbe56/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/90e4e03b66adbe56/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg
author: Lenora Wheeler
ratingvalue: 3.8
reviewcount: 9
recipeingredient:
- "1/2 kg babat sapi"
- "8 btr bawang merah"
- "2 btr bawang putih"
- "7 bh cabai merah keritingsesuai selera"
- "3 bh cabai rawit merahsesuai selera"
- "1 btr kemiri"
- "2-3 sdm kecap manissesuai selera"
- "1 sdm kecap asin1 sdt garam"
- "1 sdt kaldu jamurkaldu lainsesuai selera"
- "1/2 gelas air putih"
- "3-5 sdm minyak goreng untuk menumis"
recipeinstructions:
- "Siapkan semua bahan.. Cuci bersih babat, rebus hingga empuk, bisa dipresto atau pakai metode 5.30.7, potong/iris sesuai selera. Iris 5 btr bawang merah, sisanya haluskan bersama bawang putih+kemiri+cabai"
- "Panaskan minyak, goreng bawang merah hingga layu, masukkan bumbu halus, tumis hingga matang/agak kering, masukkan babat, aduk merata"
- "Tambahkan air+kecap manis+kecap asin/garam+kaldu jamur, aduk merata. Tunggu hingga air berkurang, cek rasa. Done.. Yuuk cobain"
categories:
- Resep
tags:
- babat
- gongso
- ala

katakunci: babat gongso ala 
nutrition: 147 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dessert

---


![Babat Gongso ala Semarang](https://img-global.cpcdn.com/recipes/90e4e03b66adbe56/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep babat gongso ala semarang yang Mudah Dan Praktis? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. apabila keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal babat gongso ala semarang yang enak seharusnya mempunyai aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso ala semarang, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan babat gongso ala semarang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.


Nah, kali ini kita coba, yuk, kreasikan babat gongso ala semarang sendiri di rumah. Tetap berbahan sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Babat Gongso ala Semarang menggunakan 11 jenis bahan dan 3 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Babat Gongso ala Semarang:

1. Gunakan 1/2 kg babat sapi
1. Siapkan 8 btr bawang merah
1. Gunakan 2 btr bawang putih
1. Gunakan 7 bh cabai merah keriting/sesuai selera
1. Siapkan 3 bh cabai rawit merah/sesuai selera
1. Siapkan 1 btr kemiri
1. Gunakan 2-3 sdm kecap manis/sesuai selera
1. Ambil 1 sdm kecap asin/1 sdt garam
1. Siapkan 1 sdt kaldu jamur/kaldu lain/sesuai selera
1. Siapkan 1/2 gelas air putih
1. Siapkan 3-5 sdm minyak goreng untuk menumis




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Babat Gongso ala Semarang:

1. Siapkan semua bahan.. Cuci bersih babat, rebus hingga empuk, bisa dipresto atau pakai metode 5.30.7, potong/iris sesuai selera. Iris 5 btr bawang merah, sisanya haluskan bersama bawang putih+kemiri+cabai
1. Panaskan minyak, goreng bawang merah hingga layu, masukkan bumbu halus, tumis hingga matang/agak kering, masukkan babat, aduk merata
1. Tambahkan air+kecap manis+kecap asin/garam+kaldu jamur, aduk merata. Tunggu hingga air berkurang, cek rasa. Done.. Yuuk cobain




Gimana nih? Mudah bukan? Itulah cara menyiapkan babat gongso ala semarang yang bisa Anda lakukan di rumah. Selamat mencoba!
