---
description: "Resep masakan 28. Gongso ayam khas kudus | Cara Membuat 28. Gongso ayam khas kudus Yang Enak Banget"
title: "Resep masakan 28. Gongso ayam khas kudus | Cara Membuat 28. Gongso ayam khas kudus Yang Enak Banget"
slug: 273-resep-masakan-28-gongso-ayam-khas-kudus-cara-membuat-28-gongso-ayam-khas-kudus-yang-enak-banget
date: 2020-09-14T19:04:44.721Z
image: https://img-global.cpcdn.com/recipes/685c4c41dbcd5d91/751x532cq70/28-gongso-ayam-khas-kudus-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/685c4c41dbcd5d91/751x532cq70/28-gongso-ayam-khas-kudus-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/685c4c41dbcd5d91/751x532cq70/28-gongso-ayam-khas-kudus-foto-resep-utama.jpg
author: Bernard Carter
ratingvalue: 3.1
reviewcount: 11
recipeingredient:
- "1 ekor ayam goreng suwir2"
- "500 ml air"
- "1 ikat sawi hijaume 4 lembar sawi putih"
- "1/4 kol me skip"
- "2 bh tomat"
- "2 sdm kecap manis"
- "1 sdt gula pasir"
- "1 sdt munjung garam"
- "1/2 sdt kaldu jamur"
- "5 bh cabe merah iris serong"
- "5 bh bawang merah iris halus"
- " Bumbu halus"
- "2 bh kemiri"
- "4 bawang putih"
- "1 sdt lada"
- "6 cabe rawit"
recipeinstructions:
- "Tumis bawang merah,bumbu halus, cabe iris, sampai harum kemudian masukan air"
- "Masukan ayam suwir, sawi,kecap manis, gula,garam,dan tomat"
- "Aduk rata dan tes rasa, jika di rasa pas, gongso ayam siap di hidangkan"
categories:
- Resep
tags:
- 28
- gongso
- ayam

katakunci: 28 gongso ayam 
nutrition: 145 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Dessert

---


![28. Gongso ayam khas kudus](https://img-global.cpcdn.com/recipes/685c4c41dbcd5d91/751x532cq70/28-gongso-ayam-khas-kudus-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep 28. gongso ayam khas kudus yang Lezat? Cara Buatnya memang susah-susah gampang. seumpama keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal 28. gongso ayam khas kudus yang enak seharusnya punya aroma dan cita rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari 28. gongso ayam khas kudus, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan 28. gongso ayam khas kudus enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan istimewa.




Nah, kali ini kita coba, yuk, buat 28. gongso ayam khas kudus sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat 28. Gongso ayam khas kudus menggunakan 16 jenis bahan dan 3 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan 28. Gongso ayam khas kudus:

1. Gunakan 1 ekor ayam goreng suwir2
1. Gunakan 500 ml air
1. Sediakan 1 ikat sawi hijau,me, 4 lembar sawi putih
1. Gunakan 1/4 kol me, skip
1. Gunakan 2 bh tomat
1. Siapkan 2 sdm kecap manis
1. Sediakan 1 sdt gula pasir
1. Siapkan 1 sdt munjung garam
1. Ambil 1/2 sdt kaldu jamur
1. Gunakan 5 bh cabe merah iris serong
1. Gunakan 5 bh bawang merah iris halus
1. Gunakan  Bumbu halus
1. Sediakan 2 bh kemiri
1. Siapkan 4 bawang putih
1. Ambil 1 sdt lada
1. Sediakan 6 cabe rawit




<!--inarticleads2-->

##### Cara menyiapkan 28. Gongso ayam khas kudus:

1. Tumis bawang merah,bumbu halus, cabe iris, sampai harum kemudian masukan air
1. Masukan ayam suwir, sawi,kecap manis, gula,garam,dan tomat
1. Aduk rata dan tes rasa, jika di rasa pas, gongso ayam siap di hidangkan




Gimana nih? Mudah bukan? Itulah cara menyiapkan 28. gongso ayam khas kudus yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
