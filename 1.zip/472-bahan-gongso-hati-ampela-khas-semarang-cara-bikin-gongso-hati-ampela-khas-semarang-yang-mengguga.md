---
description: "Bahan Gongso Hati Ampela Khas Semarang | Cara Bikin Gongso Hati Ampela Khas Semarang Yang Menggugah Selera"
title: "Bahan Gongso Hati Ampela Khas Semarang | Cara Bikin Gongso Hati Ampela Khas Semarang Yang Menggugah Selera"
slug: 472-bahan-gongso-hati-ampela-khas-semarang-cara-bikin-gongso-hati-ampela-khas-semarang-yang-menggugah-selera
date: 2020-09-05T03:12:58.238Z
image: https://img-global.cpcdn.com/recipes/ea7b75a5e702ba03/751x532cq70/gongso-hati-ampela-khas-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ea7b75a5e702ba03/751x532cq70/gongso-hati-ampela-khas-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ea7b75a5e702ba03/751x532cq70/gongso-hati-ampela-khas-semarang-foto-resep-utama.jpg
author: Jordan Cunningham
ratingvalue: 3.2
reviewcount: 8
recipeingredient:
- "5 pasang hati ampela"
- "3 lembar daun jeruk purut"
- "3 lembar daun salam"
- "1 batang serai geprek"
- "1 ruas lengkuas geprek"
- "1/2 sdt lada bubuk"
- "1 sdt saus tiram"
- "4 sdm kecap manis"
- "1 sdm gula merah iris"
- "3 buah cabai merah iris optional"
- "3 buah cabai rawit iris optional"
- "3 siung bawang putih geprek"
- "1 ruas jahe geprek"
- "Secukupnya air"
- "Secukupnya garam dan kaldu bubuk"
- "Secukupnya minyak untuk menumis"
- " Bumbu halus"
- "3 siung bawang putih"
- "1 siung bawang merah"
- "1 ruas jahe"
- "3 buah kemiri"
- "5 buah cabai merah"
- "3 buah cabai rawit"
recipeinstructions:
- "Rebus hati ampela yg sudah dicuci bersih, masukkan bawang putih dan jahe yg sudah digeprek. Rebus selama 5 menit, angkat dan tiriskan."
- "Haluskan semua bumbu halus."
- "Siapkan wajan dan panaskan minyak. Tumis bumbu halus bersama lada bubuk, daun salam, daun jeruk, lengkuas, dan serai. Tumis hingga harum."
- "Masukkan hati ampela yg sudah direbus tadi lalu beri sedikit air."
- "Masukkan kecap manis, saus tiram, gula merah, cabai merah+rawit yg sudah diiris, garam, dan kaldu bubuk. Aduk rata dan masak hingga bumbu meresap. Jangan lupa koreksi rasa."
- "Sajikan bersama nasi hangat ☺️🤩. Selamat mencoba 😘. Awas, siapkan nasi tambuh🤣"
categories:
- Resep
tags:
- gongso
- hati
- ampela

katakunci: gongso hati ampela 
nutrition: 138 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Dessert

---


![Gongso Hati Ampela Khas Semarang](https://img-global.cpcdn.com/recipes/ea7b75a5e702ba03/751x532cq70/gongso-hati-ampela-khas-semarang-foto-resep-utama.jpg)

Kamu Sedang mencari ide resep gongso hati ampela khas semarang yang Bikin Ngiler? Cara menyiapkannya memang susah-susah gampang. sekiranya salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso hati ampela khas semarang yang enak selayaknya memiliki aroma dan cita rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso hati ampela khas semarang, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tidak usah pusing jika mau menyiapkan gongso hati ampela khas semarang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan spesial.




Berikut ini ada beberapa tips dan trik praktis untuk membuat gongso hati ampela khas semarang yang siap dikreasikan. Anda bisa membuat Gongso Hati Ampela Khas Semarang memakai 23 bahan dan 6 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Gongso Hati Ampela Khas Semarang:

1. Siapkan 5 pasang hati ampela
1. Siapkan 3 lembar daun jeruk purut
1. Ambil 3 lembar daun salam
1. Sediakan 1 batang serai, geprek
1. Ambil 1 ruas lengkuas, geprek
1. Ambil 1/2 sdt lada bubuk
1. Gunakan 1 sdt saus tiram
1. Sediakan 4 sdm kecap manis
1. Sediakan 1 sdm gula merah, iris
1. Gunakan 3 buah cabai merah, iris (optional)
1. Siapkan 3 buah cabai rawit, iris (optional)
1. Gunakan 3 siung bawang putih, geprek
1. Ambil 1 ruas jahe, geprek
1. Sediakan Secukupnya air
1. Sediakan Secukupnya garam dan kaldu bubuk
1. Sediakan Secukupnya minyak untuk menumis
1. Gunakan  Bumbu halus:
1. Ambil 3 siung bawang putih
1. Ambil 1 siung bawang merah
1. Siapkan 1 ruas jahe
1. Sediakan 3 buah kemiri
1. Gunakan 5 buah cabai merah
1. Siapkan 3 buah cabai rawit




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso Hati Ampela Khas Semarang:

1. Rebus hati ampela yg sudah dicuci bersih, masukkan bawang putih dan jahe yg sudah digeprek. Rebus selama 5 menit, angkat dan tiriskan.
1. Haluskan semua bumbu halus.
1. Siapkan wajan dan panaskan minyak. Tumis bumbu halus bersama lada bubuk, daun salam, daun jeruk, lengkuas, dan serai. Tumis hingga harum.
1. Masukkan hati ampela yg sudah direbus tadi lalu beri sedikit air.
1. Masukkan kecap manis, saus tiram, gula merah, cabai merah+rawit yg sudah diiris, garam, dan kaldu bubuk. Aduk rata dan masak hingga bumbu meresap. Jangan lupa koreksi rasa.
1. Sajikan bersama nasi hangat ☺️🤩. Selamat mencoba 😘. Awas, siapkan nasi tambuh🤣




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Gongso Hati Ampela Khas Semarang yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman maupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Selamat mencoba!
