---
description: "Resep Babat gongso | Cara Mengolah Babat gongso Yang Lezat"
title: "Resep Babat gongso | Cara Mengolah Babat gongso Yang Lezat"
slug: 18-resep-babat-gongso-cara-mengolah-babat-gongso-yang-lezat
date: 2020-11-28T13:28:38.548Z
image: https://img-global.cpcdn.com/recipes/dd2583c584c71dd4/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dd2583c584c71dd4/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dd2583c584c71dd4/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Adeline Ross
ratingvalue: 5
reviewcount: 9
recipeingredient:
- "500 gr babat"
- " Bumbu halus"
- "10 bawang merah"
- "3 siung bawang putih"
- "5 butir kemiri"
- "10 buah cabe merah"
- "15 buah cabe setan sesuaikan selera"
- "secukupnya Kecap gula garam kaldu bubuk"
- "1 ruas kunyit di bakar"
- "1 ruas lengkuas memarkan"
- "2 lmbr daun salam"
recipeinstructions:
- "Jika membeli babat dri pasar tradisional otomatis babat masih dgn kulit yg warna hitam atau abu2 untuk membersihkan cukup rendam babat dalam larutan kapur sirih slma 15 -20 menit dgn begitu kulit berwarna hitam akan sangat mudah di kelupas tpi semua kembali ke selera ya.. ada yg suka babat dgn kulit yg hitam...."
- "Rebus babat dgn jahe yg di memarkan hingga empuk/di presto"
- "Tumis bumbu yg di haluskan.. hingga harum.. masukan babat.. gula..garam kaldu bubuk.. kecap manis.. tambakan 50 ml air... masak hingga bumbu meresap dan kuah mengental.. koreksi rasa.. angkat sajikan.."
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 110 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Lunch

---


![Babat gongso](https://img-global.cpcdn.com/recipes/dd2583c584c71dd4/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep babat gongso yang Menggugah Selera? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. sekiranya keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal babat gongso yang enak seharusnya punya aroma dan cita rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan babat gongso enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian spesial.

Com - Babat Gongso kali ini special karena ada isonya. Babat Gongso yang menjadi tujuan kuliner setiap orang yang ke Semarang, merupakan setidaknya primadona dari sekian banyak makanan yang ada di Semarang. Yuk, belajar membuat Babat Gongso di rumah Anda!


Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah babat gongso yang siap dikreasikan. Anda bisa menyiapkan Babat gongso menggunakan 11 bahan dan 3 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Babat gongso:

1. Ambil 500 gr babat
1. Siapkan  Bumbu halus👇
1. Sediakan 10 bawang merah
1. Siapkan 3 siung bawang putih
1. Sediakan 5 butir kemiri
1. Gunakan 10 buah cabe merah
1. Sediakan 15 buah cabe setan/ sesuaikan selera
1. Ambil secukupnya Kecap.. gula... garam... kaldu bubuk
1. Siapkan 1 ruas kunyit di bakar
1. Gunakan 1 ruas lengkuas memarkan
1. Siapkan 2 lmbr daun salam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Babat gongso:

1. Jika membeli babat dri pasar tradisional otomatis babat masih dgn kulit yg warna hitam atau abu2 untuk membersihkan cukup rendam babat dalam larutan kapur sirih slma 15 -20 menit dgn begitu kulit berwarna hitam akan sangat mudah di kelupas tpi semua kembali ke selera ya.. ada yg suka babat dgn kulit yg hitam....
1. Rebus babat dgn jahe yg di memarkan hingga empuk/di presto
1. Tumis bumbu yg di haluskan.. hingga harum.. masukan babat.. gula..garam kaldu bubuk.. kecap manis.. tambakan 50 ml air... masak hingga bumbu meresap dan kuah mengental.. koreksi rasa.. angkat sajikan..




Terima kasih telah membaca resep yang kami tampilkan di sini. Harapan kami, olahan Babat gongso yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi inspirasi untuk berjualan makanan. Selamat mencoba!
