---
description: "Bumbu Gongso Ati Ampela | Resep Bumbu Gongso Ati Ampela Yang Paling Enak"
title: "Bumbu Gongso Ati Ampela | Resep Bumbu Gongso Ati Ampela Yang Paling Enak"
slug: 436-bumbu-gongso-ati-ampela-resep-bumbu-gongso-ati-ampela-yang-paling-enak
date: 2020-11-04T21:00:58.702Z
image: https://img-global.cpcdn.com/recipes/ec87ae71490c5082/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ec87ae71490c5082/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ec87ae71490c5082/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
author: Julian Burns
ratingvalue: 4.2
reviewcount: 14
recipeingredient:
- "3 buah ati ayam"
- "5 buah ampela"
- "1 batang sereh geprek"
- "3 lembar daun jeruk"
- "2 sdm kecap manis"
- "2 sdm saus tiram"
- "1 sdt kaldu bubuk ayam"
- "Secukupnya garam lada bubuk dan gula pasir"
- "3/4 gelas air matang"
- " Bumbu iris"
- "5 butir bwg merah"
- "3 siung bwg putih"
- "10 cabe rawit sesuai selera"
- " Cabe hijau sy skip"
recipeinstructions:
- "Rebus ati ampela hingga matang, tiriskan lalu potong2."
- "Tumis bumbu iris, sereh getek dan daun jeruk hingga wangi, masukkan ati ampela. Aduk rata."
- "Beri air, kecap manis, saos tiram, garam, gula, lada, dan kaldu bubuk. Masak hingga kuah sisa sedikit."
- "Angkat dan sajikan 💚"
categories:
- Resep
tags:
- gongso
- ati
- ampela

katakunci: gongso ati ampela 
nutrition: 215 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Lunch

---


![Gongso Ati Ampela](https://img-global.cpcdn.com/recipes/ec87ae71490c5082/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg)

Sedang mencari ide resep gongso ati ampela yang Enak dan Simpel? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. kalau salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gongso ati ampela yang enak seharusnya mempunyai aroma dan cita rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ati ampela, mulai dari jenis bahan, kedua pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan gongso ati ampela yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.


Berikut ini ada beberapa cara mudah dan praktis untuk membuat gongso ati ampela yang siap dikreasikan. Anda bisa membuat Gongso Ati Ampela menggunakan 14 jenis bahan dan 4 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Gongso Ati Ampela:

1. Siapkan 3 buah ati ayam
1. Siapkan 5 buah ampela
1. Ambil 1 batang sereh, geprek
1. Ambil 3 lembar daun jeruk
1. Siapkan 2 sdm kecap manis
1. Gunakan 2 sdm saus tiram
1. Ambil 1 sdt kaldu bubuk ayam
1. Sediakan Secukupnya garam, lada bubuk dan gula pasir
1. Ambil 3/4 gelas air matang
1. Ambil  Bumbu iris:
1. Gunakan 5 butir bwg merah
1. Ambil 3 siung bwg putih
1. Sediakan 10 cabe rawit /sesuai selera
1. Ambil  Cabe hijau (sy skip)




<!--inarticleads2-->

##### Cara membuat Gongso Ati Ampela:

1. Rebus ati ampela hingga matang, tiriskan lalu potong2.
1. Tumis bumbu iris, sereh getek dan daun jeruk hingga wangi, masukkan ati ampela. Aduk rata.
1. Beri air, kecap manis, saos tiram, garam, gula, lada, dan kaldu bubuk. Masak hingga kuah sisa sedikit.
1. Angkat dan sajikan 💚




Bagaimana? Gampang kan? Itulah cara menyiapkan gongso ati ampela yang bisa Anda lakukan di rumah. Selamat mencoba!
