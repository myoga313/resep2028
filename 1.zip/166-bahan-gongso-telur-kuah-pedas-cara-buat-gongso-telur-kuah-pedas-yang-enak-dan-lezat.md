---
description: "Bahan Gongso Telur Kuah Pedas | Cara Buat Gongso Telur Kuah Pedas Yang Enak Dan Lezat"
title: "Bahan Gongso Telur Kuah Pedas | Cara Buat Gongso Telur Kuah Pedas Yang Enak Dan Lezat"
slug: 166-bahan-gongso-telur-kuah-pedas-cara-buat-gongso-telur-kuah-pedas-yang-enak-dan-lezat
date: 2020-12-21T04:10:56.396Z
image: https://img-global.cpcdn.com/recipes/b3ed347296472a4c/751x532cq70/gongso-telur-kuah-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b3ed347296472a4c/751x532cq70/gongso-telur-kuah-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b3ed347296472a4c/751x532cq70/gongso-telur-kuah-pedas-foto-resep-utama.jpg
author: Alberta Terry
ratingvalue: 3.6
reviewcount: 15
recipeingredient:
- "1 butir telur"
- "2 buah sosisbakso optional iris tipis"
- "1/3 kol iris sesuai seleradaun sawi hijau"
- "2 sdm minyak sayur"
- "1/2 sdt garam"
- "Sedikit merica bubuk"
- " Penyedap rasa secukupnya optional"
- "Sedikit Gula pasir"
- "1 sdm saus tomat"
- "1 sdt kecap manisasin"
- "500 ml air sesuai selera"
- " Bumbu halus "
- "2 cabe rawit sesuai selera"
- "3 cabe merah keriting"
- "3 siung bawang putih"
- "4 siung bawang merah"
- " Bawang goreng untuk taburan optional"
recipeinstructions:
- "Uleg cabe, bawang merah dan putih sampe halus."
- "Siapkan wajan tuang minyak sayur, kemudian pecahkan 1 butir telur dan orak arik, sisihkan di pinggir wajan."
- "Masukkan bumbu halus tumis sebentar sampe harum dan agak layu. Tuang air masukkan garam, merica dan penyedap rasa aduk sampe gak mendidih."
- "Masukkan kol dan sosis, masukkan saus tomat dan kecap manis/asin, masak kol sampe agak layu aduk dan tes rasa. Segera sajikan selagi panas.."
categories:
- Resep
tags:
- gongso
- telur
- kuah

katakunci: gongso telur kuah 
nutrition: 126 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Dinner

---


![Gongso Telur Kuah Pedas](https://img-global.cpcdn.com/recipes/b3ed347296472a4c/751x532cq70/gongso-telur-kuah-pedas-foto-resep-utama.jpg)

Kamu Sedang mencari inspirasi resep gongso telur kuah pedas yang Sempurna? Cara membuatnya memang susah-susah gampang. kalau salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gongso telur kuah pedas yang enak seharusnya punya aroma dan cita rasa yang bisa memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso telur kuah pedas, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tidak usah pusing jika mau menyiapkan gongso telur kuah pedas yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.


Nah, kali ini kita coba, yuk, kreasikan gongso telur kuah pedas sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Gongso Telur Kuah Pedas menggunakan 17 bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Gongso Telur Kuah Pedas:

1. Siapkan 1 butir telur
1. Siapkan 2 buah sosis/bakso (optional) iris tipis
1. Ambil 1/3 kol iris sesuai selera/daun sawi hijau
1. Sediakan 2 sdm minyak sayur
1. Sediakan 1/2 sdt garam
1. Gunakan Sedikit merica bubuk
1. Gunakan  Penyedap rasa secukupnya (optional)
1. Ambil Sedikit Gula pasir
1. Sediakan 1 sdm saus tomat
1. Siapkan 1 sdt kecap manis/asin
1. Sediakan 500 ml air (sesuai selera)
1. Ambil  Bumbu halus :
1. Ambil 2 cabe rawit (sesuai selera)
1. Sediakan 3 cabe merah keriting
1. Siapkan 3 siung bawang putih
1. Siapkan 4 siung bawang merah
1. Sediakan  Bawang goreng untuk taburan (optional)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso Telur Kuah Pedas:

1. Uleg cabe, bawang merah dan putih sampe halus.
1. Siapkan wajan tuang minyak sayur, kemudian pecahkan 1 butir telur dan orak arik, sisihkan di pinggir wajan.
1. Masukkan bumbu halus tumis sebentar sampe harum dan agak layu. Tuang air masukkan garam, merica dan penyedap rasa aduk sampe gak mendidih.
1. Masukkan kol dan sosis, masukkan saus tomat dan kecap manis/asin, masak kol sampe agak layu aduk dan tes rasa. Segera sajikan selagi panas..




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Harapan kami, olahan Gongso Telur Kuah Pedas yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi inspirasi dalam berjualan makanan. Semoga bermanfaat dan selamat mencoba!
