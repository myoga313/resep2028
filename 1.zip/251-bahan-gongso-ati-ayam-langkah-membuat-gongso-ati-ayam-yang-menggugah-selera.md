---
description: "Bahan Gongso ati ayam | Langkah Membuat Gongso ati ayam Yang Menggugah Selera"
title: "Bahan Gongso ati ayam | Langkah Membuat Gongso ati ayam Yang Menggugah Selera"
slug: 251-bahan-gongso-ati-ayam-langkah-membuat-gongso-ati-ayam-yang-menggugah-selera
date: 2020-08-27T04:44:01.842Z
image: https://img-global.cpcdn.com/recipes/b4d634e82743a90b/751x532cq70/gongso-ati-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b4d634e82743a90b/751x532cq70/gongso-ati-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b4d634e82743a90b/751x532cq70/gongso-ati-ayam-foto-resep-utama.jpg
author: Leona Warren
ratingvalue: 3.4
reviewcount: 14
recipeingredient:
- " ati ayam potong sesuai selera"
- " bawang bombayiris tipis"
- " bawang putih geprek cincang halus"
- " cabe merah keritingiris serong"
- " cabe rawitiris serong"
- " jahe geprek"
- " tomat ukuran sedang potong dadu"
- " sambel bawang"
- " Kecap manis"
- " Kecap inggris"
- " Saus tiram"
- " Garam"
- " gula pasir"
- " Penyedap rasa optional"
- " margarin utk menumis"
recipeinstructions:
- "Rebus ati ayam sampai matang,tiriskan,lalu potong2 sesuai selera, sisihkan"
- "Iris2 tipis bawang bombay, bawang putih digeprek cincang halus, jahe digeprek cincang halus,cabe merah dan cabe rawit iris serong"
- "Siapkan wajan, panaskan margarin utk menumis, masukkan bawang putih tumis sampai harum, lalu bawang bombay,jahe,cabe merah, cabe rawit dan tomat, tumis sampai harum dan agak layu"
- "Masukkan ati ayam,tambahkan air secukupnya, tambahkan garam, gula pasir, kecap manis, saus tiram, kecap inggris dan penyedap rasa"
- "Aduk rata, tunggu sampai mendidih, lalu koreksi rasa"
- "Tunggu sampai kuah agak menyusut, matikan kompor,siap dihidangkan"
categories:
- Resep
tags:
- gongso
- ati
- ayam

katakunci: gongso ati ayam 
nutrition: 100 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dinner

---


![Gongso ati ayam](https://img-global.cpcdn.com/recipes/b4d634e82743a90b/751x532cq70/gongso-ati-ayam-foto-resep-utama.jpg)

Bunda lagi mencari inspirasi resep gongso ati ayam yang Lezat Sekali? Cara Bikinnya memang susah-susah gampang. jikalau keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso ati ayam yang enak harusnya sih mempunyai aroma dan rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ati ayam, pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tidak usah pusing jika hendak menyiapkan gongso ati ayam enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.


Berikut ini ada beberapa tips dan trik praktis untuk membuat gongso ati ayam yang siap dikreasikan. Anda bisa membuat Gongso ati ayam memakai 15 jenis bahan dan 6 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Gongso ati ayam:

1. Sediakan  ati ayam, potong sesuai selera
1. Ambil  bawang bombay,iris tipis
1. Ambil  bawang putih, geprek cincang halus
1. Ambil  cabe merah keriting,iris serong
1. Sediakan  cabe rawit,iris serong
1. Gunakan  jahe, geprek
1. Gunakan  tomat ukuran sedang, potong dadu
1. Sediakan  sambel bawang
1. Gunakan  Kecap manis
1. Siapkan  Kecap inggris
1. Siapkan  Saus tiram
1. Gunakan  Garam
1. Gunakan  gula pasir
1. Ambil  Penyedap rasa (optional)
1. Sediakan  margarin utk menumis




<!--inarticleads2-->

##### Cara membuat Gongso ati ayam:

1. Rebus ati ayam sampai matang,tiriskan,lalu potong2 sesuai selera, sisihkan
1. Iris2 tipis bawang bombay, bawang putih digeprek cincang halus, jahe digeprek cincang halus,cabe merah dan cabe rawit iris serong
1. Siapkan wajan, panaskan margarin utk menumis, masukkan bawang putih tumis sampai harum, lalu bawang bombay,jahe,cabe merah, cabe rawit dan tomat, tumis sampai harum dan agak layu
1. Masukkan ati ayam,tambahkan air secukupnya, tambahkan garam, gula pasir, kecap manis, saus tiram, kecap inggris dan penyedap rasa
1. Aduk rata, tunggu sampai mendidih, lalu koreksi rasa
1. Tunggu sampai kuah agak menyusut, matikan kompor,siap dihidangkan




Gimana nih? Gampang kan? Itulah cara membuat gongso ati ayam yang bisa Anda lakukan di rumah. Selamat mencoba!
