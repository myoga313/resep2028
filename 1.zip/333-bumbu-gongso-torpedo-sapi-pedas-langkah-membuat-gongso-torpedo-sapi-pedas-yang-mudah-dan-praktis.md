---
description: "Bumbu Gongso Torpedo Sapi Pedas | Langkah Membuat Gongso Torpedo Sapi Pedas Yang Mudah Dan Praktis"
title: "Bumbu Gongso Torpedo Sapi Pedas | Langkah Membuat Gongso Torpedo Sapi Pedas Yang Mudah Dan Praktis"
slug: 333-bumbu-gongso-torpedo-sapi-pedas-langkah-membuat-gongso-torpedo-sapi-pedas-yang-mudah-dan-praktis
date: 2020-09-07T22:12:33.923Z
image: https://img-global.cpcdn.com/recipes/23a3a45b91b3d5f4/751x532cq70/gongso-torpedo-sapi-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/23a3a45b91b3d5f4/751x532cq70/gongso-torpedo-sapi-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/23a3a45b91b3d5f4/751x532cq70/gongso-torpedo-sapi-pedas-foto-resep-utama.jpg
author: Amy Carter
ratingvalue: 4.1
reviewcount: 5
recipeingredient:
- "1 torpedo sapi"
- "2 daun salam"
- "5 cm lengkuas"
- "12 cabai rawit utuh"
- "3 tomat"
- "1,5 sdt garam"
- "2 sdm gula jawa sisir"
- "2 sdt gula pasir"
- "1 sdt kaldu bubuk"
- "1 sdm saos tiram"
- "5 sdm kecap manis"
- "1 liter air"
- " Bumbu Halus "
- "3 bawang putih"
- "7 bawang merah"
- "25 cabai"
- "3 kemiri"
- "1 ruas jahe"
recipeinstructions:
- "Rebus torpedo sampe empuk dan potong2 sesuai selera."
- "Haluskan bahan bumbu halus."
- "Tumis bumbu halus bersama daun salam dan lengkuas, tumis sampai benar2 matang dan tanak."
- "Jika terlalu kering, tambah sedikit air dan tumis lagi sampai minyak bening &amp; tenang."
- "Masukkan torpedo sapi, aduk sampai tercampur bumbu."
- "Masukkan air, garam, gula, kaldu bubuk. Masak sampai mendidih."
- "Tambahkan cabai rawit utuh. Masak sampai air sedikit menyusut."
- "Tambahkan kecap dan saos tiram, aduk rata."
- "Masukkan irisan tomat &amp; Masak sampai air menyusut, dika suka berkuah masak jangan sampai air menyusut banyak ya."
categories:
- Resep
tags:
- gongso
- torpedo
- sapi

katakunci: gongso torpedo sapi 
nutrition: 216 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Lunch

---


![Gongso Torpedo Sapi Pedas](https://img-global.cpcdn.com/recipes/23a3a45b91b3d5f4/751x532cq70/gongso-torpedo-sapi-pedas-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep gongso torpedo sapi pedas yang Sempurna? Cara Memasaknya memang tidak susah dan tidak juga mudah. seumpama keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso torpedo sapi pedas yang enak harusnya sih punya aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso torpedo sapi pedas, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menyajikannya. Tak perlu pusing jika ingin menyiapkan gongso torpedo sapi pedas enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.


Nah, kali ini kita coba, yuk, buat gongso torpedo sapi pedas sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Gongso Torpedo Sapi Pedas menggunakan 18 jenis bahan dan 9 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Gongso Torpedo Sapi Pedas:

1. Gunakan 1 torpedo sapi
1. Ambil 2 daun salam
1. Sediakan 5 cm lengkuas
1. Ambil 12 cabai rawit utuh
1. Gunakan 3 tomat
1. Siapkan 1,5 sdt garam
1. Gunakan 2 sdm gula jawa sisir
1. Sediakan 2 sdt gula pasir
1. Ambil 1 sdt kaldu bubuk
1. Gunakan 1 sdm saos tiram
1. Siapkan 5 sdm kecap manis
1. Ambil 1 liter air
1. Ambil  Bumbu Halus :
1. Ambil 3 bawang putih
1. Gunakan 7 bawang merah
1. Ambil 25 cabai
1. Ambil 3 kemiri
1. Ambil 1 ruas jahe




<!--inarticleads2-->

##### Cara menyiapkan Gongso Torpedo Sapi Pedas:

1. Rebus torpedo sampe empuk dan potong2 sesuai selera.
1. Haluskan bahan bumbu halus.
1. Tumis bumbu halus bersama daun salam dan lengkuas, tumis sampai benar2 matang dan tanak.
1. Jika terlalu kering, tambah sedikit air dan tumis lagi sampai minyak bening &amp; tenang.
1. Masukkan torpedo sapi, aduk sampai tercampur bumbu.
1. Masukkan air, garam, gula, kaldu bubuk. Masak sampai mendidih.
1. Tambahkan cabai rawit utuh. Masak sampai air sedikit menyusut.
1. Tambahkan kecap dan saos tiram, aduk rata.
1. Masukkan irisan tomat &amp; Masak sampai air menyusut, dika suka berkuah masak jangan sampai air menyusut banyak ya.




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Gongso Torpedo Sapi Pedas yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman maupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
