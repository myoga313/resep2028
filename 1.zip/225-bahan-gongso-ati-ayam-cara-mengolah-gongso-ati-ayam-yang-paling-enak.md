---
description: "Bahan Gongso Ati Ayam | Cara Mengolah Gongso Ati Ayam Yang Paling Enak"
title: "Bahan Gongso Ati Ayam | Cara Mengolah Gongso Ati Ayam Yang Paling Enak"
slug: 225-bahan-gongso-ati-ayam-cara-mengolah-gongso-ati-ayam-yang-paling-enak
date: 2020-12-26T01:38:06.791Z
image: https://img-global.cpcdn.com/recipes/306856a41c356983/751x532cq70/gongso-ati-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/306856a41c356983/751x532cq70/gongso-ati-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/306856a41c356983/751x532cq70/gongso-ati-ayam-foto-resep-utama.jpg
author: Jeff Tran
ratingvalue: 4.1
reviewcount: 15
recipeingredient:
- " ati ampela ayam"
- " daun salam"
- " daun jeruk"
- " lengkuas"
- " Tomat"
- " Ladaku"
- " Garam"
- " Gula"
- " Kaldu jamur"
- " Kecap"
- " Kunyit bubuk"
- " Margarin"
- " Minyak goreng"
- " Air"
- " Bumbu halus"
- " bawang putih"
- " bawang merah"
- " cabe rawit"
- " kemiri"
recipeinstructions:
- "Ati ampela yang sudah direbus dipotong dadu"
- "Panaskan minyak goreng dan sedikit margarin, masukkan bumbu halus, daun salam, lengkuas, daun jeruk, lalu masukkan potongan ati ampela, aduk-aduk"
- "Masukkan air secukupnya, potongan tomat, beri garam, gula pasir, ladaku, kecap, kaldu jamur, kunyit bubuk, aduk-aduk, diamkan hingga air mendidih dan menyusut"
- "Taraaaaa gongso ati ayam super pedas siap disantap"
categories:
- Resep
tags:
- gongso
- ati
- ayam

katakunci: gongso ati ayam 
nutrition: 169 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Dessert

---


![Gongso Ati Ayam](https://img-global.cpcdn.com/recipes/306856a41c356983/751x532cq70/gongso-ati-ayam-foto-resep-utama.jpg)

Anda sedang mencari ide resep gongso ati ayam yang Lezat Sekali? Cara Bikinnya memang tidak susah dan tidak juga mudah. jikalau keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal gongso ati ayam yang enak seharusnya punya aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ati ayam, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tidak usah pusing jika mau menyiapkan gongso ati ayam yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian istimewa.




Nah, kali ini kita coba, yuk, variasikan gongso ati ayam sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Gongso Ati Ayam menggunakan 19 bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Gongso Ati Ayam:

1. Sediakan  ati ampela ayam
1. Gunakan  daun salam
1. Sediakan  daun jeruk
1. Sediakan  lengkuas
1. Sediakan  Tomat
1. Sediakan  Ladaku
1. Sediakan  Garam
1. Siapkan  Gula
1. Siapkan  Kaldu jamur
1. Siapkan  Kecap
1. Gunakan  Kunyit bubuk
1. Siapkan  Margarin
1. Gunakan  Minyak goreng
1. Gunakan  Air
1. Sediakan  Bumbu halus
1. Ambil  bawang putih
1. Gunakan  bawang merah
1. Sediakan  cabe rawit
1. Gunakan  kemiri




<!--inarticleads2-->

##### Cara membuat Gongso Ati Ayam:

1. Ati ampela yang sudah direbus dipotong dadu
1. Panaskan minyak goreng dan sedikit margarin, masukkan bumbu halus, daun salam, lengkuas, daun jeruk, lalu masukkan potongan ati ampela, aduk-aduk
1. Masukkan air secukupnya, potongan tomat, beri garam, gula pasir, ladaku, kecap, kaldu jamur, kunyit bubuk, aduk-aduk, diamkan hingga air mendidih dan menyusut
1. Taraaaaa gongso ati ayam super pedas siap disantap




Bagaimana? Gampang kan? Itulah cara menyiapkan gongso ati ayam yang bisa Anda praktikkan di rumah. Selamat mencoba!
