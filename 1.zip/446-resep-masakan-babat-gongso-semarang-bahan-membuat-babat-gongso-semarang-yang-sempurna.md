---
description: "Resep masakan Babat Gongso Semarang | Bahan Membuat Babat Gongso Semarang Yang Sempurna"
title: "Resep masakan Babat Gongso Semarang | Bahan Membuat Babat Gongso Semarang Yang Sempurna"
slug: 446-resep-masakan-babat-gongso-semarang-bahan-membuat-babat-gongso-semarang-yang-sempurna
date: 2020-09-19T05:07:32.092Z
image: https://img-global.cpcdn.com/recipes/9f1cf556cbc7cac4/751x532cq70/babat-gongso-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9f1cf556cbc7cac4/751x532cq70/babat-gongso-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9f1cf556cbc7cac4/751x532cq70/babat-gongso-semarang-foto-resep-utama.jpg
author: Benjamin Pratt
ratingvalue: 4.1
reviewcount: 10
recipeingredient:
- "150 gr babat sapi"
- "5 bh bawang merah iris tipis untuk tekstur"
- "4 bh daun jeruk"
- "2 bh daun salam"
- "1 sdm kecap manis"
- "1 sdt gula pasir"
- "1/2 sdt garam"
- "1/2 sdt kaldu jamur"
- "100 ml air"
- "5 sdm minyak untuk menumis"
- " Bumbu halus"
- "5 bh cabe merah keriting"
- "3 bh cabe rawit"
- "3 bh bawang merah"
- "2 bh bawang putih"
- "2 bh kemiri sangrai"
recipeinstructions:
- "Slow cooker babat selama 6 jam atau sampai empuk. Bisa di presto, rebus/ungkep. Potong babat sesuai selera. Ulek/ blender bumbu halus, sisihkan."
- "Tumis bawang merah sampai matang. Tambahkan bumbu halus, daun jeruk dan daun salam, masak sampai layu dan harum. Masukkan babat aduk rata, tambahkan gula garam kecap dan kaldu jamur."
- "Tambahkan air, agar bumbu tidak lengket dan gosong, koreksi rasa. Masak sampai bumbu meresap dan air surut. Sajikan dengan nasi hangat."
categories:
- Resep
tags:
- babat
- gongso
- semarang

katakunci: babat gongso semarang 
nutrition: 114 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Lunch

---


![Babat Gongso Semarang](https://img-global.cpcdn.com/recipes/9f1cf556cbc7cac4/751x532cq70/babat-gongso-semarang-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep babat gongso semarang yang Sempurna? Cara Buatnya memang tidak susah dan tidak juga mudah. bila salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal babat gongso semarang yang enak harusnya sih memiliki aroma dan rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari babat gongso semarang, mulai dari jenis bahan, lalu pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan babat gongso semarang yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian spesial.


Di bawah ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah babat gongso semarang yang siap dikreasikan. Anda dapat membuat Babat Gongso Semarang memakai 16 jenis bahan dan 3 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Babat Gongso Semarang:

1. Sediakan 150 gr babat sapi
1. Ambil 5 bh bawang merah, iris tipis untuk tekstur
1. Gunakan 4 bh daun jeruk
1. Gunakan 2 bh daun salam
1. Siapkan 1 sdm kecap manis
1. Gunakan 1 sdt gula pasir
1. Sediakan 1/2 sdt garam
1. Sediakan 1/2 sdt kaldu jamur
1. Siapkan 100 ml air
1. Ambil 5 sdm minyak untuk menumis
1. Sediakan  Bumbu halus:
1. Sediakan 5 bh cabe merah keriting
1. Siapkan 3 bh cabe rawit
1. Sediakan 3 bh bawang merah
1. Siapkan 2 bh bawang putih
1. Ambil 2 bh kemiri sangrai




<!--inarticleads2-->

##### Cara menyiapkan Babat Gongso Semarang:

1. Slow cooker babat selama 6 jam atau sampai empuk. Bisa di presto, rebus/ungkep. Potong babat sesuai selera. Ulek/ blender bumbu halus, sisihkan.
1. Tumis bawang merah sampai matang. Tambahkan bumbu halus, daun jeruk dan daun salam, masak sampai layu dan harum. Masukkan babat aduk rata, tambahkan gula garam kecap dan kaldu jamur.
1. Tambahkan air, agar bumbu tidak lengket dan gosong, koreksi rasa. Masak sampai bumbu meresap dan air surut. Sajikan dengan nasi hangat.




Bagaimana? Mudah bukan? Itulah cara membuat babat gongso semarang yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
