---
description: "Resep Rempelo Ati Tahu Gongso | Cara Buat Rempelo Ati Tahu Gongso Yang Mudah Dan Praktis"
title: "Resep Rempelo Ati Tahu Gongso | Cara Buat Rempelo Ati Tahu Gongso Yang Mudah Dan Praktis"
slug: 479-resep-rempelo-ati-tahu-gongso-cara-buat-rempelo-ati-tahu-gongso-yang-mudah-dan-praktis
date: 2020-12-22T03:51:37.744Z
image: https://img-global.cpcdn.com/recipes/3e59deb502343af1/751x532cq70/rempelo-ati-tahu-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3e59deb502343af1/751x532cq70/rempelo-ati-tahu-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3e59deb502343af1/751x532cq70/rempelo-ati-tahu-gongso-foto-resep-utama.jpg
author: Helen Montgomery
ratingvalue: 4.2
reviewcount: 10
recipeingredient:
- " Rempelo Ati ayam"
- " Tahu"
- " Bahan Cemplung "
- " Daun Salam"
- " Daun Jeruk Purut"
- " Sereh"
- " Jahe"
- " Bahan Halus "
- " Bawang Merah"
- " Bawang Putih"
- " Cabe Merah Buang Biji"
- " Cabe Rawit"
- " Kunyit  Kunyit Bubuk"
- " Minyak Goreng"
- " Gula Merah Garam Kecap Manis"
- " Kaldu Jamur"
- " Air"
recipeinstructions:
- "Pertama kita siapkan semua bahan, bersihkan cuci bersih ati ampela nya lalu rebus dg air dan tambahkan jahe, daun jeruk, daun salam, sereh dan sedikit garam. Lalu siapkan bahan lainnya"
- "Setelah ampela ati matang, iris sesuai selera lalu goreng, api sedang / kecil saja agar tidak meletup² kemana mana ampel ati yg di goreng."
- "Potong tahu kotak kotak / terserah mau dipotong seperti apa, goreng sampai kecoklatan dan sisihkan."
- "Panaskan wajan dan tumis bumbu yg sudah dihaluskan, tumis sampai matang lalu masukkan ati ampel yg sudah digoreng td, jangan lupa tambahkan kaldu jamur / masako jika suka. Lalu masukkan tahu dan tambahkan kecap, gongso sampai semua tercampur rata."
- "Terakhir tes rasa, jika dirasa sudah pas angkat dan sajikan."
categories:
- Resep
tags:
- rempelo
- ati
- tahu

katakunci: rempelo ati tahu 
nutrition: 287 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Dessert

---


![Rempelo Ati Tahu Gongso](https://img-global.cpcdn.com/recipes/3e59deb502343af1/751x532cq70/rempelo-ati-tahu-gongso-foto-resep-utama.jpg)

Lagi mencari inspirasi resep rempelo ati tahu gongso yang Enak Dan Lezat? Cara Buatnya memang tidak susah dan tidak juga mudah. jikalau salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal rempelo ati tahu gongso yang enak seharusnya memiliki aroma dan cita rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari rempelo ati tahu gongso, mulai dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tidak usah pusing jika hendak menyiapkan rempelo ati tahu gongso yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.


Nah, kali ini kita coba, yuk, siapkan rempelo ati tahu gongso sendiri di rumah. Tetap berbahan yang sederhana, sajian ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Rempelo Ati Tahu Gongso memakai 17 bahan dan 5 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Rempelo Ati Tahu Gongso:

1. Sediakan  Rempelo Ati ayam
1. Siapkan  Tahu
1. Gunakan  Bahan Cemplung 🌻
1. Sediakan  Daun Salam
1. Siapkan  Daun Jeruk Purut
1. Sediakan  Sereh
1. Siapkan  Jahe
1. Gunakan  Bahan Halus 🌻
1. Gunakan  Bawang Merah
1. Ambil  Bawang Putih
1. Sediakan  Cabe Merah (Buang Biji)
1. Siapkan  Cabe Rawit
1. Gunakan  Kunyit / Kunyit Bubuk
1. Ambil  Minyak Goreng
1. Ambil  Gula Merah, Garam, Kecap Manis
1. Ambil  Kaldu Jamur
1. Gunakan  Air




<!--inarticleads2-->

##### Langkah-langkah membuat Rempelo Ati Tahu Gongso:

1. Pertama kita siapkan semua bahan, bersihkan cuci bersih ati ampela nya lalu rebus dg air dan tambahkan jahe, daun jeruk, daun salam, sereh dan sedikit garam. Lalu siapkan bahan lainnya
1. Setelah ampela ati matang, iris sesuai selera lalu goreng, api sedang / kecil saja agar tidak meletup² kemana mana ampel ati yg di goreng.
1. Potong tahu kotak kotak / terserah mau dipotong seperti apa, goreng sampai kecoklatan dan sisihkan.
1. Panaskan wajan dan tumis bumbu yg sudah dihaluskan, tumis sampai matang lalu masukkan ati ampel yg sudah digoreng td, jangan lupa tambahkan kaldu jamur / masako jika suka. Lalu masukkan tahu dan tambahkan kecap, gongso sampai semua tercampur rata.
1. Terakhir tes rasa, jika dirasa sudah pas angkat dan sajikan.




Gimana nih? Mudah bukan? Itulah cara membuat rempelo ati tahu gongso yang bisa Anda praktikkan di rumah. Selamat mencoba!
