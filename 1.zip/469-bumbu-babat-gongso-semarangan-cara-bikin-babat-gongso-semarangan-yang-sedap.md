---
description: "Bumbu Babat gongso semarangan | Cara Bikin Babat gongso semarangan Yang Sedap"
title: "Bumbu Babat gongso semarangan | Cara Bikin Babat gongso semarangan Yang Sedap"
slug: 469-bumbu-babat-gongso-semarangan-cara-bikin-babat-gongso-semarangan-yang-sedap
date: 2020-11-27T06:51:10.285Z
image: https://img-global.cpcdn.com/recipes/453e360d4f6d5e26/751x532cq70/babat-gongso-semarangan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/453e360d4f6d5e26/751x532cq70/babat-gongso-semarangan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/453e360d4f6d5e26/751x532cq70/babat-gongso-semarangan-foto-resep-utama.jpg
author: Fanny Cole
ratingvalue: 4.9
reviewcount: 3
recipeingredient:
- "500 gr babat hati"
- "2 buah jeruk nipis potong 2"
- "2 sdm garam"
- " Secukupny air"
- " Bumbu halus"
- "7 siung bawang merah"
- "4 siung bawang putih"
- "50 gr cabai keriting merah sesuai selera"
- "7 buah cabai rawit"
- "5 butir kemiri sangrai"
- " Bumbu pelengkap"
- "5 siung bawang merah  iris besar untuk memberikan tekstur"
- "Secukupnya gula garam kaldu jamurroyco dan kecap"
recipeinstructions:
- "Cuci bersih babat. (Aku tambahin ati) kemudian presto 20menit dengan garam, jeruk nipis, daun salam dan air secukupnya."
- "Setelah matang potong sesuai keinginan ya."
- "Panaskan sedikit minyak goreng. Tumis bumbu halus beserta bawang merah yg telah diiris. Tunggu sampai berbau harum"
- "Masukkan babat yg telah diiris tadi. Aduk sampai rata. Dan masukkan gula, garam dan kaldu jamur. Aduk dan koreksi rasa. Angkat"
- "Siap dimakan dengan nasi putih hangat. Ini enak banget gaes 😋"
categories:
- Resep
tags:
- babat
- gongso
- semarangan

katakunci: babat gongso semarangan 
nutrition: 289 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Dinner

---


![Babat gongso semarangan](https://img-global.cpcdn.com/recipes/453e360d4f6d5e26/751x532cq70/babat-gongso-semarangan-foto-resep-utama.jpg)

Sedang mencari inspirasi resep babat gongso semarangan yang Paling Enak? Cara Memasaknya memang tidak susah dan tidak juga mudah. kalau keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal babat gongso semarangan yang enak seharusnya punya aroma dan rasa yang bisa memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso semarangan, mulai dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tidak usah pusing kalau ingin menyiapkan babat gongso semarangan enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian spesial.


Di bawah ini ada beberapa tips dan trik praktis dalam mengolah babat gongso semarangan yang siap dikreasikan. Anda dapat menyiapkan Babat gongso semarangan memakai 13 bahan dan 5 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Babat gongso semarangan:

1. Gunakan 500 gr babat +hati
1. Gunakan 2 buah jeruk nipis (potong 2)
1. Sediakan 2 sdm garam
1. Gunakan  Secukupny air
1. Ambil  Bumbu halus
1. Ambil 7 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Gunakan 50 gr cabai keriting merah (sesuai selera)
1. Sediakan 7 buah cabai rawit
1. Sediakan 5 butir kemiri sangrai
1. Sediakan  Bumbu pelengkap
1. Gunakan 5 siung bawang merah ( iris besar untuk memberikan tekstur
1. Sediakan Secukupnya gula, garam, kaldu jamur/royco dan kecap




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Babat gongso semarangan:

1. Cuci bersih babat. (Aku tambahin ati) kemudian presto 20menit dengan garam, jeruk nipis, daun salam dan air secukupnya.
1. Setelah matang potong sesuai keinginan ya.
1. Panaskan sedikit minyak goreng. Tumis bumbu halus beserta bawang merah yg telah diiris. Tunggu sampai berbau harum
1. Masukkan babat yg telah diiris tadi. Aduk sampai rata. Dan masukkan gula, garam dan kaldu jamur. Aduk dan koreksi rasa. Angkat
1. Siap dimakan dengan nasi putih hangat. Ini enak banget gaes 😋




Gimana nih? Mudah bukan? Itulah cara membuat babat gongso semarangan yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
