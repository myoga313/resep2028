---
description: "Resep masakan Telur Gongso Semarang | Cara Membuat Telur Gongso Semarang Yang Mudah Dan Praktis"
title: "Resep masakan Telur Gongso Semarang | Cara Membuat Telur Gongso Semarang Yang Mudah Dan Praktis"
slug: 78-resep-masakan-telur-gongso-semarang-cara-membuat-telur-gongso-semarang-yang-mudah-dan-praktis
date: 2020-11-13T11:18:12.283Z
image: https://img-global.cpcdn.com/recipes/1f4d5432d749e9b7/751x532cq70/telur-gongso-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1f4d5432d749e9b7/751x532cq70/telur-gongso-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1f4d5432d749e9b7/751x532cq70/telur-gongso-semarang-foto-resep-utama.jpg
author: Jeffrey Clarke
ratingvalue: 3.7
reviewcount: 12
recipeingredient:
- "2 butir telur diceplok"
- " Minyak goreng untuk menumis"
- " Bumbu iris"
- "2 siung bawang merah diiris"
- "1 siung bawang putih diiris"
- "1 buah tomat ukuran sedang dipotongpotong agak kecil"
- "1 cabe merah  1 cabe rawit merah iris"
- "1 batang daun bawang diiris"
- " Bahan saos"
- "1 sdm saos sambal"
- "1 sdm kecap manis"
- "1/2 sdm saos tomat"
- "1/2 sdm saos tiram"
- "1/2 sdt merica"
- "1/2 sdt garam"
- "1/2 sdt kaldu bubuk"
- "1/2 sdt gula pasir"
- "100 ml air"
recipeinstructions:
- "Ceplok telur ditambah sedikit garam, atau sesuai selera. Sisihkan."
- "Siapkan bumbu iris. Tumis irisan bawang merah dan putih sampai harum dan kayu. Masukkan tomat, masak sampai agak hancur."
- "Campur semua bahan saos. Tambah air ke dalam tumisan bumbu, masukkan bahan saos. Masak sampai mendidih, lalu masukkan telur. Masak sampai bumbu meresap."
- "Pindahkan ke piring saji. Telur gongso siap disajikan."
categories:
- Resep
tags:
- telur
- gongso
- semarang

katakunci: telur gongso semarang 
nutrition: 237 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Dinner

---


![Telur Gongso Semarang](https://img-global.cpcdn.com/recipes/1f4d5432d749e9b7/751x532cq70/telur-gongso-semarang-foto-resep-utama.jpg)

Anda sedang mencari ide resep telur gongso semarang yang Enak Dan Mudah? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. apabila keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal telur gongso semarang yang enak harusnya sih mempunyai aroma dan rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari telur gongso semarang, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menyajikannya. Tak perlu pusing kalau mau menyiapkan telur gongso semarang yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.


Nah, kali ini kita coba, yuk, ciptakan telur gongso semarang sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Telur Gongso Semarang memakai 18 jenis bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Telur Gongso Semarang:

1. Sediakan 2 butir telur, diceplok
1. Sediakan  Minyak goreng untuk menumis
1. Gunakan  Bumbu iris
1. Siapkan 2 siung bawang merah, diiris
1. Ambil 1 siung bawang putih, diiris
1. Ambil 1 buah tomat ukuran sedang, dipotong-potong agak kecil
1. Siapkan 1 cabe merah + 1 cabe rawit merah iris
1. Sediakan 1 batang daun bawang, diiris
1. Gunakan  Bahan saos
1. Ambil 1 sdm saos sambal
1. Ambil 1 sdm kecap manis
1. Ambil 1/2 sdm saos tomat
1. Siapkan 1/2 sdm saos tiram
1. Sediakan 1/2 sdt merica
1. Ambil 1/2 sdt garam
1. Siapkan 1/2 sdt kaldu bubuk
1. Ambil 1/2 sdt gula pasir
1. Ambil 100 ml air




<!--inarticleads2-->

##### Cara menyiapkan Telur Gongso Semarang:

1. Ceplok telur ditambah sedikit garam, atau sesuai selera. Sisihkan.
1. Siapkan bumbu iris. Tumis irisan bawang merah dan putih sampai harum dan kayu. Masukkan tomat, masak sampai agak hancur.
1. Campur semua bahan saos. Tambah air ke dalam tumisan bumbu, masukkan bahan saos. Masak sampai mendidih, lalu masukkan telur. Masak sampai bumbu meresap.
1. Pindahkan ke piring saji. Telur gongso siap disajikan.




Gimana nih? Gampang kan? Itulah cara membuat telur gongso semarang yang bisa Anda lakukan di rumah. Selamat mencoba!
