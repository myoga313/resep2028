---
description: "Bahan Babat Gongso | Cara Bikin Babat Gongso Yang Enak Dan Lezat"
title: "Bahan Babat Gongso | Cara Bikin Babat Gongso Yang Enak Dan Lezat"
slug: 19-bahan-babat-gongso-cara-bikin-babat-gongso-yang-enak-dan-lezat
date: 2020-12-03T19:50:35.246Z
image: https://img-global.cpcdn.com/recipes/a297a098a5f8dd8b/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a297a098a5f8dd8b/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a297a098a5f8dd8b/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Nannie Barker
ratingvalue: 3.8
reviewcount: 4
recipeingredient:
- "4 porsi"
- "500 gr Babat bole anduksumpingusus bersihkan"
- "2 butir Jeruk Nipis  belah 2"
- "4 helai Daun Salam"
- "2 sdm Garam"
- " Bumbu Halus "
- "15 Cabai merah keriting"
- "7 Cabai rawit merah"
- "10 btr Bawang merah"
- "4 btr Bawang Putih"
- "6 btr Kemirisangrai"
- " Bumbu yang ditumis"
- "7 btr Bawang merah iris serong rada tebel untuk textur"
- "Sesuai Selera GaramKaldu bubukGula PasirKecap"
recipeinstructions:
- "Bersihkan babat,Presto kurleb 20 menit.beri air secukupnya,potongan jeruk nipis+daun salam+garam Note: pilih babat yg fresh,kenyal,baunya normal,pasti seger nanti jadinya"
- "Tiriskan,potong-potong sesuai selera."
- "Tumis minyak bersama Bawang merah yg uda dpotong kasar,minyak banyakkin ya soalnya nanti masuk bumbu Halus) Tumis sampai harum aja jangan tumis lama2."
- "Masukkan gula,kecap,garam,kaldu masako sesuai selera..masukkan babat.. aduk2 terus.. tambahkan air skitar 100cc+supaya juga bumbu ga mengerak di dasar wajan."
- "Setelah keliatan tercampur+sedap,matikan api.(jangan tumis terlalu lama soale babat uda empuk,bumbu gampang merasuk)angkat,sajikan dengan Nasi hangat,bawang merah goreng+krupuk..mantap jaya.."
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 202 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dessert

---


![Babat Gongso](https://img-global.cpcdn.com/recipes/a297a098a5f8dd8b/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Bunda lagi mencari ide resep babat gongso yang Bikin Ngiler? Cara Memasaknya memang tidak terlalu sulit namun tidak gampang juga. kalau keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal babat gongso yang enak seharusnya memiliki aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tidak usah pusing kalau hendak menyiapkan babat gongso yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.

Com - Babat Gongso kali ini special karena ada isonya. Babat Gongso yang menjadi tujuan kuliner setiap orang yang ke Semarang, merupakan setidaknya primadona dari sekian banyak makanan yang ada di Semarang. Yuk, belajar membuat Babat Gongso di rumah Anda!


Nah, kali ini kita coba, yuk, siapkan babat gongso sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Babat Gongso memakai 14 jenis bahan dan 5 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Babat Gongso:

1. Ambil 4 porsi
1. Siapkan 500 gr Babat (bole anduk,sumping,usus)- bersihkan
1. Gunakan 2 butir Jeruk Nipis - belah 2
1. Ambil 4 helai Daun Salam
1. Sediakan 2 sdm Garam
1. Sediakan  Bumbu Halus :
1. Ambil 15 Cabai merah keriting
1. Sediakan 7 Cabai rawit merah
1. Ambil 10 btr Bawang merah
1. Sediakan 4 btr Bawang Putih
1. Ambil 6 btr Kemiri,sangrai
1. Sediakan  Bumbu yang ditumis:
1. Gunakan 7 btr Bawang merah iris serong rada tebel (untuk textur)
1. Gunakan Sesuai Selera Garam,Kaldu bubuk,Gula Pasir,Kecap




<!--inarticleads2-->

##### Langkah-langkah membuat Babat Gongso:

1. Bersihkan babat,Presto kurleb 20 menit.beri air secukupnya,potongan jeruk nipis+daun salam+garam Note: pilih babat yg fresh,kenyal,baunya normal,pasti seger nanti jadinya
1. Tiriskan,potong-potong sesuai selera.
1. Tumis minyak bersama Bawang merah yg uda dpotong kasar,minyak banyakkin ya soalnya nanti masuk bumbu Halus) Tumis sampai harum aja jangan tumis lama2.
1. Masukkan gula,kecap,garam,kaldu masako sesuai selera..masukkan babat.. aduk2 terus.. tambahkan air skitar 100cc+supaya juga bumbu ga mengerak di dasar wajan.
1. Setelah keliatan tercampur+sedap,matikan api.(jangan tumis terlalu lama soale babat uda empuk,bumbu gampang merasuk)angkat,sajikan dengan Nasi hangat,bawang merah goreng+krupuk..mantap jaya..




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Harapan kami, olahan Babat Gongso yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman ataupun menjadi inspirasi dalam berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
