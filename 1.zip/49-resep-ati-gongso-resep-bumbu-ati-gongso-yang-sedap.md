---
description: "Resep Ati gongso | Resep Bumbu Ati gongso Yang Sedap"
title: "Resep Ati gongso | Resep Bumbu Ati gongso Yang Sedap"
slug: 49-resep-ati-gongso-resep-bumbu-ati-gongso-yang-sedap
date: 2020-11-08T01:00:46.743Z
image: https://img-global.cpcdn.com/recipes/02e4de0d4e8651cf/751x532cq70/ati-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/02e4de0d4e8651cf/751x532cq70/ati-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/02e4de0d4e8651cf/751x532cq70/ati-gongso-foto-resep-utama.jpg
author: Chase Cooper
ratingvalue: 3.1
reviewcount: 3
recipeingredient:
- "6 potong hati ayam"
- "1 buah bawang bombay"
- "sesuai selera Cabe rawit"
- " Merica bubuk"
- " Gula jawa"
- " Kecap"
- " Garam"
- "1 buah tomat"
recipeinstructions:
- "Cuci bersih hati ayam lalu rebus kurleb 10menit"
- "Setelah agak dingin, potong-potong hati ayam sesuai selera"
- "Iris bawang bombay kemudian tumis sampai layu"
- "Masukkan hati ayam,cabe, garam, gula jawa, kecap, tomat yang sudah dipotong, lalu beri merica bubuk agak banyak"
- "Masak sampai bumbu meresap. Angkat dan sajikan"
categories:
- Resep
tags:
- ati
- gongso

katakunci: ati gongso 
nutrition: 133 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Dinner

---


![Ati gongso](https://img-global.cpcdn.com/recipes/02e4de0d4e8651cf/751x532cq70/ati-gongso-foto-resep-utama.jpg)

Kamu Sedang mencari inspirasi resep ati gongso yang Bikin Ngiler? Cara Memasaknya memang tidak susah dan tidak juga mudah. sekiranya salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal ati gongso yang enak harusnya sih memiliki aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ati gongso, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan ati gongso enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan istimewa.

Lihat juga resep Gongso Ayam ala Semarangan enak lainnya. di.gongso. menyajikan masakan aneka gongso.pilihan menu favorit bagi pecinta masakan enak. Cara membuat gongso ati ampela yang sedap. Hay Teman-teman di sini saya akan memasak Resep Babat Gongso , Kalo ada yang belum tau cara membuat Babat Gongso.


Nah, kali ini kita coba, yuk, variasikan ati gongso sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Ati gongso memakai 8 bahan dan 5 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ati gongso:

1. Sediakan 6 potong hati ayam
1. Sediakan 1 buah bawang bombay
1. Ambil sesuai selera Cabe rawit
1. Gunakan  Merica bubuk
1. Gunakan  Gula jawa
1. Gunakan  Kecap
1. Siapkan  Garam
1. Siapkan 1 buah tomat




<!--inarticleads2-->

##### Langkah-langkah membuat Ati gongso:

1. Cuci bersih hati ayam lalu rebus kurleb 10menit
1. Setelah agak dingin, potong-potong hati ayam sesuai selera
1. Iris bawang bombay kemudian tumis sampai layu
1. Masukkan hati ayam,cabe, garam, gula jawa, kecap, tomat yang sudah dipotong, lalu beri merica bubuk agak banyak
1. Masak sampai bumbu meresap. Angkat dan sajikan




Gimana nih? Mudah bukan? Itulah cara menyiapkan ati gongso yang bisa Anda lakukan di rumah. Selamat mencoba!
