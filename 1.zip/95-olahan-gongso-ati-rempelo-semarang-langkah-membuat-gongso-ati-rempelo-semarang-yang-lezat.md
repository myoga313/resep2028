---
description: "Olahan Gongso Ati Rempelo Semarang | Langkah Membuat Gongso Ati Rempelo Semarang Yang Lezat"
title: "Olahan Gongso Ati Rempelo Semarang | Langkah Membuat Gongso Ati Rempelo Semarang Yang Lezat"
slug: 95-olahan-gongso-ati-rempelo-semarang-langkah-membuat-gongso-ati-rempelo-semarang-yang-lezat
date: 2020-12-31T10:19:51.628Z
image: https://img-global.cpcdn.com/recipes/e04712a84ad73a75/751x532cq70/gongso-ati-rempelo-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e04712a84ad73a75/751x532cq70/gongso-ati-rempelo-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e04712a84ad73a75/751x532cq70/gongso-ati-rempelo-semarang-foto-resep-utama.jpg
author: Rosie Cox
ratingvalue: 4.4
reviewcount: 11
recipeingredient:
- "10 bh ati rempelo hati ampela"
- "1/3 sdt lada bubuk"
- "2 sdm kecap manis selera"
- "250 ml air"
- " Bumbu halus"
- "5 bh bawang merah"
- "4 siung bawang putih"
- "5 bh cabai merah keriting"
- "5 bh cabai rawit selera"
- "4 bh kemiri"
- "1.5 ruas jari jahe"
- " Bumbu cemplung"
- "1 btg serah geprek"
- "3 lbr daun salam"
- "3 lbr daun jeruk buang tulangnya"
recipeinstructions:
- "Siapkan bahan-bahannya."
- "Rebus hati ayam hingga empuk, angkat dan potong-potong sesuai selera."
- "Tumis bumbu halus dengan bumbu cemplung hingga harum. Masukkan potongan ati rempelo ayam dan air. Tambahkan garam, lada bubuk dan kecap manis. Aduk sesekali."
- "Biarkan gongso ati rempelo surut airnya. Koreksi rasa angkat dan sajikan langsung akan lebih nikmat."
categories:
- Resep
tags:
- gongso
- ati
- rempelo

katakunci: gongso ati rempelo 
nutrition: 158 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Dessert

---


![Gongso Ati Rempelo Semarang](https://img-global.cpcdn.com/recipes/e04712a84ad73a75/751x532cq70/gongso-ati-rempelo-semarang-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep gongso ati rempelo semarang yang Bisa Manjain Lidah? Cara menyiapkannya memang tidak susah dan tidak juga mudah. bila salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso ati rempelo semarang yang enak selayaknya mempunyai aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ati rempelo semarang, mulai dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tidak usah pusing jika mau menyiapkan gongso ati rempelo semarang yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian spesial.




Di bawah ini ada beberapa cara mudah dan praktis untuk membuat gongso ati rempelo semarang yang siap dikreasikan. Anda dapat menyiapkan Gongso Ati Rempelo Semarang memakai 15 bahan dan 4 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Gongso Ati Rempelo Semarang:

1. Ambil 10 bh ati rempelo (hati ampela)
1. Sediakan 1/3 sdt lada bubuk
1. Gunakan 2 sdm kecap manis (selera)
1. Gunakan 250 ml air
1. Ambil  Bumbu halus:
1. Ambil 5 bh bawang merah
1. Siapkan 4 siung bawang putih
1. Sediakan 5 bh cabai merah keriting
1. Ambil 5 bh cabai rawit (selera)
1. Ambil 4 bh kemiri
1. Sediakan 1.5 ruas jari jahe
1. Gunakan  Bumbu cemplung:
1. Siapkan 1 btg serah geprek
1. Gunakan 3 lbr daun salam
1. Siapkan 3 lbr daun jeruk buang tulangnya




<!--inarticleads2-->

##### Cara menyiapkan Gongso Ati Rempelo Semarang:

1. Siapkan bahan-bahannya.
1. Rebus hati ayam hingga empuk, angkat dan potong-potong sesuai selera.
1. Tumis bumbu halus dengan bumbu cemplung hingga harum. Masukkan potongan ati rempelo ayam dan air. Tambahkan garam, lada bubuk dan kecap manis. Aduk sesekali.
1. Biarkan gongso ati rempelo surut airnya. Koreksi rasa angkat dan sajikan langsung akan lebih nikmat.




Bagaimana? Gampang kan? Itulah cara menyiapkan gongso ati rempelo semarang yang bisa Anda lakukan di rumah. Selamat mencoba!
