---
description: "Bahan Gongso Ati Ampela Ayam | Cara Membuat Gongso Ati Ampela Ayam Yang Enak Dan Lezat"
title: "Bahan Gongso Ati Ampela Ayam | Cara Membuat Gongso Ati Ampela Ayam Yang Enak Dan Lezat"
slug: 438-bahan-gongso-ati-ampela-ayam-cara-membuat-gongso-ati-ampela-ayam-yang-enak-dan-lezat
date: 2020-11-07T01:23:11.073Z
image: https://img-global.cpcdn.com/recipes/030630ac2ccd724f/751x532cq70/gongso-ati-ampela-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/030630ac2ccd724f/751x532cq70/gongso-ati-ampela-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/030630ac2ccd724f/751x532cq70/gongso-ati-ampela-ayam-foto-resep-utama.jpg
author: Caroline Patton
ratingvalue: 4.1
reviewcount: 11
recipeingredient:
- "5 pasang ati ampela ayam"
- "3 lembar daun salam"
- "4 siung bawang merah"
- "2 siung bawang putih"
- "sesuai selera Cabai"
- "3 lembar daun jeruk"
- "1 batang serai"
- "1 sdm kecap manis"
- "secukupnya Gula garam"
recipeinstructions:
- "Rebus ati ampela ayam dengan daun salam hingga matang"
- "Goreng sebentar ati ampela ayam"
- "Haluskan bawang merah, bawang putih, cabai"
- "Tumis bumbu halus, daun jeruk dan serai hingga harum"
- "Tambahkan kecap manis dan sedikit air"
- "Masukkan ati ampela, koreksi rasa dengan gula dan garam"
- "Masak hingga bumbu meresap"
categories:
- Resep
tags:
- gongso
- ati
- ampela

katakunci: gongso ati ampela 
nutrition: 197 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dessert

---


![Gongso Ati Ampela Ayam](https://img-global.cpcdn.com/recipes/030630ac2ccd724f/751x532cq70/gongso-ati-ampela-ayam-foto-resep-utama.jpg)

Lagi mencari inspirasi resep gongso ati ampela ayam yang Enak Dan Lezat? Cara Bikinnya memang tidak susah dan tidak juga mudah. andaikata keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso ati ampela ayam yang enak seharusnya memiliki aroma dan rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ati ampela ayam, mulai dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan gongso ati ampela ayam enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan spesial.




Nah, kali ini kita coba, yuk, buat gongso ati ampela ayam sendiri di rumah. Tetap berbahan sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Gongso Ati Ampela Ayam menggunakan 9 jenis bahan dan 7 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Gongso Ati Ampela Ayam:

1. Gunakan 5 pasang ati ampela ayam
1. Siapkan 3 lembar daun salam
1. Ambil 4 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Ambil sesuai selera Cabai
1. Siapkan 3 lembar daun jeruk
1. Ambil 1 batang serai
1. Gunakan 1 sdm kecap manis
1. Gunakan secukupnya Gula garam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso Ati Ampela Ayam:

1. Rebus ati ampela ayam dengan daun salam hingga matang
1. Goreng sebentar ati ampela ayam
1. Haluskan bawang merah, bawang putih, cabai
1. Tumis bumbu halus, daun jeruk dan serai hingga harum
1. Tambahkan kecap manis dan sedikit air
1. Masukkan ati ampela, koreksi rasa dengan gula dan garam
1. Masak hingga bumbu meresap




Terima kasih telah membaca resep yang kami tampilkan di sini. Harapan kami, olahan Gongso Ati Ampela Ayam yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman maupun menjadi ide bagi Anda yang berkeinginan untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
