---
description: "Resep Babat gongso | Resep Membuat Babat gongso Yang Enak Dan Mudah"
title: "Resep Babat gongso | Resep Membuat Babat gongso Yang Enak Dan Mudah"
slug: 477-resep-babat-gongso-resep-membuat-babat-gongso-yang-enak-dan-mudah
date: 2020-12-23T09:52:18.138Z
image: https://img-global.cpcdn.com/recipes/7a1ec8cd11442ec6/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7a1ec8cd11442ec6/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7a1ec8cd11442ec6/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Mason Price
ratingvalue: 3.1
reviewcount: 13
recipeingredient:
- " babat sapi"
- " kapur sirih serai salam"
- " cabai merah besar iris tipis"
- " bawang merah iris kasar"
- " garam dan kaldu bubuk"
- " kecap manis"
- " Haluskan "
- " cabai merah keriting"
- " bawang putih"
- " kemiri sangrai"
recipeinstructions:
- "Rendam babat di air kapur sirih 30-60 menit. Kerok dengan sendok sampai item2nya ilang. Cuci bersih. (Skip)"
- "Blansir mendidih 30 menit, buang airnya. Rebus dengan api kecil, tambahin salam, serai dan garam. Rebus sampai benar-benar empuk. Tiriskan dan potong-potong."
- "Sementara nunggu merrbus, siapkan bahan-bahan lain."
- "Panaskan minyak, tumis bumbu halus sampai harum dan matang. Masukkan babat, bawang merah, cabe. Tambahkan sedikit air. Bumbui dengan kecap, garam, kaldu. Koreksi rasa. Masak hingga air surut."
- "Angkat dan sajikan."
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 239 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Lunch

---


![Babat gongso](https://img-global.cpcdn.com/recipes/7a1ec8cd11442ec6/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep babat gongso yang Enak Dan Lezat? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. apabila salah mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal babat gongso yang enak seharusnya mempunyai aroma dan cita rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso, pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menyajikannya. Tak perlu pusing kalau mau menyiapkan babat gongso enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.


Nah, kali ini kita coba, yuk, siapkan babat gongso sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Babat gongso memakai 10 jenis bahan dan 5 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Babat gongso:

1. Gunakan  babat sapi
1. Ambil  kapur sirih, serai, salam
1. Ambil  cabai merah besar, iris tipis
1. Sediakan  bawang merah, iris kasar
1. Sediakan  garam dan kaldu bubuk
1. Ambil  kecap manis
1. Gunakan  Haluskan ::
1. Sediakan  cabai merah keriting
1. Ambil  bawang putih
1. Sediakan  kemiri sangrai




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Babat gongso:

1. Rendam babat di air kapur sirih 30-60 menit. Kerok dengan sendok sampai item2nya ilang. Cuci bersih. (Skip)
1. Blansir mendidih 30 menit, buang airnya. Rebus dengan api kecil, tambahin salam, serai dan garam. Rebus sampai benar-benar empuk. Tiriskan dan potong-potong.
1. Sementara nunggu merrbus, siapkan bahan-bahan lain.
1. Panaskan minyak, tumis bumbu halus sampai harum dan matang. Masukkan babat, bawang merah, cabe. Tambahkan sedikit air. Bumbui dengan kecap, garam, kaldu. Koreksi rasa. Masak hingga air surut.
1. Angkat dan sajikan.




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Harapan kami, olahan Babat gongso yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman ataupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
