---
description: "Resep Gongso Ayam khas Semarang | Cara Buat Gongso Ayam khas Semarang Yang Enak Dan Mudah"
title: "Resep Gongso Ayam khas Semarang | Cara Buat Gongso Ayam khas Semarang Yang Enak Dan Mudah"
slug: 48-resep-gongso-ayam-khas-semarang-cara-buat-gongso-ayam-khas-semarang-yang-enak-dan-mudah
date: 2020-11-04T00:07:25.780Z
image: https://img-global.cpcdn.com/recipes/d29cc9d495b60af5/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d29cc9d495b60af5/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d29cc9d495b60af5/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg
author: Ricardo Washington
ratingvalue: 3.4
reviewcount: 8
recipeingredient:
- "6 potong ayam bagian paha"
- "1 buah bawang bombay iris tipis"
- "10 biji cabai rawit"
- "2 lembar daun salam"
- "1 ruas lengkuaslaos"
- " kecap manis"
- " garam"
- " lada bubuk"
- "secukupnya air"
- " minyak goreng untuk menumis"
- " bumbu halus "
- "5 siung bawang putih"
- "2 siung bawang merah"
- "3 buah kemiri"
- "5 biji cabai rawit"
- "1 biji cabai merah"
recipeinstructions:
- "Siapkan bahan, cuci bersih ayam beri kucuran air jeruk nipis agar menghilangkan bau amis nya. tunggu 10 menit. lalu rebus ayam, masukkan garam secukupnya. rebus ayam sekitar 30-40 menit. setelah itu tiriskan"
- "Haluskan bumbu sesuai resep yg ada. kemudian suwir2 ayam agar di gongso nanti bumbu bisa meresap. dan iris tipis bawang bombay"
- "Ambil wajan/teflon masukkan minyak lalu tumis bawang bombay sampai harum dan kecoklatan, lalu masukkan bumbu halus, daun salam, lengkuas. tumis sampai harum"
- "Masukkan ayam, gongso hingga merata dengan bumbu. masukkan kecap manis, garam, lada, penyedap rasa. masukkan air sedikit demi sedikit, gongso hingga air menyusut, koreksi rasa. dan siap disajikan dengan nasi panas 😋"
categories:
- Resep
tags:
- gongso
- ayam
- khas

katakunci: gongso ayam khas 
nutrition: 148 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Dinner

---


![Gongso Ayam khas Semarang](https://img-global.cpcdn.com/recipes/d29cc9d495b60af5/751x532cq70/gongso-ayam-khas-semarang-foto-resep-utama.jpg)

Lagi mencari ide resep gongso ayam khas semarang yang Enak Dan Lezat? Cara Memasaknya memang tidak susah dan tidak juga mudah. misalnya salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso ayam khas semarang yang enak seharusnya mempunyai aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ayam khas semarang, pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tak perlu pusing jika mau menyiapkan gongso ayam khas semarang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.


Nah, kali ini kita coba, yuk, buat gongso ayam khas semarang sendiri di rumah. Tetap berbahan yang sederhana, sajian ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda dapat membuat Gongso Ayam khas Semarang menggunakan 16 bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Gongso Ayam khas Semarang:

1. Siapkan 6 potong ayam, bagian paha
1. Gunakan 1 buah bawang bombay, iris tipis
1. Sediakan 10 biji cabai rawit
1. Sediakan 2 lembar daun salam
1. Siapkan 1 ruas lengkuas/laos
1. Sediakan  kecap manis
1. Sediakan  garam
1. Siapkan  lada bubuk
1. Gunakan secukupnya air
1. Ambil  minyak goreng untuk menumis
1. Siapkan  bumbu halus :
1. Ambil 5 siung bawang putih
1. Sediakan 2 siung bawang merah
1. Sediakan 3 buah kemiri
1. Siapkan 5 biji cabai rawit
1. Gunakan 1 biji cabai merah




<!--inarticleads2-->

##### Cara menyiapkan Gongso Ayam khas Semarang:

1. Siapkan bahan, cuci bersih ayam beri kucuran air jeruk nipis agar menghilangkan bau amis nya. tunggu 10 menit. lalu rebus ayam, masukkan garam secukupnya. rebus ayam sekitar 30-40 menit. setelah itu tiriskan
1. Haluskan bumbu sesuai resep yg ada. kemudian suwir2 ayam agar di gongso nanti bumbu bisa meresap. dan iris tipis bawang bombay
1. Ambil wajan/teflon masukkan minyak lalu tumis bawang bombay sampai harum dan kecoklatan, lalu masukkan bumbu halus, daun salam, lengkuas. tumis sampai harum
1. Masukkan ayam, gongso hingga merata dengan bumbu. masukkan kecap manis, garam, lada, penyedap rasa. masukkan air sedikit demi sedikit, gongso hingga air menyusut, koreksi rasa. dan siap disajikan dengan nasi panas 😋




Bagaimana? Mudah bukan? Itulah cara menyiapkan gongso ayam khas semarang yang bisa Anda lakukan di rumah. Selamat mencoba!
