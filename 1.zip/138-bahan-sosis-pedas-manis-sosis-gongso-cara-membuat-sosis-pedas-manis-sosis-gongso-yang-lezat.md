---
description: "Bahan Sosis Pedas Manis (Sosis Gongso) | Cara Membuat Sosis Pedas Manis (Sosis Gongso) Yang Lezat"
title: "Bahan Sosis Pedas Manis (Sosis Gongso) | Cara Membuat Sosis Pedas Manis (Sosis Gongso) Yang Lezat"
slug: 138-bahan-sosis-pedas-manis-sosis-gongso-cara-membuat-sosis-pedas-manis-sosis-gongso-yang-lezat
date: 2020-09-20T10:16:30.118Z
image: https://img-global.cpcdn.com/recipes/6e45b72385db5054/751x532cq70/sosis-pedas-manis-sosis-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6e45b72385db5054/751x532cq70/sosis-pedas-manis-sosis-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6e45b72385db5054/751x532cq70/sosis-pedas-manis-sosis-gongso-foto-resep-utama.jpg
author: Elsie Gill
ratingvalue: 3.7
reviewcount: 14
recipeingredient:
- "5 buah sosis saya pakai so good"
- "1 buah bawang bombay iris"
- "4 siung Bawang Putih cincang"
- "5 cabe merah besar iris serong"
- "7 cabe rawit iris serong apabila suka pedas bisa ditambah"
- " Garam"
- " Lada Bubuk"
- " Gula merah"
- " Gula Putih"
- " Kecap Manis"
- " Saos optional"
- " Air Matang"
recipeinstructions:
- "Potong sosis dan keratkan ujung-ujungnya jangan sampai putus"
- "Tumis bawang putih (cincang) cabe rawit, cabe merah besar hingga harum"
- "Tambahkan air, gula merah, gula pasir, garam, lada bubuk"
- "Masukkan sosis, aduk rata, diamkan sebentar hingga bumbu merasuk, dan air sedikit berkurang"
- "Tambahkan kecap manis, aduk rata. Cek rasa"
- "Irisan bawang bombay saya masukkan paling akhir, supaya tidak terlalu lunak."
categories:
- Resep
tags:
- sosis
- pedas
- manis

katakunci: sosis pedas manis 
nutrition: 157 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Dessert

---


![Sosis Pedas Manis (Sosis Gongso)](https://img-global.cpcdn.com/recipes/6e45b72385db5054/751x532cq70/sosis-pedas-manis-sosis-gongso-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep sosis pedas manis (sosis gongso) yang Enak Dan Mudah? Cara Bikinnya memang tidak terlalu sulit namun tidak gampang juga. bila keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal sosis pedas manis (sosis gongso) yang enak harusnya sih punya aroma dan cita rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari sosis pedas manis (sosis gongso), pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tak perlu pusing kalau hendak menyiapkan sosis pedas manis (sosis gongso) yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.


Nah, kali ini kita coba, yuk, siapkan sosis pedas manis (sosis gongso) sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Sosis Pedas Manis (Sosis Gongso) menggunakan 12 jenis bahan dan 6 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Sosis Pedas Manis (Sosis Gongso):

1. Gunakan 5 buah sosis (saya pakai so good)
1. Siapkan 1 buah bawang bombay (iris)
1. Sediakan 4 siung Bawang Putih (cincang)
1. Ambil 5 cabe merah besar (iris serong)
1. Sediakan 7 cabe rawit (iris serong, apabila suka pedas bisa ditambah)
1. Siapkan  Garam
1. Sediakan  Lada Bubuk
1. Ambil  Gula merah
1. Siapkan  Gula Putih
1. Gunakan  Kecap Manis
1. Gunakan  Saos (optional)
1. Siapkan  Air Matang




<!--inarticleads2-->

##### Cara menyiapkan Sosis Pedas Manis (Sosis Gongso):

1. Potong sosis dan keratkan ujung-ujungnya jangan sampai putus
1. Tumis bawang putih (cincang) cabe rawit, cabe merah besar hingga harum
1. Tambahkan air, gula merah, gula pasir, garam, lada bubuk
1. Masukkan sosis, aduk rata, diamkan sebentar hingga bumbu merasuk, dan air sedikit berkurang
1. Tambahkan kecap manis, aduk rata. Cek rasa
1. Irisan bawang bombay saya masukkan paling akhir, supaya tidak terlalu lunak.




Bagaimana? Gampang kan? Itulah cara membuat sosis pedas manis (sosis gongso) yang bisa Anda praktikkan di rumah. Selamat mencoba!
