---
description: "Bumbu Gongso Ati Ampela Ayam | Resep Bumbu Gongso Ati Ampela Ayam Yang Paling Enak"
title: "Bumbu Gongso Ati Ampela Ayam | Resep Bumbu Gongso Ati Ampela Ayam Yang Paling Enak"
slug: 465-bumbu-gongso-ati-ampela-ayam-resep-bumbu-gongso-ati-ampela-ayam-yang-paling-enak
date: 2021-01-12T11:09:35.501Z
image: https://img-global.cpcdn.com/recipes/88cead17a3480f0f/751x532cq70/gongso-ati-ampela-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/88cead17a3480f0f/751x532cq70/gongso-ati-ampela-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/88cead17a3480f0f/751x532cq70/gongso-ati-ampela-ayam-foto-resep-utama.jpg
author: Alfred Copeland
ratingvalue: 3.8
reviewcount: 15
recipeingredient:
- "4 pasang ati ampela"
- "1 buah tomat buang biji potong besar"
- " Minyak goreng"
- "Secukupnya air"
- " Bumbu halus"
- "4 siung bawang merah"
- "2 siung bawang putih"
- "1 jari kunyit"
- " Bumbu cemplung"
- "1 batang serai geprek"
- "4 lembar daun jeruk"
- "1 lembar daun salam"
- "2 sdm kecap manis"
- "Secukupnya garam lada gula"
recipeinstructions:
- "Didihkan air, masukkan 1 lembar daun salam dan sedikit garam lalu rebus ati Ampela yang sudah dibersihkan. Rebus sekitar 10 menit, tiriskan dan sisihkan."
- "Panaskan wajan, tuang minyak goreng lalu tumis bumbu halus, serai, daun salam dan daun jeruk. Gunakan api kecil."
- "Setelah bumbu matang, masukkan ati ampla, aduk rata dan tambahkan air kira-kira 200-300ml. Tambahkan kecap manis, garam, lada dan gula. Aduk rata. Cek rasa, lalu masukkan tomat. Masak hingga sat."
categories:
- Resep
tags:
- gongso
- ati
- ampela

katakunci: gongso ati ampela 
nutrition: 190 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Lunch

---


![Gongso Ati Ampela Ayam](https://img-global.cpcdn.com/recipes/88cead17a3480f0f/751x532cq70/gongso-ati-ampela-ayam-foto-resep-utama.jpg)

Anda sedang mencari ide resep gongso ati ampela ayam yang Enak Banget? Cara menyiapkannya memang susah-susah gampang. apabila keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso ati ampela ayam yang enak selayaknya memiliki aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ati ampela ayam, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan gongso ati ampela ayam enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan istimewa.


Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah gongso ati ampela ayam yang siap dikreasikan. Anda bisa membuat Gongso Ati Ampela Ayam menggunakan 14 jenis bahan dan 3 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Gongso Ati Ampela Ayam:

1. Ambil 4 pasang ati ampela
1. Sediakan 1 buah tomat, buang biji potong besar
1. Siapkan  Minyak goreng
1. Gunakan Secukupnya air
1. Ambil  Bumbu halus
1. Siapkan 4 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Ambil 1 jari kunyit
1. Siapkan  Bumbu cemplung
1. Siapkan 1 batang serai, geprek
1. Ambil 4 lembar daun jeruk
1. Siapkan 1 lembar daun salam
1. Sediakan 2 sdm kecap manis
1. Ambil Secukupnya garam, lada, gula




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso Ati Ampela Ayam:

1. Didihkan air, masukkan 1 lembar daun salam dan sedikit garam lalu rebus ati Ampela yang sudah dibersihkan. Rebus sekitar 10 menit, tiriskan dan sisihkan.
1. Panaskan wajan, tuang minyak goreng lalu tumis bumbu halus, serai, daun salam dan daun jeruk. Gunakan api kecil.
1. Setelah bumbu matang, masukkan ati ampla, aduk rata dan tambahkan air kira-kira 200-300ml. Tambahkan kecap manis, garam, lada dan gula. Aduk rata. Cek rasa, lalu masukkan tomat. Masak hingga sat.




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Gongso Ati Ampela Ayam yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman maupun menjadi inspirasi untuk berjualan makanan. Selamat mencoba!
