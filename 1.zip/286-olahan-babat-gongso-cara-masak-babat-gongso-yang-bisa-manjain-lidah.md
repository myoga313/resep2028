---
description: "Olahan Babat Gongso | Cara Masak Babat Gongso Yang Bisa Manjain Lidah"
title: "Olahan Babat Gongso | Cara Masak Babat Gongso Yang Bisa Manjain Lidah"
slug: 286-olahan-babat-gongso-cara-masak-babat-gongso-yang-bisa-manjain-lidah
date: 2020-11-21T04:42:22.194Z
image: https://img-global.cpcdn.com/recipes/943c461f5a328c3c/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/943c461f5a328c3c/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/943c461f5a328c3c/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Isabel Paul
ratingvalue: 4.2
reviewcount: 4
recipeingredient:
- "500 gr babat"
- "10 buah bawang merah iris"
- "1 btng serai"
- "5 lbr daun salam"
- "1 sachet kecil kecap bango"
- "1/2 sachet royco sapi"
- " Bumbu halus"
- "5 buah bawang merah"
- "3 siung bawang putih"
- "10 cabai merah keriting"
- "5 buah cabai rawit"
- "1 ruas jahe"
- "2 btr kemiri"
recipeinstructions:
- "Presto babat dengan secukupnya air,1 btng serai,laos dan 5 lbr daun salam selama 30 menit.Setelah uap hilang cuci kemabali babatnya dan potong kecil kecil."
- "Tumis bumbu halus hingga wangi dan matang.Masukkan irisan bawang merah.Masak sebentar hingga layu."
- "Masukkan babat,kecap manis,gula,penyedap dan garam.Masak hingga bumbu meresap."
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 108 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Lunch

---


![Babat Gongso](https://img-global.cpcdn.com/recipes/943c461f5a328c3c/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Lagi mencari inspirasi resep babat gongso yang Enak dan Simpel? Cara Buatnya memang susah-susah gampang. andaikata keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal babat gongso yang enak selayaknya punya aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari babat gongso, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tak perlu pusing jika mau menyiapkan babat gongso yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.




Nah, kali ini kita coba, yuk, kreasikan babat gongso sendiri di rumah. Tetap berbahan sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Babat Gongso memakai 13 jenis bahan dan 3 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Babat Gongso:

1. Sediakan 500 gr babat
1. Sediakan 10 buah bawang merah iris
1. Gunakan 1 btng serai
1. Siapkan 5 lbr daun salam
1. Ambil 1 sachet kecil kecap bango
1. Gunakan 1/2 sachet royco sapi
1. Siapkan  Bumbu halus
1. Ambil 5 buah bawang merah
1. Gunakan 3 siung bawang putih
1. Ambil 10 cabai merah keriting
1. Siapkan 5 buah cabai rawit
1. Gunakan 1 ruas jahe
1. Ambil 2 btr kemiri




<!--inarticleads2-->

##### Cara menyiapkan Babat Gongso:

1. Presto babat dengan secukupnya air,1 btng serai,laos dan 5 lbr daun salam selama 30 menit.Setelah uap hilang cuci kemabali babatnya dan potong kecil kecil.
1. Tumis bumbu halus hingga wangi dan matang.Masukkan irisan bawang merah.Masak sebentar hingga layu.
1. Masukkan babat,kecap manis,gula,penyedap dan garam.Masak hingga bumbu meresap.




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan Babat Gongso yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman ataupun menjadi ide untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
