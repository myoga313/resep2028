---
description: "Resep masakan Gongso Ayam Pedas | Cara Mengolah Gongso Ayam Pedas Yang Enak Banget"
title: "Resep masakan Gongso Ayam Pedas | Cara Mengolah Gongso Ayam Pedas Yang Enak Banget"
slug: 186-resep-masakan-gongso-ayam-pedas-cara-mengolah-gongso-ayam-pedas-yang-enak-banget
date: 2020-09-14T10:20:34.098Z
image: https://img-global.cpcdn.com/recipes/9a9158619633b08f/751x532cq70/gongso-ayam-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9a9158619633b08f/751x532cq70/gongso-ayam-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9a9158619633b08f/751x532cq70/gongso-ayam-pedas-foto-resep-utama.jpg
author: Gordon Carter
ratingvalue: 4.2
reviewcount: 14
recipeingredient:
- "2 buah paha ayam"
- "3 pasang ati ampela"
- "1 buah telur"
- "1 buah tomat ukuran sedang buang bijinya potong jadi 8"
- "1 batang daun bawang iris halus"
- "1 sdm saus sambal"
- "1 sdm saus tiram"
- "2 sdm kecap manis"
- "3 siung bawang merah iris tipis"
- "secukupnya air gula garam merica dan kaldu bubuk"
- " Bumbu halus "
- "6 buah cabe keriting"
- "6 buah cabe rawit merah"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "2 buah kemiri"
recipeinstructions:
- "Ayam potong masing2 jd 3 bagian, cuci bersih ayam &amp; ati ampela, rebus dengan 1 sdt asam jawa + 1/2 sdt garam kasar hingga matang. Goreng setengah kering ayam dan ati ampela yg telah di rebus. Potong dadu ati ampela, dan suwir2 ayam. Jgn terlalu bersih dr tulangnya"
- "Tumis bawang merah dan bumbu halus sampai wangi, masukkan telur, buat orak arik kasar aja. Tambahkan saus sambal, saus tiram dan kecap manis. Masukkan tomat, aduk rata"
- "Masukkan ayam dan ati ampela, tambahkan air secukupnya. Tambahkan gula garam merica dan kaldu bubuk sesuai selera. Test rasa, apabila sudah pas masukkan daun bawang, masak sebentar lalu matikan api. Sajikan dengan taburan bawang goreng."
categories:
- Resep
tags:
- gongso
- ayam
- pedas

katakunci: gongso ayam pedas 
nutrition: 254 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Lunch

---


![Gongso Ayam Pedas](https://img-global.cpcdn.com/recipes/9a9158619633b08f/751x532cq70/gongso-ayam-pedas-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep gongso ayam pedas yang Lezat? Cara Bikinnya memang susah-susah gampang. Jika keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gongso ayam pedas yang enak selayaknya memiliki aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ayam pedas, pertama dari jenis bahan, kemudian pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tidak usah pusing kalau ingin menyiapkan gongso ayam pedas yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.


Nah, kali ini kita coba, yuk, ciptakan gongso ayam pedas sendiri di rumah. Tetap berbahan sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Gongso Ayam Pedas menggunakan 16 bahan dan 3 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Gongso Ayam Pedas:

1. Siapkan 2 buah paha ayam,
1. Sediakan 3 pasang ati ampela,
1. Gunakan 1 buah telur
1. Gunakan 1 buah tomat ukuran sedang, buang bijinya, potong jadi 8
1. Gunakan 1 batang daun bawang, iris halus
1. Sediakan 1 sdm saus sambal
1. Siapkan 1 sdm saus tiram
1. Sediakan 2 sdm kecap manis
1. Siapkan 3 siung bawang merah, iris tipis
1. Gunakan secukupnya air, gula, garam, merica dan kaldu bubuk
1. Siapkan  Bumbu halus :
1. Siapkan 6 buah cabe keriting,
1. Ambil 6 buah cabe rawit merah,
1. Sediakan 8 siung bawang merah,
1. Sediakan 4 siung bawang putih,
1. Gunakan 2 buah kemiri




<!--inarticleads2-->

##### Cara menyiapkan Gongso Ayam Pedas:

1. Ayam potong masing2 jd 3 bagian, cuci bersih ayam &amp; ati ampela, rebus dengan 1 sdt asam jawa + 1/2 sdt garam kasar hingga matang. Goreng setengah kering ayam dan ati ampela yg telah di rebus. Potong dadu ati ampela, dan suwir2 ayam. Jgn terlalu bersih dr tulangnya
1. Tumis bawang merah dan bumbu halus sampai wangi, masukkan telur, buat orak arik kasar aja. Tambahkan saus sambal, saus tiram dan kecap manis. Masukkan tomat, aduk rata
1. Masukkan ayam dan ati ampela, tambahkan air secukupnya. Tambahkan gula garam merica dan kaldu bubuk sesuai selera. Test rasa, apabila sudah pas masukkan daun bawang, masak sebentar lalu matikan api. Sajikan dengan taburan bawang goreng.




Bagaimana? Gampang kan? Itulah cara menyiapkan gongso ayam pedas yang bisa Anda praktikkan di rumah. Selamat mencoba!
