---
description: "Resep Gongso Kepala dan ceker ayam | Cara Masak Gongso Kepala dan ceker ayam Yang Enak Banget"
title: "Resep Gongso Kepala dan ceker ayam | Cara Masak Gongso Kepala dan ceker ayam Yang Enak Banget"
slug: 234-resep-gongso-kepala-dan-ceker-ayam-cara-masak-gongso-kepala-dan-ceker-ayam-yang-enak-banget
date: 2020-12-01T12:19:11.155Z
image: https://img-global.cpcdn.com/recipes/6893ed98b2fe536d/751x532cq70/gongso-kepala-dan-ceker-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6893ed98b2fe536d/751x532cq70/gongso-kepala-dan-ceker-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6893ed98b2fe536d/751x532cq70/gongso-kepala-dan-ceker-ayam-foto-resep-utama.jpg
author: Cody Sanders
ratingvalue: 4.8
reviewcount: 8
recipeingredient:
- " kepala ayam ungkep"
- " ceker ayam ungkep"
- " sereh memarkan"
- " lengkuas memarkan"
- " daun salam"
- " daun jeruk"
- " tomat ukuran kecil"
- " kecap manis"
- " saos tiram"
- " Gula garam kaldu ayam"
- " air"
- " Minyak untuk menumis"
- " Bumbu halus"
- " bawang merah"
- " bawang putih"
- " cabai rawit buat yang suka pedes boleh ditambah ya"
- " merica"
- " jahe"
recipeinstructions:
- "Haluskan bumbu halus."
- "Siapkan kepala dan ceker yg sudah diungkep. Kalo yg belum diungkep bisa diungkep dulu pake bumbu racik ayam goreng. Hehehe"
- "Tumis bumbu halus, sereh, lengkuas. Setelah harus masukkan daun salam. Masak hingga bumbu matang."
- "Setelah matang, masukkan kepala dan ceker ayam. Lalu tambahkan air. Masukkan tomat yg sudah dipotong-potong, kecap manis, saus tiram, gula, garam, dan kaldu ayam. Masak hingga air menyusut."
- "Setelah menyusut koreksi rasa. Gongso siap untuk disajikan. Simple banget kaann..."
categories:
- Resep
tags:
- gongso
- kepala
- dan

katakunci: gongso kepala dan 
nutrition: 108 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Lunch

---


![Gongso Kepala dan ceker ayam](https://img-global.cpcdn.com/recipes/6893ed98b2fe536d/751x532cq70/gongso-kepala-dan-ceker-ayam-foto-resep-utama.jpg)

Lagi mencari ide resep gongso kepala dan ceker ayam yang Sedap? Cara membuatnya memang susah-susah gampang. sekiranya salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso kepala dan ceker ayam yang enak selayaknya mempunyai aroma dan rasa yang mampu memancing selera kita.

Ungkep kepala, ceker, ati ampela sampai empuk. Nggak hanya babat yang enak dimasak bumbu gongso tapi juga bisa daging ayam yang tidak kalah enaknya, sehingga juga cocok untuk yang nggak suka jeroan. - Gongso dan tambahkan daun salam, daun jeruk, sereh geprek, dan lengkuas geprek tumis hingga harum - Setelah harum tambahkan air secukupnya dan masukkan bumbu- bumbu penyedap seperti garam, gula, kaldu bubuk, lada bubuk secukupnya. Rasakan bila sudah enak masukkan ceker yang.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso kepala dan ceker ayam, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan gongso kepala dan ceker ayam enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian spesial.


Nah, kali ini kita coba, yuk, buat gongso kepala dan ceker ayam sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Gongso Kepala dan ceker ayam menggunakan 18 bahan dan 5 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Gongso Kepala dan ceker ayam:

1. Sediakan  kepala ayam ungkep
1. Ambil  ceker ayam ungkep
1. Siapkan  sereh (memarkan)
1. Siapkan  lengkuas (memarkan)
1. Gunakan  daun salam
1. Gunakan  daun jeruk
1. Sediakan  tomat ukuran kecil
1. Ambil  kecap manis
1. Ambil  saos tiram
1. Gunakan  Gula, garam, kaldu ayam
1. Ambil  air
1. Siapkan  Minyak untuk menumis
1. Sediakan  Bumbu halus
1. Gunakan  bawang merah
1. Gunakan  bawang putih
1. Sediakan  cabai rawit (buat yang suka pedes boleh ditambah ya)
1. Ambil  merica
1. Sediakan  jahe




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso Kepala dan ceker ayam:

1. Haluskan bumbu halus.
1. Siapkan kepala dan ceker yg sudah diungkep. Kalo yg belum diungkep bisa diungkep dulu pake bumbu racik ayam goreng. Hehehe
1. Tumis bumbu halus, sereh, lengkuas. Setelah harus masukkan daun salam. Masak hingga bumbu matang.
1. Setelah matang, masukkan kepala dan ceker ayam. Lalu tambahkan air. Masukkan tomat yg sudah dipotong-potong, kecap manis, saus tiram, gula, garam, dan kaldu ayam. Masak hingga air menyusut.
1. Setelah menyusut koreksi rasa. Gongso siap untuk disajikan. Simple banget kaann...




Gimana nih? Mudah bukan? Itulah cara menyiapkan gongso kepala dan ceker ayam yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
