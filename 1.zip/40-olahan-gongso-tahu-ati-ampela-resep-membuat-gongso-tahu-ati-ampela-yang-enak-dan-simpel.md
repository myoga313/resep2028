---
description: "Olahan Gongso Tahu Ati Ampela | Resep Membuat Gongso Tahu Ati Ampela Yang Enak dan Simpel"
title: "Olahan Gongso Tahu Ati Ampela | Resep Membuat Gongso Tahu Ati Ampela Yang Enak dan Simpel"
slug: 40-olahan-gongso-tahu-ati-ampela-resep-membuat-gongso-tahu-ati-ampela-yang-enak-dan-simpel
date: 2020-08-26T22:03:50.469Z
image: https://img-global.cpcdn.com/recipes/50bcd2527176ae55/751x532cq70/gongso-tahu-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/50bcd2527176ae55/751x532cq70/gongso-tahu-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/50bcd2527176ae55/751x532cq70/gongso-tahu-ati-ampela-foto-resep-utama.jpg
author: Kenneth Franklin
ratingvalue: 4.4
reviewcount: 9
recipeingredient:
- "6 pasang ati ampela"
- "1 blok tahu putih besar potongpotong"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1 tangkai daun bawang"
- "1 keping gula merah"
- "2 sdm kecap manis"
- "Secukupnya garam dan kaldu bubuk"
- "1 gelas air"
- " Bumbu ungkep "
- "3 siung bawang merah"
- "2 siung bawang putih"
- "1 ruas jahe geprek"
- "1 ruas kunyit bakar geprek"
- "1/2 sdt ketumbar bubuk"
- "2 Lembar daun salam"
- "1 batang serai"
- " Bumbu halus"
- "7 buah cabai merah keriting"
- "3 siung bawang putih"
- "6 siung bawang merah"
- "1 ruas kunyit bakar"
recipeinstructions:
- "Rebus ati ampela dengan bumbu ungkep biarkan meresap sisihkan. Setelah dingin potong kecil. Goreng tahu sisihkan"
- "Tumis bawang putih, bawang merah, daun bawang kemudian masukkan ati ampela tumis sampai agak kering. angkat sisihkan"
- "Haluskan bumbu halus saya di blender saja kemudian tumis sampai bumbu matang"
- "Masukkan ati ampela, tahu kemudian tuang air beri kecap manis bumbui dengan gula garam dan kaldu bubuk aduk rata."
- "Masak api sedang saja tunggu bumbu meresap koreksi rasa angkat sajikan. Saya bikin yang kering atau kalau suka yang berkuah boleh saja."
categories:
- Resep
tags:
- gongso
- tahu
- ati

katakunci: gongso tahu ati 
nutrition: 115 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Dessert

---


![Gongso Tahu Ati Ampela](https://img-global.cpcdn.com/recipes/50bcd2527176ae55/751x532cq70/gongso-tahu-ati-ampela-foto-resep-utama.jpg)

Bunda Sedang mencari ide resep gongso tahu ati ampela yang Lezat? Cara Memasaknya memang susah-susah gampang. misalnya salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gongso tahu ati ampela yang enak seharusnya punya aroma dan rasa yang dapat memancing selera kita.

Halodoc, Jakarta - Ati ampela merupakan bagian jeroan alias organ pencernaan ayam yang sering diolah menjadi makanan. Lantas, apakah jeroan ati ampela hanya memiliki kandungan yang berbahaya saja? Agar lebih jelas, yuk cari tahu fakta kandungan nutrisi yang.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso tahu ati ampela, pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan gongso tahu ati ampela enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan spesial.


Berikut ini ada beberapa tips dan trik praktis untuk membuat gongso tahu ati ampela yang siap dikreasikan. Anda bisa menyiapkan Gongso Tahu Ati Ampela menggunakan 22 bahan dan 5 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Gongso Tahu Ati Ampela:

1. Ambil 6 pasang ati ampela
1. Sediakan 1 blok tahu putih besar potong-potong
1. Sediakan 5 siung bawang merah
1. Ambil 3 siung bawang putih
1. Gunakan 1 tangkai daun bawang
1. Sediakan 1 keping gula merah
1. Sediakan 2 sdm kecap manis
1. Sediakan Secukupnya garam dan kaldu bubuk
1. Gunakan 1 gelas air
1. Gunakan  Bumbu ungkep :
1. Ambil 3 siung bawang merah
1. Sediakan 2 siung bawang putih
1. Sediakan 1 ruas jahe geprek
1. Ambil 1 ruas kunyit bakar geprek
1. Gunakan 1/2 sdt ketumbar bubuk
1. Siapkan 2 Lembar daun salam
1. Gunakan 1 batang serai
1. Sediakan  Bumbu halus:
1. Siapkan 7 buah cabai merah keriting
1. Siapkan 3 siung bawang putih
1. Siapkan 6 siung bawang merah
1. Siapkan 1 ruas kunyit bakar


Sebelum mengolah ati ampela, anda tentu harus membersihkannya terlebih dahulu agar masakan yang anda buat lebih higenis dan sehat. MASAKAN serba gongso mempunyai penampilan dan cita rasa khas. Selain daging ayam, bahan lain seperti babat iso, ati ampela dan telur juga cocok dimasak gongso. Sebelum dimasak, aneka bahan ini dimasak bacem dulu dengan bumbu-bumbu bacem. 

<!--inarticleads2-->

##### Cara menyiapkan Gongso Tahu Ati Ampela:

1. Rebus ati ampela dengan bumbu ungkep biarkan meresap sisihkan. Setelah dingin potong kecil. Goreng tahu sisihkan
1. Tumis bawang putih, bawang merah, daun bawang kemudian masukkan ati ampela tumis sampai agak kering. angkat sisihkan
1. Haluskan bumbu halus saya di blender saja kemudian tumis sampai bumbu matang
1. Masukkan ati ampela, tahu kemudian tuang air beri kecap manis bumbui dengan gula garam dan kaldu bubuk aduk rata.
1. Masak api sedang saja tunggu bumbu meresap koreksi rasa angkat sajikan. Saya bikin yang kering atau kalau suka yang berkuah boleh saja.


Masak Gongso Ati Ampela Ayam - Resep Bunda Nina. Kuncinya yaitu merebus ati ampela dengan rempah-rempah aromatik. Karena ati ampela bisa mengeras bila dimasak terlalu lama, sebelum mengolahnya kamu harus pastikan untuk menumis racikan bumbu halus sampai benar-benar matang dan tidak berbau langu. Aduk ati ampela dengan minyak goreng, lalu tusuk selang seling antara hati dan ampela dengan menggunakan tusuk sate. Panggang di atas bara api yang panas sampai matang dan angkat. 

Terima kasih telah membaca resep yang kami tampilkan di sini. Besar harapan kami, olahan Gongso Tahu Ati Ampela yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman maupun menjadi ide untuk berjualan makanan. Selamat mencoba!
