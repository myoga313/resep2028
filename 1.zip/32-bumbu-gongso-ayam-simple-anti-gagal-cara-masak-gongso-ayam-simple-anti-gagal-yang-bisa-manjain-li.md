---
description: "Bumbu Gongso ayam simple anti gagal | Cara Masak Gongso ayam simple anti gagal Yang Bisa Manjain Lidah"
title: "Bumbu Gongso ayam simple anti gagal | Cara Masak Gongso ayam simple anti gagal Yang Bisa Manjain Lidah"
slug: 32-bumbu-gongso-ayam-simple-anti-gagal-cara-masak-gongso-ayam-simple-anti-gagal-yang-bisa-manjain-lidah
date: 2021-01-11T16:09:19.286Z
image: https://img-global.cpcdn.com/recipes/19e049b5640e7a2d/751x532cq70/gongso-ayam-simple-anti-gagal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/19e049b5640e7a2d/751x532cq70/gongso-ayam-simple-anti-gagal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/19e049b5640e7a2d/751x532cq70/gongso-ayam-simple-anti-gagal-foto-resep-utama.jpg
author: Claudia Roberson
ratingvalue: 4.2
reviewcount: 8
recipeingredient:
- "1 pasang dada ayam"
- "1 butir telor ayam kocok lepas"
- "1 buah tomat"
- "secukupnya kubis"
- "sesuai selera daun bawang"
- " bumbu halus "
- "10 siung bawang merah"
- "5 siung bawang putih"
- "1 sdt merica"
- "2 biji kemiri"
- "1 sdt garam"
- "sesuai selera penyedap rasa ayam"
- "5 buah cabai keriting"
- "3 buah cabai rawit saya pakai rawit setan biar pedas nampol"
- " tambahan "
- "3 sdm kecap"
- "2 sdm saori"
recipeinstructions:
- "Ayam di cuci bersih direbus sampai matang, tiriskan lalu suwir2. Potong tomat jdi 6 bagian, kubis secukupnya, daun bawang potong uk sedang."
- "Panaskan minyak, tumis bumbu hingga benar2 bau harum dan berubah warna (hampir matang),masukkan kocokan telur(telur jgn sampai trrcampur bumbu, bumbu di pinggirkan dl) lalu kosrek2 telur, masukkan tomat, tumis hingga layu,"
- "Kemudian masukkan kecap, saori, tumis kembali sebentar, Masukkan ayam yg disuwir, aduk sampai rata, beri air secukupnya."
- "Masak sampai bumbu meresap (saya masak 10 mnt dg api sedang) masukkan kubis dan daun bawang. Aduk kembali tambahkan penyedap rasa, koreksi rasa. Jangan lupa dihidangkan dengan taburan bawang goreng."
categories:
- Resep
tags:
- gongso
- ayam
- simple

katakunci: gongso ayam simple 
nutrition: 191 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Dessert

---


![Gongso ayam simple anti gagal](https://img-global.cpcdn.com/recipes/19e049b5640e7a2d/751x532cq70/gongso-ayam-simple-anti-gagal-foto-resep-utama.jpg)

Bunda lagi mencari ide resep gongso ayam simple anti gagal yang Enak Dan Lezat? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. andaikan salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso ayam simple anti gagal yang enak harusnya sih mempunyai aroma dan cita rasa yang mampu memancing selera kita.

Resep Babat Gongso merupakan salah satu masakan Nusantara dengan cita rasa yang luar biasa. Pas banget menyajikan Resep Babat Gongso untuk menu utama makan saat Idul Adha nanti. Jangan lupa siapkan nasi yang banyak kalau menyajikan Resep Babat Gongso ini, ya.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ayam simple anti gagal, mulai dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tak perlu pusing jika ingin menyiapkan gongso ayam simple anti gagal enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian spesial.


Di bawah ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah gongso ayam simple anti gagal yang siap dikreasikan. Anda bisa membuat Gongso ayam simple anti gagal memakai 17 jenis bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Gongso ayam simple anti gagal:

1. Siapkan 1 pasang dada ayam
1. Gunakan 1 butir telor ayam kocok lepas
1. Siapkan 1 buah tomat
1. Ambil secukupnya kubis
1. Gunakan sesuai selera daun bawang
1. Ambil  bumbu halus :
1. Siapkan 10 siung bawang merah
1. Sediakan 5 siung bawang putih
1. Gunakan 1 sdt merica
1. Gunakan 2 biji kemiri
1. Siapkan 1 sdt garam
1. Sediakan sesuai selera penyedap rasa ayam
1. Ambil 5 buah cabai keriting
1. Ambil 3 buah cabai rawit (saya pakai rawit setan biar pedas nampol)
1. Siapkan  tambahan :
1. Gunakan 3 sdm kecap
1. Sediakan 2 sdm saori


Maka dari itu, sajian khas Semarang ini juga bisa diartikan ayam masak tumis. Kenampakannya gelap dan citarasanya manis mirip dengan semur yang berkuah sedikit. Di kota asalnya, ayam gongso dijajakan malam hari oleh pedagang yang juga menjual nasi. Gongso ayam khas kudus Cita Rasa Tinggi. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso ayam simple anti gagal:

1. Ayam di cuci bersih direbus sampai matang, tiriskan lalu suwir2. Potong tomat jdi 6 bagian, kubis secukupnya, daun bawang potong uk sedang.
1. Panaskan minyak, tumis bumbu hingga benar2 bau harum dan berubah warna (hampir matang),masukkan kocokan telur(telur jgn sampai trrcampur bumbu, bumbu di pinggirkan dl) lalu kosrek2 telur, masukkan tomat, tumis hingga layu,
1. Kemudian masukkan kecap, saori, tumis kembali sebentar, Masukkan ayam yg disuwir, aduk sampai rata, beri air secukupnya.
1. Masak sampai bumbu meresap (saya masak 10 mnt dg api sedang) masukkan kubis dan daun bawang. Aduk kembali tambahkan penyedap rasa, koreksi rasa. Jangan lupa dihidangkan dengan taburan bawang goreng.


Babat gongso salah satu kuliner khas Semarang yang rasanya sangat gurih, jika anda ingin mencicipinya dan belum sempat ke kota Semarang bisa membuatnya sendiri. Resep Mudah Ayam siwir sambal kemangi Anti Gagal. This modification would be detected by any simple anti-cheat engine. At the time of writing, Among Us uses no such technology. However, I am not responsible for any bans or other problems arising from the usage of this mod. 

Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Harapan kami, olahan Gongso ayam simple anti gagal yang mudah di atas dapat membantu Anda menyiapkan makanan yang menarik untuk keluarga/teman ataupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Selamat mencoba!
