---
description: "Olahan Babat Paru Gongso khas Semarang | Cara Bikin Babat Paru Gongso khas Semarang Yang Enak Banget"
title: "Olahan Babat Paru Gongso khas Semarang | Cara Bikin Babat Paru Gongso khas Semarang Yang Enak Banget"
slug: 432-olahan-babat-paru-gongso-khas-semarang-cara-bikin-babat-paru-gongso-khas-semarang-yang-enak-banget
date: 2020-12-24T19:15:54.629Z
image: https://img-global.cpcdn.com/recipes/d79c3af7cd266475/751x532cq70/babat-paru-gongso-khas-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d79c3af7cd266475/751x532cq70/babat-paru-gongso-khas-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d79c3af7cd266475/751x532cq70/babat-paru-gongso-khas-semarang-foto-resep-utama.jpg
author: Chase Gardner
ratingvalue: 3.7
reviewcount: 8
recipeingredient:
- "500 gr Paru  Babat"
- "2 Lembar Daun Salam"
- "2 Lembar Daun Jeruk"
- "1 Tangkai Serai"
- "2 Ruas Lengkuas"
- "1 Ruas Jahe geprek"
- " Bahan Halus"
- "7 Siung Bawang Merah"
- "5 Siung Bawang Putih"
- "5 Buah Cabe Merah sesuai selera"
- "5 Buah Cabe Rawit sesuaI selera"
- " Bumbu Masak"
- " Garam"
- " Gula"
- " Kecap Manis"
- " Minyak untuk menumis"
- "sesuai selera Penyedap Masakan Kaldu Jamur  Micin atau"
recipeinstructions:
- "Rebus/Presto daging Paru &amp; Babat agar empuk dengan daun salam, lengkuas &amp; daun serai. Jika sudah matang &amp; empuk tiriskan."
- "Haluskan (saya pakai blender) Bumbu² Halus dan sisakan 4 siung bawang merah untuk dicincang."
- "Panaskan minyak, masukan bawang merah yang sudah dicincang, jahe geprek, daun jeruk dan 1 batang serai sampai harum. Kemudian masukan bumbu halus, aduk² sampai matang baru tambahkan air dan kecap. Masukan paru &amp; babat, tambahkan garam, gula, bumbu penyedap. Koreksi rasa"
- "Masak sampe bumbu meresap dan air berkurang. Sajikan"
categories:
- Resep
tags:
- babat
- paru
- gongso

katakunci: babat paru gongso 
nutrition: 199 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Dessert

---


![Babat Paru Gongso khas Semarang](https://img-global.cpcdn.com/recipes/d79c3af7cd266475/751x532cq70/babat-paru-gongso-khas-semarang-foto-resep-utama.jpg)

Bunda Sedang mencari ide resep babat paru gongso khas semarang yang Menggugah Selera? Cara menyiapkannya memang susah-susah gampang. seandainya salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal babat paru gongso khas semarang yang enak seharusnya memiliki aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat paru gongso khas semarang, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tidak usah pusing kalau hendak menyiapkan babat paru gongso khas semarang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan spesial.




Nah, kali ini kita coba, yuk, ciptakan babat paru gongso khas semarang sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Babat Paru Gongso khas Semarang memakai 17 bahan dan 4 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Babat Paru Gongso khas Semarang:

1. Sediakan 500 gr Paru &amp; Babat
1. Ambil 2 Lembar Daun Salam
1. Sediakan 2 Lembar Daun Jeruk
1. Siapkan 1 Tangkai Serai
1. Ambil 2 Ruas Lengkuas
1. Gunakan 1 Ruas Jahe (geprek)
1. Sediakan  Bahan Halus
1. Siapkan 7 Siung Bawang Merah
1. Ambil 5 Siung Bawang Putih
1. Ambil 5 Buah Cabe Merah (sesuai selera)
1. Ambil 5 Buah Cabe Rawit (sesuaI selera)
1. Siapkan  Bumbu Masak
1. Siapkan  Garam
1. Ambil  Gula
1. Sediakan  Kecap Manis
1. Ambil  Minyak untuk menumis
1. Ambil sesuai selera Penyedap Masakan (Kaldu Jamur &amp; Micin) atau




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Babat Paru Gongso khas Semarang:

1. Rebus/Presto daging Paru &amp; Babat agar empuk dengan daun salam, lengkuas &amp; daun serai. Jika sudah matang &amp; empuk tiriskan.
1. Haluskan (saya pakai blender) Bumbu² Halus dan sisakan 4 siung bawang merah untuk dicincang.
1. Panaskan minyak, masukan bawang merah yang sudah dicincang, jahe geprek, daun jeruk dan 1 batang serai sampai harum. Kemudian masukan bumbu halus, aduk² sampai matang baru tambahkan air dan kecap. Masukan paru &amp; babat, tambahkan garam, gula, bumbu penyedap. Koreksi rasa
1. Masak sampe bumbu meresap dan air berkurang. Sajikan




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Babat Paru Gongso khas Semarang yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman ataupun menjadi ide bagi Anda yang berkeinginan untuk berbisnis kuliner. Selamat mencoba!
