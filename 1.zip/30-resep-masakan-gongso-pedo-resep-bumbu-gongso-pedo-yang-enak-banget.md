---
description: "Resep masakan Gongso Pedo | Resep Bumbu Gongso Pedo Yang Enak Banget"
title: "Resep masakan Gongso Pedo | Resep Bumbu Gongso Pedo Yang Enak Banget"
slug: 30-resep-masakan-gongso-pedo-resep-bumbu-gongso-pedo-yang-enak-banget
date: 2021-01-10T07:59:16.596Z
image: https://img-global.cpcdn.com/recipes/a47f8aee178e6b22/751x532cq70/gongso-pedo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a47f8aee178e6b22/751x532cq70/gongso-pedo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a47f8aee178e6b22/751x532cq70/gongso-pedo-foto-resep-utama.jpg
author: Eliza Boone
ratingvalue: 4
reviewcount: 4
recipeingredient:
- "300 gr ikan asin peda berat bersih stlh dipisah dr tulang"
- "100 gr bawang merah"
- "10 siung bawang putih"
- "200 gr cabai rawit campur merah hijau"
- "2 bh tomat merah yg sedang besarnya"
- "250 cc santan kental"
- "secukupnya gula pasir"
- "secukupnya garam kalau perlu"
- "secukupnya minyak goreng untuk menumis  menggoreng peda"
recipeinstructions:
- "Siapkan ikan asin peda, cuci bersih &amp; rendam dulu bbrp saat dlm air dingin hingga lunak mjd mudah dipisah dr durinya."
- "Pisahkan daging ikan dr kepala duri &amp; tulangnya, potong dadu kecil"
- "Goreng dlm minyak panas hingga kering, tiriskan minyaknya, sisihkan."
- "Rajang halus duo bawang, iris² cabai rawit. Tumis bumbu iris ini dlm minyak baru wajan baru (kalau mau pakai jelantahnya gpp suka² aja tp hati² nanti penambahan garam)."
- "Tumis hingga bumbu matang agak kering, kemudian masukkan peda goreng, aduk rata"
- "Tambahkan santan kental. Didihkan."
- "Masukkan tomat yg sdh dipotong² kasar, tambahkan gula secukupnya. Masak hingga santan kering &amp; berminyak. Koreksi rasa, tambahkan garam bila dirasa perlu sebab meski ikan asin tetep kurang &#34;angglek&#34; sedepnya kalau ga ditambah garam."
- "Hingga berminyak ya... Dan siap disajikan"
categories:
- Resep
tags:
- gongso
- pedo

katakunci: gongso pedo 
nutrition: 241 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Lunch

---


![Gongso Pedo](https://img-global.cpcdn.com/recipes/a47f8aee178e6b22/751x532cq70/gongso-pedo-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep gongso pedo yang Bikin Ngiler? Cara Bikinnya memang tidak terlalu sulit namun tidak gampang juga. Jika keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gongso pedo yang enak selayaknya memiliki aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso pedo, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tak perlu pusing jika mau menyiapkan gongso pedo enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.




Nah, kali ini kita coba, yuk, kreasikan gongso pedo sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Gongso Pedo menggunakan 9 bahan dan 8 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Gongso Pedo:

1. Gunakan 300 gr ikan asin peda (berat bersih stlh dipisah dr tulang)
1. Sediakan 100 gr bawang merah
1. Gunakan 10 siung bawang putih
1. Gunakan 200 gr cabai rawit campur merah hijau
1. Gunakan 2 bh tomat merah yg sedang besarnya
1. Ambil 250 cc santan kental
1. Sediakan secukupnya gula pasir
1. Ambil secukupnya garam (kalau perlu)
1. Siapkan secukupnya minyak goreng untuk menumis &amp; menggoreng peda




<!--inarticleads2-->

##### Cara membuat Gongso Pedo:

1. Siapkan ikan asin peda, cuci bersih &amp; rendam dulu bbrp saat dlm air dingin hingga lunak mjd mudah dipisah dr durinya.
1. Pisahkan daging ikan dr kepala duri &amp; tulangnya, potong dadu kecil
1. Goreng dlm minyak panas hingga kering, tiriskan minyaknya, sisihkan.
1. Rajang halus duo bawang, iris² cabai rawit. Tumis bumbu iris ini dlm minyak baru wajan baru (kalau mau pakai jelantahnya gpp suka² aja tp hati² nanti penambahan garam).
1. Tumis hingga bumbu matang agak kering, kemudian masukkan peda goreng, aduk rata
1. Tambahkan santan kental. Didihkan.
1. Masukkan tomat yg sdh dipotong² kasar, tambahkan gula secukupnya. Masak hingga santan kering &amp; berminyak. Koreksi rasa, tambahkan garam bila dirasa perlu sebab meski ikan asin tetep kurang &#34;angglek&#34; sedepnya kalau ga ditambah garam.
1. Hingga berminyak ya... Dan siap disajikan




Gimana nih? Gampang kan? Itulah cara membuat gongso pedo yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
