---
description: "Olahan Ayam Gongso 🐥🌶🥘 | Bahan Membuat Ayam Gongso 🐥🌶🥘 Yang Enak Dan Lezat"
title: "Olahan Ayam Gongso 🐥🌶🥘 | Bahan Membuat Ayam Gongso 🐥🌶🥘 Yang Enak Dan Lezat"
slug: 72-olahan-ayam-gongso-bahan-membuat-ayam-gongso-yang-enak-dan-lezat
date: 2020-11-22T19:30:20.412Z
image: https://img-global.cpcdn.com/recipes/286617cd649333d8/751x532cq70/ayam-gongso-🐥🌶🥘-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/286617cd649333d8/751x532cq70/ayam-gongso-🐥🌶🥘-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/286617cd649333d8/751x532cq70/ayam-gongso-🐥🌶🥘-foto-resep-utama.jpg
author: Antonio Watkins
ratingvalue: 3.8
reviewcount: 3
recipeingredient:
- "1/4 kg paha ayam fillet"
- "1 sdm mentegamargarin"
- "Secukupnya kecap manis"
- " Bumbu Halus "
- "2 siung bawang merah"
- "1 siung bawang putih"
- "1 buah kemiri"
- "2 buah cabe merah keriting"
- "5 buah cabe rawit merah optional"
- "1/4 keping gula merah"
- "1 sachet royco"
- "Secukupnya gula pasir"
- "Secukupnya garam"
- " Bumbu Iris "
- "4 siung bawang merah"
- "5 buah cabe rawit merah optional"
recipeinstructions:
- "Bersihkan ayam, lalu potong ayam bentuk kotak/dadu, sisihkan."
- "Haluskan bumbu halus, kecuali gula merah, royco, garam dan gula pasir."
- "Panaskan sedikit minyak dan mentega/margarin pada wajan/penggorengan. Lalu masukkan irisan bawang merah, tumis sebentar, kemudian masukkan bumbu halus. Tumis kembali bumbu sampai setengah matang."
- "Setelah bumbu hampir matang, masukkan irisan gula merah dan irisan cabe rawit merah. Tumis kembali bumbu sampai matang."
- "Setelah bumbu matang, masukkan ayam, aduk rata sampai semua tercampur. Setelah itu, masukkan kecap manis, royco dan gula pasir. Cek rasa. Apabila kurang asin, bisa tambahkan garam. Disesuaikan dengan selera masing-masing."
- "Masak ayam sampai benar-benar ter (gongso), sampai agak kecoklatan/karamelisasi."
- "Setelah matang, angkat dan sajikan dengan nasi hangat. 🍚☺"
categories:
- Resep
tags:
- ayam
- gongso

katakunci: ayam gongso 
nutrition: 243 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Gongso 🐥🌶🥘](https://img-global.cpcdn.com/recipes/286617cd649333d8/751x532cq70/ayam-gongso-🐥🌶🥘-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep ayam gongso 🐥🌶🥘 yang Menggugah Selera? Cara Memasaknya memang tidak susah dan tidak juga mudah. andaikan salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal ayam gongso 🐥🌶🥘 yang enak seharusnya punya aroma dan cita rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso 🐥🌶🥘, pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menyajikannya. Tak perlu pusing kalau mau menyiapkan ayam gongso 🐥🌶🥘 yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian spesial.


Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah ayam gongso 🐥🌶🥘 yang siap dikreasikan. Anda dapat menyiapkan Ayam Gongso 🐥🌶🥘 memakai 16 jenis bahan dan 7 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam Gongso 🐥🌶🥘:

1. Sediakan 1/4 kg paha ayam fillet
1. Sediakan 1 sdm mentega/margarin
1. Siapkan Secukupnya kecap manis
1. Ambil  Bumbu Halus :
1. Ambil 2 siung bawang merah
1. Gunakan 1 siung bawang putih
1. Ambil 1 buah kemiri
1. Siapkan 2 buah cabe merah keriting
1. Siapkan 5 buah cabe rawit merah (optional)
1. Sediakan 1/4 keping gula merah
1. Sediakan 1 sachet royco
1. Sediakan Secukupnya gula pasir
1. Sediakan Secukupnya garam
1. Siapkan  Bumbu Iris :
1. Ambil 4 siung bawang merah
1. Gunakan 5 buah cabe rawit merah (optional)




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Gongso 🐥🌶🥘:

1. Bersihkan ayam, lalu potong ayam bentuk kotak/dadu, sisihkan.
1. Haluskan bumbu halus, kecuali gula merah, royco, garam dan gula pasir.
1. Panaskan sedikit minyak dan mentega/margarin pada wajan/penggorengan. Lalu masukkan irisan bawang merah, tumis sebentar, kemudian masukkan bumbu halus. Tumis kembali bumbu sampai setengah matang.
1. Setelah bumbu hampir matang, masukkan irisan gula merah dan irisan cabe rawit merah. Tumis kembali bumbu sampai matang.
1. Setelah bumbu matang, masukkan ayam, aduk rata sampai semua tercampur. Setelah itu, masukkan kecap manis, royco dan gula pasir. Cek rasa. Apabila kurang asin, bisa tambahkan garam. Disesuaikan dengan selera masing-masing.
1. Masak ayam sampai benar-benar ter (gongso), sampai agak kecoklatan/karamelisasi.
1. Setelah matang, angkat dan sajikan dengan nasi hangat. 🍚☺




Bagaimana? Gampang kan? Itulah cara menyiapkan ayam gongso 🐥🌶🥘 yang bisa Anda lakukan di rumah. Selamat mencoba!
