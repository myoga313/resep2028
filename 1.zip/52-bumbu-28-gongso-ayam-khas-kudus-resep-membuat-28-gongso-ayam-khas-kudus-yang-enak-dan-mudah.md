---
description: "Bumbu 28. Gongso ayam khas kudus | Resep Membuat 28. Gongso ayam khas kudus Yang Enak Dan Mudah"
title: "Bumbu 28. Gongso ayam khas kudus | Resep Membuat 28. Gongso ayam khas kudus Yang Enak Dan Mudah"
slug: 52-bumbu-28-gongso-ayam-khas-kudus-resep-membuat-28-gongso-ayam-khas-kudus-yang-enak-dan-mudah
date: 2020-07-29T21:13:33.563Z
image: https://img-global.cpcdn.com/recipes/685c4c41dbcd5d91/751x532cq70/28-gongso-ayam-khas-kudus-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/685c4c41dbcd5d91/751x532cq70/28-gongso-ayam-khas-kudus-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/685c4c41dbcd5d91/751x532cq70/28-gongso-ayam-khas-kudus-foto-resep-utama.jpg
author: Gregory Wells
ratingvalue: 4.1
reviewcount: 5
recipeingredient:
- "1 ekor ayam goreng suwir2"
- "500 ml air"
- "1 ikat sawi hijaume 4 lembar sawi putih"
- "1/4 kol me skip"
- "2 bh tomat"
- "2 sdm kecap manis"
- "1 sdt gula pasir"
- "1 sdt munjung garam"
- "1/2 sdt kaldu jamur"
- "5 bh cabe merah iris serong"
- "5 bh bawang merah iris halus"
- " Bumbu halus"
- "2 bh kemiri"
- "4 bawang putih"
- "1 sdt lada"
- "6 cabe rawit"
recipeinstructions:
- "Tumis bawang merah,bumbu halus, cabe iris, sampai harum kemudian masukan air"
- "Masukan ayam suwir, sawi,kecap manis, gula,garam,dan tomat"
- "Aduk rata dan tes rasa, jika di rasa pas, gongso ayam siap di hidangkan"
categories:
- Resep
tags:
- 28
- gongso
- ayam

katakunci: 28 gongso ayam 
nutrition: 168 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Lunch

---


![28. Gongso ayam khas kudus](https://img-global.cpcdn.com/recipes/685c4c41dbcd5d91/751x532cq70/28-gongso-ayam-khas-kudus-foto-resep-utama.jpg)

Kamu Sedang mencari inspirasi resep 28. gongso ayam khas kudus yang Enak Banget? Cara Bikinnya memang susah-susah gampang. jikalau keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal 28. gongso ayam khas kudus yang enak seharusnya memiliki aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari 28. gongso ayam khas kudus, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tak perlu pusing kalau ingin menyiapkan 28. gongso ayam khas kudus yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan istimewa.

Nggak hanya babat yang enak dimasak bumbu gongso tapi juga bisa daging ayam yang tidak kalah enaknya, sehingga juga cocok untuk yang nggak suka jeroan. Makanan khas kudus berupa ayam gongso ini tidak lain adalah ayam tumis. Bumbu yang digunakan dalam masakan ayam gongso ini adalah bumbu kecap.


Nah, kali ini kita coba, yuk, buat 28. gongso ayam khas kudus sendiri di rumah. Tetap berbahan sederhana, hidangan ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan 28. Gongso ayam khas kudus menggunakan 16 jenis bahan dan 3 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan 28. Gongso ayam khas kudus:

1. Siapkan 1 ekor ayam goreng suwir2
1. Siapkan 500 ml air
1. Siapkan 1 ikat sawi hijau,me, 4 lembar sawi putih
1. Sediakan 1/4 kol me, skip
1. Sediakan 2 bh tomat
1. Sediakan 2 sdm kecap manis
1. Ambil 1 sdt gula pasir
1. Sediakan 1 sdt munjung garam
1. Sediakan 1/2 sdt kaldu jamur
1. Siapkan 5 bh cabe merah iris serong
1. Sediakan 5 bh bawang merah iris halus
1. Siapkan  Bumbu halus
1. Sediakan 2 bh kemiri
1. Sediakan 4 bawang putih
1. Ambil 1 sdt lada
1. Gunakan 6 cabe rawit


Masakan khas Semarang- Babat Gongso yang seringkali juga dijadikan nasi goreng babat, dan ini enak sekali apalagi jika. Gongso merupakan bahasa jawa dari kata tumis ya food lovers. Jadi gongso ayam artinya tumis ayam yg khas dari Kota. Ayam gongso Khas Kudus ini pun adalahf tumisan ayam yang dimasak menggunakan bumbu kecap. 

<!--inarticleads2-->

##### Cara membuat 28. Gongso ayam khas kudus:

1. Tumis bawang merah,bumbu halus, cabe iris, sampai harum kemudian masukan air
1. Masukan ayam suwir, sawi,kecap manis, gula,garam,dan tomat
1. Aduk rata dan tes rasa, jika di rasa pas, gongso ayam siap di hidangkan


Menghadirkan rasa gurih, pedas dan manis tentu sangat memanjakan lidah anda. Anda dapat menyantap makanan ini dengan nasi putih hangat agar dapat mengenyangkan perut anda selama. Babat gongso khas Semarang rasanya manis berkat penggunaan kecap. KOMPAS.com - Babat gongso adalah makanan khas Semarang yang rasanya manis berkat penggunaan kecap. Ada juga versi lebih pedas, tinggal tambah takaran cabai keriting atau rawit merah. 

Gimana nih? Mudah bukan? Itulah cara menyiapkan 28. gongso ayam khas kudus yang bisa Anda praktikkan di rumah. Selamat mencoba!
