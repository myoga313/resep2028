---
description: "Olahan Ayam Gongso Sawi | Bahan Membuat Ayam Gongso Sawi Yang Lezat"
title: "Olahan Ayam Gongso Sawi | Bahan Membuat Ayam Gongso Sawi Yang Lezat"
slug: 223-olahan-ayam-gongso-sawi-bahan-membuat-ayam-gongso-sawi-yang-lezat
date: 2020-11-28T03:00:50.772Z
image: https://img-global.cpcdn.com/recipes/b133571b7294e128/751x532cq70/ayam-gongso-sawi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b133571b7294e128/751x532cq70/ayam-gongso-sawi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b133571b7294e128/751x532cq70/ayam-gongso-sawi-foto-resep-utama.jpg
author: Fannie Armstrong
ratingvalue: 3
reviewcount: 13
recipeingredient:
- " ayam paha  dada"
- " sawi sesuai selera"
- " sereh geprek"
- " jahe geprek"
- " lengkuas geprek"
- " daun jeruk"
- " daun salam"
- " saos tiram"
- " kecap manis"
- " gula pasir"
- " garam"
- " Bumbu Halus"
- " bawang merah"
- " bawang putih"
- " cabe rawitkeriting"
- " terasi"
recipeinstructions:
- "Cuci ayam lalu rebus selama 20-30 menit, kemudian suwir atau potong kecil2 (ambil dagingnya aja)"
- "Siapkan semua bahan. Blender/uleg bumbu halus, sampai halus."
- "Tumis bumbu halus dengan minyak panas, kemudian masukkan sereh, jahe, lengkuas, daun salam, dan daun jeruk. Tumis hingga harum."
- "Masukkan ayam, aduk rata. Tambahkan saos tiram, kecap manis, garam, dan gula pasir."
- "Masukkan sawi yang sudah dipotong2, oseng hingga sedikit layu. Koreksi rasa. Matikan api."
categories:
- Resep
tags:
- ayam
- gongso
- sawi

katakunci: ayam gongso sawi 
nutrition: 252 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Gongso Sawi](https://img-global.cpcdn.com/recipes/b133571b7294e128/751x532cq70/ayam-gongso-sawi-foto-resep-utama.jpg)

Bunda Sedang mencari ide resep ayam gongso sawi yang Paling Enak? Cara membuatnya memang susah-susah gampang. misalnya keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal ayam gongso sawi yang enak selayaknya memiliki aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso sawi, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tidak usah pusing jika mau menyiapkan ayam gongso sawi enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.




Berikut ini ada beberapa cara mudah dan praktis dalam mengolah ayam gongso sawi yang siap dikreasikan. Anda dapat membuat Ayam Gongso Sawi menggunakan 16 bahan dan 5 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam Gongso Sawi:

1. Siapkan  ayam (paha &amp; dada)
1. Siapkan  sawi (sesuai selera)
1. Ambil  sereh (geprek)
1. Siapkan  jahe (geprek)
1. Ambil  lengkuas (geprek)
1. Ambil  daun jeruk
1. Gunakan  daun salam
1. Siapkan  saos tiram
1. Ambil  kecap manis
1. Sediakan  gula pasir
1. Ambil  garam
1. Sediakan  Bumbu Halus
1. Gunakan  bawang merah
1. Ambil  bawang putih
1. Sediakan  cabe rawit/keriting
1. Gunakan  terasi




<!--inarticleads2-->

##### Cara membuat Ayam Gongso Sawi:

1. Cuci ayam lalu rebus selama 20-30 menit, kemudian suwir atau potong kecil2 (ambil dagingnya aja)
1. Siapkan semua bahan. Blender/uleg bumbu halus, sampai halus.
1. Tumis bumbu halus dengan minyak panas, kemudian masukkan sereh, jahe, lengkuas, daun salam, dan daun jeruk. Tumis hingga harum.
1. Masukkan ayam, aduk rata. Tambahkan saos tiram, kecap manis, garam, dan gula pasir.
1. Masukkan sawi yang sudah dipotong2, oseng hingga sedikit layu. Koreksi rasa. Matikan api.




Gimana nih? Gampang kan? Itulah cara menyiapkan ayam gongso sawi yang bisa Anda praktikkan di rumah. Selamat mencoba!
