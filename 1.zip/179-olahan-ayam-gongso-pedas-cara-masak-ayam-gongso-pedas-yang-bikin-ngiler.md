---
description: "Olahan Ayam gongso pedas | Cara Masak Ayam gongso pedas Yang Bikin Ngiler"
title: "Olahan Ayam gongso pedas | Cara Masak Ayam gongso pedas Yang Bikin Ngiler"
slug: 179-olahan-ayam-gongso-pedas-cara-masak-ayam-gongso-pedas-yang-bikin-ngiler
date: 2020-09-19T21:54:06.442Z
image: https://img-global.cpcdn.com/recipes/09ddec9ac706dbc0/751x532cq70/ayam-gongso-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/09ddec9ac706dbc0/751x532cq70/ayam-gongso-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/09ddec9ac706dbc0/751x532cq70/ayam-gongso-pedas-foto-resep-utama.jpg
author: Chase Horton
ratingvalue: 4.2
reviewcount: 13
recipeingredient:
- "1/2 kg ayam"
- "10 buah cabe rawit"
- "2 sdm saus tiram"
- "2 sdm kecap manis"
- "1/2 sdt merica bubuk"
- "Secukupnya garam"
- "Secukupnya minyak goreng"
- " Air untuk merebus ayam"
- " Bumbu halus "
- "3 siung bawang putih"
- "3 siung bawang merah"
- "2 buah kemiri"
recipeinstructions:
- "Cuci bersih ayam, beri air sampai ayam terendam, rebus +/- 10 menit, buang busa coklatnya."
- "Ulek semua bumbu halus."
- "Panaskan sedikit minyak goreng, tumis bumbu halus sampai wangi, lalu tambahkan air kaldu merebus ayam tadi."
- "Tambahkan ayam, lalu beri saos tiram, kecap manis, merica, koreksi rasa. Bila kurang asin tambahkan garam secukupnya."
- "Terakhir tambahkan cabe rawit, masak sampai kuah sedikit menyusut."
categories:
- Resep
tags:
- ayam
- gongso
- pedas

katakunci: ayam gongso pedas 
nutrition: 159 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam gongso pedas](https://img-global.cpcdn.com/recipes/09ddec9ac706dbc0/751x532cq70/ayam-gongso-pedas-foto-resep-utama.jpg)

Kamu Sedang mencari inspirasi resep ayam gongso pedas yang Enak Banget? Cara Memasaknya memang susah-susah gampang. andaikan salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal ayam gongso pedas yang enak selayaknya mempunyai aroma dan rasa yang bisa memancing selera kita.

Terinspirasi dari menu babat gongso, kali ini kami memasak ayam gongso. Perjodohan ayam gongso dan es buah memberi kenikmatan tersendiri. MASAKAN serba gongso mempunyai penampilan dan cita rasa khas.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso pedas, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan ayam gongso pedas yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian spesial.


Di bawah ini ada beberapa tips dan trik praktis dalam mengolah ayam gongso pedas yang siap dikreasikan. Anda dapat membuat Ayam gongso pedas menggunakan 12 bahan dan 5 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam gongso pedas:

1. Siapkan 1/2 kg ayam
1. Ambil 10 buah cabe rawit
1. Siapkan 2 sdm saus tiram
1. Gunakan 2 sdm kecap manis
1. Siapkan 1/2 sdt merica bubuk
1. Gunakan Secukupnya garam
1. Ambil Secukupnya minyak goreng
1. Ambil  Air untuk merebus ayam
1. Ambil  Bumbu halus :
1. Siapkan 3 siung bawang putih
1. Ambil 3 siung bawang merah
1. Ambil 2 buah kemiri


Tika dan Firda berkesempatan menjajal gongso pedas babat, gongso pedas ceker, gongso pedas iga, dan gongso pedas ayam. Nah seperti apa review makanan mereka? Nah mau ayam bakar madu yang manis kayak Mister, atau Gongso Ayam pedas sepedas kenyataan hidup? Hahaha becanda ding, nah lets enjoy our life and our day with special menu from Waroeng Abol.. 

<!--inarticleads2-->

##### Cara membuat Ayam gongso pedas:

1. Cuci bersih ayam, beri air sampai ayam terendam, rebus +/- 10 menit, buang busa coklatnya.
1. Ulek semua bumbu halus.
1. Panaskan sedikit minyak goreng, tumis bumbu halus sampai wangi, lalu tambahkan air kaldu merebus ayam tadi.
1. Tambahkan ayam, lalu beri saos tiram, kecap manis, merica, koreksi rasa. Bila kurang asin tambahkan garam secukupnya.
1. Terakhir tambahkan cabe rawit, masak sampai kuah sedikit menyusut.


Penjelasan lengkap seputar Resep Ayam Suwir yang Enak, Lezat, Pedas, Sederhana, Mudah. Dibuat dari Bumbu dan Rempah Pilihan. Indonesia memiliki beragam olahan ayam yang lezat. Setiap daerah memiliki menu ayam Ibu kota Jawa Tengah ini punya sajian bernama ayam gongso. Dalam Bahasa Jawa, gongso berarti ditumis. 

Bagaimana? Gampang kan? Itulah cara membuat ayam gongso pedas yang bisa Anda lakukan di rumah. Selamat mencoba!
