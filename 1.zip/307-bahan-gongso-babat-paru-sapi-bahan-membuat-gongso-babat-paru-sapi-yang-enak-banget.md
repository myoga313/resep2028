---
description: "Bahan Gongso Babat Paru Sapi | Bahan Membuat Gongso Babat Paru Sapi Yang Enak Banget"
title: "Bahan Gongso Babat Paru Sapi | Bahan Membuat Gongso Babat Paru Sapi Yang Enak Banget"
slug: 307-bahan-gongso-babat-paru-sapi-bahan-membuat-gongso-babat-paru-sapi-yang-enak-banget
date: 2020-11-16T20:03:56.682Z
image: https://img-global.cpcdn.com/recipes/d2cbd470a1ee9cf7/751x532cq70/gongso-babat-paru-sapi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d2cbd470a1ee9cf7/751x532cq70/gongso-babat-paru-sapi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d2cbd470a1ee9cf7/751x532cq70/gongso-babat-paru-sapi-foto-resep-utama.jpg
author: Ada Edwards
ratingvalue: 4.7
reviewcount: 10
recipeingredient:
- " Babat Sapi"
- " Paru Sapi"
- " Jahe Geprek"
- " Lengkuas Geprek"
- " Daun Jeruk"
- " Kecap Manis"
- " Garam"
- " Gula Pasir"
- " Penyedap Rasa"
- " Bumbu Halus"
- " Kemiri"
- " Cabe Rawit"
- " Cabe Merah Keriting"
- " bawang Merah"
- " Bawang Putih"
- " Sayuran"
- " Kol optional"
recipeinstructions:
- "Rebus babat dan paru hingga empuk"
- "Tumis bumbu halus, jahe, lengkuas, daun jeruk"
- "Beri sedikit air,kemudian masukkan kol"
- "Jika kol sudah mulai layu, tambahkan kecap manis, garam, gula, penyedap rasa"
- "Koreksi rasa, lalu masukkan babat dan paru"
- "Aduk hingga bumbu tercampur merata dan air menyusut"
- "Angkat dan sajikan"
categories:
- Resep
tags:
- gongso
- babat
- paru

katakunci: gongso babat paru 
nutrition: 197 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Dinner

---


![Gongso Babat Paru Sapi](https://img-global.cpcdn.com/recipes/d2cbd470a1ee9cf7/751x532cq70/gongso-babat-paru-sapi-foto-resep-utama.jpg)

Lagi mencari ide resep gongso babat paru sapi yang Lezat? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. sekiranya salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gongso babat paru sapi yang enak seharusnya punya aroma dan rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso babat paru sapi, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan gongso babat paru sapi yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.


Nah, kali ini kita coba, yuk, kreasikan gongso babat paru sapi sendiri di rumah. Tetap berbahan sederhana, sajian ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa membuat Gongso Babat Paru Sapi memakai 17 jenis bahan dan 7 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Gongso Babat Paru Sapi:

1. Sediakan  Babat Sapi
1. Ambil  Paru Sapi
1. Gunakan  Jahe Geprek
1. Sediakan  Lengkuas Geprek
1. Gunakan  Daun Jeruk
1. Sediakan  Kecap Manis
1. Siapkan  Garam
1. Gunakan  Gula Pasir
1. Sediakan  Penyedap Rasa
1. Ambil  Bumbu Halus
1. Sediakan  Kemiri
1. Siapkan  Cabe Rawit
1. Ambil  Cabe Merah Keriting
1. Sediakan  bawang Merah
1. Ambil  Bawang Putih
1. Ambil  Sayuran
1. Siapkan  Kol (optional)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso Babat Paru Sapi:

1. Rebus babat dan paru hingga empuk
1. Tumis bumbu halus, jahe, lengkuas, daun jeruk
1. Beri sedikit air,kemudian masukkan kol
1. Jika kol sudah mulai layu, tambahkan kecap manis, garam, gula, penyedap rasa
1. Koreksi rasa, lalu masukkan babat dan paru
1. Aduk hingga bumbu tercampur merata dan air menyusut
1. Angkat dan sajikan




Gimana nih? Mudah bukan? Itulah cara membuat gongso babat paru sapi yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
