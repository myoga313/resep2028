---
description: "Resep Ayam Gongso | Cara Mengolah Ayam Gongso Yang Sempurna"
title: "Resep Ayam Gongso | Cara Mengolah Ayam Gongso Yang Sempurna"
slug: 206-resep-ayam-gongso-cara-mengolah-ayam-gongso-yang-sempurna
date: 2020-12-10T21:11:42.417Z
image: https://img-global.cpcdn.com/recipes/9c2acf1de78f9b08/751x532cq70/ayam-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9c2acf1de78f9b08/751x532cq70/ayam-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9c2acf1de78f9b08/751x532cq70/ayam-gongso-foto-resep-utama.jpg
author: Charlotte Dean
ratingvalue: 5
reviewcount: 9
recipeingredient:
- "500 g ayam potong sesuai selera"
- "1/2 buah bawang bombay iris"
- "1 buah tomat merah potong 8"
- "2 lembar daun salam"
- "1 ruas lengkuas memarkan"
- "2 sdm kecap manis"
- "1/2 sdt lada bubuk"
- "Secukupnya garam kaldu bubuk"
- "200 ml air"
- "Secukupnya minyak untuk menumis"
- " Bumbu halus"
- "5 siung bawang putih"
- "3 siung bawang merah"
- "3 butir kemiri"
- "5 buah cabe merah"
- "5 buah cabe rawit"
recipeinstructions:
- "Bersihkan ayam dan potong sesuai selera, didihkan air, rebus ayam selama 5 menit. Tiriskan. Sisihkan."
- "Panaskan minyak tumis bawang bombay sampai layu. masukkan bumbu halus, salam, lengkuas tumis sampai harum"
- "Masukkan ayam, aduk rata. Tuang air, bumbui kecap manis, garam, lada, kaldu bubuk masak sampai bumbu meresap dan kuah menyusut. Koreksi rasa. Masukkan tomat sesaat sebelum diangkat."
- "Siap disajikan. Selamat mencoba."
categories:
- Resep
tags:
- ayam
- gongso

katakunci: ayam gongso 
nutrition: 215 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Gongso](https://img-global.cpcdn.com/recipes/9c2acf1de78f9b08/751x532cq70/ayam-gongso-foto-resep-utama.jpg)

Lagi mencari inspirasi resep ayam gongso yang Enak Dan Lezat? Cara Memasaknya memang tidak terlalu sulit namun tidak gampang juga. seumpama keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal ayam gongso yang enak seharusnya memiliki aroma dan rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam gongso, mulai dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan ayam gongso enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian spesial.


Nah, kali ini kita coba, yuk, kreasikan ayam gongso sendiri di rumah. Tetap dengan bahan sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa membuat Ayam Gongso memakai 16 bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Gongso:

1. Siapkan 500 g ayam, potong sesuai selera
1. Gunakan 1/2 buah bawang bombay, iris
1. Siapkan 1 buah tomat merah, potong 8
1. Gunakan 2 lembar daun salam
1. Ambil 1 ruas lengkuas, memarkan
1. Siapkan 2 sdm kecap manis
1. Siapkan 1/2 sdt lada bubuk
1. Sediakan Secukupnya garam, kaldu bubuk
1. Sediakan 200 ml air
1. Gunakan Secukupnya minyak untuk menumis
1. Siapkan  Bumbu halus:
1. Siapkan 5 siung bawang putih
1. Siapkan 3 siung bawang merah
1. Siapkan 3 butir kemiri
1. Siapkan 5 buah cabe merah
1. Ambil 5 buah cabe rawit




<!--inarticleads2-->

##### Cara membuat Ayam Gongso:

1. Bersihkan ayam dan potong sesuai selera, didihkan air, rebus ayam selama 5 menit. Tiriskan. Sisihkan.
1. Panaskan minyak tumis bawang bombay sampai layu. masukkan bumbu halus, salam, lengkuas tumis sampai harum
1. Masukkan ayam, aduk rata. Tuang air, bumbui kecap manis, garam, lada, kaldu bubuk masak sampai bumbu meresap dan kuah menyusut. Koreksi rasa. Masukkan tomat sesaat sebelum diangkat.
1. Siap disajikan. Selamat mencoba.




Gimana nih? Mudah bukan? Itulah cara menyiapkan ayam gongso yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
