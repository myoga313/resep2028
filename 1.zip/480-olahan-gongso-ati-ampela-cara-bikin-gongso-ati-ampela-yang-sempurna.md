---
description: "Olahan Gongso ati ampela | Cara Bikin Gongso ati ampela Yang Sempurna"
title: "Olahan Gongso ati ampela | Cara Bikin Gongso ati ampela Yang Sempurna"
slug: 480-olahan-gongso-ati-ampela-cara-bikin-gongso-ati-ampela-yang-sempurna
date: 2020-08-30T13:26:33.598Z
image: https://img-global.cpcdn.com/recipes/f129450ce067d03e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f129450ce067d03e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f129450ce067d03e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg
author: Isabelle Patrick
ratingvalue: 4.6
reviewcount: 14
recipeingredient:
- "10 pasang ati ampela"
- " Bumbu rebusan "
- "2 lembar Daun salam"
- "3 Lembar Daun jeruk"
- "1 batang serai"
- "2 ruas jari jahe"
- "2 ruas jari Lengkuas"
- "1 St ketumbar bubuk"
- " Blender"
- "5 Butir bawang merah"
- "4 Butir bawang putih"
- "5 biji Cabe merah keriting"
- "20 biji rawit selera"
- "1 St Kunyit giling"
- " Bumbu lainnya "
- "4 butir Bawang merah"
- "3 SM Kecap manis"
- "100 gr air"
- "secukupnya Garam dan totole"
- "secukupnya Minyak"
- " Pelengkap "
- " Bawang goreng"
recipeinstructions:
- "Geprek jahe, Lengkuas dan serai, satukan dengan daun salam dan daun jeruk, lalu masukkan kedalam ati ampela yang sudah dibersihkan, rebus angkat dan potong&#34;, sisihkan"
- "Iris&#34; bawang merah, blender bumbu halus, siapkan bumbu lainnya"
- "Goreng bawang merah hingga harum, kemudian masukkan ati ampela, goreng hingga agak kering, angkat tiriskan"
- "Tumis bumbu halus hingga wangi, bubuhi garam dan totole, beri air biarkan mendidih dan bumbu agak kental"
- "Masukkan ati - ampela, tambahkan kecap manis, aduk&#34; tes rasa jika sudah pas matikan kompor"
- "Tuang ke atas piring, taburi dgn bawang merah goreng. Hidangkan"
categories:
- Resep
tags:
- gongso
- ati
- ampela

katakunci: gongso ati ampela 
nutrition: 219 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dinner

---


![Gongso ati ampela](https://img-global.cpcdn.com/recipes/f129450ce067d03e/751x532cq70/gongso-ati-ampela-foto-resep-utama.jpg)

Bunda lagi mencari inspirasi resep gongso ati ampela yang Enak Dan Mudah? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. sekiranya salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gongso ati ampela yang enak seharusnya mempunyai aroma dan rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ati ampela, mulai dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tidak usah pusing kalau ingin menyiapkan gongso ati ampela enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan spesial.




Berikut ini ada beberapa cara mudah dan praktis dalam mengolah gongso ati ampela yang siap dikreasikan. Anda dapat membuat Gongso ati ampela menggunakan 22 bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Gongso ati ampela:

1. Ambil 10 pasang ati ampela
1. Siapkan  Bumbu rebusan :
1. Gunakan 2 lembar Daun salam
1. Siapkan 3 Lembar Daun jeruk
1. Gunakan 1 batang serai
1. Gunakan 2 ruas jari jahe
1. Ambil 2 ruas jari Lengkuas
1. Gunakan 1 St ketumbar bubuk
1. Siapkan  Blender
1. Gunakan 5 Butir bawang merah
1. Gunakan 4 Butir bawang putih
1. Ambil 5 biji Cabe merah keriting
1. Ambil 20 biji rawit (selera)
1. Siapkan 1 St Kunyit giling
1. Sediakan  Bumbu lainnya :
1. Ambil 4 butir Bawang merah
1. Sediakan 3 SM Kecap manis
1. Siapkan 100 gr air
1. Ambil secukupnya Garam dan totole
1. Gunakan secukupnya Minyak
1. Sediakan  Pelengkap :
1. Ambil  Bawang goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Gongso ati ampela:

1. Geprek jahe, Lengkuas dan serai, satukan dengan daun salam dan daun jeruk, lalu masukkan kedalam ati ampela yang sudah dibersihkan, rebus angkat dan potong&#34;, sisihkan
1. Iris&#34; bawang merah, blender bumbu halus, siapkan bumbu lainnya
1. Goreng bawang merah hingga harum, kemudian masukkan ati ampela, goreng hingga agak kering, angkat tiriskan
1. Tumis bumbu halus hingga wangi, bubuhi garam dan totole, beri air biarkan mendidih dan bumbu agak kental
1. Masukkan ati - ampela, tambahkan kecap manis, aduk&#34; tes rasa jika sudah pas matikan kompor
1. Tuang ke atas piring, taburi dgn bawang merah goreng. Hidangkan




Gimana nih? Gampang kan? Itulah cara menyiapkan gongso ati ampela yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
