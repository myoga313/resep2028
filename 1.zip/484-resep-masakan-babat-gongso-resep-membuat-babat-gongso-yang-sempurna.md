---
description: "Resep masakan Babat Gongso | Resep Membuat Babat Gongso Yang Sempurna"
title: "Resep masakan Babat Gongso | Resep Membuat Babat Gongso Yang Sempurna"
slug: 484-resep-masakan-babat-gongso-resep-membuat-babat-gongso-yang-sempurna
date: 2020-09-11T19:18:48.548Z
image: https://img-global.cpcdn.com/recipes/cbef112b9bfaf665/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cbef112b9bfaf665/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cbef112b9bfaf665/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Ian Weber
ratingvalue: 3
reviewcount: 15
recipeingredient:
- " babat"
- " Utk merebus babat "
- " daun salam"
- " daun jeruk disobek sobek"
- " bawang merah iris kasar"
- " cabe rawit utuh"
- " Bumbu halus "
- " cabe kriting"
- " bawang merah"
- " bawang putih"
- " kemiri sangrai"
- " Kecap"
- " Daun salam  daun jeruk"
- " Garam gula pasir penyedap"
recipeinstructions:
- "Cuci babat sampai benar2 bersih &amp; Rebus babat utk menghilangkan lemak &amp; kotoran. Cuci kembali, rebus lagi dg daun salam &amp; daun jeruk menggunakan presto. Tiriskan kemudian potong2."
- "Iris bawang merah, lalu tumis sampai harum. Masukan bumbu halus &amp; daun salam &amp; daun jeruk. Tunggu sampai harum."
- "Setelah bumbu masak, masukan babat yg sudah dipotong potong, aduk rata, masukan cabai rawit, kecap manis, gula, garam &amp; penyedap. Aduk rata jangan lupa koreksi rasanya, tunggu sampai air menyusut. Siap dihidangkan dg nasi panas."
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 251 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dessert

---


![Babat Gongso](https://img-global.cpcdn.com/recipes/cbef112b9bfaf665/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep babat gongso yang Lezat? Cara Memasaknya memang susah-susah gampang. misalnya keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal babat gongso yang enak selayaknya mempunyai aroma dan rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso, pertama dari jenis bahan, lalu pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tidak usah pusing kalau ingin menyiapkan babat gongso yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian istimewa.

Com - Babat Gongso kali ini special karena ada isonya. Babat Gongso yang menjadi tujuan kuliner setiap orang yang ke Semarang, merupakan setidaknya primadona dari sekian banyak makanan yang ada di Semarang. Yuk, belajar membuat Babat Gongso di rumah Anda!


Di bawah ini ada beberapa tips dan trik praktis dalam mengolah babat gongso yang siap dikreasikan. Anda dapat membuat Babat Gongso memakai 14 bahan dan 3 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Babat Gongso:

1. Siapkan  babat
1. Siapkan  Utk merebus babat :
1. Ambil  daun salam
1. Siapkan  daun jeruk disobek sobek
1. Ambil  bawang merah, iris kasar
1. Gunakan  cabe rawit utuh
1. Sediakan  Bumbu halus :
1. Siapkan  cabe kriting
1. Ambil  bawang merah
1. Gunakan  bawang putih
1. Gunakan  kemiri sangrai
1. Ambil  Kecap
1. Sediakan  Daun salam &amp; daun jeruk
1. Sediakan  Garam, gula pasir, penyedap




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Babat Gongso:

1. Cuci babat sampai benar2 bersih &amp; Rebus babat utk menghilangkan lemak &amp; kotoran. Cuci kembali, rebus lagi dg daun salam &amp; daun jeruk menggunakan presto. Tiriskan kemudian potong2.
1. Iris bawang merah, lalu tumis sampai harum. Masukan bumbu halus &amp; daun salam &amp; daun jeruk. Tunggu sampai harum.
1. Setelah bumbu masak, masukan babat yg sudah dipotong potong, aduk rata, masukan cabai rawit, kecap manis, gula, garam &amp; penyedap. Aduk rata jangan lupa koreksi rasanya, tunggu sampai air menyusut. Siap dihidangkan dg nasi panas.




Gimana nih? Mudah bukan? Itulah cara menyiapkan babat gongso yang bisa Anda lakukan di rumah. Selamat mencoba!
