---
description: "Resep masakan Sop gongso | Resep Bumbu Sop gongso Yang Sempurna"
title: "Resep masakan Sop gongso | Resep Bumbu Sop gongso Yang Sempurna"
slug: 66-resep-masakan-sop-gongso-resep-bumbu-sop-gongso-yang-sempurna
date: 2021-01-11T14:28:35.666Z
image: https://img-global.cpcdn.com/recipes/eba41d85f2e9de29/751x532cq70/sop-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/eba41d85f2e9de29/751x532cq70/sop-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/eba41d85f2e9de29/751x532cq70/sop-gongso-foto-resep-utama.jpg
author: Gregory Fuller
ratingvalue: 5
reviewcount: 9
recipeingredient:
- "1/2 kubis diiris iris"
- "2 buah wortel iris tipis"
- "2 daun bawang iris besar"
- "2 seledri iris besar"
- "2 Bakso belah jadi 2"
- " Makaroni seplastik kecil"
- "secukupnya Air"
- " Bumbu halus"
- "6 Bawang putih"
- "1 sdt Merica"
- " Garam"
- " Bumbu pelengkap"
- " Royco"
- "secukupnya Gula"
recipeinstructions:
- "Didihkan air dipanci serta masukan makaroni dan bakso"
- "Gongso bumbu yang sudah dihaluskan sampai terciun wangi dan dengan api kecil setelah wangi masukkan ke panci yg berisi tersebut"
- "Kemudian cuci bersih kubis dan wortel kemudian gongso di bekas menggongso bumbu tadi sampai layu"
- "Setelah layu dan air mendidih baru dimasukkan sayurnya"
- "Kemudian masukan royco dan gula sedikit dan icip rasa kalau kurang pas bisa ditambahi garam sesuai selera"
- "Setelah dirasa pas baru dimasukan seledri dan daun bawang yang sebelumnya sudah dicuci"
- "Setelah itu baru dimatikan api dan siap disajikan dalam mangkok"
- "Selamat menikmati"
- "Catatan; sebaiknya bawang putih yang banyak agar masakan terasa enak"
categories:
- Resep
tags:
- sop
- gongso

katakunci: sop gongso 
nutrition: 135 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Lunch

---


![Sop gongso](https://img-global.cpcdn.com/recipes/eba41d85f2e9de29/751x532cq70/sop-gongso-foto-resep-utama.jpg)

Kamu Sedang mencari inspirasi resep sop gongso yang Bikin Ngiler? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. seumpama keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal sop gongso yang enak selayaknya punya aroma dan rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari sop gongso, mulai dari jenis bahan, kedua pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan sop gongso yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian spesial.


Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah sop gongso yang siap dikreasikan. Anda dapat menyiapkan Sop gongso menggunakan 14 bahan dan 9 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Sop gongso:

1. Gunakan 1/2 kubis diiris iris
1. Ambil 2 buah wortel iris tipis
1. Ambil 2 daun bawang iris besar
1. Ambil 2 seledri iris besar
1. Sediakan 2 Bakso belah jadi 2
1. Gunakan  Makaroni seplastik kecil
1. Siapkan secukupnya Air
1. Ambil  Bumbu halus
1. Ambil 6 Bawang putih
1. Siapkan 1 sdt Merica
1. Siapkan  Garam
1. Ambil  Bumbu pelengkap
1. Siapkan  Royco
1. Sediakan secukupnya Gula




<!--inarticleads2-->

##### Cara menyiapkan Sop gongso:

1. Didihkan air dipanci serta masukan makaroni dan bakso
1. Gongso bumbu yang sudah dihaluskan sampai terciun wangi dan dengan api kecil setelah wangi masukkan ke panci yg berisi tersebut
1. Kemudian cuci bersih kubis dan wortel kemudian gongso di bekas menggongso bumbu tadi sampai layu
1. Setelah layu dan air mendidih baru dimasukkan sayurnya
1. Kemudian masukan royco dan gula sedikit dan icip rasa kalau kurang pas bisa ditambahi garam sesuai selera
1. Setelah dirasa pas baru dimasukan seledri dan daun bawang yang sebelumnya sudah dicuci
1. Setelah itu baru dimatikan api dan siap disajikan dalam mangkok
1. Selamat menikmati
1. Catatan; sebaiknya bawang putih yang banyak agar masakan terasa enak




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Harapan kami, olahan Sop gongso yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman maupun menjadi inspirasi dalam berjualan makanan. Selamat mencoba!
