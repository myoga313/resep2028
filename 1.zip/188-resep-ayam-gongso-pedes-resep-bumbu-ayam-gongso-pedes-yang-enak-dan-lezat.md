---
description: "Resep Ayam Gongso Pedes | Resep Bumbu Ayam Gongso Pedes Yang Enak Dan Lezat"
title: "Resep Ayam Gongso Pedes | Resep Bumbu Ayam Gongso Pedes Yang Enak Dan Lezat"
slug: 188-resep-ayam-gongso-pedes-resep-bumbu-ayam-gongso-pedes-yang-enak-dan-lezat
date: 2020-10-14T08:50:35.743Z
image: https://img-global.cpcdn.com/recipes/625a92b74826d4ad/751x532cq70/ayam-gongso-pedes-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/625a92b74826d4ad/751x532cq70/ayam-gongso-pedes-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/625a92b74826d4ad/751x532cq70/ayam-gongso-pedes-foto-resep-utama.jpg
author: Pearl Fowler
ratingvalue: 4.9
reviewcount: 8
recipeingredient:
- "500gr Ayam fillet  potong sesuai selera"
- "1 buah Kemiri  haluskan"
- "2 siung Bawang merah  haluskan"
- "2 siung Bawang putih  haluskan"
- " Cabe iris kalau suka pedes blh pake banyak"
- "1 buah Tomat  potong2"
- " Garam gula lada kaldu jamur"
- "1 sdm Minyak tumis"
- "150-200 ml Air"
- "2 sdm Kecap manis"
- "2 sdm Saus tiram"
- "1 buah Jeruk nipis"
recipeinstructions:
- "Potong2 ayam, kasih garam, kaldu jamur, lada, perasan jeruk nipis. aduk2, diamkan"
- "Haluskan bawang putih, bawang merah, dan kemiri"
- "Tumis bahan no 2 pake minyak 1sdm"
- "Masukan ayam oseng2 dulu bentar, masukin saos tiram, kecap manis aduk2 sampai rata"
- "Masukan air, diemin sampe ayam matang dan air mulai meresap. Blh ksh bumbu2 lg sesuai selera (jgn banyak2 krn td ayam mentahnya sdh di bumbui)"
- "Masukkan tomat dan cabe, aduk2 sampai tomat layu dan menyatu semua"
- "Cicipi rasa"
- "Siap dihidangkan ❤️"
categories:
- Resep
tags:
- ayam
- gongso
- pedes

katakunci: ayam gongso pedes 
nutrition: 180 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Gongso Pedes](https://img-global.cpcdn.com/recipes/625a92b74826d4ad/751x532cq70/ayam-gongso-pedes-foto-resep-utama.jpg)

Kamu Lagi mencari ide resep ayam gongso pedes yang Lezat? Cara Memasaknya memang tidak susah dan tidak juga mudah. jikalau salah mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal ayam gongso pedes yang enak selayaknya memiliki aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam gongso pedes, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan ayam gongso pedes enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.




Nah, kali ini kita coba, yuk, kreasikan ayam gongso pedes sendiri di rumah. Tetap berbahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Ayam Gongso Pedes memakai 12 bahan dan 8 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam Gongso Pedes:

1. Gunakan 500gr Ayam fillet  potong sesuai selera
1. Ambil 1 buah Kemiri  haluskan
1. Gunakan 2 siung Bawang merah  haluskan
1. Siapkan 2 siung Bawang putih  haluskan
1. Sediakan  Cabe iris (kalau suka pedes blh pake banyak)
1. Sediakan 1 buah Tomat  potong2
1. Sediakan  Garam, gula, lada, kaldu jamur
1. Siapkan 1 sdm Minyak tumis
1. Sediakan 150-200 ml Air
1. Gunakan 2 sdm Kecap manis
1. Sediakan 2 sdm Saus tiram
1. Siapkan 1 buah Jeruk nipis




<!--inarticleads2-->

##### Cara menyiapkan Ayam Gongso Pedes:

1. Potong2 ayam, kasih garam, kaldu jamur, lada, perasan jeruk nipis. aduk2, diamkan
1. Haluskan bawang putih, bawang merah, dan kemiri
1. Tumis bahan no 2 pake minyak 1sdm
1. Masukan ayam oseng2 dulu bentar, masukin saos tiram, kecap manis aduk2 sampai rata
1. Masukan air, diemin sampe ayam matang dan air mulai meresap. Blh ksh bumbu2 lg sesuai selera (jgn banyak2 krn td ayam mentahnya sdh di bumbui)
1. Masukkan tomat dan cabe, aduk2 sampai tomat layu dan menyatu semua
1. Cicipi rasa
1. Siap dihidangkan ❤️




Bagaimana? Gampang kan? Itulah cara membuat ayam gongso pedes yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
