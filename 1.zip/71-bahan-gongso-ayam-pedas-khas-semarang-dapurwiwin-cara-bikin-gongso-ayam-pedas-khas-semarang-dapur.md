---
description: "Bahan Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳 | Cara Bikin Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳 Yang Bikin Ngiler"
title: "Bahan Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳 | Cara Bikin Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳 Yang Bikin Ngiler"
slug: 71-bahan-gongso-ayam-pedas-khas-semarang-dapurwiwin-cara-bikin-gongso-ayam-pedas-khas-semarang-dapurwiwin-yang-bikin-ngiler
date: 2020-09-14T18:12:08.117Z
image: https://img-global.cpcdn.com/recipes/805edecca99c9ca2/751x532cq70/gongso-ayam-pedas-khas-semarang-dapurwiwin-👩🏻🍳-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/805edecca99c9ca2/751x532cq70/gongso-ayam-pedas-khas-semarang-dapurwiwin-👩🏻🍳-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/805edecca99c9ca2/751x532cq70/gongso-ayam-pedas-khas-semarang-dapurwiwin-👩🏻🍳-foto-resep-utama.jpg
author: Maurice Henry
ratingvalue: 3.1
reviewcount: 14
recipeingredient:
- " Bahan"
- "1 ekor ayam kampung suwirsuwir"
- "5 Buah Cabe Rawit Setan"
- "sesuai selera Kobis"
- "1/2 Buah Tomat"
- "1/2 Bawang Bombay"
- " Daun BawangLoncang"
- "1 ruas lengkuas"
- "secukupnya Kecap Manis"
- "secukupnya Gula Garam"
- "secukupnya Air"
- " Bahan Bumbu Halus"
- "5 Siung Bawang Merah"
- "2 Siung Bawang Putih"
- "3 Buah Cabe Merah"
- "3 Butir Kemiri"
recipeinstructions:
- "Siapkan bahan."
- "Uleg bumbu halus."
- "Suwir-suwir ayam sesuai selera, geprek lengkuas, cincang bombay, iris-iris (kobis, daun bawang, cabe merah, tomat)."
- "Tumis bombay cincang + bumbu halus hingga harum, masukkan ayam suwir, tambahkan air, kemudian kobis, daun bawang, tomat dan cabe rawit utuh."
- "Aduk-aduk sebentar tunggu hingga airnya meresap biar mantap, kemudian hidangkan."
categories:
- Resep
tags:
- gongso
- ayam
- pedas

katakunci: gongso ayam pedas 
nutrition: 210 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dinner

---


![Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳](https://img-global.cpcdn.com/recipes/805edecca99c9ca2/751x532cq70/gongso-ayam-pedas-khas-semarang-dapurwiwin-👩🏻🍳-foto-resep-utama.jpg)

Bunda Sedang mencari ide resep gongso ayam pedas khas semarang #dapurwiwin 👩🏻‍🍳 yang Menggugah Selera? Cara menyiapkannya memang tidak susah dan tidak juga mudah. seandainya salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso ayam pedas khas semarang #dapurwiwin 👩🏻‍🍳 yang enak seharusnya mempunyai aroma dan cita rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ayam pedas khas semarang #dapurwiwin 👩🏻‍🍳, mulai dari jenis bahan, kedua pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tidak usah pusing jika hendak menyiapkan gongso ayam pedas khas semarang #dapurwiwin 👩🏻‍🍳 enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.


Berikut ini ada beberapa cara mudah dan praktis untuk membuat gongso ayam pedas khas semarang #dapurwiwin 👩🏻‍🍳 yang siap dikreasikan. Anda bisa membuat Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳 menggunakan 16 jenis bahan dan 5 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳:

1. Siapkan  Bahan
1. Sediakan 1 ekor ayam kampung (suwir-suwir)
1. Siapkan 5 Buah Cabe Rawit Setan
1. Siapkan sesuai selera Kobis
1. Gunakan 1/2 Buah Tomat
1. Sediakan 1/2 Bawang Bombay
1. Sediakan  Daun Bawang/Loncang
1. Gunakan 1 ruas lengkuas
1. Ambil secukupnya Kecap Manis
1. Siapkan secukupnya Gula Garam
1. Sediakan secukupnya Air
1. Sediakan  Bahan Bumbu Halus
1. Siapkan 5 Siung Bawang Merah
1. Gunakan 2 Siung Bawang Putih
1. Ambil 3 Buah Cabe Merah
1. Siapkan 3 Butir Kemiri




<!--inarticleads2-->

##### Cara membuat Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳:

1. Siapkan bahan.
1. Uleg bumbu halus.
1. Suwir-suwir ayam sesuai selera, geprek lengkuas, cincang bombay, iris-iris (kobis, daun bawang, cabe merah, tomat).
1. Tumis bombay cincang + bumbu halus hingga harum, masukkan ayam suwir, tambahkan air, kemudian kobis, daun bawang, tomat dan cabe rawit utuh.
1. Aduk-aduk sebentar tunggu hingga airnya meresap biar mantap, kemudian hidangkan.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Gongso Ayam Pedas khas Semarang #dapurwiwin 👩🏻‍🍳">



Bagaimana? Gampang kan? Itulah cara menyiapkan gongso ayam pedas khas semarang #dapurwiwin 👩🏻‍🍳 yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
