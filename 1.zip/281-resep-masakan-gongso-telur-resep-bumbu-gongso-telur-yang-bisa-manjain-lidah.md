---
description: "Resep masakan Gongso Telur | Resep Bumbu Gongso Telur Yang Bisa Manjain Lidah"
title: "Resep masakan Gongso Telur | Resep Bumbu Gongso Telur Yang Bisa Manjain Lidah"
slug: 281-resep-masakan-gongso-telur-resep-bumbu-gongso-telur-yang-bisa-manjain-lidah
date: 2020-11-28T06:36:51.539Z
image: https://img-global.cpcdn.com/recipes/b3cc9057dcdc6e04/751x532cq70/gongso-telur-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b3cc9057dcdc6e04/751x532cq70/gongso-telur-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b3cc9057dcdc6e04/751x532cq70/gongso-telur-foto-resep-utama.jpg
author: Loretta Logan
ratingvalue: 4.5
reviewcount: 8
recipeingredient:
- "1 btr telur ayam"
- "1 bh tomat merah potong dadu"
- "1/2 mangkok irisan kol"
- "1 tangkai daun bawang iris kasar"
- "2 sdm minyak sayur"
- "1 sdm kecap manis"
- "1 sdm saus sambal"
- "100 ml air"
- "1 sdt gula merah"
- "secukupnya merica bubuk"
- "secukupnya garam"
- "secukupnya kaldu jamur"
- " Bumbu halus"
- "1 siung bawang putih"
- "2 siung bawang merah"
- "1/2 butir kemiri"
- "3 buah cabe merah atau sesuai selera"
recipeinstructions:
- "Panaskan wajan lalu buat telur orak arik. sisihkan."
- "Panaskan minyak dalam wajan, tumis bumbu halus sampai harum atau berwarna agak kecoklatan."
- "Tambahkan saus dan kecap, aduk rata dan panaskan sebentar."
- "Masukkan air, aduk rata dan masak sampai meletup-letup dan sedikit mengental."
- "Kemudian tambahkan telur, tomat, kol, dan daun bawang. Aduk rata."
- "Masak hingga bumbu meresap atau hingga kol dan tomat layu."
- "Sajikan selagi hangat."
categories:
- Resep
tags:
- gongso
- telur

katakunci: gongso telur 
nutrition: 270 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Dessert

---


![Gongso Telur](https://img-global.cpcdn.com/recipes/b3cc9057dcdc6e04/751x532cq70/gongso-telur-foto-resep-utama.jpg)

Bunda Sedang mencari inspirasi resep gongso telur yang Enak Banget? Cara menyiapkannya memang tidak susah dan tidak juga mudah. andaikata keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal gongso telur yang enak harusnya sih mempunyai aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso telur, mulai dari jenis bahan, lalu pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tak perlu pusing jika mau menyiapkan gongso telur enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan spesial.




Di bawah ini ada beberapa tips dan trik praktis dalam mengolah gongso telur yang siap dikreasikan. Anda bisa membuat Gongso Telur menggunakan 17 bahan dan 7 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Gongso Telur:

1. Gunakan 1 btr telur ayam
1. Siapkan 1 bh tomat merah, potong dadu
1. Gunakan 1/2 mangkok irisan kol
1. Sediakan 1 tangkai daun bawang, iris kasar
1. Sediakan 2 sdm minyak sayur
1. Sediakan 1 sdm kecap manis
1. Sediakan 1 sdm saus sambal
1. Sediakan 100 ml air
1. Siapkan 1 sdt gula merah
1. Sediakan secukupnya merica bubuk
1. Gunakan secukupnya garam
1. Siapkan secukupnya kaldu jamur
1. Sediakan  Bumbu halus
1. Gunakan 1 siung bawang putih
1. Ambil 2 siung bawang merah
1. Gunakan 1/2 butir kemiri
1. Sediakan 3 buah cabe merah atau sesuai selera




<!--inarticleads2-->

##### Cara membuat Gongso Telur:

1. Panaskan wajan lalu buat telur orak arik. sisihkan.
1. Panaskan minyak dalam wajan, tumis bumbu halus sampai harum atau berwarna agak kecoklatan.
1. Tambahkan saus dan kecap, aduk rata dan panaskan sebentar.
1. Masukkan air, aduk rata dan masak sampai meletup-letup dan sedikit mengental.
1. Kemudian tambahkan telur, tomat, kol, dan daun bawang. Aduk rata.
1. Masak hingga bumbu meresap atau hingga kol dan tomat layu.
1. Sajikan selagi hangat.




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Besar harapan kami, olahan Gongso Telur yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman maupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
