---
description: "Resep Babat Gongso | Cara Buat Babat Gongso Yang Enak Banget"
title: "Resep Babat Gongso | Cara Buat Babat Gongso Yang Enak Banget"
slug: 327-resep-babat-gongso-cara-buat-babat-gongso-yang-enak-banget
date: 2020-11-09T16:53:23.811Z
image: https://img-global.cpcdn.com/recipes/4651c7d27a7911bc/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4651c7d27a7911bc/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4651c7d27a7911bc/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Gordon Floyd
ratingvalue: 3.3
reviewcount: 13
recipeingredient:
- " babat potong kecil saya ditambah tetelan 250 gram"
- " gula merah 30 gram iris"
- " tomat"
- " cabai rawit merah"
- " kecap manis"
- " Bumbu Halus"
- " bawang merah"
- " bawang putih"
- " kemiri sangrai"
- " cabai keriting merah"
- " ketumbar sangrai"
- " Bumbu Utuh"
- " sereh"
- " daun salam"
- " daun jeruk"
- " lengkuas geprek"
recipeinstructions:
- "Blansir babat dan tetelan. Presto selama 30 menit hingga empuk. Sisihkan."
- "Haluskan bumbu. Tumis hingga wangi bersama bumbu utuh."
- "Masukkan babat, gula merah, kecap, garam, dan gula. Tambahkan air."
- "Masak hingga air menyusut dan bumbu meresap. Masukkan cabai rawit utuh dan irisan tomat."
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 128 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Lunch

---


![Babat Gongso](https://img-global.cpcdn.com/recipes/4651c7d27a7911bc/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Kamu Sedang mencari inspirasi resep babat gongso yang Bikin Ngiler? Cara membuatnya memang susah-susah gampang. jikalau keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal babat gongso yang enak harusnya sih mempunyai aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tidak usah pusing kalau hendak menyiapkan babat gongso yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan istimewa.

Com - Babat Gongso kali ini special karena ada isonya. Babat Gongso yang menjadi tujuan kuliner setiap orang yang ke Semarang, merupakan setidaknya primadona dari sekian banyak makanan yang ada di Semarang. Yuk, belajar membuat Babat Gongso di rumah Anda!


Berikut ini ada beberapa cara mudah dan praktis untuk membuat babat gongso yang siap dikreasikan. Anda dapat menyiapkan Babat Gongso memakai 16 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Babat Gongso:

1. Siapkan  babat potong kecil (saya ditambah tetelan 250 gram)
1. Siapkan  gula merah (30 gram) iris
1. Sediakan  tomat
1. Sediakan  cabai rawit merah
1. Gunakan  kecap manis
1. Gunakan  Bumbu Halus
1. Gunakan  bawang merah
1. Siapkan  bawang putih
1. Ambil  kemiri sangrai
1. Sediakan  cabai keriting merah
1. Sediakan  ketumbar sangrai
1. Gunakan  Bumbu Utuh
1. Sediakan  sereh
1. Ambil  daun salam
1. Gunakan  daun jeruk
1. Siapkan  lengkuas geprek




<!--inarticleads2-->

##### Cara menyiapkan Babat Gongso:

1. Blansir babat dan tetelan. Presto selama 30 menit hingga empuk. Sisihkan.
1. Haluskan bumbu. Tumis hingga wangi bersama bumbu utuh.
1. Masukkan babat, gula merah, kecap, garam, dan gula. Tambahkan air.
1. Masak hingga air menyusut dan bumbu meresap. Masukkan cabai rawit utuh dan irisan tomat.




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Babat Gongso yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman ataupun menjadi inspirasi bagi Anda yang berkeinginan untuk berjualan makanan. Selamat mencoba!
