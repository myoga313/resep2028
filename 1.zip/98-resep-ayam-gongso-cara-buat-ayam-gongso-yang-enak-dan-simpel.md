---
description: "Resep Ayam Gongso | Cara Buat Ayam Gongso Yang Enak dan Simpel"
title: "Resep Ayam Gongso | Cara Buat Ayam Gongso Yang Enak dan Simpel"
slug: 98-resep-ayam-gongso-cara-buat-ayam-gongso-yang-enak-dan-simpel
date: 2021-01-06T02:57:11.120Z
image: https://img-global.cpcdn.com/recipes/6abd680c11ee0b62/751x532cq70/ayam-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6abd680c11ee0b62/751x532cq70/ayam-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6abd680c11ee0b62/751x532cq70/ayam-gongso-foto-resep-utama.jpg
author: Bettie Delgado
ratingvalue: 3
reviewcount: 6
recipeingredient:
- "1/2 ekor Ayam sedang cuci bersih"
- "3 siung Bawang merah"
- "2 siung Bawang putih"
- "1/2 siung Bawang bombay"
- "7 biji Cabe rawit"
- "2 sdm Kecap manis"
- "2 sdm Saos Tiram"
- "1/3 sdt Himalaya salt"
- "1/3 sdt Lada bubuk"
- "1/2 sdt Kaldu bubuk"
- " Air untuk merebus"
recipeinstructions:
- "Potong ayah agak kecil, lalu didihkan air dan rebus hingga ayam matang. Sisihkan jangan dibuang air rebusannya"
- "Iris trio bawang dan cabe, aslinya dihaluskan ya bamer, baput n cabe nya. Lalu tumis dengan minyak hingga wangi"
- "Masukkan air rebusan, kecap, saos tiram, garam, lada, kaldu bubuk. Masak hingga mendidih"
- "Masukkan ayam, masak hingga kuah meresap ke daging ayam"
- "Angkat dan sajikan, nikmat dengan sebakul nasi"
categories:
- Resep
tags:
- ayam
- gongso

katakunci: ayam gongso 
nutrition: 260 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT59M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Gongso](https://img-global.cpcdn.com/recipes/6abd680c11ee0b62/751x532cq70/ayam-gongso-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep ayam gongso yang Enak Dan Mudah? Cara Buatnya memang tidak susah dan tidak juga mudah. bila salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal ayam gongso yang enak selayaknya punya aroma dan cita rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam gongso, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tak perlu pusing kalau mau menyiapkan ayam gongso enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan istimewa.


Di bawah ini ada beberapa cara mudah dan praktis untuk membuat ayam gongso yang siap dikreasikan. Anda bisa membuat Ayam Gongso memakai 11 jenis bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Gongso:

1. Sediakan 1/2 ekor Ayam sedang, cuci bersih
1. Sediakan 3 siung Bawang merah
1. Gunakan 2 siung Bawang putih
1. Gunakan 1/2 siung Bawang bombay
1. Gunakan 7 biji Cabe rawit
1. Siapkan 2 sdm Kecap manis
1. Sediakan 2 sdm Saos Tiram
1. Ambil 1/3 sdt Himalaya salt
1. Ambil 1/3 sdt Lada bubuk
1. Siapkan 1/2 sdt Kaldu bubuk
1. Ambil  Air untuk merebus




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Gongso:

1. Potong ayah agak kecil, lalu didihkan air dan rebus hingga ayam matang. Sisihkan jangan dibuang air rebusannya
1. Iris trio bawang dan cabe, aslinya dihaluskan ya bamer, baput n cabe nya. Lalu tumis dengan minyak hingga wangi
1. Masukkan air rebusan, kecap, saos tiram, garam, lada, kaldu bubuk. Masak hingga mendidih
1. Masukkan ayam, masak hingga kuah meresap ke daging ayam
1. Angkat dan sajikan, nikmat dengan sebakul nasi




Bagaimana? Gampang kan? Itulah cara membuat ayam gongso yang bisa Anda praktikkan di rumah. Selamat mencoba!
