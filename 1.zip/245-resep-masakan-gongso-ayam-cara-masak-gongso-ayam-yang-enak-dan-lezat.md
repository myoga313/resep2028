---
description: "Resep masakan Gongso ayam | Cara Masak Gongso ayam Yang Enak Dan Lezat"
title: "Resep masakan Gongso ayam | Cara Masak Gongso ayam Yang Enak Dan Lezat"
slug: 245-resep-masakan-gongso-ayam-cara-masak-gongso-ayam-yang-enak-dan-lezat
date: 2020-10-24T17:44:15.424Z
image: https://img-global.cpcdn.com/recipes/0928f4bdbfe5f6a0/751x532cq70/gongso-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0928f4bdbfe5f6a0/751x532cq70/gongso-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0928f4bdbfe5f6a0/751x532cq70/gongso-ayam-foto-resep-utama.jpg
author: Craig Wells
ratingvalue: 4.4
reviewcount: 3
recipeingredient:
- " ayam"
- " jeruk nipis"
- " bumbu iris "
- " bawang putih geprek"
- " bombay iris kasar"
- " cabe merah teropong iris kasar memanjang"
- " cabe ijo teropong iris kasar memanjang"
- " jahe geprek"
- " bumbu tambahan "
- " kecap manis"
- " saos tiram"
- " saos sambal"
- " tomat bagi 5"
- " garam penyedap"
recipeinstructions:
- "Cuci bersih ayam, lalu lumuri air nipis, diamkan sekitar 5 mnt, cuci lagi"
- "Rebus ayam dengan 1 ruas jahe agar tidak amis, setelah matang matikan api"
- "Tumis bumbu iris smp agak layu lalu masukkan ayam..kemudian tambahkan kecap manis, saos tiram dan saos sambal"
- "Aduk&#34; agar tidak gosong..."
- "Sesaat sebelum diangkat masukkan potongan tomat.. aduk smp agak layu, kemudian angkat,"
- "Note : masak dengan api besar ya...dan akan lebih sedap jika ada daun bawang yg diiris kasar...dimasukkan bersamaan dengan tomat.."
categories:
- Resep
tags:
- gongso
- ayam

katakunci: gongso ayam 
nutrition: 247 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Lunch

---


![Gongso ayam](https://img-global.cpcdn.com/recipes/0928f4bdbfe5f6a0/751x532cq70/gongso-ayam-foto-resep-utama.jpg)

Sedang mencari inspirasi resep gongso ayam yang Enak Dan Lezat? Cara Memasaknya memang susah-susah gampang. seumpama keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso ayam yang enak selayaknya memiliki aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gongso ayam, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tidak usah pusing jika mau menyiapkan gongso ayam yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan spesial.


Di bawah ini ada beberapa tips dan trik praktis dalam mengolah gongso ayam yang siap dikreasikan. Anda dapat menyiapkan Gongso ayam menggunakan 14 jenis bahan dan 6 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Gongso ayam:

1. Ambil  ayam
1. Ambil  jeruk nipis
1. Siapkan  bumbu iris&#34; :
1. Ambil  bawang putih geprek
1. Ambil  bombay iris kasar
1. Siapkan  cabe merah teropong iris kasar memanjang
1. Ambil  cabe ijo teropong iris kasar memanjang
1. Siapkan  jahe geprek
1. Siapkan  bumbu tambahan :
1. Ambil  kecap manis
1. Ambil  saos tiram
1. Gunakan  saos sambal
1. Sediakan  tomat bagi 5
1. Siapkan  garam, penyedap




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso ayam:

1. Cuci bersih ayam, lalu lumuri air nipis, diamkan sekitar 5 mnt, cuci lagi
1. Rebus ayam dengan 1 ruas jahe agar tidak amis, setelah matang matikan api
1. Tumis bumbu iris smp agak layu lalu masukkan ayam..kemudian tambahkan kecap manis, saos tiram dan saos sambal
1. Aduk&#34; agar tidak gosong...
1. Sesaat sebelum diangkat masukkan potongan tomat.. aduk smp agak layu, kemudian angkat,
1. Note : masak dengan api besar ya...dan akan lebih sedap jika ada daun bawang yg diiris kasar...dimasukkan bersamaan dengan tomat..




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Besar harapan kami, olahan Gongso ayam yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi inspirasi dalam berbisnis kuliner. Selamat mencoba!
