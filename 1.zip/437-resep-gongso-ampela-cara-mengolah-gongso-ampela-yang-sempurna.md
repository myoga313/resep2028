---
description: "Resep Gongso Ampela | Cara Mengolah Gongso Ampela Yang Sempurna"
title: "Resep Gongso Ampela | Cara Mengolah Gongso Ampela Yang Sempurna"
slug: 437-resep-gongso-ampela-cara-mengolah-gongso-ampela-yang-sempurna
date: 2020-09-22T15:20:44.610Z
image: https://img-global.cpcdn.com/recipes/c17d1b0231749e06/751x532cq70/gongso-ampela-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c17d1b0231749e06/751x532cq70/gongso-ampela-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c17d1b0231749e06/751x532cq70/gongso-ampela-foto-resep-utama.jpg
author: Mae Aguilar
ratingvalue: 3
reviewcount: 7
recipeingredient:
- "500 gram ampela"
- " Bumbu Rebusan"
- "2 lembar Daun salam"
- "1 batang Sereh"
- "3 lembar daun jeruk"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1 sdt ketumbar bubuk"
- "750 ml air"
- " Bumbu dihaluskan"
- "1 buah cabe"
- "7 siung bawang merah"
- "7 siung bawang putih"
- "1 ruas kunyit"
- " Bumbu lainya"
- "4 siung bawang merah diiris"
- "7 buah cabe jablay"
- "3 lembar daun jeruk"
- "1 batang sereh"
- "1 lembar daun salam"
- "2 sdm kecap manis"
- "sesuai selera Garam"
- "200 ml air"
- " Minyak untuk menggoreng"
recipeinstructions:
- "Didihkan air, kemudian masukan daun salam, daun jeruk, sereh, jahe, lengkuas dan ketumbar bubuk aduk. Kemudian masukkan ampela. Rebus sampai matang, kemudian angkat dan potong potong"
- "Goreng bawang merah iris sampai wangi, masukkan potongan ampela. Goreng hingga setengah kering, angkat"
- "Tumis bumbu halus sampai wangi, tambahkan air masak sampai air mendidih masukkan ampela, tambahkan kecap, garam, penyedap rasa koreksi rasa, matikan kompor dan angkat"
- "Siap disantap dengan nasi hangat 😘"
categories:
- Resep
tags:
- gongso
- ampela

katakunci: gongso ampela 
nutrition: 140 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Dinner

---


![Gongso Ampela](https://img-global.cpcdn.com/recipes/c17d1b0231749e06/751x532cq70/gongso-ampela-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep gongso ampela yang Bisa Manjain Lidah? Cara membuatnya memang susah-susah gampang. andaikan salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal gongso ampela yang enak seharusnya mempunyai aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ampela, mulai dari jenis bahan, lalu pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tak perlu pusing jika ingin menyiapkan gongso ampela enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan istimewa.


Berikut ini ada beberapa tips dan trik praktis dalam mengolah gongso ampela yang siap dikreasikan. Anda dapat menyiapkan Gongso Ampela memakai 24 bahan dan 4 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Gongso Ampela:

1. Sediakan 500 gram ampela
1. Ambil  Bumbu Rebusan
1. Sediakan 2 lembar Daun salam
1. Ambil 1 batang Sereh
1. Ambil 3 lembar daun jeruk
1. Sediakan 1 ruas jahe
1. Siapkan 1 ruas lengkuas
1. Gunakan 1 sdt ketumbar bubuk
1. Ambil 750 ml air
1. Gunakan  Bumbu dihaluskan
1. Sediakan 1 buah cabe
1. Sediakan 7 siung bawang merah
1. Gunakan 7 siung bawang putih
1. Siapkan 1 ruas kunyit
1. Siapkan  Bumbu lainya
1. Sediakan 4 siung bawang merah, diiris
1. Siapkan 7 buah cabe jablay
1. Siapkan 3 lembar daun jeruk
1. Gunakan 1 batang sereh
1. Ambil 1 lembar daun salam
1. Sediakan 2 sdm kecap manis
1. Ambil sesuai selera Garam
1. Siapkan 200 ml air
1. Gunakan  Minyak untuk menggoreng




<!--inarticleads2-->

##### Cara menyiapkan Gongso Ampela:

1. Didihkan air, kemudian masukan daun salam, daun jeruk, sereh, jahe, lengkuas dan ketumbar bubuk aduk. Kemudian masukkan ampela. Rebus sampai matang, kemudian angkat dan potong potong
1. Goreng bawang merah iris sampai wangi, masukkan potongan ampela. Goreng hingga setengah kering, angkat
1. Tumis bumbu halus sampai wangi, tambahkan air masak sampai air mendidih masukkan ampela, tambahkan kecap, garam, penyedap rasa koreksi rasa, matikan kompor dan angkat
1. Siap disantap dengan nasi hangat 😘




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Gongso Ampela yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman ataupun menjadi inspirasi dalam berjualan makanan. Selamat mencoba!
