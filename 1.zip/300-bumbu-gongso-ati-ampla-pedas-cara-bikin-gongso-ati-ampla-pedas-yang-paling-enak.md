---
description: "Bumbu Gongso ati ampla pedas | Cara Bikin Gongso ati ampla pedas Yang Paling Enak"
title: "Bumbu Gongso ati ampla pedas | Cara Bikin Gongso ati ampla pedas Yang Paling Enak"
slug: 300-bumbu-gongso-ati-ampla-pedas-cara-bikin-gongso-ati-ampla-pedas-yang-paling-enak
date: 2020-08-16T06:06:15.924Z
image: https://img-global.cpcdn.com/recipes/e90dbb9a393478e9/751x532cq70/gongso-ati-ampla-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e90dbb9a393478e9/751x532cq70/gongso-ati-ampla-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e90dbb9a393478e9/751x532cq70/gongso-ati-ampla-pedas-foto-resep-utama.jpg
author: Bryan Watson
ratingvalue: 4.5
reviewcount: 6
recipeingredient:
- " ati ampla"
- " Bumbu halus"
- " cabe rawit merahtergantung selera ya Bun"
- " cabe merah keriting"
- " cabe merah besar buang biji"
- " bawang merah"
- " bawang putih"
- " kunyit"
- " Bumbu cemplung"
- " daun jeruk buang batang tengahnya"
- " lengkoas geprek"
- " daun salam"
- " lada bubuk"
- " kecap manis"
- " nya garam"
- " kaldu bubuk"
- " gula pasir"
- " Setngh gelas belimbing air"
- " minyak untuk menumis"
recipeinstructions:
- "Bersihkan ati ampla lalu cuci dan rebus,beri sedikit garam,jeruk nipis dan sedikit kecap Inggris,rebus sampai matang dan sisihkan"
- "Panaskan minyak tumis bumbu halus sampai harum tambahkan bumbu cemplung aduk rata"
- "Masukkan ati ampla yg sudah direbus td,beri sedikit air,garam,gula pasir, penyedap rasa,lada dan kecap aduk rata"
- "Masak sampai matang dan sedikit kental lalu koreksi rasa,jika sudah pas dan matang segera angkat dan sajikan"
categories:
- Resep
tags:
- gongso
- ati
- ampla

katakunci: gongso ati ampla 
nutrition: 181 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Dessert

---


![Gongso ati ampla pedas](https://img-global.cpcdn.com/recipes/e90dbb9a393478e9/751x532cq70/gongso-ati-ampla-pedas-foto-resep-utama.jpg)

Anda sedang mencari ide resep gongso ati ampla pedas yang Bikin Ngiler? Cara membuatnya memang susah-susah gampang. Jika salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal gongso ati ampla pedas yang enak harusnya sih mempunyai aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso ati ampla pedas, pertama dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan gongso ati ampla pedas enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.




Nah, kali ini kita coba, yuk, variasikan gongso ati ampla pedas sendiri di rumah. Tetap berbahan sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Gongso ati ampla pedas memakai 19 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Gongso ati ampla pedas:

1. Siapkan  ati ampla
1. Gunakan  Bumbu halus
1. Gunakan  cabe rawit merah(tergantung selera ya Bun)
1. Gunakan  cabe merah keriting
1. Sediakan  cabe merah besar buang biji
1. Siapkan  bawang merah
1. Sediakan  bawang putih
1. Siapkan  kunyit
1. Gunakan  Bumbu cemplung
1. Ambil  daun jeruk buang batang tengahnya
1. Ambil  lengkoas geprek
1. Ambil  daun salam
1. Ambil  lada bubuk
1. Ambil  kecap manis
1. Ambil  nya garam
1. Gunakan  kaldu bubuk
1. Sediakan  gula pasir
1. Ambil  Setngh gelas belimbing air
1. Sediakan  minyak untuk menumis




<!--inarticleads2-->

##### Cara membuat Gongso ati ampla pedas:

1. Bersihkan ati ampla lalu cuci dan rebus,beri sedikit garam,jeruk nipis dan sedikit kecap Inggris,rebus sampai matang dan sisihkan
1. Panaskan minyak tumis bumbu halus sampai harum tambahkan bumbu cemplung aduk rata
1. Masukkan ati ampla yg sudah direbus td,beri sedikit air,garam,gula pasir, penyedap rasa,lada dan kecap aduk rata
1. Masak sampai matang dan sedikit kental lalu koreksi rasa,jika sudah pas dan matang segera angkat dan sajikan




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Harapan kami, olahan Gongso ati ampla pedas yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman ataupun menjadi ide bagi Anda yang berkeinginan untuk berbisnis kuliner. Selamat mencoba!
