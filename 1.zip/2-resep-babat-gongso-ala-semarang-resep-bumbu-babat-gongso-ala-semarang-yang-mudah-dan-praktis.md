---
description: "Resep Babat Gongso ala Semarang | Resep Bumbu Babat Gongso ala Semarang Yang Mudah Dan Praktis"
title: "Resep Babat Gongso ala Semarang | Resep Bumbu Babat Gongso ala Semarang Yang Mudah Dan Praktis"
slug: 2-resep-babat-gongso-ala-semarang-resep-bumbu-babat-gongso-ala-semarang-yang-mudah-dan-praktis
date: 2020-09-06T04:04:04.853Z
image: https://img-global.cpcdn.com/recipes/db726aa66c19f125/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/db726aa66c19f125/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/db726aa66c19f125/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg
author: Ina Barrett
ratingvalue: 4.2
reviewcount: 9
recipeingredient:
- "150 gr Babat bole anduksumpingusus bersihkan"
- "2 lembar Daun Salam"
- "1/2 sdt Garam"
- " Bumbu Halus "
- "5 buah Cabe Merah Keriting"
- "4 buah Cabe Rawit"
- "4 buah Bawang Merah"
- "1 siung Bawang Putih"
- "1 butir Kemiri sangrai"
- " Bumbu Tumis "
- "3 buah Bawang Merahiris serong rada tebal untuk tekstur"
- "Sesuai selera Garam Kaldu BubukGula Pasir"
- "1 sdm Kecap Manis"
recipeinstructions:
- "Bersihkan babat, beri air secukupnya, potongan jeruk nipis,daun salam dan garan. Presto kurang lebih 20 menit. Note : kata ci Tintin pilih babat yang FRESH,kenyal, baunya normal,pasti nanti seger hasilnya."
- "Tiriskan, potong2 sesuai selera kecil/gede potongnya."
- "Tumis minyak bersama bawang merah yang sudah dipotong kasar,minyak banyakin ya soale nanti masak bumbu halus. Tumis sampai harum jangan lama2."
- "Masukan gula,kecap,garam, kaldu bubuk sesuai selera. Masukan babat,aduk rata terus. Tambahkan air kurang lebih 100 ml/sesuai selera,supaya bumbu ga mengerak didasar wajan."
- "Setelah kelihatan tercampur dan sedap,matikan api (jangan tumis terlalu lama soale babat udah empuk,bumbu gampang meresap). Angkat dan sajikan dengan nasi hangat ditaburi bawang goreng."
categories:
- Resep
tags:
- babat
- gongso
- ala

katakunci: babat gongso ala 
nutrition: 133 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dessert

---


![Babat Gongso ala Semarang](https://img-global.cpcdn.com/recipes/db726aa66c19f125/751x532cq70/babat-gongso-ala-semarang-foto-resep-utama.jpg)

Bunda Sedang mencari ide resep babat gongso ala semarang yang Bikin Ngiler? Cara Memasaknya memang susah-susah gampang. andaikan keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal babat gongso ala semarang yang enak seharusnya punya aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari babat gongso ala semarang, pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tidak usah pusing jika ingin menyiapkan babat gongso ala semarang yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian spesial.


Nah, kali ini kita coba, yuk, ciptakan babat gongso ala semarang sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Babat Gongso ala Semarang memakai 13 jenis bahan dan 5 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Babat Gongso ala Semarang:

1. Siapkan 150 gr Babat (bole anduk,sumping,usus) bersihkan
1. Sediakan 2 lembar Daun Salam
1. Sediakan 1/2 sdt Garam
1. Ambil  Bumbu Halus :
1. Gunakan 5 buah Cabe Merah Keriting
1. Gunakan 4 buah Cabe Rawit
1. Gunakan 4 buah Bawang Merah
1. Gunakan 1 siung Bawang Putih
1. Ambil 1 butir Kemiri, sangrai
1. Gunakan  Bumbu Tumis :
1. Siapkan 3 buah Bawang Merah,iris serong rada tebal (untuk tekstur)
1. Ambil Sesuai selera Garam, Kaldu Bubuk,Gula Pasir
1. Ambil 1 sdm Kecap Manis




<!--inarticleads2-->

##### Cara membuat Babat Gongso ala Semarang:

1. Bersihkan babat, beri air secukupnya, potongan jeruk nipis,daun salam dan garan. Presto kurang lebih 20 menit. Note : kata ci Tintin pilih babat yang FRESH,kenyal, baunya normal,pasti nanti seger hasilnya.
1. Tiriskan, potong2 sesuai selera kecil/gede potongnya.
1. Tumis minyak bersama bawang merah yang sudah dipotong kasar,minyak banyakin ya soale nanti masak bumbu halus. Tumis sampai harum jangan lama2.
1. Masukan gula,kecap,garam, kaldu bubuk sesuai selera. Masukan babat,aduk rata terus. Tambahkan air kurang lebih 100 ml/sesuai selera,supaya bumbu ga mengerak didasar wajan.
1. Setelah kelihatan tercampur dan sedap,matikan api (jangan tumis terlalu lama soale babat udah empuk,bumbu gampang meresap). Angkat dan sajikan dengan nasi hangat ditaburi bawang goreng.




Bagaimana? Mudah bukan? Itulah cara menyiapkan babat gongso ala semarang yang bisa Anda lakukan di rumah. Selamat mencoba!
