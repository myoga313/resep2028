---
description: "Resep masakan Babat gongso | Bahan Membuat Babat gongso Yang Enak Banget"
title: "Resep masakan Babat gongso | Bahan Membuat Babat gongso Yang Enak Banget"
slug: 316-resep-masakan-babat-gongso-bahan-membuat-babat-gongso-yang-enak-banget
date: 2020-09-25T13:02:58.781Z
image: https://img-global.cpcdn.com/recipes/e2413d99b10af22d/751x532cq70/babat-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e2413d99b10af22d/751x532cq70/babat-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e2413d99b10af22d/751x532cq70/babat-gongso-foto-resep-utama.jpg
author: Martin Bush
ratingvalue: 4.8
reviewcount: 14
recipeingredient:
- "1/4 babat yg sdh di rebus"
- "secukupnya Kol"
- "1 buah tomat"
- "10 cabe rawit merahselera jika suka pedas bs tambahkan"
- "3 cabe merah keriting"
- "5 bawang merah"
- "4 bawang putih"
- "1/2 sdt lada bubuk"
- "1 sdt garam"
- "1 sdt gula merah"
- "1/2 penyedap me royko"
- "2 lembar daun salam"
- "1 sdt saus tiram"
- "4 sdm kecap manis"
- "1 gelas belimbing air"
- " Bahan rebus babat"
- "3 bawang merah"
- "2 bawang putih"
- "1 sdt ketumbar"
- "3 lembar daun jeruk"
- "2 lembar daun salam"
- "1 ruas lengkuas"
- "1 1/2 sdt garam"
recipeinstructions:
- "Cuci bersih babat. Uleg bahan-bahan yg untuk merebus babat (bawang merah,bawang putih,ketumbar,daun jeruk) lalu rebus babat dg bumbu yg sdh dihaluskan dan tambahkan daun salam,lengkuas (geprek),garam sampai matang."
- "Uleg bumbu (cabe rawit merah,cabe merah keriting,bawang merah,bawang putih) sampai halus lalu tumis/gongso bumbu yg sdh dihaluskan dan tambahkan garam,gula merah,lada bubuk,penyedap rasa,daun salam sampai harum lalu masukkan babat yg sdh direbut td,jgn lupa babat dipotong-potong terlebih dahulu lalu tambahkan saus tiram,kecap manis,1 gelas belimbing air aduk-aduk sampai rata."
- "Dan terakhir masukkan kol yg di iris kasar kecil-kecil. (Note ya bun,kalau gak suka sayur blh di skip namun kalau mau pake sayur masukkinnya terakir krn nunggu babat meresap dg bumbu cpt layu). Test rasa dan siap dihidangkan."
- "Supaya cantik diatasnya di beri toping kol yg sudah diiris dan potongan tomat.Selamat mencoba🙏"
categories:
- Resep
tags:
- babat
- gongso

katakunci: babat gongso 
nutrition: 169 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Dinner

---


![Babat gongso](https://img-global.cpcdn.com/recipes/e2413d99b10af22d/751x532cq70/babat-gongso-foto-resep-utama.jpg)

Sedang mencari ide resep babat gongso yang Enak Dan Lezat? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. seandainya keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal babat gongso yang enak seharusnya memiliki aroma dan rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari babat gongso, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tak perlu pusing kalau hendak menyiapkan babat gongso yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan spesial.




Nah, kali ini kita coba, yuk, variasikan babat gongso sendiri di rumah. Tetap dengan bahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Babat gongso menggunakan 23 bahan dan 4 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Babat gongso:

1. Siapkan 1/4 babat yg sdh di rebus
1. Ambil secukupnya Kol
1. Ambil 1 buah tomat
1. Sediakan 10 cabe rawit merah(selera jika suka pedas bs tambahkan)
1. Ambil 3 cabe merah keriting
1. Siapkan 5 bawang merah
1. Gunakan 4 bawang putih
1. Ambil 1/2 sdt lada bubuk
1. Siapkan 1 sdt garam
1. Sediakan 1 sdt gula merah
1. Siapkan 1/2 penyedap (me: royko)
1. Gunakan 2 lembar daun salam
1. Siapkan 1 sdt saus tiram
1. Ambil 4 sdm kecap manis
1. Ambil 1 gelas belimbing air
1. Gunakan  Bahan rebus babat
1. Sediakan 3 bawang merah
1. Sediakan 2 bawang putih
1. Ambil 1 sdt ketumbar
1. Siapkan 3 lembar daun jeruk
1. Ambil 2 lembar daun salam
1. Siapkan 1 ruas lengkuas
1. Sediakan 1 1/2 sdt garam




<!--inarticleads2-->

##### Langkah-langkah membuat Babat gongso:

1. Cuci bersih babat. Uleg bahan-bahan yg untuk merebus babat (bawang merah,bawang putih,ketumbar,daun jeruk) lalu rebus babat dg bumbu yg sdh dihaluskan dan tambahkan daun salam,lengkuas (geprek),garam sampai matang.
1. Uleg bumbu (cabe rawit merah,cabe merah keriting,bawang merah,bawang putih) sampai halus lalu tumis/gongso bumbu yg sdh dihaluskan dan tambahkan garam,gula merah,lada bubuk,penyedap rasa,daun salam sampai harum lalu masukkan babat yg sdh direbut td,jgn lupa babat dipotong-potong terlebih dahulu lalu tambahkan saus tiram,kecap manis,1 gelas belimbing air aduk-aduk sampai rata.
1. Dan terakhir masukkan kol yg di iris kasar kecil-kecil. (Note ya bun,kalau gak suka sayur blh di skip namun kalau mau pake sayur masukkinnya terakir krn nunggu babat meresap dg bumbu cpt layu). Test rasa dan siap dihidangkan.
1. Supaya cantik diatasnya di beri toping kol yg sudah diiris dan potongan tomat.Selamat mencoba🙏




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Harapan kami, olahan Babat gongso yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman maupun menjadi ide untuk berjualan makanan. Selamat mencoba!
