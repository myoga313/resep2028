---
description: "Resep masakan Gongso telur sosis pedas | Cara Mengolah Gongso telur sosis pedas Yang Enak Banget"
title: "Resep masakan Gongso telur sosis pedas | Cara Mengolah Gongso telur sosis pedas Yang Enak Banget"
slug: 152-resep-masakan-gongso-telur-sosis-pedas-cara-mengolah-gongso-telur-sosis-pedas-yang-enak-banget
date: 2020-08-01T07:01:08.251Z
image: https://img-global.cpcdn.com/recipes/36758f5d3309d942/751x532cq70/gongso-telur-sosis-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/36758f5d3309d942/751x532cq70/gongso-telur-sosis-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/36758f5d3309d942/751x532cq70/gongso-telur-sosis-pedas-foto-resep-utama.jpg
author: Francis Holland
ratingvalue: 4.2
reviewcount: 4
recipeingredient:
- "3 butir telur"
- "3 buah sosis iris"
- "3 buah bawang merah iris"
- "1 buah bawang putih cincang"
- "1 buah tomat merah cacah"
- "1 buah cabe merah iris serong"
- "8 buah cabe rawit iris"
- "3 sdm saos sambal"
- "2 sdm saos tomat"
- "1 btng daun bawang iris"
- "secukupnya gula dan garam"
- "sejumput merica bubuk"
- "secukupnya minyak goreng"
- "3 sdm air"
- "secukupnya kaldu bubuk"
recipeinstructions:
- "Kocok lepas telur beri sejumput merica dan garam aduk rata."
- "Panaskan pan masukkan minyak goreng lalu goreng sosis sebentar bolak balik lalu angkat, sisihkan."
- "Buat telur orak-arik angkat sisihkan."
- "Tumis bawang sampai harum masukkan cabe dan tomat aduk hingga layu lalu masukkan saos” an, daun bawang aduk rata beri air tunggu sampai meletup-letup tambahkan gula dan garam serta kaldu bubuk aduk, cek rasa."
- "Masukkan telur orak-arik, sosis aduk sebentar biar bumbu meresap dan merata, angkat dan sajikan."
categories:
- Resep
tags:
- gongso
- telur
- sosis

katakunci: gongso telur sosis 
nutrition: 168 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Dinner

---


![Gongso telur sosis pedas](https://img-global.cpcdn.com/recipes/36758f5d3309d942/751x532cq70/gongso-telur-sosis-pedas-foto-resep-utama.jpg)

Kamu Lagi mencari inspirasi resep gongso telur sosis pedas yang Lezat Sekali? Cara Buatnya memang tidak susah dan tidak juga mudah. andaikan salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gongso telur sosis pedas yang enak harusnya sih punya aroma dan cita rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gongso telur sosis pedas, pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tidak usah pusing kalau mau menyiapkan gongso telur sosis pedas yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian istimewa.


Nah, kali ini kita coba, yuk, buat gongso telur sosis pedas sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Gongso telur sosis pedas memakai 15 bahan dan 5 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Gongso telur sosis pedas:

1. Ambil 3 butir telur
1. Ambil 3 buah sosis iris
1. Gunakan 3 buah bawang merah iris
1. Ambil 1 buah bawang putih cincang
1. Ambil 1 buah tomat merah cacah
1. Siapkan 1 buah cabe merah iris serong
1. Sediakan 8 buah cabe rawit iris
1. Sediakan 3 sdm saos sambal
1. Gunakan 2 sdm saos tomat
1. Siapkan 1 btng daun bawang iris”
1. Siapkan secukupnya gula dan garam
1. Ambil sejumput merica bubuk
1. Sediakan secukupnya minyak goreng
1. Ambil 3 sdm air
1. Ambil secukupnya kaldu bubuk




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gongso telur sosis pedas:

1. Kocok lepas telur beri sejumput merica dan garam aduk rata.
1. Panaskan pan masukkan minyak goreng lalu goreng sosis sebentar bolak balik lalu angkat, sisihkan.
1. Buat telur orak-arik angkat sisihkan.
1. Tumis bawang sampai harum masukkan cabe dan tomat aduk hingga layu lalu masukkan saos” an, daun bawang aduk rata beri air tunggu sampai meletup-letup tambahkan gula dan garam serta kaldu bubuk aduk, cek rasa.
1. Masukkan telur orak-arik, sosis aduk sebentar biar bumbu meresap dan merata, angkat dan sajikan.




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Gongso telur sosis pedas yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman maupun menjadi ide untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
