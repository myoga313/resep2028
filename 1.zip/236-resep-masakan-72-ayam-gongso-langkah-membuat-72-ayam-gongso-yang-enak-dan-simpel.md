---
description: "Resep masakan 72. Ayam gongso | Langkah Membuat 72. Ayam gongso Yang Enak dan Simpel"
title: "Resep masakan 72. Ayam gongso | Langkah Membuat 72. Ayam gongso Yang Enak dan Simpel"
slug: 236-resep-masakan-72-ayam-gongso-langkah-membuat-72-ayam-gongso-yang-enak-dan-simpel
date: 2020-08-16T19:27:48.050Z
image: https://img-global.cpcdn.com/recipes/7090e57e2f90194c/751x532cq70/72-ayam-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7090e57e2f90194c/751x532cq70/72-ayam-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7090e57e2f90194c/751x532cq70/72-ayam-gongso-foto-resep-utama.jpg
author: Owen Soto
ratingvalue: 4.2
reviewcount: 4
recipeingredient:
- "1/2 ekor ayam potong kecil2 rebus"
- "2 helai daun salam"
- "1/2 sdt garam"
- " Bumbu halus"
- "15 cabe merah keriting"
- "7 cabe rawit merah"
- "10 btr bawang merah"
- "4 btr bawang putih"
- "4 btr kemiri sangrai"
- " iris Bumbu"
- "5 btr bawang merah"
- "sesuai selera Garam kaldu bubuk gula pasir dan kecap"
recipeinstructions:
- "Rebus potongan ayam dng daun salam dan garam"
- "Tumis potongan bawang merah, lalu masukkan bumbu yg sdh halus tumis sampe harum"
- "Tambahkan air 100 ml, bumbui dng gula, garam, kaldu bubuk dan kecap tes rasa masukkan daging ayam yg sdh direbus biarkan sampai bumbu meresap dan air menyusut, angkat dan sajikan"
categories:
- Resep
tags:
- 72
- ayam
- gongso

katakunci: 72 ayam gongso 
nutrition: 276 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Dessert

---


![72. Ayam gongso](https://img-global.cpcdn.com/recipes/7090e57e2f90194c/751x532cq70/72-ayam-gongso-foto-resep-utama.jpg)

Lagi mencari ide resep 72. ayam gongso yang Bikin Ngiler? Cara membuatnya memang susah-susah gampang. andaikata keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal 72. ayam gongso yang enak seharusnya memiliki aroma dan cita rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari 72. ayam gongso, pertama dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tidak usah pusing kalau ingin menyiapkan 72. ayam gongso enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian istimewa.


Di bawah ini ada beberapa tips dan trik praktis untuk membuat 72. ayam gongso yang siap dikreasikan. Anda dapat menyiapkan 72. Ayam gongso memakai 12 bahan dan 3 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan 72. Ayam gongso:

1. Sediakan 1/2 ekor ayam potong kecil2 rebus
1. Sediakan 2 helai daun salam
1. Siapkan 1/2 sdt garam
1. Ambil  Bumbu halus
1. Gunakan 15 cabe merah keriting
1. Ambil 7 cabe rawit merah
1. Gunakan 10 btr bawang merah
1. Sediakan 4 btr bawang putih
1. Siapkan 4 btr kemiri sangrai
1. Ambil  iris Bumbu
1. Siapkan 5 btr bawang merah
1. Siapkan sesuai selera Garam, kaldu bubuk, gula pasir dan kecap




<!--inarticleads2-->

##### Cara menyiapkan 72. Ayam gongso:

1. Rebus potongan ayam dng daun salam dan garam
1. Tumis potongan bawang merah, lalu masukkan bumbu yg sdh halus tumis sampe harum
1. Tambahkan air 100 ml, bumbui dng gula, garam, kaldu bubuk dan kecap tes rasa masukkan daging ayam yg sdh direbus biarkan sampai bumbu meresap dan air menyusut, angkat dan sajikan




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan 72. Ayam gongso yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman maupun menjadi ide dalam berjualan makanan. Selamat mencoba!
